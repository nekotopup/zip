package com.spotifry.music.ui.spotifried;

import com.spotifry.music.data.db.ListenRow;
import com.spotifry.music.data.db.SongYearEntity;
import com.spotifry.music.data.spotifried.AgeStats;
import com.spotifry.music.data.spotifried.SpotifriedStats;
import com.spotifry.music.data.spotifried.WrappedPeriod;
import java.time.Instant;
import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.IntIterator;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.functions.Function5;
import kotlin.jvm.internal.AdaptedFunctionReference;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.text.RegexKt;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class SpotifriedViewModel$state$1 extends AdaptedFunctionReference implements Function5 {
    public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4, Object obj5) {
        Long lValueOf;
        LocalDate localDate;
        SpotifriedStats spotifriedStatsBuild$statsOf;
        SpotifriedStats spotifriedStatsBuild$statsOf2;
        List list = (List) obj;
        List<SongYearEntity> list2 = (List) obj2;
        WrappedPeriod wrappedPeriod = (WrappedPeriod) obj3;
        String str = (String) obj4;
        SpotifriedViewModel spotifriedViewModel = (SpotifriedViewModel) ((AdaptedFunctionReference) this).receiver;
        LocalDate localDate2 = (LocalDate) spotifriedViewModel.today.invoke();
        Iterator it = list.iterator();
        if (it.hasNext()) {
            lValueOf = Long.valueOf(((ListenRow) it.next()).startedAt);
            while (it.hasNext()) {
                Long lValueOf2 = Long.valueOf(((ListenRow) it.next()).startedAt);
                if (lValueOf.compareTo(lValueOf2) > 0) {
                    lValueOf = lValueOf2;
                }
            }
        } else {
            lValueOf = null;
        }
        if (lValueOf == null || (localDate = Instant.ofEpochMilli(lValueOf.longValue()).atZone(spotifriedViewModel.zone).toLocalDate()) == null) {
            localDate = localDate2;
        }
        localDate.getClass();
        localDate2.getClass();
        IntProgression intProgression = new IntProgression(localDate2.getYear(), localDate.getYear(), -1);
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(intProgression, 10));
        IntIterator it2 = intProgression.iterator();
        while (((IntProgressionIterator) it2).hasNext) {
            arrayList.add(RegexKt.calendarYear(it2.nextInt(), localDate2));
        }
        LocalDate localDatePlusDays = localDate2.minusYears(1L).plusDays(1L);
        localDatePlusDays.getClass();
        ArrayList arrayListPlus = CollectionsKt.plus(CollectionsKt.plus(arrayList, new WrappedPeriod(localDatePlusDays, localDate2, "Last 12 months")), new WrappedPeriod(localDate, localDate2, "All time"));
        ArrayList arrayList2 = new ArrayList();
        for (SongYearEntity songYearEntity : list2) {
            Integer num = songYearEntity.year;
            Pair pair = num != null ? new Pair(songYearEntity.songId, Integer.valueOf(num.intValue())) : null;
            if (pair != null) {
                arrayList2.add(pair);
            }
        }
        Map map = MapsKt__MapsKt.toMap(arrayList2);
        ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list2, 10));
        Iterator it3 = list2.iterator();
        while (it3.hasNext()) {
            arrayList3.add(((SongYearEntity) it3.next()).songId);
        }
        Set set = CollectionsKt.toSet(arrayList3);
        if (wrappedPeriod != null) {
            spotifriedStatsBuild$statsOf2 = SpotifriedViewModel.build$statsOf(list, map, spotifriedViewModel, set, wrappedPeriod);
        } else {
            Iterator it4 = arrayListPlus.iterator();
            do {
                if (!it4.hasNext()) {
                    spotifriedStatsBuild$statsOf = null;
                    break;
                }
                WrappedPeriod wrappedPeriod2 = (WrappedPeriod) it4.next();
                wrappedPeriod2.getClass();
                spotifriedStatsBuild$statsOf = SpotifriedViewModel.build$statsOf(list, map, spotifriedViewModel, set, wrappedPeriod2);
            } while (ByteStreamsKt.shownCards(spotifriedStatsBuild$statsOf).isEmpty());
            spotifriedStatsBuild$statsOf2 = spotifriedStatsBuild$statsOf == null ? SpotifriedViewModel.build$statsOf(list, map, spotifriedViewModel, set, RegexKt.calendarYear(localDate2.getYear(), localDate2)) : spotifriedStatsBuild$statsOf;
        }
        List listShownCards = ByteStreamsKt.shownCards(spotifriedStatsBuild$statsOf2);
        AgeStats ageStats = spotifriedStatsBuild$statsOf2.age;
        int i = ageStats.songsTotal;
        int i2 = ageStats.unchecked;
        return new SpotifriedState(spotifriedStatsBuild$statsOf2, listShownCards, arrayListPlus, i - i2, i2, spotifriedStatsBuild$statsOf2.period.to.compareTo((ChronoLocalDate) localDate2) >= 0 ? Integer.valueOf(Math.max(1, 10 - spotifriedStatsBuild$statsOf2.plays)) : null, str);
    }
}
