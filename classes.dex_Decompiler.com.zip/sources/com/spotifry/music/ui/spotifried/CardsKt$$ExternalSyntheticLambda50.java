package com.spotifry.music.ui.spotifried;

import androidx.compose.ui.layout.Measurable;
import androidx.compose.ui.layout.MeasureScope;
import androidx.compose.ui.layout.Placeable;
import androidx.compose.ui.unit.Constraints;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.EmptyMap;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function3;
import kotlin.math.MathKt;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda50 implements Function3 {
    public final /* synthetic */ float f$0;
    public final /* synthetic */ float f$1;

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda50(float f, float f2) {
        this.f$0 = f;
        this.f$1 = f2;
    }

    public final Object invoke(Object obj, Object obj2, Object obj3) {
        MeasureScope measureScope = (MeasureScope) obj;
        Measurable measurable = (Measurable) obj2;
        final Constraints constraints = (Constraints) obj3;
        measureScope.getClass();
        measurable.getClass();
        final Placeable placeable = measurable.measure-BRTryo0(Constraints.copy-Zbe2FdA$default(constraints.value, 0, 0, 0, 0, 14));
        int i = Constraints.getMaxWidth-impl(constraints.value);
        int i2 = placeable.height;
        final float f = this.f$0;
        final float f2 = this.f$1;
        return measureScope.layout(i, i2, EmptyMap.INSTANCE, new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda72
            public final Object invoke(Object obj4) {
                Placeable.PlacementScope placementScope = (Placeable.PlacementScope) obj4;
                placementScope.getClass();
                int i3 = placementScope.roundToPx-0680j_4(f);
                Placeable placeable2 = placeable;
                placementScope.place(placeable2, ResultKt.coerceIn(i3 - MathKt.roundToInt(placeable2.width * f2), 0, Math.max(0, Constraints.getMaxWidth-impl(constraints.value) - placeable2.width)), 0, 0.0f);
                return Unit.INSTANCE;
            }
        });
    }
}
