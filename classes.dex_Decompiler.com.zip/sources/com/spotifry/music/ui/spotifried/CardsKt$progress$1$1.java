package com.spotifry.music.ui.spotifried;

import androidx.compose.animation.core.Animatable;
import androidx.compose.animation.core.TweenSpec;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import org.jsoup.parser.CharacterReader$;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final class CardsKt$progress$1$1 extends SuspendLambda implements Function2 {
    public final /* synthetic */ int $delayMs;
    public final /* synthetic */ int $durationMs;
    public final /* synthetic */ Animatable $p;
    public boolean label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CardsKt$progress$1$1(Animatable animatable, int i, int i2, Continuation continuation) {
        super(2, continuation);
        this.$p = animatable;
        this.$durationMs = i;
        this.$delayMs = i2;
    }

    public final Continuation create(Object obj, Continuation continuation) {
        return new CardsKt$progress$1$1(this.$p, this.$durationMs, this.$delayMs, continuation);
    }

    public final Object invoke(Object obj, Object obj2) {
        return create((CoroutineScope) obj, (Continuation) obj2).invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        boolean z = this.label;
        if (!z) {
            ResultKt.throwOnFailure(obj);
            Float f = new Float(1.0f);
            TweenSpec tweenSpec = new TweenSpec(this.$durationMs, this.$delayMs, CardsKt.Ease);
            this.label = true;
            Object objAnimateTo$default = Animatable.animateTo$default(this.$p, f, tweenSpec, (Function1) null, this, 12);
            CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
            if (objAnimateTo$default == coroutineSingletons) {
                return coroutineSingletons;
            }
        } else {
            if (!z) {
                CharacterReader$.ExternalSyntheticLambda2.m$2("call to 'resume' before 'invoke' with coroutine");
                return null;
            }
            ResultKt.throwOnFailure(obj);
        }
        return Unit.INSTANCE;
    }
}
