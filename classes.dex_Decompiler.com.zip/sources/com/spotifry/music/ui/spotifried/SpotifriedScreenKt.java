package com.spotifry.music.ui.spotifried;

import android.content.Context;
import androidx.compose.animation.Scale;
import androidx.compose.animation.core.AnimateAsStateKt;
import androidx.compose.animation.core.ArcSplineKt;
import androidx.compose.animation.core.Easing;
import androidx.compose.animation.core.SnapSpec;
import androidx.compose.foundation.AndroidEdgeEffectOverscrollEffect;
import androidx.compose.foundation.ImageKt;
import androidx.compose.foundation.gestures.DefaultFlingBehavior;
import androidx.compose.foundation.gestures.TapGestureDetectorKt;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnMeasurePolicy;
import androidx.compose.foundation.layout.LayoutWeightElement;
import androidx.compose.foundation.layout.OffsetKt;
import androidx.compose.foundation.layout.PaddingValuesImpl;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowMeasurePolicy;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.lazy.LazyListState;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import androidx.compose.material3.IconButtonColors;
import androidx.compose.material3.MenuKt;
import androidx.compose.material3.SliderKt;
import androidx.compose.material3.TextKt;
import androidx.compose.material3.Typography;
import androidx.compose.material3.TypographyKt;
import androidx.compose.runtime.AnchoredGroupPath;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerImpl;
import androidx.compose.runtime.ComposerKt$;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.NeverEqualPolicy;
import androidx.compose.runtime.ParcelableSnapshotMutableIntState;
import androidx.compose.runtime.RecomposeScopeImpl;
import androidx.compose.runtime.StaticProvidableCompositionLocal;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import androidx.compose.runtime.internal.Expect_jvmKt;
import androidx.compose.runtime.internal.PersistentCompositionLocalHashMap;
import androidx.compose.runtime.saveable.SaverKt;
import androidx.compose.ui.AbsoluteAlignment;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.BiasAlignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.input.pointer.PointerEvent;
import androidx.compose.ui.input.pointer.PointerInputEventHandler;
import androidx.compose.ui.input.pointer.PointerInputScope;
import androidx.compose.ui.input.pointer.SuspendPointerInputElement;
import androidx.compose.ui.input.pointer.SuspendingPointerInputFilterKt;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.node.LayoutNode;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.semantics.SemanticsModifierKt;
import androidx.compose.ui.text.SaversKt$;
import androidx.compose.ui.text.font.FontListFontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.style.TextAlign;
import androidx.media3.session.MediaSessionStub$;
import androidx.sqlite.db.framework.FrameworkSQLiteDatabase$;
import androidx.work.OperationKt$;
import com.spotifry.music.MainActivityKt$;
import com.spotifry.music.data.spotifried.CardId;
import com.spotifry.music.data.spotifried.SpotifriedStats;
import com.spotifry.music.player.PlayerController$;
import com.spotifry.music.ui.FadeBarKt$;
import com.spotifry.music.ui.SongMenuSheetKt$;
import com.spotifry.music.ui.home.ArtistPageKt$;
import com.spotifry.music.ui.listening.SunKt;
import com.spotifry.music.ui.listening.SunKt$;
import com.spotifry.music.ui.nowplaying.LyricsViewsKt$;
import com.spotifry.music.ui.theme.ThemeKt;
import dev.chrisbanes.haze.HazeStyleKt$;
import java.util.List;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.IntIterator;
import kotlin.coroutines.CombinedContext$;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function4;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntProgressionIterator;
import kotlin.text.CharsKt;
import kotlinx.coroutines.CoroutineScope;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public abstract class SpotifriedScreenKt {
    public static final ComposableLambdaImpl lambda$1523791782 = new ComposableLambdaImpl(1523791782, false, new CombinedContext$.ExternalSyntheticLambda0((byte) 4));

    public static final void NotEnough(Integer num, ComposerImpl composerImpl, int i) {
        boolean z;
        ComposerImpl composerImpl2 = composerImpl;
        composerImpl2.startRestartGroup(820947178);
        int i2 = i | (composerImpl2.changed(num) ? 4 : 2);
        if (composerImpl2.shouldExecute(i2 & 1, (i2 & 3) != 2)) {
            Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
            Modifier modifier = OffsetKt.padding-VpY3zN4$default(SizeKt.fillMaxSize(companion, 1.0f), 20.0f, 0.0f, 2);
            ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(OffsetKt.Center, Alignment.Companion.Start, composerImpl2, 6);
            int iHashCode = Long.hashCode(composerImpl2.compositeKeyHashCode);
            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl2.currentCompositionLocalScope();
            Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl2, modifier);
            ComposeUiNode.Companion.getClass();
            LayoutNode.Companion.Constructor.1 r9 = ComposeUiNode.Companion.Constructor;
            composerImpl2.startReusableNode();
            if (composerImpl2.inserting) {
                composerImpl2.createNode(r9);
            } else {
                composerImpl2.useNode();
            }
            AnchoredGroupPath.set-impl(composerImpl2, columnMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
            AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope, ComposeUiNode.Companion.SetResolvedCompositionLocals);
            ComposeUiNode.Companion.SetModifier.1 r3 = ComposeUiNode.Companion.SetCompositeKeyHash;
            if (composerImpl2.inserting || !Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode))) {
                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl2, iHashCode, r3);
            }
            AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier, ComposeUiNode.Companion.SetModifier);
            StaticProvidableCompositionLocal staticProvidableCompositionLocal = TypographyKt.LocalTypography;
            TextKt.Text-Nvy7gAk("Not enough listening yet", (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, ((Typography) composerImpl2.consume(staticProvidableCompositionLocal)).headlineMedium, composerImpl, 6, 0, 131070);
            composerImpl2 = composerImpl;
            if (num != null) {
                composerImpl2.startReplaceGroup(-2119563822);
                TextKt.Text-Nvy7gAk(num + " more " + (num.intValue() == 1 ? "play" : "plays") + " to go", OffsetKt.padding-qDBjuR0$default(companion, 0.0f, 8.0f, 0.0f, 0.0f, 13), ((ColorScheme) composerImpl2.consume(ColorSchemeKt.LocalColorScheme)).onSurfaceVariant, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, ((Typography) composerImpl2.consume(staticProvidableCompositionLocal)).bodyLarge, composerImpl, 48, 0, 131064);
                composerImpl2 = composerImpl;
                z = false;
            } else {
                z = false;
                composerImpl2.startReplaceGroup(-2128298258);
            }
            composerImpl2.end(z);
            composerImpl2.end(true);
        } else {
            composerImpl2.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new ComposerKt$.ExternalSyntheticLambda1(num, i, (byte) 29);
        }
    }

    /* JADX INFO: renamed from: SpotifriedScreen-942rkJo, reason: not valid java name */
    public static final void m0SpotifriedScreen942rkJo(final SpotifriedViewModel spotifriedViewModel, final Function0 function0, final float f, Function4 function4, ComposerImpl composerImpl, final int i) {
        final Function4 function5;
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup;
        Function2 function2;
        Function4 function6;
        Function4 function7;
        spotifriedViewModel.getClass();
        function0.getClass();
        composerImpl.startRestartGroup(648063473);
        int i2 = i | (composerImpl.changedInstance(spotifriedViewModel) ? 4 : 2) | (composerImpl.changedInstance(function0) ? 32 : 16) | (composerImpl.changed(f) ? 256 : 128) | 1024;
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 1171) != 1170)) {
            composerImpl.startDefaults();
            int i3 = i & 1;
            NeverEqualPolicy neverEqualPolicy = Composer.Companion.Empty;
            if (i3 == 0 || composerImpl.getDefaultsInvalid()) {
                Object objRememberedValue = composerImpl.rememberedValue();
                if (objRememberedValue == neverEqualPolicy) {
                    objRememberedValue = new SpotifriedScreenKt$SpotifriedScreen$1$1(4, null);
                    composerImpl.updateRememberedValue(objRememberedValue);
                }
                function6 = (Function4) objRememberedValue;
            } else {
                composerImpl.skipToGroupEnd();
                function6 = function4;
            }
            composerImpl.endDefaults();
            final SpotifriedState spotifriedState = (SpotifriedState) CharsKt.collectAsStateWithLifecycle(spotifriedViewModel.state, composerImpl, 0, 7).getValue();
            if (spotifriedState == null) {
                recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
                if (recomposeScopeImplEndRestartGroup == null) {
                    return;
                }
                final byte b = 0;
                final Function4 function8 = function6;
                function2 = new Function2(spotifriedViewModel, function0, f, function8, i, b) { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda0
                    public final /* synthetic */ byte $r8$classId;
                    public final /* synthetic */ SpotifriedViewModel f$0;
                    public final /* synthetic */ Function0 f$1;
                    public final /* synthetic */ float f$2;
                    public final /* synthetic */ Function4 f$3;

                    {
                        this.$r8$classId = b;
                    }

                    public final Object invoke(Object obj, Object obj2) {
                        byte b2 = this.$r8$classId;
                        Unit unit = Unit.INSTANCE;
                        switch (b2) {
                            case 0:
                                ((Integer) obj2).getClass();
                                int iUpdateChangedFlags = AnchoredGroupPath.updateChangedFlags(1);
                                SpotifriedScreenKt.m0SpotifriedScreen942rkJo(this.f$0, this.f$1, this.f$2, this.f$3, (ComposerImpl) obj, iUpdateChangedFlags);
                                break;
                            default:
                                ((Integer) obj2).getClass();
                                int iUpdateChangedFlags2 = AnchoredGroupPath.updateChangedFlags(1);
                                SpotifriedScreenKt.m0SpotifriedScreen942rkJo(this.f$0, this.f$1, this.f$2, this.f$3, (ComposerImpl) obj, iUpdateChangedFlags2);
                                break;
                        }
                        return unit;
                    }
                };
            } else {
                Function4 function9 = function6;
                Object[] objArr = {spotifriedState.stats.period};
                Object objRememberedValue2 = composerImpl.rememberedValue();
                if (objRememberedValue2 == neverEqualPolicy) {
                    objRememberedValue2 = new HazeStyleKt$.ExternalSyntheticLambda0((byte) 9);
                    composerImpl.updateRememberedValue(objRememberedValue2);
                }
                final ParcelableSnapshotMutableIntState parcelableSnapshotMutableIntState = (ParcelableSnapshotMutableIntState) SaverKt.rememberSaveable(objArr, (Function0) objRememberedValue2, composerImpl, 48);
                Context context = (Context) composerImpl.consume(AndroidCompositionLocals_androidKt.LocalContext);
                Object objRememberedValue3 = composerImpl.rememberedValue();
                if (objRememberedValue3 == neverEqualPolicy) {
                    objRememberedValue3 = AnchoredGroupPath.createCompositionCoroutineScope(composerImpl);
                    composerImpl.updateRememberedValue(objRememberedValue3);
                }
                CoroutineScope coroutineScope = (CoroutineScope) objRememberedValue3;
                Object objRememberedValue4 = composerImpl.rememberedValue();
                if (objRememberedValue4 == neverEqualPolicy) {
                    objRememberedValue4 = AnchoredGroupPath.mutableStateOf$default(Boolean.FALSE);
                    composerImpl.updateRememberedValue(objRememberedValue4);
                }
                final MutableState mutableState = (MutableState) objRememberedValue4;
                Object objRememberedValue5 = composerImpl.rememberedValue();
                if (objRememberedValue5 == neverEqualPolicy) {
                    objRememberedValue5 = AnchoredGroupPath.mutableStateOf$default(Boolean.FALSE);
                    composerImpl.updateRememberedValue(objRememberedValue5);
                }
                final MutableState mutableState2 = (MutableState) objRememberedValue5;
                boolean zChangedInstance = composerImpl.changedInstance(coroutineScope) | composerImpl.changedInstance(context) | composerImpl.changedInstance(spotifriedState) | composerImpl.changedInstance(function9);
                Object objRememberedValue6 = composerImpl.rememberedValue();
                if (zChangedInstance || objRememberedValue6 == neverEqualPolicy) {
                    function7 = function9;
                    MainActivityKt$.ExternalSyntheticLambda83 externalSyntheticLambda83 = new MainActivityKt$.ExternalSyntheticLambda83(coroutineScope, mutableState, mutableState2, context, spotifriedState, function7);
                    composerImpl.updateRememberedValue(externalSyntheticLambda83);
                    objRememberedValue6 = externalSyntheticLambda83;
                } else {
                    function7 = function9;
                }
                final Function0 function1 = (Function0) objRememberedValue6;
                StoryTheme(Expect_jvmKt.rememberComposableLambda(771733266, new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda3
                    public final Object invoke(Object obj, Object obj2) {
                        boolean z;
                        SpotifriedState spotifriedState2 = spotifriedState;
                        List list = spotifriedState2.cards;
                        ComposerImpl composerImpl2 = (ComposerImpl) obj;
                        int iIntValue = ((Integer) obj2).intValue();
                        if (composerImpl2.shouldExecute(iIntValue & 1, (iIntValue & 3) != 2)) {
                            Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
                            Modifier modifier = OffsetKt.padding-qDBjuR0$default(SizeKt.fillMaxSize(companion, 1.0f), 0.0f, 0.0f, 0.0f, f, 7);
                            ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(OffsetKt.Top, Alignment.Companion.Start, composerImpl2, 0);
                            int iHashCode = Long.hashCode(composerImpl2.compositeKeyHashCode);
                            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl2.currentCompositionLocalScope();
                            Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl2, modifier);
                            ComposeUiNode.Companion.getClass();
                            LayoutNode.Companion.Constructor.1 r10 = ComposeUiNode.Companion.Constructor;
                            composerImpl2.startReusableNode();
                            if (composerImpl2.inserting) {
                                composerImpl2.createNode(r10);
                            } else {
                                composerImpl2.useNode();
                            }
                            AnchoredGroupPath.set-impl(composerImpl2, columnMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
                            AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope, ComposeUiNode.Companion.SetResolvedCompositionLocals);
                            ComposeUiNode.Companion.SetModifier.1 r3 = ComposeUiNode.Companion.SetCompositeKeyHash;
                            if (composerImpl2.inserting || !Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode))) {
                                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl2, iHashCode, r3);
                            }
                            AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier, ComposeUiNode.Companion.SetModifier);
                            MenuKt.IconButton(function0, OffsetKt.padding-qDBjuR0$default(companion, 8.0f, 4.0f, 0.0f, 0.0f, 12), false, (IconButtonColors) null, (Shape) null, SpotifriedScreenKt.lambda$1523791782, composerImpl2, 1572912, 60);
                            PaddingValuesImpl paddingValuesImpl = OffsetKt.PaddingValues-YgX7TsA$default(20.0f, 2);
                            Arrangement.SpacedAligned spacedAligned = new Arrangement.SpacedAligned(8.0f, new SaversKt$.ExternalSyntheticLambda0((byte) 3));
                            boolean zChangedInstance2 = composerImpl2.changedInstance(spotifriedState2);
                            SpotifriedViewModel spotifriedViewModel2 = spotifriedViewModel;
                            boolean zChangedInstance3 = zChangedInstance2 | composerImpl2.changedInstance(spotifriedViewModel2);
                            Object objRememberedValue7 = composerImpl2.rememberedValue();
                            NeverEqualPolicy neverEqualPolicy2 = Composer.Companion.Empty;
                            if (zChangedInstance3 || objRememberedValue7 == neverEqualPolicy2) {
                                objRememberedValue7 = new SongMenuSheetKt$.ExternalSyntheticLambda29(spotifriedState2, spotifriedViewModel2, (byte) 29);
                                composerImpl2.updateRememberedValue(objRememberedValue7);
                            }
                            CharsKt.LazyRow((Modifier) null, (LazyListState) null, paddingValuesImpl, spacedAligned, (BiasAlignment.Vertical) null, (DefaultFlingBehavior) null, false, (AndroidEdgeEffectOverscrollEffect) null, (Function1) objRememberedValue7, composerImpl2, 24960, 491);
                            if (list.isEmpty()) {
                                composerImpl2.startReplaceGroup(400545634);
                                SpotifriedScreenKt.NotEnough(spotifriedState2.morePlays, composerImpl2, 0);
                                composerImpl2.end(false);
                                z = true;
                            } else {
                                composerImpl2.startReplaceGroup(400547012);
                                ParcelableSnapshotMutableIntState parcelableSnapshotMutableIntState2 = parcelableSnapshotMutableIntState;
                                int intValue = parcelableSnapshotMutableIntState2.getIntValue();
                                boolean zChanged = composerImpl2.changed(parcelableSnapshotMutableIntState2);
                                Object objRememberedValue8 = composerImpl2.rememberedValue();
                                if (zChanged || objRememberedValue8 == neverEqualPolicy2) {
                                    objRememberedValue8 = new LyricsViewsKt$.ExternalSyntheticLambda11(parcelableSnapshotMutableIntState2, (byte) 2);
                                    composerImpl2.updateRememberedValue(objRememberedValue8);
                                }
                                z = true;
                                SpotifriedScreenKt.StoryShell(list, intValue, (Function1) objRememberedValue8, Expect_jvmKt.rememberComposableLambda(696407020, new SongMenuSheetKt$.ExternalSyntheticLambda5(spotifriedState2, function1, mutableState, mutableState2, (byte) 5), composerImpl2), composerImpl2, 3072);
                                composerImpl2.end(false);
                            }
                            composerImpl2.end(z);
                        } else {
                            composerImpl2.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }
                }, composerImpl), composerImpl, 6);
                function5 = function7;
            }
            recomposeScopeImplEndRestartGroup.block = function2;
        }
        composerImpl.skipToGroupEnd();
        function5 = function4;
        recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            final byte b2 = 1;
            function2 = new Function2(spotifriedViewModel, function0, f, function5, i, b2) { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda0
                public final /* synthetic */ byte $r8$classId;
                public final /* synthetic */ SpotifriedViewModel f$0;
                public final /* synthetic */ Function0 f$1;
                public final /* synthetic */ float f$2;
                public final /* synthetic */ Function4 f$3;

                {
                    this.$r8$classId = b2;
                }

                public final Object invoke(Object obj, Object obj2) {
                    byte b3 = this.$r8$classId;
                    Unit unit = Unit.INSTANCE;
                    switch (b3) {
                        case 0:
                            ((Integer) obj2).getClass();
                            int iUpdateChangedFlags = AnchoredGroupPath.updateChangedFlags(1);
                            SpotifriedScreenKt.m0SpotifriedScreen942rkJo(this.f$0, this.f$1, this.f$2, this.f$3, (ComposerImpl) obj, iUpdateChangedFlags);
                            break;
                        default:
                            ((Integer) obj2).getClass();
                            int iUpdateChangedFlags2 = AnchoredGroupPath.updateChangedFlags(1);
                            SpotifriedScreenKt.m0SpotifriedScreen942rkJo(this.f$0, this.f$1, this.f$2, this.f$3, (ComposerImpl) obj, iUpdateChangedFlags2);
                            break;
                    }
                    return unit;
                }
            };
            recomposeScopeImplEndRestartGroup.block = function2;
        }
    }

    /* JADX WARN: Code duplicated, block: B:30:0x0057  */
    /* JADX WARN: Code duplicated, block: B:32:0x005f  */
    /* JADX WARN: Code duplicated, block: B:33:0x0062  */
    /* JADX WARN: Code duplicated, block: B:37:0x0069  */
    /* JADX WARN: Code duplicated, block: B:39:0x006e  */
    /* JADX WARN: Code duplicated, block: B:41:0x0072  */
    /* JADX WARN: Code duplicated, block: B:43:0x007a  */
    /* JADX WARN: Code duplicated, block: B:44:0x007d  */
    /* JADX WARN: Code duplicated, block: B:48:0x0086  */
    /* JADX WARN: Code duplicated, block: B:50:0x008a  */
    /* JADX WARN: Code duplicated, block: B:52:0x008d  */
    /* JADX WARN: Code duplicated, block: B:54:0x0095  */
    /* JADX WARN: Code duplicated, block: B:55:0x0098  */
    /* JADX WARN: Code duplicated, block: B:59:0x00a5  */
    /* JADX WARN: Code duplicated, block: B:60:0x00a7  */
    /* JADX WARN: Code duplicated, block: B:63:0x00b0 A[DONT_INVERT] */
    /* JADX WARN: Code duplicated, block: B:64:0x00b2  */
    /* JADX WARN: Code duplicated, block: B:66:0x00b5  */
    /* JADX WARN: Code duplicated, block: B:67:0x00b7  */
    /* JADX WARN: Code duplicated, block: B:69:0x00ba  */
    /* JADX WARN: Code duplicated, block: B:72:0x00c2  */
    /* JADX WARN: Code duplicated, block: B:74:0x00cf  */
    /* JADX WARN: Code duplicated, block: B:75:0x00f7  */
    /* JADX WARN: Code duplicated, block: B:76:0x010a  */
    /* JADX WARN: Code duplicated, block: B:77:0x011c  */
    /* JADX WARN: Code duplicated, block: B:78:0x012e  */
    /* JADX WARN: Code duplicated, block: B:79:0x0146  */
    /* JADX WARN: Code duplicated, block: B:80:0x0158  */
    /* JADX WARN: Code duplicated, block: B:81:0x016a  */
    /* JADX WARN: Code duplicated, block: B:83:0x017f  */
    /* JADX WARN: Code duplicated, block: B:86:0x0189  */
    /* JADX WARN: Code duplicated, block: B:88:? A[RETURN, SYNTHETIC] */
    public static final void StoryCard(final CardId cardId, final SpotifriedState spotifriedState, boolean z, final Function0 function0, boolean z2, boolean z3, ComposerImpl composerImpl, final int i, final int i2) {
        int i3;
        boolean z4;
        int i4;
        boolean z5;
        int i5;
        int i6;
        boolean z6;
        int i7;
        boolean z7;
        final boolean z8;
        final boolean z9;
        final boolean z10;
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup;
        boolean z11;
        int i8;
        ComposerImpl composerImpl2 = composerImpl;
        cardId.getClass();
        spotifriedState.getClass();
        SpotifriedStats spotifriedStats = spotifriedState.stats;
        composerImpl2.startRestartGroup(1918312474);
        if ((i & 6) == 0) {
            i3 = (composerImpl2.changed(cardId.ordinal()) ? 4 : 2) | i;
        } else {
            i3 = i;
        }
        if ((i & 48) == 0) {
            i3 |= composerImpl2.changedInstance(spotifriedState) ? 32 : 16;
        }
        int i9 = i2 & 4;
        if (i9 == 0) {
            if ((i & 384) == 0) {
                z4 = z;
                i3 |= composerImpl2.changed(z4) ? 256 : 128;
            }
            if ((i & 3072) == 0) {
                if (composerImpl2.changedInstance(function0)) {
                    i8 = 2048;
                } else {
                    i8 = 1024;
                }
                i3 |= i8;
            }
            i4 = i2 & 16;
            if (i4 != 0) {
                if ((i & 24576) == 0) {
                    z5 = z2;
                    if (composerImpl2.changed(z5)) {
                        i5 = 16384;
                    } else {
                        i5 = 8192;
                    }
                    i3 |= i5;
                }
                i6 = i2 & 32;
                if (i6 != 0) {
                    if ((196608 & i) == 0) {
                        z6 = z3;
                        if (composerImpl2.changed(z6)) {
                            i7 = 131072;
                        } else {
                            i7 = 65536;
                        }
                        i3 |= i7;
                    }
                    if ((74899 & i3) != 74898) {
                        z7 = true;
                    } else {
                        z7 = false;
                    }
                    if (composerImpl2.shouldExecute(i3 & 1, z7)) {
                        if (i9 != 0) {
                            z4 = false;
                        }
                        if (i4 != 0) {
                            z11 = false;
                        } else {
                            z11 = z5;
                        }
                        if (i6 != 0) {
                            z6 = false;
                        }
                        switch (cardId.ordinal()) {
                            case 0:
                                z5 = z11;
                                composerImpl2.startReplaceGroup(957324343);
                                CardsKt.IntroCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                                composerImpl2.end(false);
                                break;
                            case 1:
                                z5 = z11;
                                composerImpl2.startReplaceGroup(957326169);
                                CardsKt.TopSongCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                                composerImpl2.end(false);
                                break;
                            case 2:
                                z5 = z11;
                                composerImpl2.startReplaceGroup(957327959);
                                CardsKt.HoursCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                                composerImpl2.end(false);
                                break;
                            case 3:
                                z5 = z11;
                                composerImpl2.startReplaceGroup(957329653);
                                boolean z12 = z4;
                                CardsKt.AgeCard(spotifriedStats, spotifriedState.checked, spotifriedState.unchecked, z12, composerImpl2, (i3 << 3) & 7168);
                                z4 = z12;
                                composerImpl2.end(false);
                                break;
                            case 4:
                                z5 = z11;
                                composerImpl2.startReplaceGroup(957332245);
                                CardsKt.DayCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                                composerImpl2.end(false);
                                break;
                            case 5:
                                z5 = z11;
                                composerImpl2.startReplaceGroup(957333944);
                                CardsKt.MonthsCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                                composerImpl2.end(false);
                                break;
                            case 6:
                                z5 = z11;
                                composerImpl2.startReplaceGroup(957335637);
                                CardsKt.SunCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                                composerImpl2.end(false);
                                break;
                            case 7:
                                composerImpl2.startReplaceGroup(957337308);
                                int i10 = ((i3 >> 6) & 112) | (i3 & 896);
                                int i11 = i3 >> 3;
                                CardsKt.TypeCard(spotifriedStats, function0, z4, z11, z6, spotifriedState.name, composerImpl2, i10 | (i11 & 7168) | (i11 & 57344));
                                composerImpl2 = composerImpl2;
                                z5 = z11;
                                composerImpl2.end(false);
                                break;
                            default:
                                composerImpl2.startReplaceGroup(957323674);
                                composerImpl2.end(false);
                                MediaSessionStub$.ExternalSyntheticLambda8.m();
                                return;
                        }
                    } else {
                        composerImpl2.skipToGroupEnd();
                    }
                    z8 = z4;
                    z9 = z5;
                    z10 = z6;
                    recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
                    if (recomposeScopeImplEndRestartGroup != null) {
                        recomposeScopeImplEndRestartGroup.block = new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda12
                            public final Object invoke(Object obj, Object obj2) {
                                ((Integer) obj2).getClass();
                                SpotifriedScreenKt.StoryCard(cardId, spotifriedState, z8, function0, z9, z10, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), i2);
                                return Unit.INSTANCE;
                            }
                        };
                    }
                }
                i3 |= 196608;
                z6 = z3;
                if ((74899 & i3) != 74898) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                if (composerImpl2.shouldExecute(i3 & 1, z7)) {
                    if (i9 != 0) {
                        z4 = false;
                    }
                    if (i4 != 0) {
                        z11 = false;
                    } else {
                        z11 = z5;
                    }
                    if (i6 != 0) {
                        z6 = false;
                    }
                    switch (cardId.ordinal()) {
                        case 0:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957324343);
                            CardsKt.IntroCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 1:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957326169);
                            CardsKt.TopSongCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 2:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957327959);
                            CardsKt.HoursCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 3:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957329653);
                            boolean z13 = z4;
                            CardsKt.AgeCard(spotifriedStats, spotifriedState.checked, spotifriedState.unchecked, z13, composerImpl2, (i3 << 3) & 7168);
                            z4 = z13;
                            composerImpl2.end(false);
                            break;
                        case 4:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957332245);
                            CardsKt.DayCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 5:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957333944);
                            CardsKt.MonthsCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 6:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957335637);
                            CardsKt.SunCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 7:
                            composerImpl2.startReplaceGroup(957337308);
                            int i12 = ((i3 >> 6) & 112) | (i3 & 896);
                            int i13 = i3 >> 3;
                            CardsKt.TypeCard(spotifriedStats, function0, z4, z11, z6, spotifriedState.name, composerImpl2, i12 | (i13 & 7168) | (i13 & 57344));
                            composerImpl2 = composerImpl2;
                            z5 = z11;
                            composerImpl2.end(false);
                            break;
                        default:
                            composerImpl2.startReplaceGroup(957323674);
                            composerImpl2.end(false);
                            MediaSessionStub$.ExternalSyntheticLambda8.m();
                            return;
                    }
                } else {
                    composerImpl2.skipToGroupEnd();
                }
                z8 = z4;
                z9 = z5;
                z10 = z6;
                recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
                if (recomposeScopeImplEndRestartGroup != null) {
                    recomposeScopeImplEndRestartGroup.block = new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda12
                        public final Object invoke(Object obj, Object obj2) {
                            ((Integer) obj2).getClass();
                            SpotifriedScreenKt.StoryCard(cardId, spotifriedState, z8, function0, z9, z10, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), i2);
                            return Unit.INSTANCE;
                        }
                    };
                }
            }
            i3 |= 24576;
            z5 = z2;
            i6 = i2 & 32;
            if (i6 != 0) {
                if ((196608 & i) == 0) {
                    z6 = z3;
                    if (composerImpl2.changed(z6)) {
                        i7 = 131072;
                    } else {
                        i7 = 65536;
                    }
                    i3 |= i7;
                }
                if ((74899 & i3) != 74898) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                if (composerImpl2.shouldExecute(i3 & 1, z7)) {
                    if (i9 != 0) {
                        z4 = false;
                    }
                    if (i4 != 0) {
                        z11 = false;
                    } else {
                        z11 = z5;
                    }
                    if (i6 != 0) {
                        z6 = false;
                    }
                    switch (cardId.ordinal()) {
                        case 0:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957324343);
                            CardsKt.IntroCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 1:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957326169);
                            CardsKt.TopSongCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 2:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957327959);
                            CardsKt.HoursCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 3:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957329653);
                            boolean z14 = z4;
                            CardsKt.AgeCard(spotifriedStats, spotifriedState.checked, spotifriedState.unchecked, z14, composerImpl2, (i3 << 3) & 7168);
                            z4 = z14;
                            composerImpl2.end(false);
                            break;
                        case 4:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957332245);
                            CardsKt.DayCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 5:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957333944);
                            CardsKt.MonthsCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 6:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957335637);
                            CardsKt.SunCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 7:
                            composerImpl2.startReplaceGroup(957337308);
                            int i14 = ((i3 >> 6) & 112) | (i3 & 896);
                            int i15 = i3 >> 3;
                            CardsKt.TypeCard(spotifriedStats, function0, z4, z11, z6, spotifriedState.name, composerImpl2, i14 | (i15 & 7168) | (i15 & 57344));
                            composerImpl2 = composerImpl2;
                            z5 = z11;
                            composerImpl2.end(false);
                            break;
                        default:
                            composerImpl2.startReplaceGroup(957323674);
                            composerImpl2.end(false);
                            MediaSessionStub$.ExternalSyntheticLambda8.m();
                            return;
                    }
                } else {
                    composerImpl2.skipToGroupEnd();
                }
                z8 = z4;
                z9 = z5;
                z10 = z6;
                recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
                if (recomposeScopeImplEndRestartGroup != null) {
                    recomposeScopeImplEndRestartGroup.block = new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda12
                        public final Object invoke(Object obj, Object obj2) {
                            ((Integer) obj2).getClass();
                            SpotifriedScreenKt.StoryCard(cardId, spotifriedState, z8, function0, z9, z10, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), i2);
                            return Unit.INSTANCE;
                        }
                    };
                }
            }
            i3 |= 196608;
            z6 = z3;
            if ((74899 & i3) != 74898) {
                z7 = true;
            } else {
                z7 = false;
            }
            if (composerImpl2.shouldExecute(i3 & 1, z7)) {
                if (i9 != 0) {
                    z4 = false;
                }
                if (i4 != 0) {
                    z11 = false;
                } else {
                    z11 = z5;
                }
                if (i6 != 0) {
                    z6 = false;
                }
                switch (cardId.ordinal()) {
                    case 0:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957324343);
                        CardsKt.IntroCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 1:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957326169);
                        CardsKt.TopSongCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 2:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957327959);
                        CardsKt.HoursCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 3:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957329653);
                        boolean z15 = z4;
                        CardsKt.AgeCard(spotifriedStats, spotifriedState.checked, spotifriedState.unchecked, z15, composerImpl2, (i3 << 3) & 7168);
                        z4 = z15;
                        composerImpl2.end(false);
                        break;
                    case 4:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957332245);
                        CardsKt.DayCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 5:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957333944);
                        CardsKt.MonthsCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 6:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957335637);
                        CardsKt.SunCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 7:
                        composerImpl2.startReplaceGroup(957337308);
                        int i16 = ((i3 >> 6) & 112) | (i3 & 896);
                        int i17 = i3 >> 3;
                        CardsKt.TypeCard(spotifriedStats, function0, z4, z11, z6, spotifriedState.name, composerImpl2, i16 | (i17 & 7168) | (i17 & 57344));
                        composerImpl2 = composerImpl2;
                        z5 = z11;
                        composerImpl2.end(false);
                        break;
                    default:
                        composerImpl2.startReplaceGroup(957323674);
                        composerImpl2.end(false);
                        MediaSessionStub$.ExternalSyntheticLambda8.m();
                        return;
                }
            } else {
                composerImpl2.skipToGroupEnd();
            }
            z8 = z4;
            z9 = z5;
            z10 = z6;
            recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
            if (recomposeScopeImplEndRestartGroup != null) {
                recomposeScopeImplEndRestartGroup.block = new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda12
                    public final Object invoke(Object obj, Object obj2) {
                        ((Integer) obj2).getClass();
                        SpotifriedScreenKt.StoryCard(cardId, spotifriedState, z8, function0, z9, z10, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), i2);
                        return Unit.INSTANCE;
                    }
                };
            }
        }
        i3 |= 384;
        z4 = z;
        if ((i & 3072) == 0) {
            if (composerImpl2.changedInstance(function0)) {
                i8 = 2048;
            } else {
                i8 = 1024;
            }
            i3 |= i8;
        }
        i4 = i2 & 16;
        if (i4 != 0) {
            if ((i & 24576) == 0) {
                z5 = z2;
                if (composerImpl2.changed(z5)) {
                    i5 = 16384;
                } else {
                    i5 = 8192;
                }
                i3 |= i5;
            }
            i6 = i2 & 32;
            if (i6 != 0) {
                if ((196608 & i) == 0) {
                    z6 = z3;
                    if (composerImpl2.changed(z6)) {
                        i7 = 131072;
                    } else {
                        i7 = 65536;
                    }
                    i3 |= i7;
                }
                if ((74899 & i3) != 74898) {
                    z7 = true;
                } else {
                    z7 = false;
                }
                if (composerImpl2.shouldExecute(i3 & 1, z7)) {
                    if (i9 != 0) {
                        z4 = false;
                    }
                    if (i4 != 0) {
                        z11 = false;
                    } else {
                        z11 = z5;
                    }
                    if (i6 != 0) {
                        z6 = false;
                    }
                    switch (cardId.ordinal()) {
                        case 0:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957324343);
                            CardsKt.IntroCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 1:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957326169);
                            CardsKt.TopSongCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 2:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957327959);
                            CardsKt.HoursCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 3:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957329653);
                            boolean z16 = z4;
                            CardsKt.AgeCard(spotifriedStats, spotifriedState.checked, spotifriedState.unchecked, z16, composerImpl2, (i3 << 3) & 7168);
                            z4 = z16;
                            composerImpl2.end(false);
                            break;
                        case 4:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957332245);
                            CardsKt.DayCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 5:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957333944);
                            CardsKt.MonthsCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 6:
                            z5 = z11;
                            composerImpl2.startReplaceGroup(957335637);
                            CardsKt.SunCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                            composerImpl2.end(false);
                            break;
                        case 7:
                            composerImpl2.startReplaceGroup(957337308);
                            int i18 = ((i3 >> 6) & 112) | (i3 & 896);
                            int i19 = i3 >> 3;
                            CardsKt.TypeCard(spotifriedStats, function0, z4, z11, z6, spotifriedState.name, composerImpl2, i18 | (i19 & 7168) | (i19 & 57344));
                            composerImpl2 = composerImpl2;
                            z5 = z11;
                            composerImpl2.end(false);
                            break;
                        default:
                            composerImpl2.startReplaceGroup(957323674);
                            composerImpl2.end(false);
                            MediaSessionStub$.ExternalSyntheticLambda8.m();
                            return;
                    }
                } else {
                    composerImpl2.skipToGroupEnd();
                }
                z8 = z4;
                z9 = z5;
                z10 = z6;
                recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
                if (recomposeScopeImplEndRestartGroup != null) {
                    recomposeScopeImplEndRestartGroup.block = new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda12
                        public final Object invoke(Object obj, Object obj2) {
                            ((Integer) obj2).getClass();
                            SpotifriedScreenKt.StoryCard(cardId, spotifriedState, z8, function0, z9, z10, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), i2);
                            return Unit.INSTANCE;
                        }
                    };
                }
            }
            i3 |= 196608;
            z6 = z3;
            if ((74899 & i3) != 74898) {
                z7 = true;
            } else {
                z7 = false;
            }
            if (composerImpl2.shouldExecute(i3 & 1, z7)) {
                if (i9 != 0) {
                    z4 = false;
                }
                if (i4 != 0) {
                    z11 = false;
                } else {
                    z11 = z5;
                }
                if (i6 != 0) {
                    z6 = false;
                }
                switch (cardId.ordinal()) {
                    case 0:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957324343);
                        CardsKt.IntroCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 1:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957326169);
                        CardsKt.TopSongCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 2:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957327959);
                        CardsKt.HoursCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 3:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957329653);
                        boolean z17 = z4;
                        CardsKt.AgeCard(spotifriedStats, spotifriedState.checked, spotifriedState.unchecked, z17, composerImpl2, (i3 << 3) & 7168);
                        z4 = z17;
                        composerImpl2.end(false);
                        break;
                    case 4:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957332245);
                        CardsKt.DayCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 5:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957333944);
                        CardsKt.MonthsCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 6:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957335637);
                        CardsKt.SunCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 7:
                        composerImpl2.startReplaceGroup(957337308);
                        int i110 = ((i3 >> 6) & 112) | (i3 & 896);
                        int i111 = i3 >> 3;
                        CardsKt.TypeCard(spotifriedStats, function0, z4, z11, z6, spotifriedState.name, composerImpl2, i110 | (i111 & 7168) | (i111 & 57344));
                        composerImpl2 = composerImpl2;
                        z5 = z11;
                        composerImpl2.end(false);
                        break;
                    default:
                        composerImpl2.startReplaceGroup(957323674);
                        composerImpl2.end(false);
                        MediaSessionStub$.ExternalSyntheticLambda8.m();
                        return;
                }
            } else {
                composerImpl2.skipToGroupEnd();
            }
            z8 = z4;
            z9 = z5;
            z10 = z6;
            recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
            if (recomposeScopeImplEndRestartGroup != null) {
                recomposeScopeImplEndRestartGroup.block = new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda12
                    public final Object invoke(Object obj, Object obj2) {
                        ((Integer) obj2).getClass();
                        SpotifriedScreenKt.StoryCard(cardId, spotifriedState, z8, function0, z9, z10, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), i2);
                        return Unit.INSTANCE;
                    }
                };
            }
        }
        i3 |= 24576;
        z5 = z2;
        i6 = i2 & 32;
        if (i6 != 0) {
            if ((196608 & i) == 0) {
                z6 = z3;
                if (composerImpl2.changed(z6)) {
                    i7 = 131072;
                } else {
                    i7 = 65536;
                }
                i3 |= i7;
            }
            if ((74899 & i3) != 74898) {
                z7 = true;
            } else {
                z7 = false;
            }
            if (composerImpl2.shouldExecute(i3 & 1, z7)) {
                if (i9 != 0) {
                    z4 = false;
                }
                if (i4 != 0) {
                    z11 = false;
                } else {
                    z11 = z5;
                }
                if (i6 != 0) {
                    z6 = false;
                }
                switch (cardId.ordinal()) {
                    case 0:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957324343);
                        CardsKt.IntroCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 1:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957326169);
                        CardsKt.TopSongCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 2:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957327959);
                        CardsKt.HoursCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 3:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957329653);
                        boolean z18 = z4;
                        CardsKt.AgeCard(spotifriedStats, spotifriedState.checked, spotifriedState.unchecked, z18, composerImpl2, (i3 << 3) & 7168);
                        z4 = z18;
                        composerImpl2.end(false);
                        break;
                    case 4:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957332245);
                        CardsKt.DayCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 5:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957333944);
                        CardsKt.MonthsCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 6:
                        z5 = z11;
                        composerImpl2.startReplaceGroup(957335637);
                        CardsKt.SunCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                        composerImpl2.end(false);
                        break;
                    case 7:
                        composerImpl2.startReplaceGroup(957337308);
                        int i112 = ((i3 >> 6) & 112) | (i3 & 896);
                        int i113 = i3 >> 3;
                        CardsKt.TypeCard(spotifriedStats, function0, z4, z11, z6, spotifriedState.name, composerImpl2, i112 | (i113 & 7168) | (i113 & 57344));
                        composerImpl2 = composerImpl2;
                        z5 = z11;
                        composerImpl2.end(false);
                        break;
                    default:
                        composerImpl2.startReplaceGroup(957323674);
                        composerImpl2.end(false);
                        MediaSessionStub$.ExternalSyntheticLambda8.m();
                        return;
                }
            } else {
                composerImpl2.skipToGroupEnd();
            }
            z8 = z4;
            z9 = z5;
            z10 = z6;
            recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
            if (recomposeScopeImplEndRestartGroup != null) {
                recomposeScopeImplEndRestartGroup.block = new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda12
                    public final Object invoke(Object obj, Object obj2) {
                        ((Integer) obj2).getClass();
                        SpotifriedScreenKt.StoryCard(cardId, spotifriedState, z8, function0, z9, z10, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), i2);
                        return Unit.INSTANCE;
                    }
                };
            }
        }
        i3 |= 196608;
        z6 = z3;
        if ((74899 & i3) != 74898) {
            z7 = true;
        } else {
            z7 = false;
        }
        if (composerImpl2.shouldExecute(i3 & 1, z7)) {
            if (i9 != 0) {
                z4 = false;
            }
            if (i4 != 0) {
                z11 = false;
            } else {
                z11 = z5;
            }
            if (i6 != 0) {
                z6 = false;
            }
            switch (cardId.ordinal()) {
                case 0:
                    z5 = z11;
                    composerImpl2.startReplaceGroup(957324343);
                    CardsKt.IntroCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                    composerImpl2.end(false);
                    break;
                case 1:
                    z5 = z11;
                    composerImpl2.startReplaceGroup(957326169);
                    CardsKt.TopSongCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                    composerImpl2.end(false);
                    break;
                case 2:
                    z5 = z11;
                    composerImpl2.startReplaceGroup(957327959);
                    CardsKt.HoursCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                    composerImpl2.end(false);
                    break;
                case 3:
                    z5 = z11;
                    composerImpl2.startReplaceGroup(957329653);
                    boolean z19 = z4;
                    CardsKt.AgeCard(spotifriedStats, spotifriedState.checked, spotifriedState.unchecked, z19, composerImpl2, (i3 << 3) & 7168);
                    z4 = z19;
                    composerImpl2.end(false);
                    break;
                case 4:
                    z5 = z11;
                    composerImpl2.startReplaceGroup(957332245);
                    CardsKt.DayCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                    composerImpl2.end(false);
                    break;
                case 5:
                    z5 = z11;
                    composerImpl2.startReplaceGroup(957333944);
                    CardsKt.MonthsCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                    composerImpl2.end(false);
                    break;
                case 6:
                    z5 = z11;
                    composerImpl2.startReplaceGroup(957335637);
                    CardsKt.SunCard(spotifriedStats, z4, composerImpl2, (i3 >> 3) & 112);
                    composerImpl2.end(false);
                    break;
                case 7:
                    composerImpl2.startReplaceGroup(957337308);
                    int i114 = ((i3 >> 6) & 112) | (i3 & 896);
                    int i115 = i3 >> 3;
                    CardsKt.TypeCard(spotifriedStats, function0, z4, z11, z6, spotifriedState.name, composerImpl2, i114 | (i115 & 7168) | (i115 & 57344));
                    composerImpl2 = composerImpl2;
                    z5 = z11;
                    composerImpl2.end(false);
                    break;
                default:
                    composerImpl2.startReplaceGroup(957323674);
                    composerImpl2.end(false);
                    MediaSessionStub$.ExternalSyntheticLambda8.m();
                    return;
            }
        } else {
            composerImpl2.skipToGroupEnd();
        }
        z8 = z4;
        z9 = z5;
        z10 = z6;
        recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new Function2() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$$ExternalSyntheticLambda12
                public final Object invoke(Object obj, Object obj2) {
                    ((Integer) obj2).getClass();
                    SpotifriedScreenKt.StoryCard(cardId, spotifriedState, z8, function0, z9, z10, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), i2);
                    return Unit.INSTANCE;
                }
            };
        }
    }

    public static final void StoryShell(final List list, final int i, final Function1 function1, ComposableLambdaImpl composableLambdaImpl, ComposerImpl composerImpl, int i2) {
        ComposableLambdaImpl composableLambdaImpl2;
        ComposerImpl composerImpl2 = composerImpl;
        function1.getClass();
        composerImpl2.startRestartGroup(6133977);
        int i3 = i2 | (composerImpl2.changedInstance(list) ? 4 : 2) | (composerImpl2.changed(i) ? 32 : 16) | (composerImpl2.changedInstance(function1) ? 256 : 128);
        if (composerImpl2.shouldExecute(i3 & 1, (i3 & 1171) != 1170)) {
            boolean zRememberNoMotion = SunKt.rememberNoMotion(composerImpl2);
            Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
            Modifier modifierFillMaxSize = SizeKt.fillMaxSize(companion, 1.0f);
            ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(OffsetKt.Top, Alignment.Companion.Start, composerImpl2, 0);
            int iHashCode = Long.hashCode(composerImpl2.compositeKeyHashCode);
            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl2.currentCompositionLocalScope();
            Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl2, modifierFillMaxSize);
            ComposeUiNode.Companion.getClass();
            LayoutNode.Companion.Constructor.1 r13 = ComposeUiNode.Companion.Constructor;
            composerImpl2.startReusableNode();
            if (composerImpl2.inserting) {
                composerImpl2.createNode(r13);
            } else {
                composerImpl2.useNode();
            }
            ComposeUiNode.Companion.SetModifier.1 r14 = ComposeUiNode.Companion.SetMeasurePolicy;
            AnchoredGroupPath.set-impl(composerImpl2, columnMeasurePolicy, r14);
            ComposeUiNode.Companion.SetModifier.1 r6 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
            AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope, r6);
            ComposeUiNode.Companion.SetModifier.1 r12 = ComposeUiNode.Companion.SetCompositeKeyHash;
            if (composerImpl2.inserting || !Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode))) {
                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl2, iHashCode, r12);
            }
            ComposeUiNode.Companion.SetModifier.1 r9 = ComposeUiNode.Companion.SetModifier;
            AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier, r9);
            Modifier modifier = OffsetKt.padding-VpY3zN4(SizeKt.fillMaxWidth(companion, 1.0f), 20.0f, 12.0f);
            RowMeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(new Arrangement.SpacedAligned(4.0f, new SaversKt$.ExternalSyntheticLambda0((byte) 3)), Alignment.Companion.Top, composerImpl2, 6);
            int iHashCode2 = Long.hashCode(composerImpl2.compositeKeyHashCode);
            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope2 = composerImpl2.currentCompositionLocalScope();
            Modifier modifierMaterializeModifier2 = AbsoluteAlignment.materializeModifier(composerImpl2, modifier);
            composerImpl2.startReusableNode();
            if (composerImpl2.inserting) {
                composerImpl2.createNode(r13);
            } else {
                composerImpl2.useNode();
            }
            AnchoredGroupPath.set-impl(composerImpl2, rowMeasurePolicy, r14);
            AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope2, r6);
            if (composerImpl2.inserting || !Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                OperationKt$.ExternalSyntheticLambda0.m(iHashCode2, composerImpl2, iHashCode2, r12);
            }
            AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier2, r9);
            composerImpl2.startReplaceGroup(547342233);
            IntIterator it = ByteStreamsKt.getIndices(list).iterator();
            while (((IntProgressionIterator) it).hasNext) {
                ComposerImpl composerImpl3 = composerImpl2;
                BoxKt.Box(ImageKt.background-bw27NRU(ClipKt.clip(TestTagKt.testTag(SizeKt.height-3ABfNKs(new LayoutWeightElement(1.0f, true), 3.0f), "segment"), RoundedCornerShapeKt.RoundedCornerShape-0680j_4(2.0f)), Color.copy-wmQWz5c$default(((Number) AnimateAsStateKt.animateFloatAsState(it.nextInt() <= i ? 1.0f : 0.18f, zRememberNoMotion ? new SnapSpec() : ArcSplineKt.tween$default(300, 150, (Easing) null, 4), "segment", composerImpl3, 3072, 20).getValue()).floatValue(), ((ColorScheme) composerImpl3.consume(ColorSchemeKt.LocalColorScheme)).onBackground), ColorKt.RectangleShape), composerImpl3, 0);
                composerImpl2 = composerImpl3;
            }
            ComposerImpl composerImpl4 = composerImpl2;
            composerImpl4.end(false);
            composerImpl4.end(true);
            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.fillMaxWidth(new LayoutWeightElement(1.0f, true), 1.0f), "tap");
            int i4 = i3 & 112;
            int i5 = i3 & 896;
            boolean zChangedInstance = (i4 == 32) | composerImpl4.changedInstance(list) | (i5 == 256);
            Object objRememberedValue = composerImpl4.rememberedValue();
            NeverEqualPolicy neverEqualPolicy = Composer.Companion.Empty;
            if (zChangedInstance || objRememberedValue == neverEqualPolicy) {
                objRememberedValue = new FadeBarKt$.ExternalSyntheticLambda4(i, list, function1);
                composerImpl4.updateRememberedValue(objRememberedValue);
            }
            Modifier modifierSemantics = SemanticsModifierKt.semantics(modifierTestTag, false, (Function1) objRememberedValue);
            Integer numValueOf = Integer.valueOf(i);
            boolean zChangedInstance2 = (i4 == 32) | composerImpl4.changedInstance(list) | (i5 == 256);
            Object objRememberedValue2 = composerImpl4.rememberedValue();
            if (zChangedInstance2 || objRememberedValue2 == neverEqualPolicy) {
                objRememberedValue2 = new PointerInputEventHandler() { // from class: com.spotifry.music.ui.spotifried.SpotifriedScreenKt$StoryShell$1$3$1
                    public final Object invoke(PointerInputScope pointerInputScope, Continuation continuation) {
                        Object objDetectTapGestures$default = TapGestureDetectorKt.detectTapGestures$default(pointerInputScope, (SliderKt.sliderTapModifier.1.1) null, new PlayerController$.ExternalSyntheticLambda6(pointerInputScope, i, list, function1), continuation, 7);
                        return objDetectTapGestures$default == CoroutineSingletons.COROUTINE_SUSPENDED ? objDetectTapGestures$default : Unit.INSTANCE;
                    }
                };
                composerImpl4.updateRememberedValue(objRememberedValue2);
            }
            PointerEvent pointerEvent = SuspendingPointerInputFilterKt.EmptyPointerEvent;
            Modifier modifierThen = modifierSemantics.then(new SuspendPointerInputElement(list, numValueOf, (PointerInputEventHandler) objRememberedValue2, 4));
            BiasAlignment biasAlignment = Alignment.Companion.Center;
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(biasAlignment, false);
            int iHashCode3 = Long.hashCode(composerImpl4.compositeKeyHashCode);
            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl4.currentCompositionLocalScope();
            Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl4, modifierThen);
            ComposeUiNode.Companion.getClass();
            LayoutNode.Companion.Constructor.1 r10 = ComposeUiNode.Companion.Constructor;
            composerImpl4.startReusableNode();
            if (composerImpl4.inserting) {
                composerImpl4.createNode(r10);
            } else {
                composerImpl4.useNode();
            }
            AnchoredGroupPath.set-impl(composerImpl4, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
            AnchoredGroupPath.set-impl(composerImpl4, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, ComposeUiNode.Companion.SetResolvedCompositionLocals);
            ComposeUiNode.Companion.SetModifier.1 r5 = ComposeUiNode.Companion.SetCompositeKeyHash;
            if (composerImpl4.inserting || !Intrinsics.areEqual(composerImpl4.rememberedValue(), Integer.valueOf(iHashCode3))) {
                OperationKt$.ExternalSyntheticLambda0.m(iHashCode3, composerImpl4, iHashCode3, r5);
            }
            AnchoredGroupPath.set-impl(composerImpl4, modifierMaterializeModifier3, ComposeUiNode.Companion.SetModifier);
            Object obj = list.get(ResultKt.coerceIn(i, ByteStreamsKt.getIndices(list)));
            Modifier modifierFillMaxSize2 = SizeKt.fillMaxSize(companion, 1.0f);
            boolean zChanged = composerImpl4.changed(zRememberNoMotion);
            Object objRememberedValue3 = composerImpl4.rememberedValue();
            if (zChanged || objRememberedValue3 == neverEqualPolicy) {
                objRememberedValue3 = new SunKt$.ExternalSyntheticLambda3((byte) 1, zRememberNoMotion);
                composerImpl4.updateRememberedValue(objRememberedValue3);
            }
            composableLambdaImpl2 = composableLambdaImpl;
            composerImpl2 = composerImpl4;
            Scale.AnimatedContent(obj, modifierFillMaxSize2, (Function1) objRememberedValue3, biasAlignment, "card", (Function1) null, Expect_jvmKt.rememberComposableLambda(-147548807, new FrameworkSQLiteDatabase$.ExternalSyntheticLambda0(composableLambdaImpl2, (byte) 2), composerImpl4), composerImpl2, 1600560);
            composerImpl2.end(true);
            composerImpl2.end(true);
        } else {
            composableLambdaImpl2 = composableLambdaImpl;
            composerImpl2.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new ArtistPageKt$.ExternalSyntheticLambda12(list, i, function1, composableLambdaImpl2, i2, (byte) 16);
        }
    }

    public static final void StoryTheme(ComposableLambdaImpl composableLambdaImpl, ComposerImpl composerImpl, int i) {
        ComposerImpl composerImpl2;
        composerImpl.startRestartGroup(-244387295);
        if (composerImpl.shouldExecute(i & 1, (i & 3) != 2)) {
            composerImpl2 = composerImpl;
            ThemeKt.AlwaysDark-KTwxG1Y(com.spotifry.music.ui.theme.ColorKt.StoryBlack, false, Expect_jvmKt.rememberComposableLambda(-364133931, new MainActivityKt$.ExternalSyntheticLambda137(composableLambdaImpl, (byte) 9), composerImpl), composerImpl2, 390, 2);
        } else {
            composerImpl2 = composerImpl;
            composerImpl2.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new MainActivityKt$.ExternalSyntheticLambda137(composableLambdaImpl, i, (byte) 10);
        }
    }
}
