package com.spotifry.music.ui.spotifried;

import androidx.compose.animation.core.Animatable;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.ui.graphics.LinearGradient;
import androidx.compose.ui.graphics.RadialGradient;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import androidx.compose.ui.graphics.drawscope.Stroke;
import java.util.Iterator;
import java.util.List;
import kotlin.Unit;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda55 implements Function1 {
    public final /* synthetic */ byte $r8$classId = 0;
    public final /* synthetic */ long f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ Object f$2;
    public final /* synthetic */ float f$3;
    public final /* synthetic */ long f$4;

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda55(long j, List list, Animatable animatable, float f, long j2) {
        this.f$0 = j;
        this.f$1 = list;
        this.f$2 = animatable;
        this.f$3 = f;
        this.f$4 = j2;
    }

    public final Object invoke(Object obj) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        Object obj2 = this.f$2;
        Object obj3 = this.f$1;
        switch (b) {
            case 0:
                List list = (List) obj3;
                Animatable animatable = (Animatable) obj2;
                DrawScope drawScope = (DrawScope) obj;
                drawScope.getClass();
                float f = drawScope.toPx-0680j_4(4.0f);
                DrawScope.drawRect-n-J9OG0$default(drawScope, this.f$0, ((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) - drawScope.toPx-0680j_4(1.0f))) & 4294967295L, (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() >> 32)))) << 32) | (((long) Float.floatToRawIntBits(drawScope.toPx-0680j_4(1.0f))) & 4294967295L), 0.0f, 0, 120);
                Iterator it = list.iterator();
                int i = 0;
                while (true) {
                    if (!it.hasNext()) {
                        return unit;
                    }
                    Object next = it.next();
                    int i2 = i + 1;
                    if (i < 0) {
                        ByteStreamsKt.throwIndexOverflow();
                        throw null;
                    }
                    float fFloatValue = ((Number) next).floatValue();
                    float fStepAt = CardsKt.stepAt(((Number) animatable.getValue()).floatValue(), (i * this.f$3) + 500.0f, 550.0f) * Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) * (((i2 * 0.65f) / list.size()) + 0.35f);
                    long jFloatToRawIntBits = (((long) Float.floatToRawIntBits((Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() >> 32)) - f) * (fFloatValue / 24.0f))) << 32) | (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) - fStepAt)) & 4294967295L);
                    long jFloatToRawIntBits2 = (((long) Float.floatToRawIntBits(f)) << 32) | (((long) Float.floatToRawIntBits(fStepAt)) & 4294967295L);
                    float f2 = f / 2.0f;
                    DrawScope.drawRoundRect-u-Aw5IA$default(drawScope, this.f$4, jFloatToRawIntBits, jFloatToRawIntBits2, (((long) Float.floatToRawIntBits(f2)) << 32) | (((long) Float.floatToRawIntBits(f2)) & 4294967295L), (Stroke) null, 0.0f, 240);
                    i = i2;
                }
                break;
            default:
                RadialGradient radialGradient = (RadialGradient) obj3;
                DrawScope drawScope2 = (DrawScope) obj;
                drawScope2.getClass();
                float f3 = this.f$3;
                long j = this.f$0;
                DrawScope.drawCircle-V9BoPsw$default(drawScope2, radialGradient, 70.0f * f3, j, 0.0f, (Stroke) null, 120);
                long j2 = this.f$4;
                DrawScope.drawCircle-VaOC9Bg$default(drawScope2, Color.copy-wmQWz5c$default(0.8f, j2), 41.0f * f3, j, 0.0f, new Stroke(f3, 0.0f, 0, 0, 30), 104);
                long j3 = Color.Black;
                DrawScope.drawCircle-VaOC9Bg$default(drawScope2, Color.copy-wmQWz5c$default(0.18f, j3), 63.0f * f3, j, 0.0f, new Stroke(f3, 0.0f, 0, 0, 30), 104);
                float f4 = 54.75f * f3;
                float f5 = 2.0f * f4;
                drawScope2.drawArc-yD3GUKo(Color.copy-wmQWz5c$default(0.85f, j2), 195.0f, 90.0f, Offset.minus-MK-Hz9U(j, (((long) Float.floatToRawIntBits(f4)) << 32) | (((long) Float.floatToRawIntBits(f4)) & 4294967295L)), (((long) Float.floatToRawIntBits(f5)) << 32) | (((long) Float.floatToRawIntBits(f5)) & 4294967295L), new Stroke(f3 * 2.5f, 0.0f, 0, 0, 30));
                DrawScope.drawCircle-V9BoPsw$default(drawScope2, (LinearGradient) obj2, f3 * 67.5f, j, 0.0f, new Stroke(4.0f * f3, 0.0f, 0, 0, 30), 104);
                DrawScope.drawCircle-VaOC9Bg$default(drawScope2, Color.copy-wmQWz5c$default(0.25f, j3), f3 * 69.5f, j, 0.0f, new Stroke(f3, 0.0f, 0, 0, 30), 104);
                DrawScope.drawCircle-VaOC9Bg$default(drawScope2, ColorKt.Color(4278519045L), f3 * 3.8f, j, 0.0f, (DrawStyle) null, 120);
                return unit;
        }
    }

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda55(RadialGradient radialGradient, float f, long j, long j2, LinearGradient linearGradient) {
        this.f$1 = radialGradient;
        this.f$3 = f;
        this.f$0 = j;
        this.f$4 = j2;
        this.f$2 = linearGradient;
    }
}
