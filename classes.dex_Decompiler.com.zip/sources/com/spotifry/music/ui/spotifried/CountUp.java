package com.spotifry.music.ui.spotifried;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final class CountUp {
    public final boolean started;
    public final String text;

    public CountUp(boolean z, String str) {
        this.started = z;
        this.text = str;
    }

    public CountUp(String str, boolean z) {
        this.text = str;
        this.started = z;
    }
}
