package com.spotifry.music.ui.spotifried;

import androidx.compose.runtime.AnchoredGroupPath;
import androidx.compose.runtime.ComposerImpl;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import androidx.compose.ui.Modifier;
import com.spotifry.music.data.spotifried.ObsessionDay;
import com.spotifry.music.data.spotifried.SpotifriedStats;
import com.spotifry.music.ui.components.FadeInKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda20 implements Function2 {
    public final /* synthetic */ byte $r8$classId = 1;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ Object f$1;
    public final /* synthetic */ boolean f$2;
    public final /* synthetic */ int f$3;

    /* JADX WARN: Multi-variable type inference failed */
    public /* synthetic */ CardsKt$$ExternalSyntheticLambda20(Modifier modifier, ComposableLambdaImpl composableLambdaImpl, int i, int i2) {
        this.f$0 = modifier;
        this.f$1 = composableLambdaImpl;
        this.f$3 = i;
        this.f$2 = i2;
    }

    public final Object invoke(Object obj, Object obj2) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        boolean z = this.f$2;
        int i = this.f$3;
        Object obj3 = this.f$1;
        Object obj4 = this.f$0;
        switch (b) {
            case 0:
                ((Integer) obj2).getClass();
                CardsKt.Day((SpotifriedStats) obj4, (ObsessionDay) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            default:
                ((Integer) obj2).getClass();
                FadeInKt.LoadingShapes((Modifier) obj4, (ComposableLambdaImpl) obj3, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1), z ? 1 : 0);
                break;
        }
        return unit;
    }

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda20(SpotifriedStats spotifriedStats, ObsessionDay obsessionDay, boolean z, int i) {
        this.f$0 = spotifriedStats;
        this.f$1 = obsessionDay;
        this.f$2 = z;
        this.f$3 = i;
    }
}
