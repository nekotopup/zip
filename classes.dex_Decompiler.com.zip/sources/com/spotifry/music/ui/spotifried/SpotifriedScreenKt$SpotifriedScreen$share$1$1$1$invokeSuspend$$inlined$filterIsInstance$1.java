package com.spotifry.music.ui.spotifried;

import android.app.Activity;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final class SpotifriedScreenKt$SpotifriedScreen$share$1$1$1$invokeSuspend$$inlined$filterIsInstance$1 implements Function1 {
    public static final SpotifriedScreenKt$SpotifriedScreen$share$1$1$1$invokeSuspend$$inlined$filterIsInstance$1 INSTANCE = new SpotifriedScreenKt$SpotifriedScreen$share$1$1$1$invokeSuspend$$inlined$filterIsInstance$1();

    public final Object invoke(Object obj) {
        return Boolean.valueOf(obj instanceof Activity);
    }
}
