package com.spotifry.music.ui.spotifried;

import androidx.compose.animation.core.Animatable;
import androidx.compose.animation.core.ArcSplineKt;
import androidx.compose.animation.core.EasingKt;
import androidx.compose.animation.core.TweenSpec;
import androidx.compose.foundation.MutatePriority;
import androidx.compose.material3.SheetState;
import androidx.compose.material3.internal.AnchoredDraggableKt;
import androidx.compose.material3.internal.AnchoredDraggableState;
import androidx.compose.ui.geometry.Offset;
import androidx.compose.ui.scrollcapture.ComposeScrollCaptureCallback;
import androidx.compose.ui.semantics.SemanticsActions;
import androidx.work.OperationKt$;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import org.jsoup.SerializationException;
import org.jsoup.parser.CharacterReader$;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final class CardsKt$clock$1$1 extends SuspendLambda implements Function2 {
    public final /* synthetic */ Object $c;
    public /* synthetic */ float $end;
    public final /* synthetic */ byte $r8$classId;
    public boolean label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ CardsKt$clock$1$1(Object obj, float f, Continuation continuation, byte b) {
        super(2, continuation);
        this.$r8$classId = b;
        this.$c = obj;
        this.$end = f;
    }

    public final Continuation create(Object obj, Continuation continuation) {
        byte b = this.$r8$classId;
        Object obj2 = this.$c;
        switch (b) {
            case 0:
                return new CardsKt$clock$1$1((Animatable) obj2, this.$end, continuation, (byte) 0);
            case 1:
                return new CardsKt$clock$1$1((SheetState) obj2, this.$end, continuation, (byte) 1);
            default:
                CardsKt$clock$1$1 cardsKt$clock$1$1 = new CardsKt$clock$1$1((ComposeScrollCaptureCallback) obj2, continuation);
                cardsKt$clock$1$1.$end = ((Number) obj).floatValue();
                return cardsKt$clock$1$1;
        }
    }

    public final Object invoke(Object obj, Object obj2) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        switch (b) {
            case 0:
                return create((CoroutineScope) obj, (Continuation) obj2).invokeSuspend(unit);
            case 1:
                return create((CoroutineScope) obj, (Continuation) obj2).invokeSuspend(unit);
            default:
                return create(Float.valueOf(((Number) obj).floatValue()), (Continuation) obj2).invokeSuspend(unit);
        }
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: org.jsoup.SerializationException */
    /* JADX WARN: Code duplicated, block: B:36:0x00c8  */
    public final Object invokeSuspend(Object obj) throws SerializationException {
        Object objAnchoredDrag;
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        Object obj2 = this.$c;
        switch (b) {
            case 0:
                float f = this.$end;
                boolean z = this.label;
                if (z) {
                    if (z) {
                        ResultKt.throwOnFailure(obj);
                        return unit;
                    }
                    CharacterReader$.ExternalSyntheticLambda2.m$2("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                ResultKt.throwOnFailure(obj);
                Float f2 = new Float(f);
                TweenSpec tweenSpecTween$default = ArcSplineKt.tween$default((int) f, 0, EasingKt.LinearEasing, 2);
                this.label = true;
                return Animatable.animateTo$default((Animatable) obj2, f2, tweenSpecTween$default, (Function1) null, this, 12) == coroutineSingletons ? coroutineSingletons : unit;
            case 1:
                boolean z2 = this.label;
                if (z2) {
                    if (z2) {
                        ResultKt.throwOnFailure(obj);
                        return unit;
                    }
                    CharacterReader$.ExternalSyntheticLambda2.m$2("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                ResultKt.throwOnFailure(obj);
                float f3 = this.$end;
                this.label = true;
                AnchoredDraggableState anchoredDraggableState = ((SheetState) obj2).anchoredDraggableState;
                Object value = anchoredDraggableState.currentValue$delegate.getValue();
                Object objComputeTarget = anchoredDraggableState.computeTarget(anchoredDraggableState.requireOffset(), f3, value);
                boolean zBooleanValue = ((Boolean) anchoredDraggableState.confirmValueChange.invoke(objComputeTarget)).booleanValue();
                MutatePriority mutatePriority = MutatePriority.Default;
                if (zBooleanValue) {
                    objAnchoredDrag = anchoredDraggableState.anchoredDrag(objComputeTarget, mutatePriority, new AnchoredDraggableKt.animateTo.2(anchoredDraggableState, f3, (Continuation) null), this);
                    if (objAnchoredDrag != coroutineSingletons) {
                        objAnchoredDrag = unit;
                    }
                    if (objAnchoredDrag != coroutineSingletons) {
                        objAnchoredDrag = unit;
                    }
                } else {
                    objAnchoredDrag = anchoredDraggableState.anchoredDrag(value, mutatePriority, new AnchoredDraggableKt.animateTo.2(anchoredDraggableState, f3, (Continuation) null), this);
                    if (objAnchoredDrag != coroutineSingletons) {
                        objAnchoredDrag = unit;
                    }
                    if (objAnchoredDrag != coroutineSingletons) {
                        objAnchoredDrag = unit;
                    }
                }
                if (objAnchoredDrag != coroutineSingletons) {
                    objAnchoredDrag = unit;
                }
                return objAnchoredDrag == coroutineSingletons ? coroutineSingletons : unit;
            default:
                ComposeScrollCaptureCallback composeScrollCaptureCallback = (ComposeScrollCaptureCallback) obj2;
                boolean z3 = this.label;
                if (!z3) {
                    ResultKt.throwOnFailure(obj);
                    float f4 = this.$end;
                    Object obj3 = composeScrollCaptureCallback.node.unmergedConfig.props.get(SemanticsActions.ScrollByOffset);
                    Function2 function2 = (Function2) (obj3 != null ? obj3 : null);
                    if (function2 == null) {
                        throw OperationKt$.ExternalSyntheticLambda0.m("Required value was null.");
                    }
                    Offset offset = new Offset(((long) Float.floatToRawIntBits(f4)) & 4294967295L);
                    this.label = true;
                    obj = function2.invoke(offset, this);
                    if (obj == coroutineSingletons) {
                        return coroutineSingletons;
                    }
                } else {
                    if (!z3) {
                        CharacterReader$.ExternalSyntheticLambda2.m$2("call to 'resume' before 'invoke' with coroutine");
                        return null;
                    }
                    ResultKt.throwOnFailure(obj);
                }
                return new Float(Float.intBitsToFloat((int) (((Offset) obj).packedValue & 4294967295L)));
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CardsKt$clock$1$1(ComposeScrollCaptureCallback composeScrollCaptureCallback, Continuation continuation) {
        super(2, continuation);
        this.$r8$classId = (byte) 2;
        this.$c = composeScrollCaptureCallback;
    }
}
