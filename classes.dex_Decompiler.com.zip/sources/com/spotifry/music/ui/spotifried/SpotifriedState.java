package com.spotifry.music.ui.spotifried;

import androidx.work.OperationKt$;
import com.spotifry.music.data.spotifried.SpotifriedStats;
import java.util.ArrayList;
import java.util.List;
import kotlin.jvm.internal.Intrinsics;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final class SpotifriedState {
    public final List cards;
    public final int checked;
    public final ArrayList choices;
    public final Integer morePlays;
    public final String name;
    public final SpotifriedStats stats;
    public final int unchecked;

    public SpotifriedState(SpotifriedStats spotifriedStats, List list, ArrayList arrayList, int i, int i2, Integer num, String str) {
        str.getClass();
        this.stats = spotifriedStats;
        this.cards = list;
        this.choices = arrayList;
        this.checked = i;
        this.unchecked = i2;
        this.morePlays = num;
        this.name = str;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SpotifriedState)) {
            return false;
        }
        SpotifriedState spotifriedState = (SpotifriedState) obj;
        return this.stats.equals(spotifriedState.stats) && this.cards.equals(spotifriedState.cards) && this.choices.equals(spotifriedState.choices) && this.checked == spotifriedState.checked && this.unchecked == spotifriedState.unchecked && Intrinsics.areEqual(this.morePlays, spotifriedState.morePlays) && Intrinsics.areEqual(this.name, spotifriedState.name);
    }

    public final int hashCode() {
        int iM = OperationKt$.ExternalSyntheticLambda0.m(this.unchecked, OperationKt$.ExternalSyntheticLambda0.m(this.checked, (this.choices.hashCode() + OperationKt$.ExternalSyntheticLambda0.m(this.stats.hashCode() * 31, this.cards, 31)) * 31, 31), 31);
        Integer num = this.morePlays;
        return this.name.hashCode() + ((iM + (num == null ? 0 : num.hashCode())) * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder("SpotifriedState(stats=");
        sb.append(this.stats);
        sb.append(", cards=");
        sb.append(this.cards);
        sb.append(", choices=");
        sb.append(this.choices);
        sb.append(", checked=");
        sb.append(this.checked);
        sb.append(", unchecked=");
        sb.append(this.unchecked);
        sb.append(", morePlays=");
        sb.append(this.morePlays);
        sb.append(", name=");
        return OperationKt$.ExternalSyntheticLambda0.m(sb, this.name, ")");
    }
}
