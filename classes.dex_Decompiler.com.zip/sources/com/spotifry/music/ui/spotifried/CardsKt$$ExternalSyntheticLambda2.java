package com.spotifry.music.ui.spotifried;

import androidx.compose.runtime.AnchoredGroupPath;
import androidx.compose.runtime.ComposerImpl;
import com.spotifry.music.data.spotifried.SpotifriedStats;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda2 implements Function2 {
    public final /* synthetic */ byte $r8$classId;
    public final /* synthetic */ SpotifriedStats f$0;
    public final /* synthetic */ int f$1;
    public final /* synthetic */ int f$2;
    public final /* synthetic */ boolean f$3;
    public final /* synthetic */ int f$4;

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda2(SpotifriedStats spotifriedStats, int i, int i2, boolean z, int i3, byte b) {
        this.$r8$classId = b;
        this.f$0 = spotifriedStats;
        this.f$1 = i;
        this.f$2 = i2;
        this.f$3 = z;
        this.f$4 = i3;
    }

    public final Object invoke(Object obj, Object obj2) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        int i = this.f$4;
        switch (b) {
            case 0:
                ((Integer) obj2).getClass();
                int iUpdateChangedFlags = AnchoredGroupPath.updateChangedFlags(i | 1);
                CardsKt.AgeCard(this.f$0, this.f$1, this.f$2, this.f$3, (ComposerImpl) obj, iUpdateChangedFlags);
                break;
            default:
                ((Integer) obj2).getClass();
                int iUpdateChangedFlags2 = AnchoredGroupPath.updateChangedFlags(i | 1);
                CardsKt.Age(this.f$0, this.f$1, this.f$2, this.f$3, (ComposerImpl) obj, iUpdateChangedFlags2);
                break;
        }
        return unit;
    }
}
