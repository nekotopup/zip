package com.spotifry.music.ui.spotifried;

import androidx.collection.internal.Lock;
import androidx.compose.animation.core.Animatable;
import androidx.compose.foundation.lazy.DefaultLazyListPrefetchStrategy;
import androidx.compose.foundation.lazy.grid.LazyGridState;
import androidx.compose.foundation.lazy.layout.LazyLayoutPrefetchState;
import androidx.compose.runtime.snapshots.Snapshot;
import androidx.compose.ui.graphics.ReusableGraphicsLayerScope;
import java.util.Collection;
import java.util.List;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda36 implements Function1 {
    public final /* synthetic */ byte $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ int f$1;

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda36(int i, Collection collection) {
        this.$r8$classId = (byte) 2;
        this.f$1 = i;
        this.f$0 = collection;
    }

    public final Object invoke(Object obj) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        Object obj2 = this.f$0;
        int i = this.f$1;
        switch (b) {
            case 0:
                ReusableGraphicsLayerScope reusableGraphicsLayerScope = (ReusableGraphicsLayerScope) obj;
                reusableGraphicsLayerScope.getClass();
                reusableGraphicsLayerScope.setAlpha(ResultKt.coerceIn(((CardsKt.stepAt(((Number) ((Animatable) obj2).getValue()).floatValue(), 500.0f, 1800.0f) * 24.0f) - i) / 3.0f, 0.0f, 1.0f));
                return unit;
            case 1:
                LazyLayoutPrefetchState.NestedPrefetchScopeImpl nestedPrefetchScopeImpl = (LazyLayoutPrefetchState.NestedPrefetchScopeImpl) obj;
                DefaultLazyListPrefetchStrategy defaultLazyListPrefetchStrategy = ((LazyGridState) obj2).prefetchStrategy;
                Snapshot currentThreadSnapshot = Lock.getCurrentThreadSnapshot();
                Lock.restoreNonObservable(currentThreadSnapshot, Lock.makeCurrentNonObservable(currentThreadSnapshot), currentThreadSnapshot != null ? currentThreadSnapshot.getReadObserver() : null);
                defaultLazyListPrefetchStrategy.getClass();
                int i2 = nestedPrefetchScopeImpl.nestedPrefetchItemCount;
                if (i2 == -1) {
                    i2 = 2;
                }
                for (int i3 = 0; i3 < i2; i3++) {
                    nestedPrefetchScopeImpl.schedulePrecomposition(i + i3);
                }
                return unit;
            default:
                return Boolean.valueOf(((List) obj).addAll(i, (Collection) obj2));
        }
    }

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda36(Object obj, int i, byte b) {
        this.$r8$classId = b;
        this.f$0 = obj;
        this.f$1 = i;
    }
}
