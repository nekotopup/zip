package com.spotifry.music.ui.spotifried;

import androidx.compose.animation.core.Animatable;
import kotlin.ResultKt;
import kotlin.jvm.functions.Function0;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda11 implements Function0 {
    public final /* synthetic */ byte $r8$classId;
    public final /* synthetic */ Animatable f$0;

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda11(Animatable animatable, byte b) {
        this.$r8$classId = b;
        this.f$0 = animatable;
    }

    public final Object invoke() {
        byte b = this.$r8$classId;
        Animatable animatable = this.f$0;
        switch (b) {
            case 0:
                return Boolean.valueOf(((Number) animatable.getValue()).floatValue() >= 1.0f);
            default:
                return Float.valueOf(ResultKt.coerceIn((((Number) animatable.getValue()).floatValue() - 3000.0f) / 500.0f, 0.0f, 1.0f));
        }
    }
}
