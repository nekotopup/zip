package com.spotifry.music.ui.spotifried;

import androidx.compose.animation.core.Animatable;
import androidx.compose.animation.core.AnimationSpec;
import androidx.compose.animation.core.ArcSplineKt;
import androidx.compose.animation.core.Easing;
import androidx.compose.animation.core.EasingKt;
import androidx.compose.animation.core.TweenSpec;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlinx.coroutines.CoroutineScope;
import org.jsoup.parser.CharacterReader$;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final class CardsKt$Hours$2$1 extends SuspendLambda implements Function2 {
    public final /* synthetic */ Animatable $clock;
    public final /* synthetic */ byte $r8$classId;
    public boolean label;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ CardsKt$Hours$2$1(Animatable animatable, Continuation continuation, byte b) {
        super(2, continuation);
        this.$r8$classId = b;
        this.$clock = animatable;
    }

    public final Continuation create(Object obj, Continuation continuation) {
        switch (this.$r8$classId) {
            case 0:
                return new CardsKt$Hours$2$1(this.$clock, continuation, (byte) 0);
            case 1:
                return new CardsKt$Hours$2$1(this.$clock, continuation, (byte) 1);
            default:
                return new CardsKt$Hours$2$1(this.$clock, continuation, (byte) 2);
        }
    }

    public final Object invoke(Object obj, Object obj2) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        CoroutineScope coroutineScope = (CoroutineScope) obj;
        Continuation continuation = (Continuation) obj2;
        switch (b) {
            case 0:
                break;
            case 1:
                break;
        }
        return create(coroutineScope, continuation).invokeSuspend(unit);
    }

    public final Object invokeSuspend(Object obj) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        switch (b) {
            case 0:
                boolean z = this.label;
                if (z) {
                    if (z) {
                        ResultKt.throwOnFailure(obj);
                        return unit;
                    }
                    CharacterReader$.ExternalSyntheticLambda2.m$2("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                ResultKt.throwOnFailure(obj);
                Float f = new Float(2500.0f);
                TweenSpec tweenSpecTween$default = ArcSplineKt.tween$default(2500, 0, EasingKt.LinearEasing, 2);
                this.label = true;
                return Animatable.animateTo$default(this.$clock, f, tweenSpecTween$default, (Function1) null, this, 12) == coroutineSingletons ? coroutineSingletons : unit;
            case 1:
                boolean z2 = this.label;
                if (!z2) {
                    ResultKt.throwOnFailure(obj);
                    Float f2 = new Float(0.0f);
                    this.label = true;
                    return Animatable.animateTo$default(this.$clock, f2, (AnimationSpec) null, (Function1) null, this, 14) == coroutineSingletons ? coroutineSingletons : unit;
                }
                if (z2) {
                    ResultKt.throwOnFailure(obj);
                    return unit;
                }
                CharacterReader$.ExternalSyntheticLambda2.m$2("call to 'resume' before 'invoke' with coroutine");
                return null;
            default:
                boolean z3 = this.label;
                if (z3) {
                    if (z3) {
                        ResultKt.throwOnFailure(obj);
                        return unit;
                    }
                    CharacterReader$.ExternalSyntheticLambda2.m$2("call to 'resume' before 'invoke' with coroutine");
                    return null;
                }
                ResultKt.throwOnFailure(obj);
                Float f3 = new Float(1.0f);
                TweenSpec tweenSpecTween$default2 = ArcSplineKt.tween$default(250, 0, (Easing) null, 6);
                this.label = true;
                return Animatable.animateTo$default(this.$clock, f3, tweenSpecTween$default2, (Function1) null, this, 12) == coroutineSingletons ? coroutineSingletons : unit;
        }
    }
}
