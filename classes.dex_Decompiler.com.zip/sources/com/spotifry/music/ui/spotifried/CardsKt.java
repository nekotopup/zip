package com.spotifry.music.ui.spotifried;

import android.os.Build;
import androidx.compose.animation.core.Animatable;
import androidx.compose.animation.core.ArcSplineKt;
import androidx.compose.animation.core.CubicBezierEasing;
import androidx.compose.animation.core.EasingKt;
import androidx.compose.animation.core.InfiniteTransition;
import androidx.compose.animation.core.RepeatMode;
import androidx.compose.foundation.BorderStroke;
import androidx.compose.foundation.ImageKt;
import androidx.compose.foundation.ScrollState;
import androidx.compose.foundation.layout.Arrangement;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.BoxWithConstraintsScopeImpl;
import androidx.compose.foundation.layout.ColumnKt;
import androidx.compose.foundation.layout.ColumnMeasurePolicy;
import androidx.compose.foundation.layout.ColumnScopeInstance;
import androidx.compose.foundation.layout.HorizontalAlignElement;
import androidx.compose.foundation.layout.LayoutWeightElement;
import androidx.compose.foundation.layout.OffsetKt;
import androidx.compose.foundation.layout.PaddingValuesImpl;
import androidx.compose.foundation.layout.RowKt;
import androidx.compose.foundation.layout.RowMeasurePolicy;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.foundation.layout.WithAlignmentLineElement;
import androidx.compose.foundation.shape.RoundedCornerShape;
import androidx.compose.foundation.shape.RoundedCornerShapeKt;
import androidx.compose.material3.ButtonDefaults;
import androidx.compose.material3.ButtonElevation;
import androidx.compose.material3.ColorScheme;
import androidx.compose.material3.ColorSchemeKt;
import androidx.compose.material3.MenuKt;
import androidx.compose.material3.SliderDefaults$;
import androidx.compose.material3.TextKt;
import androidx.compose.runtime.AnchoredGroupPath;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerImpl;
import androidx.compose.runtime.MutableState;
import androidx.compose.runtime.NeverEqualPolicy;
import androidx.compose.runtime.ParcelableSnapshotMutableFloatState;
import androidx.compose.runtime.ParcelableSnapshotMutableLongState;
import androidx.compose.runtime.RecomposeScopeImpl;
import androidx.compose.runtime.SnapshotStateKt__DerivedStateKt;
import androidx.compose.runtime.State;
import androidx.compose.runtime.StaticProvidableCompositionLocal;
import androidx.compose.runtime.internal.ComposableLambdaImpl;
import androidx.compose.runtime.internal.Expect_jvmKt;
import androidx.compose.runtime.internal.PersistentCompositionLocalHashMap;
import androidx.compose.ui.AbsoluteAlignment;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.BiasAlignment;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.draw.BlurKt;
import androidx.compose.ui.draw.ClipKt;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.ui.graphics.ReusableGraphicsLayerScope;
import androidx.compose.ui.graphics.Shadow;
import androidx.compose.ui.graphics.Shape;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import androidx.compose.ui.graphics.drawscope.Stroke;
import androidx.compose.ui.layout.AlignmentLineKt;
import androidx.compose.ui.layout.HorizontalAlignmentLine;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.layout.RulerKt;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.node.LayoutNode;
import androidx.compose.ui.platform.CompositionLocalsKt;
import androidx.compose.ui.platform.TestTagKt;
import androidx.compose.ui.semantics.SemanticsModifierKt;
import androidx.compose.ui.text.AnnotatedString;
import androidx.compose.ui.text.MultiParagraph$;
import androidx.compose.ui.text.ParagraphKt;
import androidx.compose.ui.text.SaversKt$;
import androidx.compose.ui.text.SpanStyle;
import androidx.compose.ui.text.TextMeasurer;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontListFontFamily;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontSynthesis;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.intl.LocaleList;
import androidx.compose.ui.text.style.BaselineShift;
import androidx.compose.ui.text.style.LineHeightStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.style.TextGeometricTransform;
import androidx.compose.ui.unit.Constraints;
import androidx.compose.ui.unit.ConstraintsKt;
import androidx.compose.ui.unit.Density;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnit;
import androidx.media3.session.MediaSessionStub$;
import androidx.room.RoomDatabase$;
import androidx.work.OperationKt$;
import com.google.protobuf.FieldSet$;
import com.spotifry.music.MainActivityKt$;
import com.spotifry.music.data.Log;
import com.spotifry.music.data.TopSong;
import com.spotifry.music.data.db.SongEntity;
import com.spotifry.music.data.spotifried.AgeStats;
import com.spotifry.music.data.spotifried.ArtistShare;
import com.spotifry.music.data.spotifried.ListenerType;
import com.spotifry.music.data.spotifried.MonthTop;
import com.spotifry.music.data.spotifried.ObsessionDay;
import com.spotifry.music.data.spotifried.SpotifriedStats;
import com.spotifry.music.data.spotifried.WrappedPeriod;
import com.spotifry.music.ui.components.CoverKt;
import com.spotifry.music.ui.components.FadeInKt$;
import com.spotifry.music.ui.home.PageScreenKt$;
import com.spotifry.music.ui.listening.ListeningScreenKt;
import com.spotifry.music.ui.listening.SunKt;
import com.spotifry.music.ui.listening.SunKt$;
import com.spotifry.music.ui.listening.SunMotion;
import com.spotifry.music.ui.theme.TypeKt;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Pair;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.UnsignedKt;
import kotlin.collections.AbstractMap$;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.CollectionsKt__MutableCollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Intrinsics;
import kotlin.math.MathKt;
import kotlin.ranges.IntProgression;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlin.sequences.FilteringSequence;
import kotlin.sequences.SequencesKt;
import kotlin.sequences.TakeWhileSequence;
import kotlin.text.MatcherMatchResult;
import kotlin.text.Regex$;
import kotlin.text.RegexKt;
import kotlin.text.StringsKt;
import okhttp3.ConnectionPool;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public abstract class CardsKt {
    public static final CubicBezierEasing Ease = new CubicBezierEasing(0.16f, 1.0f, 0.3f, 1.0f);
    public static final TextStyle Headline;
    public static final float RISE;
    public static final TextStyle Sub;
    public static final float WIDE_BAR;
    public static final Locale english;

    static {
        FontListFontFamily fontListFontFamily = TypeKt.Albert;
        Headline = new TextStyle(0L, UnsignedKt.getSp(46), FontWeight.Black, fontListFontFamily, UnsignedKt.getSp(-1.6d), 0, UnsignedKt.getSp(45), 0, 16645977);
        Sub = new TextStyle(0L, UnsignedKt.getSp(15), (FontWeight) null, fontListFontFamily, 0L, 0, UnsignedKt.getSp(22), 0, 16646109);
        english = Locale.ENGLISH;
        WIDE_BAR = 14.0f;
        RISE = 18.0f;
    }

    public static final void Age(SpotifriedStats spotifriedStats, final int i, final int i2, boolean z, ComposerImpl composerImpl, int i3) {
        int i4;
        Integer num;
        composerImpl.startRestartGroup(1137322841);
        int i5 = (i3 & 6) == 0 ? (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i3 : i3;
        if ((i3 & 48) == 0) {
            i5 |= composerImpl.changed(i) ? 32 : 16;
        }
        if ((i3 & 384) == 0) {
            i5 |= composerImpl.changed(i2) ? 256 : 128;
        }
        if ((i3 & 3072) == 0) {
            i5 |= composerImpl.changed(z) ? 2048 : 1024;
        }
        if (composerImpl.shouldExecute(i5 & 1, (i5 & 1171) != 1170)) {
            StaticProvidableCompositionLocal staticProvidableCompositionLocal = ColorSchemeKt.LocalColorScheme;
            final long j = ((ColorScheme) composerImpl.consume(staticProvidableCompositionLocal)).primary;
            final long j2 = ((ColorScheme) composerImpl.consume(staticProvidableCompositionLocal)).onBackground;
            final long j3 = Color.copy-wmQWz5c$default(0.14f, j2);
            final AgeStats ageStats = spotifriedStats.age;
            Integer num2 = ageStats.typicalYear;
            List list = ageStats.years;
            if (ageStats.age == null) {
                num2 = null;
            }
            boolean zChanged = composerImpl.changed(list);
            Object objRememberedValue = composerImpl.rememberedValue();
            if (zChanged || objRememberedValue == Composer.Companion.Empty) {
                List listSorted = CollectionsKt.sorted(list);
                LinkedHashMap linkedHashMap = new LinkedHashMap();
                for (Object obj : listSorted) {
                    Integer numValueOf = Integer.valueOf(((Number) obj).intValue());
                    Object obj2 = linkedHashMap.get(numValueOf);
                    if (obj2 == null) {
                        ArrayList arrayList = new ArrayList();
                        linkedHashMap.put(numValueOf, arrayList);
                        obj2 = arrayList;
                    }
                    ((List) obj2).add(obj);
                }
                ArrayList arrayList2 = new ArrayList();
                for (Map.Entry entry : linkedHashMap.entrySet()) {
                    int iIntValue = ((Number) entry.getKey()).intValue();
                    int i6 = i5;
                    Integer num3 = num2;
                    ArrayList arrayList3 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(ByteStreamsKt.getIndices((List) entry.getValue()), 10));
                    for (Iterator it = r7.iterator(); ((IntProgressionIterator) it).hasNext; it = it) {
                        arrayList3.add(new Pair(Integer.valueOf(iIntValue), Integer.valueOf(((IntIterator) it).nextInt())));
                    }
                    CollectionsKt__MutableCollectionsKt.addAll$1(arrayList3, arrayList2);
                    i5 = i6;
                    num2 = num3;
                }
                i4 = i5;
                num = num2;
                composerImpl.updateRememberedValue(arrayList2);
                objRememberedValue = arrayList2;
            } else {
                i4 = i5;
                num = num2;
            }
            final List list2 = (List) objRememberedValue;
            Integer num4 = (Integer) CollectionsKt.minOrNull(list);
            final int iMin = Math.min(1960, ((num4 != null ? num4.intValue() : 1960) / 10) * 10);
            int year = spotifriedStats.period.to.getYear();
            Integer num5 = (Integer) CollectionsKt.maxOrNull(list);
            final int iMax = Math.max(year, Math.max(num5 != null ? num5.intValue() : 0, iMin + 20));
            final Animatable animatableClock = clock(z, 4600.0f, composerImpl, ((i4 >> 9) & 14) | 48);
            final float fontScale = ((Density) composerImpl.consume(CompositionLocalsKt.LocalDensity)).getFontScale();
            final Integer num6 = num;
            OffsetKt.BoxWithConstraints(SizeKt.fillMaxSize(Modifier.Companion.$$INSTANCE, 1.0f), (BiasAlignment) null, Expect_jvmKt.rememberComposableLambda(-1757076945, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda21
                public final Object invoke(Object obj3, Object obj4, Object obj5) {
                    BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl = (BoxWithConstraintsScopeImpl) obj3;
                    ComposerImpl composerImpl2 = (ComposerImpl) obj4;
                    int iIntValue2 = ((Integer) obj5).intValue();
                    boxWithConstraintsScopeImpl.getClass();
                    if ((iIntValue2 & 6) == 0) {
                        iIntValue2 |= composerImpl2.changed(boxWithConstraintsScopeImpl) ? 4 : 2;
                    }
                    if (composerImpl2.shouldExecute(iIntValue2 & 1, (iIntValue2 & 19) != 18)) {
                        final Integer num7 = num6;
                        final boolean z2 = num7 == null && Float.compare(boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM(), 520.0f) >= 0 && fontScale < 1.5f;
                        final AgeStats ageStats2 = ageStats;
                        final Animatable animatable = animatableClock;
                        final int i7 = i;
                        final int i8 = i2;
                        final long j4 = j3;
                        final long j5 = j;
                        final List list3 = list2;
                        final int i9 = iMin;
                        final int i10 = iMax;
                        final long j6 = j2;
                        CardsKt.CardColumn(Expect_jvmKt.rememberComposableLambda(841137234, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda39
                            public final Object invoke(Object obj6, Object obj7, Object obj8) {
                                Integer num8;
                                String str;
                                boolean z3;
                                final long j7;
                                ComposerImpl composerImpl3;
                                ColumnScopeInstance columnScopeInstance;
                                int i11;
                                Modifier modifier;
                                ComposerImpl composerImpl4;
                                boolean z4;
                                TextStyle textStyle;
                                Object next;
                                String strM;
                                ColumnScopeInstance columnScopeInstance2 = (ColumnScopeInstance) obj6;
                                ComposerImpl composerImpl5 = (ComposerImpl) obj7;
                                int iIntValue3 = ((Integer) obj8).intValue();
                                columnScopeInstance2.getClass();
                                if ((iIntValue3 & 6) == 0) {
                                    iIntValue3 |= composerImpl5.changed(columnScopeInstance2) ? 4 : 2;
                                }
                                if (composerImpl5.shouldExecute(iIntValue3 & 1, (iIntValue3 & 19) != 18)) {
                                    TextStyle textStyle2 = TextStyle.copy-p1EtxEg$default(CardsKt.Headline, 0L, UnsignedKt.getSp(40), (FontWeight) null, (FontStyle) null, (FontFamily) null, UnsignedKt.getSp(-1.4d), (Shadow) null, UnsignedKt.getSp(40), (LineHeightStyle) null, 0, 16646013);
                                    Integer num9 = num7;
                                    long j8 = j5;
                                    if (num9 != null) {
                                        composerImpl5.startReplaceGroup(1480266749);
                                        AnnotatedString.Builder builder = new AnnotatedString.Builder();
                                        builder.append("You listen like someone who was ");
                                        j7 = j8;
                                        int iPushStyle = builder.pushStyle(new SpanStyle(j8, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
                                        try {
                                            builder.append("14 in " + num9 + ".");
                                            builder.pop(iPushStyle);
                                            str = ".";
                                            z3 = false;
                                            num8 = num9;
                                            TextKt.Text-Z58ophY(builder.toAnnotatedString(), (Modifier) null, 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, textStyle2, composerImpl5, 0, 0, 262142);
                                            composerImpl3 = composerImpl5;
                                            composerImpl3.end(false);
                                        } catch (Throwable th) {
                                            builder.pop(iPushStyle);
                                            throw th;
                                        }
                                    } else {
                                        num8 = num9;
                                        str = ".";
                                        z3 = false;
                                        composerImpl5.startReplaceGroup(1480449494);
                                        AnnotatedString.Builder builder2 = new AnnotatedString.Builder();
                                        builder2.append("How old is ");
                                        j7 = j8;
                                        int iPushStyle2 = builder2.pushStyle(new SpanStyle(j8, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
                                        try {
                                            builder2.append("your music?");
                                            builder2.pop(iPushStyle2);
                                            TextKt.Text-Z58ophY(builder2.toAnnotatedString(), (Modifier) null, 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, textStyle2, composerImpl5, 0, 0, 262142);
                                            composerImpl3 = composerImpl5;
                                            composerImpl3.end(false);
                                        } catch (Throwable th2) {
                                            builder2.pop(iPushStyle2);
                                            throw th2;
                                        }
                                    }
                                    boolean z5 = z2;
                                    if (z5) {
                                        composerImpl3.startReplaceGroup(879045934);
                                        columnScopeInstance = columnScopeInstance2;
                                        OffsetKt.Spacer(composerImpl3, ColumnScopeInstance.weight$default(columnScopeInstance, 0.6f));
                                    } else {
                                        columnScopeInstance = columnScopeInstance2;
                                        composerImpl3.startReplaceGroup(1454993968);
                                    }
                                    composerImpl3.end(z3);
                                    Modifier modifierClipToBounds = ClipKt.clipToBounds(SizeKt.fillMaxWidth(ColumnScopeInstance.weight$default(columnScopeInstance, z5 ? 0.7f : 1.0f), 1.0f));
                                    final List list4 = list3;
                                    final long j9 = j4;
                                    final Animatable animatable2 = animatable;
                                    final int i12 = i9;
                                    final int i13 = i10;
                                    final long j10 = j6;
                                    final AgeStats ageStats3 = ageStats2;
                                    final Integer num10 = num8;
                                    OffsetKt.BoxWithConstraints(modifierClipToBounds, (BiasAlignment) null, Expect_jvmKt.rememberComposableLambda(1541863464, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda63
                                        public final Object invoke(Object obj9, Object obj10, Object obj11) {
                                            Integer numValueOf2;
                                            ComposerImpl composerImpl6;
                                            float f;
                                            List list5;
                                            float f2;
                                            Object obj12;
                                            Modifier modifier2;
                                            Animatable animatable3;
                                            int i14;
                                            boolean z6;
                                            Object obj13;
                                            BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl2 = (BoxWithConstraintsScopeImpl) obj9;
                                            ComposerImpl composerImpl7 = (ComposerImpl) obj10;
                                            int iIntValue4 = ((Integer) obj11).intValue();
                                            boxWithConstraintsScopeImpl2.getClass();
                                            if ((iIntValue4 & 6) == 0) {
                                                iIntValue4 |= composerImpl7.changed(boxWithConstraintsScopeImpl2) ? 4 : 2;
                                            }
                                            if (composerImpl7.shouldExecute(iIntValue4 & 1, (iIntValue4 & 19) != 18)) {
                                                final float f3 = boxWithConstraintsScopeImpl2.getMaxHeight-D9Ej5fM() - 22.0f;
                                                TextStyle textStyle3 = TextStyle.copy-p1EtxEg$default(CardsKt.Sub, 0L, UnsignedKt.getSp(11), (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, UnsignedKt.getSp(14), (LineHeightStyle) null, 0, 16646141);
                                                Density density = (Density) composerImpl7.consume(CompositionLocalsKt.LocalDensity);
                                                float f4 = density.toDp-GaN1DYA(textStyle3.paragraphStyle.lineHeight);
                                                final List list6 = list4;
                                                Iterator it2 = list6.iterator();
                                                Integer num11 = null;
                                                if (it2.hasNext()) {
                                                    numValueOf2 = Integer.valueOf(((Number) ((Pair) it2.next()).second).intValue());
                                                    while (it2.hasNext()) {
                                                        Integer numValueOf3 = Integer.valueOf(((Number) ((Pair) it2.next()).second).intValue());
                                                        if (numValueOf2.compareTo(numValueOf3) < 0) {
                                                            numValueOf2 = numValueOf3;
                                                        }
                                                    }
                                                } else {
                                                    numValueOf2 = null;
                                                }
                                                int iIntValue5 = numValueOf2 != null ? numValueOf2.intValue() : 0;
                                                float f5 = f3 - 12.0f;
                                                float f6 = f5 - (((22.0f + f4) + 8.0f) + 4.0f);
                                                float f7 = 10.0f;
                                                if (iIntValue5 != 0) {
                                                    Dp dp = new Dp(10.0f);
                                                    Dp dp2 = new Dp(f6);
                                                    Dp dp3 = new Dp(0.0f);
                                                    if (dp2.compareTo(dp3) < 0) {
                                                        dp2 = dp3;
                                                    }
                                                    Dp dp4 = new Dp(dp2.value / iIntValue5);
                                                    if (dp.compareTo(dp4) > 0) {
                                                        dp = dp4;
                                                    }
                                                    f7 = dp.value;
                                                }
                                                final float f8 = f7;
                                                final float f9 = ResultKt.coerceIn(new Dp(0.8f * f8), new Dp(3.0f), new Dp(8.0f)).value;
                                                float f10 = density.toPx-0680j_4(18.0f);
                                                TextMeasurer textMeasurerRememberTextMeasurer = ParagraphKt.rememberTextMeasurer(0, composerImpl7, 0, 1);
                                                Modifier modifier3 = Modifier.Companion.$$INSTANCE;
                                                final BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl3 = boxWithConstraintsScopeImpl2;
                                                int i15 = iIntValue4;
                                                Modifier modifierFillMaxSize = SizeKt.fillMaxSize(modifier3, 1.0f);
                                                boolean zChanged2 = composerImpl7.changed(f3);
                                                final long j11 = j9;
                                                boolean zChanged3 = zChanged2 | composerImpl7.changed(j11) | composerImpl7.changedInstance(list6);
                                                final Animatable animatable4 = animatable2;
                                                boolean zChangedInstance = zChanged3 | composerImpl7.changedInstance(animatable4);
                                                final int i16 = i12;
                                                boolean zChanged4 = zChangedInstance | composerImpl7.changed(i16);
                                                final int i17 = i13;
                                                boolean zChanged5 = zChanged4 | composerImpl7.changed(i17) | composerImpl7.changed(f8);
                                                final long j12 = j10;
                                                boolean zChanged6 = zChanged5 | composerImpl7.changed(j12) | composerImpl7.changed(f9);
                                                boolean z7 = (i15 & 14) == 4;
                                                final Integer num12 = num10;
                                                boolean zChanged7 = zChanged6 | z7 | composerImpl7.changed(num12);
                                                TextStyle textStyle4 = textStyle3;
                                                final long j13 = j7;
                                                boolean zChanged8 = zChanged7 | composerImpl7.changed(j13);
                                                Object objRememberedValue2 = composerImpl7.rememberedValue();
                                                NeverEqualPolicy neverEqualPolicy = Composer.Companion.Empty;
                                                if (zChanged8 || objRememberedValue2 == neverEqualPolicy) {
                                                    composerImpl6 = composerImpl7;
                                                    f = f10;
                                                    Function1 function1 = new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda69
                                                        public final Object invoke(Object obj14) {
                                                            Animatable animatable5;
                                                            int i18;
                                                            int i19;
                                                            BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl4;
                                                            DrawScope drawScope = (DrawScope) obj14;
                                                            drawScope.getClass();
                                                            float f11 = drawScope.toPx-0680j_4(f3);
                                                            long j14 = 4294967295L;
                                                            DrawScope.drawRect-n-J9OG0$default(drawScope, j11, ((long) Float.floatToRawIntBits(f11)) & 4294967295L, (((long) Float.floatToRawIntBits(Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() >> 32)))) << 32) | (((long) Float.floatToRawIntBits(drawScope.toPx-0680j_4(1.0f))) & 4294967295L), 0.0f, 0, 120);
                                                            Iterator it3 = list6.iterator();
                                                            while (true) {
                                                                boolean zHasNext = it3.hasNext();
                                                                animatable5 = animatable4;
                                                                i18 = i16;
                                                                i19 = i17;
                                                                boxWithConstraintsScopeImpl4 = boxWithConstraintsScopeImpl3;
                                                                if (!zHasNext) {
                                                                    break;
                                                                }
                                                                Pair pair = (Pair) it3.next();
                                                                int iIntValue6 = ((Number) pair.first).intValue();
                                                                long j15 = j14;
                                                                float fIntValue = ((Number) pair.second).intValue();
                                                                float fStepAt = CardsKt.stepAt(((Number) animatable5.getValue()).floatValue(), (25.0f * fIntValue) + (((iIntValue6 - i18) * 1450.0f) / (i19 - i18)) + 300.0f, 800.0f);
                                                                float f12 = ((f11 - drawScope.toPx-0680j_4(12.0f)) - (drawScope.toPx-0680j_4(f8) * fIntValue)) - (drawScope.toPx-0680j_4(120.0f) * (1.0f - fStepAt));
                                                                DrawScope.drawCircle-VaOC9Bg$default(drawScope, j12, drawScope.toPx-0680j_4(f9) / 2.0f, (Float.floatToRawIntBits(drawScope.toPx-0680j_4(CardsKt.Age$lambda$123$lambda$122$lambda$111$xOf(boxWithConstraintsScopeImpl4, i18, i19, iIntValue6))) << 32) | (((long) Float.floatToRawIntBits(f12)) & j15), fStepAt * 0.9f, (DrawStyle) null, 112);
                                                                j14 = j15;
                                                            }
                                                            long j16 = j14;
                                                            Integer num13 = num12;
                                                            if (num13 != null) {
                                                                float fStepAt2 = CardsKt.stepAt(((Number) animatable5.getValue()).floatValue(), 2200.0f, 800.0f);
                                                                float f13 = drawScope.toPx-0680j_4(26.0f);
                                                                float f14 = drawScope.toPx-0680j_4(CardsKt.Age$lambda$123$lambda$122$lambda$111$xOf(boxWithConstraintsScopeImpl4, i18, i19, num13.intValue())) - drawScope.toPx-0680j_4(1.0f);
                                                                float f15 = (f11 - f13) * fStepAt2;
                                                                long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(f14)) << 32) | (((long) Float.floatToRawIntBits(f11 - f15)) & j16);
                                                                long jFloatToRawIntBits2 = (((long) Float.floatToRawIntBits(drawScope.toPx-0680j_4(2.0f))) << 32) | (((long) Float.floatToRawIntBits(f15)) & j16);
                                                                float f16 = drawScope.toPx-0680j_4(1.0f);
                                                                DrawScope.drawRoundRect-u-Aw5IA$default(drawScope, j13, jFloatToRawIntBits, jFloatToRawIntBits2, (((long) Float.floatToRawIntBits(f16)) << 32) | (((long) Float.floatToRawIntBits(f16)) & j16), (Stroke) null, 0.0f, 240);
                                                            }
                                                            return Unit.INSTANCE;
                                                        }
                                                    };
                                                    list5 = list6;
                                                    composerImpl6.updateRememberedValue(function1);
                                                    objRememberedValue2 = function1;
                                                } else {
                                                    f = f10;
                                                    composerImpl6 = composerImpl7;
                                                    list5 = list6;
                                                }
                                                ImageKt.Canvas(modifierFillMaxSize, (Function1) objRememberedValue2, composerImpl6, 6);
                                                int i18 = i17 - i16 > 100 ? 40 : 20;
                                                composerImpl6.startReplaceGroup(-32874389);
                                                for (Iterator it3 = ResultKt.step(i18, new IntRange((((i16 + i18) - 1) / i18) * i18, i17, 1)).iterator(); ((IntProgressionIterator) it3).hasNext; it3 = it3) {
                                                    int iNextInt = ((IntIterator) it3).nextInt();
                                                    ComposerImpl composerImpl8 = composerImpl6;
                                                    TextKt.Text-Nvy7gAk(String.valueOf(iNextInt), RulerKt.layout(boxWithConstraintsScopeImpl3.align(modifier3, Alignment.Companion.BottomStart), new CardsKt$$ExternalSyntheticLambda50(CardsKt.Age$lambda$123$lambda$122$lambda$111$xOf(boxWithConstraintsScopeImpl3, i16, i17, iNextInt), 0.5f)), CardsKt.soft(composerImpl6), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, textStyle4, composerImpl8, 0, 0, 131064);
                                                    boxWithConstraintsScopeImpl3 = boxWithConstraintsScopeImpl3;
                                                    i16 = i16;
                                                    composerImpl6 = composerImpl8;
                                                    animatable4 = animatable4;
                                                    i17 = i17;
                                                }
                                                BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl4 = boxWithConstraintsScopeImpl3;
                                                ComposerImpl composerImpl9 = composerImpl6;
                                                int i19 = i16;
                                                int i20 = i17;
                                                Animatable animatable5 = animatable4;
                                                composerImpl9.end(false);
                                                if (num12 != null) {
                                                    composerImpl9.startReplaceGroup(-32868925);
                                                    String strValueOf = String.valueOf(num12);
                                                    Modifier modifier4 = OffsetKt.padding-qDBjuR0$default(RulerKt.layout(modifier3, new CardsKt$$ExternalSyntheticLambda50(CardsKt.Age$lambda$123$lambda$122$lambda$111$xOf(boxWithConstraintsScopeImpl4, i19, i20, num12.intValue()), 0.5f)), 0.0f, 4.0f, 0.0f, 0.0f, 13);
                                                    f2 = 4.0f;
                                                    float f11 = f;
                                                    boolean zChangedInstance2 = composerImpl9.changedInstance(animatable5) | composerImpl9.changed(f11);
                                                    Object objRememberedValue3 = composerImpl9.rememberedValue();
                                                    if (zChangedInstance2) {
                                                        obj13 = neverEqualPolicy;
                                                    } else {
                                                        obj13 = neverEqualPolicy;
                                                        if (objRememberedValue3 == obj13) {
                                                        }
                                                        Modifier modifierGraphicsLayer = ColorKt.graphicsLayer(modifier4, (Function1) objRememberedValue3);
                                                        TextStyle textStyle5 = TextStyle.copy-p1EtxEg$default(textStyle4, 0L, UnsignedKt.getSp(12), FontWeight.ExtraBold, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, 0L, (LineHeightStyle) null, 0, 16777209);
                                                        textStyle4 = textStyle4;
                                                        modifier2 = modifier3;
                                                        i14 = i20;
                                                        animatable3 = animatable5;
                                                        obj12 = obj13;
                                                        TextKt.Text-Nvy7gAk(strValueOf, modifierGraphicsLayer, j13, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, textStyle5, composerImpl9, 0, 0, 131064);
                                                        composerImpl9 = composerImpl9;
                                                        z6 = false;
                                                    }
                                                    objRememberedValue3 = new CardsKt$$ExternalSyntheticLambda37(animatable5, f11, (byte) 4);
                                                    composerImpl9.updateRememberedValue(objRememberedValue3);
                                                    Modifier modifierGraphicsLayer2 = ColorKt.graphicsLayer(modifier4, (Function1) objRememberedValue3);
                                                    TextStyle textStyle6 = TextStyle.copy-p1EtxEg$default(textStyle4, 0L, UnsignedKt.getSp(12), FontWeight.ExtraBold, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, 0L, (LineHeightStyle) null, 0, 16777209);
                                                    textStyle4 = textStyle4;
                                                    modifier2 = modifier3;
                                                    i14 = i20;
                                                    animatable3 = animatable5;
                                                    obj12 = obj13;
                                                    TextKt.Text-Nvy7gAk(strValueOf, modifierGraphicsLayer2, j13, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, textStyle6, composerImpl9, 0, 0, 131064);
                                                    composerImpl9 = composerImpl9;
                                                    z6 = false;
                                                } else {
                                                    f2 = 4.0f;
                                                    obj12 = neverEqualPolicy;
                                                    modifier2 = modifier3;
                                                    animatable3 = animatable5;
                                                    i14 = i20;
                                                    z6 = false;
                                                    composerImpl9.startReplaceGroup(-1046528006);
                                                }
                                                composerImpl9.end(z6);
                                                Integer num13 = ageStats3.oldestYear;
                                                if (num13 == null) {
                                                    composerImpl9.startReplaceGroup(-1018568704);
                                                } else {
                                                    composerImpl9.startReplaceGroup(-1018568703);
                                                    int iIntValue6 = num13.intValue();
                                                    String strM2 = FieldSet$.ExternalSyntheticOutline0.m(iIntValue6, ", your oldest");
                                                    float f12 = density.toDp-u2uoSUM((int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, strM2, textStyle4, 0, 0L, 1020).size >> 32));
                                                    int i21 = i14;
                                                    Dp dp5 = new Dp((CardsKt.Age$lambda$123$lambda$122$lambda$111$xOf(boxWithConstraintsScopeImpl4, i19, i21, iIntValue6) + f2) - f12);
                                                    Dp dp6 = new Dp(0.0f);
                                                    if (dp5.compareTo(dp6) < 0) {
                                                        dp5 = dp6;
                                                    }
                                                    ArrayList arrayList4 = new ArrayList();
                                                    for (Object obj14 : list5) {
                                                        float f13 = dp5.value;
                                                        float f14 = f13 - f2;
                                                        float f15 = f13 + f12 + f2;
                                                        float fAge$lambda$123$lambda$122$lambda$111$xOf = CardsKt.Age$lambda$123$lambda$122$lambda$111$xOf(boxWithConstraintsScopeImpl4, i19, i21, ((Number) ((Pair) obj14).first).intValue());
                                                        if (Float.compare(fAge$lambda$123$lambda$122$lambda$111$xOf, f14) >= 0 && Float.compare(fAge$lambda$123$lambda$122$lambda$111$xOf, f15) <= 0) {
                                                            arrayList4.add(obj14);
                                                        }
                                                    }
                                                    Iterator it4 = arrayList4.iterator();
                                                    if (it4.hasNext()) {
                                                        Integer numValueOf4 = Integer.valueOf(((Number) ((Pair) it4.next()).second).intValue());
                                                        while (it4.hasNext()) {
                                                            Integer numValueOf5 = Integer.valueOf(((Number) ((Pair) it4.next()).second).intValue());
                                                            if (numValueOf4.compareTo(numValueOf5) < 0) {
                                                                numValueOf4 = numValueOf5;
                                                            }
                                                        }
                                                        num11 = numValueOf4;
                                                    }
                                                    float fIntValue = (((f5 - (f8 * (num11 != null ? num11.intValue() : 0))) - f2) - 8.0f) - f4;
                                                    if (num12 != null || Float.compare(fIntValue, 0.0f) >= 0) {
                                                        if (num12 != null) {
                                                            Dp dp7 = new Dp(fIntValue);
                                                            Dp dp8 = new Dp(22.0f);
                                                            if (dp7.compareTo(dp8) < 0) {
                                                                dp7 = dp8;
                                                            }
                                                            fIntValue = dp7.value;
                                                        }
                                                        Modifier modifierLayout = RulerKt.layout(OffsetKt.offset-VpY3zN4$default(modifier2, 0.0f, fIntValue, 1), new CardsKt$$ExternalSyntheticLambda50(CardsKt.Age$lambda$123$lambda$122$lambda$111$xOf(boxWithConstraintsScopeImpl4, i19, i21, iIntValue6) + f2, 1.0f));
                                                        Animatable animatable6 = animatable3;
                                                        boolean zChangedInstance3 = composerImpl9.changedInstance(animatable6);
                                                        Object objRememberedValue4 = composerImpl9.rememberedValue();
                                                        if (zChangedInstance3 || objRememberedValue4 == obj12) {
                                                            objRememberedValue4 = new FadeInKt$.ExternalSyntheticLambda1(animatable6, (byte) 5);
                                                            composerImpl9.updateRememberedValue(objRememberedValue4);
                                                        }
                                                        ComposerImpl composerImpl10 = composerImpl9;
                                                        TextKt.Text-Nvy7gAk(strM2, ColorKt.graphicsLayer(modifierLayout, (Function1) objRememberedValue4), CardsKt.soft(composerImpl9), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 1, 0, (Function1) null, textStyle4, composerImpl10, 0, 24576, 114680);
                                                        composerImpl9 = composerImpl10;
                                                    }
                                                    z6 = false;
                                                }
                                                composerImpl9.end(z6);
                                            } else {
                                                composerImpl7.skipToGroupEnd();
                                            }
                                            return Unit.INSTANCE;
                                        }
                                    }, composerImpl3), composerImpl3, 3072, 6);
                                    Modifier modifier2 = Modifier.Companion.$$INSTANCE;
                                    Object obj9 = Composer.Companion.Empty;
                                    if (num10 != null) {
                                        composerImpl3.startReplaceGroup(1484228642);
                                        Integer num11 = ageStats3.age;
                                        num11.getClass();
                                        String strCount = ListeningScreenKt.count(MathKt.roundToInt(CardsKt.stepAt(((Number) animatable2.getValue()).floatValue(), 3000.0f, 900.0f) * num11.intValue()));
                                        boolean zChangedInstance = composerImpl3.changedInstance(animatable2);
                                        Object objRememberedValue2 = composerImpl3.rememberedValue();
                                        if (zChangedInstance || objRememberedValue2 == obj9) {
                                            objRememberedValue2 = new CardsKt$$ExternalSyntheticLambda11(animatable2, (byte) 1);
                                            composerImpl3.updateRememberedValue(objRememberedValue2);
                                        }
                                        Function0 function0 = (Function0) objRememberedValue2;
                                        Iterator it2 = MathKt.eachCount(new ConnectionPool(ageStats3.years)).entrySet().iterator();
                                        if (it2.hasNext()) {
                                            next = it2.next();
                                            if (it2.hasNext()) {
                                                int iIntValue4 = ((Number) ((Map.Entry) next).getValue()).intValue();
                                                do {
                                                    Object next2 = it2.next();
                                                    int iIntValue5 = ((Number) ((Map.Entry) next2).getValue()).intValue();
                                                    if (iIntValue4 < iIntValue5) {
                                                        next = next2;
                                                        iIntValue4 = iIntValue5;
                                                    }
                                                } while (it2.hasNext());
                                            }
                                        } else {
                                            next = null;
                                        }
                                        Map.Entry entry2 = (Map.Entry) next;
                                        Integer num12 = entry2 != null ? (Integer) entry2.getKey() : null;
                                        if (num12 != null) {
                                            int iIntValue6 = num12.intValue();
                                            if (1910 <= iIntValue6 && iIntValue6 < 1991) {
                                                iIntValue6 %= 100;
                                            }
                                            strM = OperationKt$.ExternalSyntheticLambda0.m(" Most of your songs are from the ", FieldSet$.ExternalSyntheticOutline0.m(iIntValue6, "s"), str);
                                        } else {
                                            strM = "";
                                        }
                                        String strConcat = "Your listening age.".concat(strM);
                                        Modifier modifier3 = OffsetKt.padding-qDBjuR0$default(modifier2, 0.0f, 6.0f, 0.0f, 0.0f, 13);
                                        modifier = modifier2;
                                        RowMeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(new Arrangement.SpacedAligned(10.0f, new SaversKt$.ExternalSyntheticLambda0((byte) 3)), Alignment.Companion.Top, composerImpl3, 6);
                                        int iHashCode = Long.hashCode(composerImpl3.compositeKeyHashCode);
                                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl3.currentCompositionLocalScope();
                                        Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl3, modifier3);
                                        ComposeUiNode.Companion.getClass();
                                        LayoutNode.Companion.Constructor.1 r11 = ComposeUiNode.Companion.Constructor;
                                        composerImpl3.startReusableNode();
                                        if (composerImpl3.inserting) {
                                            composerImpl3.createNode(r11);
                                        } else {
                                            composerImpl3.useNode();
                                        }
                                        AnchoredGroupPath.set-impl(composerImpl3, rowMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
                                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope, ComposeUiNode.Companion.SetResolvedCompositionLocals);
                                        ComposeUiNode.Companion.SetModifier.1 r8 = ComposeUiNode.Companion.SetCompositeKeyHash;
                                        if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode))) {
                                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl3, iHashCode, r8);
                                        }
                                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier, ComposeUiNode.Companion.SetModifier);
                                        HorizontalAlignmentLine horizontalAlignmentLine = AlignmentLineKt.FirstBaseline;
                                        WithAlignmentLineElement withAlignmentLineElement = new WithAlignmentLineElement(horizontalAlignmentLine);
                                        boolean zChanged2 = composerImpl3.changed(function0);
                                        Object objRememberedValue3 = composerImpl3.rememberedValue();
                                        if (zChanged2 || objRememberedValue3 == obj9) {
                                            objRememberedValue3 = new RoomDatabase$.ExternalSyntheticLambda3(function0, (byte) 11);
                                            composerImpl3.updateRememberedValue(objRememberedValue3);
                                        }
                                        i11 = 11;
                                        ComposerImpl composerImpl6 = composerImpl3;
                                        TextKt.Text-Nvy7gAk(strCount, ColorKt.graphicsLayer(withAlignmentLineElement, (Function1) objRememberedValue3), j7, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, new TextStyle(0L, UnsignedKt.getSp(112), FontWeight.Black, TypeKt.Albert, UnsignedKt.getSp(-5.6d), 0, UnsignedKt.getSp(96), 0, 16645913), composerImpl6, 0, 0, 131064);
                                        WithAlignmentLineElement withAlignmentLineElement2 = new WithAlignmentLineElement(horizontalAlignmentLine);
                                        boolean zChanged3 = composerImpl6.changed(function0);
                                        Object objRememberedValue4 = composerImpl6.rememberedValue();
                                        if (zChanged3 || objRememberedValue4 == obj9) {
                                            objRememberedValue4 = new RoomDatabase$.ExternalSyntheticLambda3(function0, (byte) 12);
                                            composerImpl6.updateRememberedValue(objRememberedValue4);
                                        }
                                        Modifier modifierGraphicsLayer = ColorKt.graphicsLayer(withAlignmentLineElement2, (Function1) objRememberedValue4);
                                        long jSoft = CardsKt.soft(composerImpl6);
                                        TextStyle textStyle3 = CardsKt.Sub;
                                        TextKt.Text-Nvy7gAk(strConcat, modifierGraphicsLayer, jSoft, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(textStyle3, 0L, 0L, (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, 0L, (LineHeightStyle) null, 66307, 14680063), composerImpl6, 0, 0, 131064);
                                        composerImpl4 = composerImpl6;
                                        composerImpl4.end(true);
                                        composerImpl4.end(false);
                                        textStyle = textStyle3;
                                    } else {
                                        i11 = 11;
                                        modifier = modifier2;
                                        composerImpl3.startReplaceGroup(1485602903);
                                        int i14 = i7;
                                        float f = i14;
                                        int i15 = i14 + i8;
                                        final float f2 = f / (i15 >= 1 ? i15 : 1);
                                        ComposerImpl composerImpl7 = composerImpl3;
                                        ColumnScopeInstance columnScopeInstance3 = columnScopeInstance;
                                        final long j11 = j7;
                                        TextKt.Text-Nvy7gAk(FieldSet$.ExternalSyntheticOutline0.m("Checking song years: ", ListeningScreenKt.count(i14), " of ", ListeningScreenKt.count(i15)), OffsetKt.padding-qDBjuR0$default(modifier, 0.0f, 14.0f, 0.0f, 0.0f, 13), 0L, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, new TextStyle(0L, UnsignedKt.getSp(24), FontWeight.ExtraBold, TypeKt.Albert, UnsignedKt.getSp(-0.4d), 0, UnsignedKt.getSp(28), 0, 16645913), composerImpl7, 48, 0, 131068);
                                        Modifier modifierTestTag = TestTagKt.testTag(SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth(OffsetKt.padding-qDBjuR0$default(modifier, 0.0f, 14.0f, 0.0f, 0.0f, 13), 1.0f), 4.0f), "years_progress");
                                        boolean zChanged4 = composerImpl7.changed(j9) | composerImpl7.changed(j11) | composerImpl7.changed(f2);
                                        Object objRememberedValue5 = composerImpl7.rememberedValue();
                                        if (zChanged4 || objRememberedValue5 == obj9) {
                                            Function1 function1 = new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda67
                                                public final Object invoke(Object obj10) {
                                                    DrawScope drawScope = (DrawScope) obj10;
                                                    drawScope.getClass();
                                                    float fIntBitsToFloat = Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) / 2.0f;
                                                    long jFloatToRawIntBits = (((long) Float.floatToRawIntBits(fIntBitsToFloat)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat)) & 4294967295L);
                                                    DrawScope.drawRoundRect-u-Aw5IA$default(drawScope, j9, 0L, 0L, jFloatToRawIntBits, (Stroke) null, 0.0f, 246);
                                                    float fIntBitsToFloat2 = Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() >> 32)) * f2;
                                                    float fIntBitsToFloat3 = Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L));
                                                    DrawScope.drawRoundRect-u-Aw5IA$default(drawScope, j11, 0L, (((long) Float.floatToRawIntBits(fIntBitsToFloat2)) << 32) | (((long) Float.floatToRawIntBits(fIntBitsToFloat3)) & 4294967295L), jFloatToRawIntBits, (Stroke) null, 0.0f, 242);
                                                    return Unit.INSTANCE;
                                                }
                                            };
                                            composerImpl7.updateRememberedValue(function1);
                                            objRememberedValue5 = function1;
                                        }
                                        BoxKt.Box(ClipKt.drawBehind(modifierTestTag, (Function1) objRememberedValue5), composerImpl7, 0);
                                        Modifier modifier4 = OffsetKt.padding-qDBjuR0$default(modifier, 0.0f, 12.0f, 0.0f, 0.0f, 13);
                                        long jSoft2 = CardsKt.soft(composerImpl7);
                                        TextStyle textStyle4 = CardsKt.Sub;
                                        TextKt.Text-Nvy7gAk("Needs 20 songs with a year.", modifier4, jSoft2, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, textStyle4, composerImpl7, 54, 12582912, 131064);
                                        composerImpl4 = composerImpl7;
                                        if (z5) {
                                            composerImpl4.startReplaceGroup(879237998);
                                            OffsetKt.Spacer(composerImpl4, ColumnScopeInstance.weight$default(columnScopeInstance3, 0.8f));
                                            z4 = false;
                                        } else {
                                            z4 = false;
                                            composerImpl4.startReplaceGroup(1454993968);
                                        }
                                        composerImpl4.end(z4);
                                        composerImpl4.end(z4);
                                        textStyle = textStyle4;
                                    }
                                    ComposerImpl composerImpl8 = composerImpl4;
                                    TextKt.Text-Nvy7gAk("Song years from MusicBrainz", OffsetKt.padding-qDBjuR0$default(modifier, 0.0f, 8.0f, 0.0f, 0.0f, 13), CardsKt.soft(composerImpl8), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(textStyle, 0L, UnsignedKt.getSp(i11), (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, UnsignedKt.getSp(14), (LineHeightStyle) null, 0, 16646141), composerImpl8, 54, 0, 131064);
                                } else {
                                    composerImpl5.skipToGroupEnd();
                                }
                                return Unit.INSTANCE;
                            }
                        }, composerImpl2), composerImpl2, 6);
                    } else {
                        composerImpl2.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }, composerImpl), composerImpl, 3078, 6);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda2(spotifriedStats, i, i2, z, i3, (byte) 1);
        }
    }

    public static final float Age$lambda$123$lambda$122$lambda$111$xOf(BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl, int i, int i2, int i3) {
        return (((i3 - i) / (i2 - i)) * (boxWithConstraintsScopeImpl.getMaxWidth-D9Ej5fM() - 8.0f)) + 4.0f;
    }

    public static final void AgeCard(SpotifriedStats spotifriedStats, int i, int i2, boolean z, ComposerImpl composerImpl, int i3) {
        int i4;
        boolean zRememberNoMotion;
        composerImpl.startRestartGroup(1902467593);
        if ((i3 & 6) == 0) {
            i4 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i3;
        } else {
            i4 = i3;
        }
        if ((i3 & 48) == 0) {
            i4 |= composerImpl.changed(i) ? 32 : 16;
        }
        if ((i3 & 384) == 0) {
            i4 |= composerImpl.changed(i2) ? 256 : 128;
        }
        if ((i3 & 3072) == 0) {
            i4 |= composerImpl.changed(z) ? 2048 : 1024;
        }
        if (composerImpl.shouldExecute(i4 & 1, (i4 & 1171) != 1170)) {
            if (z) {
                composerImpl.startReplaceGroup(23749441);
                composerImpl.end(false);
                zRememberNoMotion = true;
            } else {
                composerImpl.startReplaceGroup(-1384706949);
                zRememberNoMotion = SunKt.rememberNoMotion(composerImpl);
                composerImpl.end(false);
            }
            composerImpl.startMovableGroup(-1384702604, composerImpl.joinKey(composerImpl.joinKey(spotifriedStats.period, Boolean.valueOf(zRememberNoMotion)), Boolean.valueOf(spotifriedStats.age.age != null)));
            Age(spotifriedStats, i, i2, zRememberNoMotion, composerImpl, i4 & 1022);
            composerImpl.end(false);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda2(spotifriedStats, i, i2, z, i3, (byte) 0);
        }
    }

    public static final void CardColumn(ComposableLambdaImpl composableLambdaImpl, ComposerImpl composerImpl, int i) {
        composerImpl.startRestartGroup(-2130699332);
        if (composerImpl.shouldExecute(i & 1, (i & 3) != 2)) {
            Modifier modifier = OffsetKt.padding-qDBjuR0(SizeKt.fillMaxSize(Modifier.Companion.$$INSTANCE, 1.0f), 26.0f, 20.0f, 26.0f, 28.0f);
            ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(OffsetKt.Top, Alignment.Companion.Start, composerImpl, 0);
            int iHashCode = Long.hashCode(composerImpl.compositeKeyHashCode);
            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl.currentCompositionLocalScope();
            Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl, modifier);
            ComposeUiNode.Companion.getClass();
            LayoutNode.Companion.Constructor.1 r5 = ComposeUiNode.Companion.Constructor;
            composerImpl.startReusableNode();
            if (composerImpl.inserting) {
                composerImpl.createNode(r5);
            } else {
                composerImpl.useNode();
            }
            AnchoredGroupPath.set-impl(composerImpl, columnMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
            AnchoredGroupPath.set-impl(composerImpl, persistentCompositionLocalHashMapCurrentCompositionLocalScope, ComposeUiNode.Companion.SetResolvedCompositionLocals);
            ComposeUiNode.Companion.SetModifier.1 r1 = ComposeUiNode.Companion.SetCompositeKeyHash;
            if (composerImpl.inserting || !Intrinsics.areEqual(composerImpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl, iHashCode, r1);
            }
            AnchoredGroupPath.set-impl(composerImpl, modifierMaterializeModifier, ComposeUiNode.Companion.SetModifier);
            composableLambdaImpl.invoke(ColumnScopeInstance.INSTANCE, composerImpl, 54);
            composerImpl.end(true);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new MainActivityKt$.ExternalSyntheticLambda137(composableLambdaImpl, i, (byte) 7);
        }
    }

    public static final void Day(final SpotifriedStats spotifriedStats, ObsessionDay obsessionDay, final boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        final ObsessionDay obsessionDay2 = obsessionDay;
        composerImpl.startRestartGroup(889184533);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changedInstance(obsessionDay2) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= composerImpl.changed(z) ? 256 : 128;
        }
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 147) != 146)) {
            StaticProvidableCompositionLocal staticProvidableCompositionLocal = ColorSchemeKt.LocalColorScheme;
            final long j = ((ColorScheme) composerImpl.consume(staticProvidableCompositionLocal)).primary;
            final long j2 = ((ColorScheme) composerImpl.consume(staticProvidableCompositionLocal)).onBackground;
            final long j3 = Color.copy-wmQWz5c$default(0.14f, j2);
            boolean zChanged = composerImpl.changed(obsessionDay2);
            Object objRememberedValue = composerImpl.rememberedValue();
            if (zChanged || objRememberedValue == Composer.Companion.Empty) {
                objRememberedValue = CollectionsKt.sorted(obsessionDay2.startHours);
                composerImpl.updateRememberedValue(objRememberedValue);
            }
            final List list = (List) objRememberedValue;
            int size = list.size();
            final float fMin = Math.min(70.0f, 2000.0f / (size >= 1 ? size : 1));
            final Animatable animatableClock = clock(z, (list.size() * fMin) + 500.0f + 550.0f, composerImpl, (i2 >> 6) & 14);
            final CountUp countUp = countUp(obsessionDay2.plays, 450, ((i2 >> 3) & 112) | 384, composerImpl, z);
            obsessionDay2 = obsessionDay;
            CardColumn(Expect_jvmKt.rememberComposableLambda(965115986, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda19
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    ColumnScopeInstance columnScopeInstance = (ColumnScopeInstance) obj;
                    ComposerImpl composerImpl2 = (ComposerImpl) obj2;
                    int iIntValue = ((Integer) obj3).intValue();
                    columnScopeInstance.getClass();
                    if ((iIntValue & 6) == 0) {
                        iIntValue |= composerImpl2.changed(columnScopeInstance) ? 4 : 2;
                    }
                    if (composerImpl2.shouldExecute(iIntValue & 1, (iIntValue & 19) != 18)) {
                        AnnotatedString.Builder builder = new AnnotatedString.Builder();
                        ObsessionDay obsessionDay3 = obsessionDay2;
                        LocalDate localDate = obsessionDay3.date;
                        SpotifriedStats spotifriedStats2 = spotifriedStats;
                        String str = localDate.format(DateTimeFormatter.ofPattern(spotifriedStats2.start.getYear() != spotifriedStats2.period.to.getYear() ? "d MMMM yyyy" : "d MMMM", CardsKt.english));
                        str.getClass();
                        builder.append("On " + str + ", ");
                        final long j4 = j;
                        int iPushStyle = builder.pushStyle(new SpanStyle(j4, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
                        try {
                            builder.append("something happened.");
                            builder.pop(iPushStyle);
                            AnnotatedString annotatedString = builder.toAnnotatedString();
                            Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
                            final boolean z2 = z;
                            TextKt.Text-Z58ophY(annotatedString, CardsKt.rise(companion, 0, z2, composerImpl2, 54), 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, CardsKt.Headline, composerImpl2, 0, 100663296, 262140);
                            AnnotatedString.Builder builder2 = new AnnotatedString.Builder();
                            String strM = obsessionDay3.song.title;
                            strM.getClass();
                            if (strM.length() > 60) {
                                String strTrimEnd = StringsKt.trimEnd(StringsKt.substringBeforeLast$default(StringsKt.take(60, strM), ' '), new char[]{',', ' ', '-'});
                                if (strTrimEnd.length() < 40) {
                                    strTrimEnd = StringsKt.trimEnd(StringsKt.take(60, strM)).toString();
                                }
                                strM = FieldSet$.ExternalSyntheticOutline0.m(strTrimEnd, "…");
                            }
                            builder2.append("You played “" + strM + "” ");
                            SpanStyle spanStyle = new SpanStyle(j2, 0L, FontWeight.Bold, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, "tnum", 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65466);
                            CountUp countUp2 = countUp;
                            CardsKt.countSpan(builder2, countUp2, spanStyle, OperationKt$.ExternalSyntheticLambda0.m(countUp2.text, " ", obsessionDay3.plays == 1 ? "time" : "times"));
                            builder2.append(" in one day. We won't ask.");
                            TextKt.Text-Z58ophY(builder2.toAnnotatedString(), CardsKt.rise(OffsetKt.padding-qDBjuR0$default(companion, 0.0f, 14.0f, 0.0f, 0.0f, 13), 1, z2, composerImpl2, 54), CardsKt.soft(composerImpl2), 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, CardsKt.Sub, composerImpl2, 0, 100663296, 262136);
                            Modifier modifierFillMaxWidth = SizeKt.fillMaxWidth(ColumnScopeInstance.weight$default(columnScopeInstance, 1.0f), 1.0f);
                            BiasAlignment biasAlignment = Alignment.Companion.BottomStart;
                            final long j5 = j3;
                            final List list2 = list;
                            final Animatable animatable = animatableClock;
                            final float f = fMin;
                            OffsetKt.BoxWithConstraints(modifierFillMaxWidth, biasAlignment, Expect_jvmKt.rememberComposableLambda(-473917124, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda44
                                public final Object invoke(Object obj4, Object obj5, Object obj6) {
                                    BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl = (BoxWithConstraintsScopeImpl) obj4;
                                    ComposerImpl composerImpl3 = (ComposerImpl) obj5;
                                    int iIntValue2 = ((Integer) obj6).intValue();
                                    boxWithConstraintsScopeImpl.getClass();
                                    if ((iIntValue2 & 6) == 0) {
                                        iIntValue2 |= composerImpl3.changed(boxWithConstraintsScopeImpl) ? 4 : 2;
                                    }
                                    if (composerImpl3.shouldExecute(iIntValue2 & 1, (iIntValue2 & 19) != 18)) {
                                        Dp dp = new Dp(boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM() - 26.0f);
                                        Dp dp2 = new Dp(190.0f);
                                        if (dp.compareTo(dp2) > 0) {
                                            dp = dp2;
                                        }
                                        Dp dp3 = new Dp(40.0f);
                                        if (dp.compareTo(dp3) < 0) {
                                            dp = dp3;
                                        }
                                        Modifier.Companion companion2 = Modifier.Companion.$$INSTANCE;
                                        Modifier modifierRise = CardsKt.rise(companion2, 2, z2, composerImpl3, 54);
                                        ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(OffsetKt.Top, Alignment.Companion.Start, composerImpl3, 0);
                                        int iHashCode = Long.hashCode(composerImpl3.compositeKeyHashCode);
                                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl3.currentCompositionLocalScope();
                                        Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl3, modifierRise);
                                        ComposeUiNode.Companion.getClass();
                                        LayoutNode.Companion.Constructor.1 r10 = ComposeUiNode.Companion.Constructor;
                                        composerImpl3.startReusableNode();
                                        if (composerImpl3.inserting) {
                                            composerImpl3.createNode(r10);
                                        } else {
                                            composerImpl3.useNode();
                                        }
                                        ComposeUiNode.Companion.SetModifier.1 r11 = ComposeUiNode.Companion.SetMeasurePolicy;
                                        AnchoredGroupPath.set-impl(composerImpl3, columnMeasurePolicy, r11);
                                        ComposeUiNode.Companion.SetModifier.1 r5 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
                                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope, r5);
                                        ComposeUiNode.Companion.SetModifier.1 r9 = ComposeUiNode.Companion.SetCompositeKeyHash;
                                        if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode))) {
                                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl3, iHashCode, r9);
                                        }
                                        ComposeUiNode.Companion.SetModifier.1 r6 = ComposeUiNode.Companion.SetModifier;
                                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier, r6);
                                        Modifier modifier = SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth(companion2, 1.0f), dp.value);
                                        long j6 = j5;
                                        boolean zChanged2 = composerImpl3.changed(j6);
                                        List list3 = list2;
                                        boolean zChangedInstance = zChanged2 | composerImpl3.changedInstance(list3);
                                        Animatable animatable2 = animatable;
                                        boolean zChangedInstance2 = zChangedInstance | composerImpl3.changedInstance(animatable2);
                                        float f2 = f;
                                        boolean zChanged3 = zChangedInstance2 | composerImpl3.changed(f2);
                                        long j7 = j4;
                                        boolean zChanged4 = zChanged3 | composerImpl3.changed(j7);
                                        Object objRememberedValue2 = composerImpl3.rememberedValue();
                                        if (zChanged4 || objRememberedValue2 == Composer.Companion.Empty) {
                                            CardsKt$$ExternalSyntheticLambda55 cardsKt$$ExternalSyntheticLambda55 = new CardsKt$$ExternalSyntheticLambda55(j6, list3, animatable2, f2, j7);
                                            composerImpl3.updateRememberedValue(cardsKt$$ExternalSyntheticLambda55);
                                            objRememberedValue2 = cardsKt$$ExternalSyntheticLambda55;
                                        }
                                        ImageKt.Canvas(modifier, (Function1) objRememberedValue2, composerImpl3, 0);
                                        Modifier modifier2 = OffsetKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth(companion2, 1.0f), 0.0f, 8.0f, 0.0f, 0.0f, 13);
                                        RowMeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(OffsetKt.SpaceBetween, Alignment.Companion.Top, composerImpl3, 6);
                                        int iHashCode2 = Long.hashCode(composerImpl3.compositeKeyHashCode);
                                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope2 = composerImpl3.currentCompositionLocalScope();
                                        Modifier modifierMaterializeModifier2 = AbsoluteAlignment.materializeModifier(composerImpl3, modifier2);
                                        composerImpl3.startReusableNode();
                                        if (composerImpl3.inserting) {
                                            composerImpl3.createNode(r10);
                                        } else {
                                            composerImpl3.useNode();
                                        }
                                        AnchoredGroupPath.set-impl(composerImpl3, rowMeasurePolicy, r11);
                                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope2, r5);
                                        if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode2))) {
                                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode2, composerImpl3, iHashCode2, r9);
                                        }
                                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier2, r6);
                                        composerImpl3.startReplaceGroup(-1238931106);
                                        Iterator it = ByteStreamsKt.listOf(new String[]{"00", "06", "12", "18", "24"}).iterator();
                                        while (it.hasNext()) {
                                            ComposerImpl composerImpl4 = composerImpl3;
                                            TextKt.Text-Nvy7gAk((String) it.next(), (Modifier) null, CardsKt.soft(composerImpl3), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(CardsKt.Sub, 0L, UnsignedKt.getSp(11), (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, UnsignedKt.getSp(14), (LineHeightStyle) null, 0, 16646141), composerImpl4, 0, 0, 131066);
                                            composerImpl3 = composerImpl4;
                                        }
                                        composerImpl3.end(false);
                                        composerImpl3.end(true);
                                        composerImpl3.end(true);
                                    } else {
                                        composerImpl3.skipToGroupEnd();
                                    }
                                    return Unit.INSTANCE;
                                }
                            }, composerImpl2), composerImpl2, 3120, 4);
                        } catch (Throwable th) {
                            builder.pop(iPushStyle);
                            throw th;
                        }
                    } else {
                        composerImpl2.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }, composerImpl), composerImpl, 6);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda20(spotifriedStats, obsessionDay2, z, i);
        }
    }

    public static final void DayCard(SpotifriedStats spotifriedStats, boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup;
        CardsKt$$ExternalSyntheticLambda0 cardsKt$$ExternalSyntheticLambda0;
        composerImpl.startRestartGroup(916936800);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changed(z) ? 32 : 16;
        }
        boolean zRememberNoMotion = true;
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            ObsessionDay obsessionDay = spotifriedStats.obsession;
            if (obsessionDay == null) {
                recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
                if (recomposeScopeImplEndRestartGroup == null) {
                    return;
                } else {
                    cardsKt$$ExternalSyntheticLambda0 = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 9);
                }
            } else {
                if (z) {
                    composerImpl.startReplaceGroup(472336586);
                } else {
                    composerImpl.startReplaceGroup(707973586);
                    zRememberNoMotion = SunKt.rememberNoMotion(composerImpl);
                }
                composerImpl.end(false);
                composerImpl.startMovableGroup(707974345, composerImpl.joinKey(spotifriedStats.period, Boolean.valueOf(zRememberNoMotion)));
                Day(spotifriedStats, obsessionDay, zRememberNoMotion, composerImpl, i2 & 14);
                composerImpl.end(false);
            }
            recomposeScopeImplEndRestartGroup.block = cardsKt$$ExternalSyntheticLambda0;
        }
        composerImpl.skipToGroupEnd();
        recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            cardsKt$$ExternalSyntheticLambda0 = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 10);
            recomposeScopeImplEndRestartGroup.block = cardsKt$$ExternalSyntheticLambda0;
        }
    }

    /* JADX WARN: Code duplicated, block: B:41:0x00c2  */
    public static final void Hours(final SpotifriedStats spotifriedStats, final boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        Pair pair;
        final Integer num;
        long j = spotifriedStats.seconds;
        composerImpl.startRestartGroup(2010421539);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changed(z) ? 32 : 16;
        }
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            StaticProvidableCompositionLocal staticProvidableCompositionLocal = ColorSchemeKt.LocalColorScheme;
            final long j2 = ((ColorScheme) composerImpl.consume(staticProvidableCompositionLocal)).primary;
            final long j3 = Color.copy-wmQWz5c$default(0.2f, ((ColorScheme) composerImpl.consume(staticProvidableCompositionLocal)).onBackground);
            int iRoundToInt = MathKt.roundToInt(j / 3600.0d);
            if (iRoundToInt >= 1) {
                pair = new Pair(Integer.valueOf(iRoundToInt), iRoundToInt == 1 ? "hour." : "hours.");
            } else {
                int iMinutesOf = Log.minutesOf(j);
                pair = new Pair(Integer.valueOf(iMinutesOf), iMinutesOf == 1 ? "minute." : "minutes.");
            }
            int iIntValue = ((Number) pair.first).intValue();
            final String str = (String) pair.second;
            final CountUp countUp = countUp(iIntValue, 450, (i2 & 112) | 384, composerImpl, z);
            final int size = spotifriedStats.daySeconds.size();
            LocalDate localDate = spotifriedStats.longestDay;
            if (localDate != null) {
                int iBetween = (int) ChronoUnit.DAYS.between(spotifriedStats.start, localDate);
                Integer numValueOf = Integer.valueOf(iBetween);
                if (iBetween < 0 || iBetween >= size) {
                    num = null;
                } else {
                    num = numValueOf;
                }
            } else {
                num = null;
            }
            Object objRememberedValue = composerImpl.rememberedValue();
            NeverEqualPolicy neverEqualPolicy = Composer.Companion.Empty;
            if (objRememberedValue == neverEqualPolicy) {
                objRememberedValue = ArcSplineKt.Animatable$default(z ? 2500.0f : 0.0f);
                composerImpl.updateRememberedValue(objRememberedValue);
            }
            final Animatable animatable = (Animatable) objRememberedValue;
            boolean zChangedInstance = composerImpl.changedInstance(animatable);
            Object objRememberedValue2 = composerImpl.rememberedValue();
            if (zChangedInstance || objRememberedValue2 == neverEqualPolicy) {
                objRememberedValue2 = new CardsKt$Hours$2$1(animatable, null, (byte) 0);
                composerImpl.updateRememberedValue(objRememberedValue2);
            }
            AnchoredGroupPath.LaunchedEffect(composerImpl, animatable, (Function2) objRememberedValue2);
            CardColumn(Expect_jvmKt.rememberComposableLambda(-57074170, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda17
                /* JADX WARN: Code duplicated, block: B:26:0x0071  */
                /* JADX WARN: Code duplicated, block: B:27:0x0074  */
                /* JADX WARN: Code duplicated, block: B:29:0x007c  */
                /* JADX WARN: Code duplicated, block: B:30:0x007f  */
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    String strConcat;
                    Modifier modifier;
                    boolean z2;
                    int i3;
                    boolean z3;
                    final SpotifriedStats spotifriedStats2 = spotifriedStats;
                    WrappedPeriod wrappedPeriod = spotifriedStats2.period;
                    ColumnScopeInstance columnScopeInstance = (ColumnScopeInstance) obj;
                    ComposerImpl composerImpl2 = (ComposerImpl) obj2;
                    int iIntValue2 = ((Integer) obj3).intValue();
                    columnScopeInstance.getClass();
                    if ((iIntValue2 & 6) == 0) {
                        iIntValue2 |= composerImpl2.changed(columnScopeInstance) ? 4 : 2;
                    }
                    if (composerImpl2.shouldExecute(iIntValue2 & 1, (iIntValue2 & 19) != 18)) {
                        AnnotatedString.Builder builder = new AnnotatedString.Builder();
                        LocalDate localDate2 = spotifriedStats2.start;
                        long j4 = spotifriedStats2.seconds;
                        String str2 = wrappedPeriod.label;
                        if (str2.length() == 4) {
                            int i4 = 0;
                            while (true) {
                                if (i4 >= str2.length()) {
                                    strConcat = OperationKt$.ExternalSyntheticLambda0.m("You gave ", str2, " ");
                                } else if (Character.isDigit(str2.charAt(i4))) {
                                    i4++;
                                } else if (str2.equals("Last 12 months")) {
                                    strConcat = "Twelve months, ";
                                } else if (str2.equals("All time")) {
                                    strConcat = "All told, ";
                                } else {
                                    strConcat = str2.concat(", ");
                                }
                            }
                        } else if (str2.equals("Last 12 months")) {
                            strConcat = "Twelve months, ";
                        } else if (str2.equals("All time")) {
                            strConcat = "All told, ";
                        } else {
                            strConcat = str2.concat(", ");
                        }
                        builder.append(strConcat);
                        final long j5 = j2;
                        SpanStyle spanStyle = new SpanStyle(j5, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, "tnum", 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65470);
                        CountUp countUp2 = countUp;
                        CardsKt.countSpan(builder, countUp2, spanStyle, OperationKt$.ExternalSyntheticLambda0.m(countUp2.text, " ", str));
                        AnnotatedString annotatedString = builder.toAnnotatedString();
                        Modifier modifier2 = Modifier.Companion.$$INSTANCE;
                        boolean z4 = z;
                        TextKt.Text-Z58ophY(annotatedString, CardsKt.rise(modifier2, 0, z4, composerImpl2, 54), 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, CardsKt.Headline, composerImpl2, 0, 100663296, 262140);
                        ComposerImpl composerImpl3 = composerImpl2;
                        if (j4 >= 86400) {
                            composerImpl3.startReplaceGroup(510731453);
                            modifier = modifier2;
                            i3 = 1;
                            TextKt.Text-Nvy7gAk(OperationKt$.ExternalSyntheticLambda0.m("That is ", Log.longDuration(Log.minutesOf(j4)), ", with no break."), CardsKt.rise(OffsetKt.padding-qDBjuR0$default(modifier2, 0.0f, 14.0f, 0.0f, 0.0f, 13), 1, z4, composerImpl3, 54), CardsKt.soft(composerImpl3), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, CardsKt.Sub, composerImpl3, 0, 12582912, 131064);
                            composerImpl3 = composerImpl3;
                            z2 = false;
                        } else {
                            modifier = modifier2;
                            z2 = false;
                            i3 = 1;
                            composerImpl3.startReplaceGroup(491139484);
                        }
                        composerImpl3.end(z2);
                        Modifier modifierFillMaxWidth = SizeKt.fillMaxWidth(ColumnScopeInstance.weight$default(columnScopeInstance, 1.0f), 1.0f);
                        BiasAlignment biasAlignment = Alignment.Companion.BottomStart;
                        final int i5 = size;
                        final Integer num2 = num;
                        final Animatable animatable2 = animatable;
                        final long j6 = j3;
                        int i6 = i3;
                        OffsetKt.BoxWithConstraints(modifierFillMaxWidth, biasAlignment, Expect_jvmKt.rememberComposableLambda(-495619236, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda45
                            /* JADX WARN: Code duplicated, block: B:100:0x02b4  */
                            /* JADX WARN: Code duplicated, block: B:102:0x02b8  */
                            /* JADX WARN: Code duplicated, block: B:103:0x02bb  */
                            /* JADX WARN: Code duplicated, block: B:106:0x02c7  */
                            /* JADX WARN: Code duplicated, block: B:107:0x02d0  */
                            /* JADX WARN: Code duplicated, block: B:111:0x02f4 A[LOOP:0: B:109:0x02ee->B:111:0x02f4, LOOP_END] */
                            /* JADX WARN: Code duplicated, block: B:115:0x0310 A[LOOP:1: B:113:0x030a->B:115:0x0310, LOOP_END] */
                            /* JADX WARN: Code duplicated, block: B:58:0x0127  */
                            /* JADX WARN: Code duplicated, block: B:60:0x0130 A[LOOP:4: B:59:0x012e->B:60:0x0130, LOOP_END] */
                            /* JADX WARN: Code duplicated, block: B:87:0x0229  */
                            /* JADX WARN: Code duplicated, block: B:90:0x026f  */
                            /* JADX WARN: Code duplicated, block: B:91:0x0273  */
                            /* JADX WARN: Code duplicated, block: B:96:0x028e  */
                            /* JADX WARN: Code duplicated, block: B:99:0x02b1  */
                            public final Object invoke(Object obj4, Object obj5, Object obj6) {
                                Integer num3;
                                Long lValueOf;
                                Dp dp;
                                ArrayList arrayList;
                                int i7;
                                ComposerImpl composerImpl4;
                                boolean z5;
                                int i8;
                                final float f;
                                final Animatable animatable3;
                                final Integer num4;
                                final long j7;
                                final long j8;
                                boolean zChanged;
                                Object objRememberedValue3;
                                boolean z6;
                                int iHashCode;
                                LocalDate localDate3;
                                int i9;
                                long j9;
                                LocalDate localDatePlusDays;
                                String str3;
                                DateTimeFormatter dateTimeFormatterOfPattern;
                                List listListOf;
                                ArrayList arrayList2;
                                Iterator it;
                                Iterator it2;
                                SpotifriedStats spotifriedStats3 = spotifriedStats2;
                                List list = spotifriedStats3.daySeconds;
                                BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl = (BoxWithConstraintsScopeImpl) obj4;
                                ComposerImpl composerImpl5 = (ComposerImpl) obj5;
                                int iIntValue3 = ((Integer) obj6).intValue();
                                boxWithConstraintsScopeImpl.getClass();
                                if ((iIntValue3 & 6) == 0) {
                                    iIntValue3 |= composerImpl5.changed(boxWithConstraintsScopeImpl) ? 4 : 2;
                                }
                                if (composerImpl5.shouldExecute(iIntValue3 & 1, (iIntValue3 & 19) != 18)) {
                                    float f2 = boxWithConstraintsScopeImpl.getMaxWidth-D9Ej5fM();
                                    int i10 = i5;
                                    int iMin = Math.min(i10, (int) (f2 / 2.5f));
                                    if (iMin < 1) {
                                        iMin = 1;
                                    }
                                    float f3 = f2 / iMin;
                                    Dp dp2 = new Dp(1.0f);
                                    Dp dp3 = new Dp(0.4f * f3);
                                    if (dp2.compareTo(dp3) > 0) {
                                        dp2 = dp3;
                                    }
                                    Dp dp4 = new Dp(f3 - dp2.value);
                                    Dp dp5 = new Dp(CardsKt.WIDE_BAR);
                                    if (dp4.compareTo(dp5) > 0) {
                                        dp4 = dp5;
                                    }
                                    boolean zChanged2 = composerImpl5.changed(list) | composerImpl5.changed(iMin);
                                    Object objRememberedValue4 = composerImpl5.rememberedValue();
                                    NeverEqualPolicy neverEqualPolicy2 = Composer.Companion.Empty;
                                    if (zChanged2 || objRememberedValue4 == neverEqualPolicy2) {
                                        int iMin2 = Math.min(list.size(), iMin);
                                        long[] jArr = new long[iMin2];
                                        Iterator it3 = list.iterator();
                                        int i11 = 0;
                                        while (it3.hasNext()) {
                                            Object next = it3.next();
                                            int i12 = i11 + 1;
                                            if (i11 < 0) {
                                                ByteStreamsKt.throwIndexOverflow();
                                                throw null;
                                            }
                                            long jLongValue = ((Number) next).longValue();
                                            int size2 = (i11 * iMin2) / list.size();
                                            jArr[size2] = Math.max(jArr[size2], jLongValue);
                                            it3 = it3;
                                            i11 = i12;
                                        }
                                        num3 = null;
                                        if (iMin2 == 0) {
                                            lValueOf = null;
                                        } else {
                                            long j10 = jArr[0];
                                            int i13 = iMin2 - 1;
                                            if (1 <= i13) {
                                                int i14 = 1;
                                                while (true) {
                                                    long j11 = jArr[i14];
                                                    if (j10 < j11) {
                                                        j10 = j11;
                                                    }
                                                    if (i14 == i13) {
                                                        break;
                                                    }
                                                    i14++;
                                                }
                                            }
                                            lValueOf = Long.valueOf(j10);
                                        }
                                        if (lValueOf == null) {
                                            dp = dp4;
                                            arrayList = new ArrayList(iMin2);
                                            for (i7 = 0; i7 < iMin2; i7++) {
                                                arrayList.add(Float.valueOf(0.0f));
                                            }
                                        } else {
                                            if (lValueOf.longValue() <= 0) {
                                                lValueOf = null;
                                            }
                                            if (lValueOf != null) {
                                                long jLongValue2 = lValueOf.longValue();
                                                arrayList = new ArrayList(iMin2);
                                                int i15 = 0;
                                                while (true) {
                                                    dp = dp4;
                                                    if (i15 >= iMin2) {
                                                        break;
                                                    }
                                                    arrayList.add(Float.valueOf((float) Math.sqrt(jArr[i15] / jLongValue2)));
                                                    i15++;
                                                    dp4 = dp;
                                                }
                                            } else {
                                                dp = dp4;
                                                arrayList = new ArrayList(iMin2);
                                                while (i7 < iMin2) {
                                                    arrayList.add(Float.valueOf(0.0f));
                                                }
                                            }
                                        }
                                        objRememberedValue4 = arrayList;
                                        composerImpl5.updateRememberedValue(objRememberedValue4);
                                    } else {
                                        dp = dp4;
                                        num3 = null;
                                    }
                                    final List list2 = (List) objRememberedValue4;
                                    Integer num5 = num2;
                                    Integer numValueOf2 = num5 != null ? Integer.valueOf((list2.size() * num5.intValue()) / i10) : num3;
                                    Dp dp6 = new Dp(boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM() - 30.0f);
                                    Dp dp7 = new Dp(270.0f);
                                    if (dp6.compareTo(dp7) > 0) {
                                        dp6 = dp7;
                                    }
                                    Dp dp8 = new Dp(40.0f);
                                    if (dp6.compareTo(dp8) < 0) {
                                        dp6 = dp8;
                                    }
                                    if (i10 > 0) {
                                        composerImpl5.startReplaceGroup(451295179);
                                        ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(OffsetKt.Top, Alignment.Companion.Start, composerImpl5, 0);
                                        int iHashCode2 = Long.hashCode(composerImpl5.compositeKeyHashCode);
                                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl5.currentCompositionLocalScope();
                                        Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
                                        Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl5, companion);
                                        ComposeUiNode.Companion.getClass();
                                        LayoutNode.Companion.Constructor.1 r11 = ComposeUiNode.Companion.Constructor;
                                        composerImpl5.startReusableNode();
                                        if (composerImpl5.inserting) {
                                            composerImpl5.createNode(r11);
                                        } else {
                                            composerImpl5.useNode();
                                        }
                                        ComposeUiNode.Companion.SetModifier.1 r8 = ComposeUiNode.Companion.SetMeasurePolicy;
                                        AnchoredGroupPath.set-impl(composerImpl5, columnMeasurePolicy, r8);
                                        ComposeUiNode.Companion.SetModifier.1 r2 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
                                        AnchoredGroupPath.set-impl(composerImpl5, persistentCompositionLocalHashMapCurrentCompositionLocalScope, r2);
                                        ComposeUiNode.Companion.SetModifier.1 r6 = ComposeUiNode.Companion.SetCompositeKeyHash;
                                        Dp dp9 = dp;
                                        if (composerImpl5.inserting) {
                                            i8 = i10;
                                        } else {
                                            i8 = i10;
                                            if (!Intrinsics.areEqual(composerImpl5.rememberedValue(), Integer.valueOf(iHashCode2))) {
                                            }
                                            ComposeUiNode.Companion.SetModifier.1 r5 = ComposeUiNode.Companion.SetModifier;
                                            AnchoredGroupPath.set-impl(composerImpl5, modifierMaterializeModifier, r5);
                                            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth(companion, 1.0f), dp6.value), "day_bars");
                                            f = dp9.value;
                                            boolean zChanged3 = composerImpl5.changed(f) | composerImpl5.changedInstance(list2);
                                            animatable3 = animatable2;
                                            boolean zChangedInstance2 = zChanged3 | composerImpl5.changedInstance(animatable3) | composerImpl5.changed(numValueOf2);
                                            num4 = numValueOf2;
                                            j7 = j5;
                                            boolean zChanged4 = zChangedInstance2 | composerImpl5.changed(j7);
                                            j8 = j6;
                                            zChanged = zChanged4 | composerImpl5.changed(j8);
                                            objRememberedValue3 = composerImpl5.rememberedValue();
                                            if (zChanged || objRememberedValue3 == neverEqualPolicy2) {
                                                objRememberedValue3 = new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda68
                                                    public final Object invoke(Object obj7) {
                                                        CardsKt$$ExternalSyntheticLambda68 cardsKt$$ExternalSyntheticLambda68 = this;
                                                        DrawScope drawScope = (DrawScope) obj7;
                                                        drawScope.getClass();
                                                        float f4 = drawScope.toPx-0680j_4(f);
                                                        List list3 = list2;
                                                        float fIntBitsToFloat = list3.size() > 1 ? (Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() >> 32)) - f4) / (list3.size() - 1) : 0.0f;
                                                        float f5 = drawScope.toPx-0680j_4(1.5f);
                                                        float f6 = 1.0f;
                                                        float f7 = f4 >= drawScope.toPx-0680j_4(CardsKt.WIDE_BAR) ? drawScope.toPx-0680j_4(3.0f) : Math.min(drawScope.toPx-0680j_4(1.0f), f4 / 2.0f);
                                                        int i16 = 0;
                                                        for (Object obj8 : list3) {
                                                            int i17 = i16 + 1;
                                                            if (i16 < 0) {
                                                                ByteStreamsKt.throwIndexOverflow();
                                                                throw null;
                                                            }
                                                            float fMax = Math.max(Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) * ((Number) obj8).floatValue(), f5) * CardsKt.Ease.transform(ResultKt.coerceIn(((((Number) animatable3.getValue()).floatValue() - 400.0f) - ((i16 * 1400) / list3.size())) / 700.0f, 0.0f, f6));
                                                            Integer num6 = num4;
                                                            long j12 = (num6 == null || i16 != num6.intValue()) ? j8 : j7;
                                                            float fIntBitsToFloat2 = Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) - fMax;
                                                            long jFloatToRawIntBits = Float.floatToRawIntBits(i16 * fIntBitsToFloat);
                                                            long jFloatToRawIntBits2 = ((long) Float.floatToRawIntBits(fIntBitsToFloat2)) & 4294967295L;
                                                            long jFloatToRawIntBits3 = (((long) Float.floatToRawIntBits(f4)) << 32) | (((long) Float.floatToRawIntBits(fMax)) & 4294967295L);
                                                            float fMin = Math.min(f7, fMax / 2.0f);
                                                            drawScope = drawScope;
                                                            DrawScope.drawRoundRect-u-Aw5IA$default(drawScope, j12, jFloatToRawIntBits2 | (jFloatToRawIntBits << 32), jFloatToRawIntBits3, (((long) Float.floatToRawIntBits(fMin)) << 32) | (((long) Float.floatToRawIntBits(fMin)) & 4294967295L), (Stroke) null, 0.0f, 240);
                                                            f5 = f5;
                                                            i16 = i17;
                                                            f7 = f7;
                                                            f6 = 1.0f;
                                                            cardsKt$$ExternalSyntheticLambda68 = this;
                                                        }
                                                        return Unit.INSTANCE;
                                                    }
                                                };
                                                composerImpl5.updateRememberedValue(objRememberedValue3);
                                            }
                                            z6 = false;
                                            ImageKt.Canvas(modifierTestTag, (Function1) objRememberedValue3, composerImpl5, 0);
                                            Modifier modifier3 = OffsetKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth(companion, 1.0f), 0.0f, 8.0f, 0.0f, 0.0f, 13);
                                            RowMeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(OffsetKt.SpaceBetween, Alignment.Companion.Top, composerImpl5, 6);
                                            iHashCode = Long.hashCode(composerImpl5.compositeKeyHashCode);
                                            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope2 = composerImpl5.currentCompositionLocalScope();
                                            Modifier modifierMaterializeModifier2 = AbsoluteAlignment.materializeModifier(composerImpl5, modifier3);
                                            composerImpl5.startReusableNode();
                                            if (composerImpl5.inserting) {
                                                composerImpl5.createNode(r11);
                                            } else {
                                                composerImpl5.useNode();
                                            }
                                            AnchoredGroupPath.set-impl(composerImpl5, rowMeasurePolicy, r8);
                                            AnchoredGroupPath.set-impl(composerImpl5, persistentCompositionLocalHashMapCurrentCompositionLocalScope2, r2);
                                            if (composerImpl5.inserting || !Intrinsics.areEqual(composerImpl5.rememberedValue(), Integer.valueOf(iHashCode))) {
                                                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl5, iHashCode, r6);
                                            }
                                            AnchoredGroupPath.set-impl(composerImpl5, modifierMaterializeModifier2, r5);
                                            composerImpl5.startReplaceGroup(-1099100883);
                                            localDate3 = spotifriedStats3.start;
                                            i9 = i8;
                                            j9 = i9;
                                            localDatePlusDays = localDate3.plusDays(j9 - 1);
                                            if (localDate3.getYear() != localDatePlusDays.getYear()) {
                                                str3 = "MMM yyyy";
                                            } else if (i9 > 62) {
                                                str3 = "MMM";
                                            } else {
                                                str3 = "d MMM";
                                            }
                                            dateTimeFormatterOfPattern = DateTimeFormatter.ofPattern(str3, CardsKt.english);
                                            if (i9 < 30) {
                                                listListOf = ByteStreamsKt.listOf(new LocalDate[]{localDate3, localDatePlusDays});
                                            } else {
                                                listListOf = ByteStreamsKt.listOf(new LocalDate[]{localDate3, localDate3.plusDays(j9 / 2), localDatePlusDays});
                                            }
                                            arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(listListOf, 10));
                                            it = listListOf.iterator();
                                            while (it.hasNext()) {
                                                arrayList2.add(((LocalDate) it.next()).format(dateTimeFormatterOfPattern));
                                            }
                                            it2 = CollectionsKt.distinct(arrayList2).iterator();
                                            while (it2.hasNext()) {
                                                ComposerImpl composerImpl6 = composerImpl5;
                                                TextKt.Text-Nvy7gAk((String) it2.next(), (Modifier) null, CardsKt.soft(composerImpl5), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(CardsKt.Sub, 0L, UnsignedKt.getSp(11), (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, UnsignedKt.getSp(14), (LineHeightStyle) null, 0, 16646141), composerImpl6, 0, 0, 131066);
                                                z6 = z6;
                                                composerImpl5 = composerImpl6;
                                            }
                                            composerImpl4 = composerImpl5;
                                            z5 = z6;
                                            composerImpl4.end(z5);
                                            composerImpl4.end(true);
                                            composerImpl4.end(true);
                                        }
                                        OperationKt$.ExternalSyntheticLambda0.m(iHashCode2, composerImpl5, iHashCode2, r6);
                                        ComposeUiNode.Companion.SetModifier.1 r7 = ComposeUiNode.Companion.SetModifier;
                                        AnchoredGroupPath.set-impl(composerImpl5, modifierMaterializeModifier, r7);
                                        Modifier modifierTestTag2 = TestTagKt.testTag(SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth(companion, 1.0f), dp6.value), "day_bars");
                                        f = dp9.value;
                                        boolean zChanged5 = composerImpl5.changed(f) | composerImpl5.changedInstance(list2);
                                        animatable3 = animatable2;
                                        boolean zChangedInstance3 = zChanged5 | composerImpl5.changedInstance(animatable3) | composerImpl5.changed(numValueOf2);
                                        num4 = numValueOf2;
                                        j7 = j5;
                                        boolean zChanged6 = zChangedInstance3 | composerImpl5.changed(j7);
                                        j8 = j6;
                                        zChanged = zChanged6 | composerImpl5.changed(j8);
                                        objRememberedValue3 = composerImpl5.rememberedValue();
                                        if (zChanged) {
                                            objRememberedValue3 = new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda68
                                                public final Object invoke(Object obj7) {
                                                    CardsKt$$ExternalSyntheticLambda68 cardsKt$$ExternalSyntheticLambda68 = this;
                                                    DrawScope drawScope = (DrawScope) obj7;
                                                    drawScope.getClass();
                                                    float f4 = drawScope.toPx-0680j_4(f);
                                                    List list3 = list2;
                                                    float fIntBitsToFloat = list3.size() > 1 ? (Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() >> 32)) - f4) / (list3.size() - 1) : 0.0f;
                                                    float f5 = drawScope.toPx-0680j_4(1.5f);
                                                    float f6 = 1.0f;
                                                    float f7 = f4 >= drawScope.toPx-0680j_4(CardsKt.WIDE_BAR) ? drawScope.toPx-0680j_4(3.0f) : Math.min(drawScope.toPx-0680j_4(1.0f), f4 / 2.0f);
                                                    int i16 = 0;
                                                    for (Object obj8 : list3) {
                                                        int i17 = i16 + 1;
                                                        if (i16 < 0) {
                                                            ByteStreamsKt.throwIndexOverflow();
                                                            throw null;
                                                        }
                                                        float fMax = Math.max(Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) * ((Number) obj8).floatValue(), f5) * CardsKt.Ease.transform(ResultKt.coerceIn(((((Number) animatable3.getValue()).floatValue() - 400.0f) - ((i16 * 1400) / list3.size())) / 700.0f, 0.0f, f6));
                                                        Integer num6 = num4;
                                                        long j12 = (num6 == null || i16 != num6.intValue()) ? j8 : j7;
                                                        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) - fMax;
                                                        long jFloatToRawIntBits = Float.floatToRawIntBits(i16 * fIntBitsToFloat);
                                                        long jFloatToRawIntBits2 = ((long) Float.floatToRawIntBits(fIntBitsToFloat2)) & 4294967295L;
                                                        long jFloatToRawIntBits3 = (((long) Float.floatToRawIntBits(f4)) << 32) | (((long) Float.floatToRawIntBits(fMax)) & 4294967295L);
                                                        float fMin = Math.min(f7, fMax / 2.0f);
                                                        drawScope = drawScope;
                                                        DrawScope.drawRoundRect-u-Aw5IA$default(drawScope, j12, jFloatToRawIntBits2 | (jFloatToRawIntBits << 32), jFloatToRawIntBits3, (((long) Float.floatToRawIntBits(fMin)) << 32) | (((long) Float.floatToRawIntBits(fMin)) & 4294967295L), (Stroke) null, 0.0f, 240);
                                                        f5 = f5;
                                                        i16 = i17;
                                                        f7 = f7;
                                                        f6 = 1.0f;
                                                        cardsKt$$ExternalSyntheticLambda68 = this;
                                                    }
                                                    return Unit.INSTANCE;
                                                }
                                            };
                                            composerImpl5.updateRememberedValue(objRememberedValue3);
                                        } else {
                                            objRememberedValue3 = new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda68
                                                public final Object invoke(Object obj7) {
                                                    CardsKt$$ExternalSyntheticLambda68 cardsKt$$ExternalSyntheticLambda68 = this;
                                                    DrawScope drawScope = (DrawScope) obj7;
                                                    drawScope.getClass();
                                                    float f4 = drawScope.toPx-0680j_4(f);
                                                    List list3 = list2;
                                                    float fIntBitsToFloat = list3.size() > 1 ? (Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() >> 32)) - f4) / (list3.size() - 1) : 0.0f;
                                                    float f5 = drawScope.toPx-0680j_4(1.5f);
                                                    float f6 = 1.0f;
                                                    float f7 = f4 >= drawScope.toPx-0680j_4(CardsKt.WIDE_BAR) ? drawScope.toPx-0680j_4(3.0f) : Math.min(drawScope.toPx-0680j_4(1.0f), f4 / 2.0f);
                                                    int i16 = 0;
                                                    for (Object obj8 : list3) {
                                                        int i17 = i16 + 1;
                                                        if (i16 < 0) {
                                                            ByteStreamsKt.throwIndexOverflow();
                                                            throw null;
                                                        }
                                                        float fMax = Math.max(Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) * ((Number) obj8).floatValue(), f5) * CardsKt.Ease.transform(ResultKt.coerceIn(((((Number) animatable3.getValue()).floatValue() - 400.0f) - ((i16 * 1400) / list3.size())) / 700.0f, 0.0f, f6));
                                                        Integer num6 = num4;
                                                        long j12 = (num6 == null || i16 != num6.intValue()) ? j8 : j7;
                                                        float fIntBitsToFloat2 = Float.intBitsToFloat((int) (drawScope.getSize-NH-jbRc() & 4294967295L)) - fMax;
                                                        long jFloatToRawIntBits = Float.floatToRawIntBits(i16 * fIntBitsToFloat);
                                                        long jFloatToRawIntBits2 = ((long) Float.floatToRawIntBits(fIntBitsToFloat2)) & 4294967295L;
                                                        long jFloatToRawIntBits3 = (((long) Float.floatToRawIntBits(f4)) << 32) | (((long) Float.floatToRawIntBits(fMax)) & 4294967295L);
                                                        float fMin = Math.min(f7, fMax / 2.0f);
                                                        drawScope = drawScope;
                                                        DrawScope.drawRoundRect-u-Aw5IA$default(drawScope, j12, jFloatToRawIntBits2 | (jFloatToRawIntBits << 32), jFloatToRawIntBits3, (((long) Float.floatToRawIntBits(fMin)) << 32) | (((long) Float.floatToRawIntBits(fMin)) & 4294967295L), (Stroke) null, 0.0f, 240);
                                                        f5 = f5;
                                                        i16 = i17;
                                                        f7 = f7;
                                                        f6 = 1.0f;
                                                        cardsKt$$ExternalSyntheticLambda68 = this;
                                                    }
                                                    return Unit.INSTANCE;
                                                }
                                            };
                                            composerImpl5.updateRememberedValue(objRememberedValue3);
                                        }
                                        z6 = false;
                                        ImageKt.Canvas(modifierTestTag2, (Function1) objRememberedValue3, composerImpl5, 0);
                                        Modifier modifier4 = OffsetKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth(companion, 1.0f), 0.0f, 8.0f, 0.0f, 0.0f, 13);
                                        RowMeasurePolicy rowMeasurePolicy2 = RowKt.rowMeasurePolicy(OffsetKt.SpaceBetween, Alignment.Companion.Top, composerImpl5, 6);
                                        iHashCode = Long.hashCode(composerImpl5.compositeKeyHashCode);
                                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl5.currentCompositionLocalScope();
                                        Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl5, modifier4);
                                        composerImpl5.startReusableNode();
                                        if (composerImpl5.inserting) {
                                            composerImpl5.createNode(r11);
                                        } else {
                                            composerImpl5.useNode();
                                        }
                                        AnchoredGroupPath.set-impl(composerImpl5, rowMeasurePolicy2, r8);
                                        AnchoredGroupPath.set-impl(composerImpl5, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, r2);
                                        if (composerImpl5.inserting) {
                                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl5, iHashCode, r6);
                                        } else {
                                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl5, iHashCode, r6);
                                        }
                                        AnchoredGroupPath.set-impl(composerImpl5, modifierMaterializeModifier3, r7);
                                        composerImpl5.startReplaceGroup(-1099100883);
                                        localDate3 = spotifriedStats3.start;
                                        i9 = i8;
                                        j9 = i9;
                                        localDatePlusDays = localDate3.plusDays(j9 - 1);
                                        if (localDate3.getYear() != localDatePlusDays.getYear()) {
                                            str3 = "MMM yyyy";
                                        } else if (i9 > 62) {
                                            str3 = "MMM";
                                        } else {
                                            str3 = "d MMM";
                                        }
                                        dateTimeFormatterOfPattern = DateTimeFormatter.ofPattern(str3, CardsKt.english);
                                        if (i9 < 30) {
                                            listListOf = ByteStreamsKt.listOf(new LocalDate[]{localDate3, localDatePlusDays});
                                        } else {
                                            listListOf = ByteStreamsKt.listOf(new LocalDate[]{localDate3, localDate3.plusDays(j9 / 2), localDatePlusDays});
                                        }
                                        arrayList2 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(listListOf, 10));
                                        it = listListOf.iterator();
                                        while (it.hasNext()) {
                                            arrayList2.add(((LocalDate) it.next()).format(dateTimeFormatterOfPattern));
                                        }
                                        it2 = CollectionsKt.distinct(arrayList2).iterator();
                                        while (it2.hasNext()) {
                                            ComposerImpl composerImpl7 = composerImpl5;
                                            TextKt.Text-Nvy7gAk((String) it2.next(), (Modifier) null, CardsKt.soft(composerImpl5), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(CardsKt.Sub, 0L, UnsignedKt.getSp(11), (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, UnsignedKt.getSp(14), (LineHeightStyle) null, 0, 16646141), composerImpl7, 0, 0, 131066);
                                            z6 = z6;
                                            composerImpl5 = composerImpl7;
                                        }
                                        composerImpl4 = composerImpl5;
                                        z5 = z6;
                                        composerImpl4.end(z5);
                                        composerImpl4.end(true);
                                        composerImpl4.end(true);
                                    } else {
                                        composerImpl4 = composerImpl5;
                                        z5 = false;
                                        composerImpl4.startReplaceGroup(1085072902);
                                    }
                                    composerImpl4.end(z5);
                                } else {
                                    composerImpl5.skipToGroupEnd();
                                }
                                return Unit.INSTANCE;
                            }
                        }, composerImpl3), composerImpl3, 3120, 4);
                        if (num2 != null) {
                            composerImpl3.startReplaceGroup(512520990);
                            LocalDate localDatePlusDays = localDate2.plusDays(num2.intValue());
                            long jLongValue = ((Number) spotifriedStats2.daySeconds.get(num2.intValue())).longValue();
                            int iRoundToInt2 = MathKt.roundToInt(jLongValue / 3600.0d);
                            ComposerImpl composerImpl4 = composerImpl3;
                            z3 = false;
                            TextKt.Text-Nvy7gAk(FieldSet$.ExternalSyntheticOutline0.m("Longest day: ", iRoundToInt2 >= i6 ? CardsKt.plural(iRoundToInt2, "hour") : CardsKt.plural(Log.minutesOf(jLongValue), "minute"), ", ", localDatePlusDays.format(DateTimeFormatter.ofPattern(localDate2.getYear() != wrappedPeriod.to.getYear() ? "d MMMM yyyy" : "d MMMM", CardsKt.english))), CardsKt.rise(OffsetKt.padding-qDBjuR0$default(modifier, 0.0f, 10.0f, 0.0f, 0.0f, 13), 3, z4, composerImpl3, 54), j5, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(CardsKt.Sub, 0L, UnsignedKt.getSp(14), FontWeight.SemiBold, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, UnsignedKt.getSp(19), (LineHeightStyle) null, 0, 16646137), composerImpl4, 0, 0, 131064);
                            composerImpl3 = composerImpl4;
                        } else {
                            z3 = false;
                            composerImpl3.startReplaceGroup(491139484);
                        }
                        composerImpl3.end(z3);
                    } else {
                        composerImpl2.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }, composerImpl), composerImpl, 6);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 3);
        }
    }

    public static final void HoursCard(SpotifriedStats spotifriedStats, boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        composerImpl.startRestartGroup(125710291);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changed(z) ? 32 : 16;
        }
        boolean zRememberNoMotion = true;
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            if (z) {
                composerImpl.startReplaceGroup(-176106313);
            } else {
                composerImpl.startReplaceGroup(548508741);
                zRememberNoMotion = SunKt.rememberNoMotion(composerImpl);
            }
            composerImpl.end(false);
            composerImpl.startMovableGroup(548509497, composerImpl.joinKey(spotifriedStats.period, Boolean.valueOf(zRememberNoMotion)));
            Hours(spotifriedStats, zRememberNoMotion, composerImpl, i2 & 14);
            composerImpl.end(false);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 11);
        }
    }

    public static final void Intro(final SpotifriedStats spotifriedStats, final boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        Object obj;
        ComposerImpl composerImpl2 = composerImpl;
        composerImpl2.startRestartGroup(-1100974464);
        if ((i & 6) == 0) {
            i2 = (composerImpl2.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl2.changed(z) ? 32 : 16;
        }
        if (composerImpl2.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            long j = ((ColorScheme) composerImpl2.consume(ColorSchemeKt.LocalColorScheme)).primary;
            long j2 = spotifriedStats.seconds;
            List list = spotifriedStats.hours;
            final float fSunScale = Log.sunScale(Log.minutesOf(j2));
            final SunMotion sunMotionRememberSunMotion = rememberSunMotion(list, fSunScale, z, composerImpl2);
            IntIterator it = ByteStreamsKt.getIndices(list).iterator();
            IntProgressionIterator intProgressionIterator = (IntProgressionIterator) it;
            if (intProgressionIterator.hasNext) {
                IntIterator intIterator = it;
                Object next = intIterator.next();
                if (intProgressionIterator.hasNext) {
                    long jLongValue = ((Number) list.get(((Number) next).intValue())).longValue();
                    while (true) {
                        Object next2 = intIterator.next();
                        long jLongValue2 = ((Number) list.get(((Number) next2).intValue())).longValue();
                        if (jLongValue < jLongValue2) {
                            next = next2;
                            jLongValue = jLongValue2;
                        }
                        if (!intProgressionIterator.hasNext) {
                            break;
                        }
                        composerImpl2 = composerImpl;
                        j = j;
                    }
                }
                obj = next;
            } else {
                obj = null;
            }
            Integer num = (Integer) obj;
            final float f = 15.0f * (-(num != null ? num.intValue() : 0));
            final Animatable animatableProgress = progress(200, 1400, ((i2 >> 3) & 14) | 432, composerImpl2, z);
            final long j3 = j;
            OffsetKt.BoxWithConstraints(ClipKt.clipToBounds(SizeKt.fillMaxSize(Modifier.Companion.$$INSTANCE, 1.0f)), (BiasAlignment) null, Expect_jvmKt.rememberComposableLambda(733660630, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda23
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl = (BoxWithConstraintsScopeImpl) obj2;
                    ComposerImpl composerImpl3 = (ComposerImpl) obj3;
                    int iIntValue = ((Integer) obj4).intValue();
                    boxWithConstraintsScopeImpl.getClass();
                    if ((iIntValue & 6) == 0) {
                        iIntValue |= composerImpl3.changed(boxWithConstraintsScopeImpl) ? 4 : 2;
                    }
                    if (composerImpl3.shouldExecute(iIntValue & 1, (iIntValue & 19) != 18)) {
                        float f2 = boxWithConstraintsScopeImpl.getMaxWidth-D9Ej5fM() * 1.33f;
                        float f3 = ((Density) composerImpl3.consume(CompositionLocalsKt.LocalDensity)).toPx-0680j_4(140.0f);
                        Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
                        Modifier modifierDrawWithContent = ClipKt.drawWithContent(ColorKt.graphicsLayer(SizeKt.fillMaxSize(companion, 1.0f), new SunKt$.ExternalSyntheticLambda1((byte) 13)), new SunKt$.ExternalSyntheticLambda1((byte) 14));
                        BiasAlignment biasAlignment = Alignment.Companion.TopStart;
                        MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(biasAlignment, false);
                        int iHashCode = Long.hashCode(composerImpl3.compositeKeyHashCode);
                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl3.currentCompositionLocalScope();
                        Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl3, modifierDrawWithContent);
                        ComposeUiNode.Companion.getClass();
                        LayoutNode.Companion.Constructor.1 r13 = ComposeUiNode.Companion.Constructor;
                        composerImpl3.startReusableNode();
                        if (composerImpl3.inserting) {
                            composerImpl3.createNode(r13);
                        } else {
                            composerImpl3.useNode();
                        }
                        ComposeUiNode.Companion.SetModifier.1 r14 = ComposeUiNode.Companion.SetMeasurePolicy;
                        AnchoredGroupPath.set-impl(composerImpl3, measurePolicyMaybeCachedBoxMeasurePolicy, r14);
                        ComposeUiNode.Companion.SetModifier.1 r9 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope, r9);
                        ComposeUiNode.Companion.SetModifier.1 r11 = ComposeUiNode.Companion.SetCompositeKeyHash;
                        if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode))) {
                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl3, iHashCode, r11);
                        }
                        ComposeUiNode.Companion.SetModifier.1 r4 = ComposeUiNode.Companion.SetModifier;
                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier, r4);
                        Modifier modifier = SizeKt.requiredSize-3ABfNKs(OffsetKt.offset-VpY3zN4$default(BoxScopeInstance.INSTANCE.align(companion, Alignment.Companion.BottomCenter), 0.0f, (f2 / 2.0f) - 50.0f, 1), f2);
                        Animatable animatable = animatableProgress;
                        boolean zChangedInstance = composerImpl3.changedInstance(animatable) | composerImpl3.changed(f3);
                        Object objRememberedValue = composerImpl3.rememberedValue();
                        Object obj5 = Composer.Companion.Empty;
                        if (zChangedInstance || objRememberedValue == obj5) {
                            objRememberedValue = new CardsKt$$ExternalSyntheticLambda37(animatable, f3, (byte) 1);
                            composerImpl3.updateRememberedValue(objRememberedValue);
                        }
                        Modifier modifierGraphicsLayer = ColorKt.graphicsLayer(modifier, (Function1) objRememberedValue);
                        MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(biasAlignment, false);
                        int iHashCode2 = Long.hashCode(composerImpl3.compositeKeyHashCode);
                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope2 = composerImpl3.currentCompositionLocalScope();
                        Modifier modifierMaterializeModifier2 = AbsoluteAlignment.materializeModifier(composerImpl3, modifierGraphicsLayer);
                        composerImpl3.startReusableNode();
                        if (composerImpl3.inserting) {
                            composerImpl3.createNode(r13);
                        } else {
                            composerImpl3.useNode();
                        }
                        AnchoredGroupPath.set-impl(composerImpl3, measurePolicyMaybeCachedBoxMeasurePolicy2, r14);
                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope2, r9);
                        if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode2))) {
                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode2, composerImpl3, iHashCode2, r11);
                        }
                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier2, r4);
                        Modifier modifierFillMaxSize = SizeKt.fillMaxSize(companion, 1.0f);
                        final long j4 = j3;
                        boolean zChanged = composerImpl3.changed(j4);
                        Object objRememberedValue2 = composerImpl3.rememberedValue();
                        if (zChanged || objRememberedValue2 == obj5) {
                            objRememberedValue2 = new MainActivityKt$.ExternalSyntheticLambda140(j4, (byte) 12);
                            composerImpl3.updateRememberedValue(objRememberedValue2);
                        }
                        ImageKt.Canvas(modifierFillMaxSize, (Function1) objRememberedValue2, composerImpl3, 6);
                        Modifier modifierFillMaxSize2 = SizeKt.fillMaxSize(companion, 1.0f);
                        float f4 = f;
                        boolean zChanged2 = composerImpl3.changed(f4);
                        Object objRememberedValue3 = composerImpl3.rememberedValue();
                        if (zChanged2 || objRememberedValue3 == obj5) {
                            objRememberedValue3 = new SunKt$.ExternalSyntheticLambda2(f4, (byte) 2);
                            composerImpl3.updateRememberedValue(objRememberedValue3);
                        }
                        Modifier modifierGraphicsLayer2 = ColorKt.graphicsLayer(modifierFillMaxSize2, (Function1) objRememberedValue3);
                        MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy3 = BoxKt.maybeCachedBoxMeasurePolicy(biasAlignment, false);
                        int iHashCode3 = Long.hashCode(composerImpl3.compositeKeyHashCode);
                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl3.currentCompositionLocalScope();
                        Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl3, modifierGraphicsLayer2);
                        composerImpl3.startReusableNode();
                        if (composerImpl3.inserting) {
                            composerImpl3.createNode(r13);
                        } else {
                            composerImpl3.useNode();
                        }
                        AnchoredGroupPath.set-impl(composerImpl3, measurePolicyMaybeCachedBoxMeasurePolicy3, r14);
                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, r9);
                        if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode3, composerImpl3, iHashCode3, r11);
                        }
                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier3, r4);
                        final SpotifriedStats spotifriedStats2 = spotifriedStats;
                        SunKt.Sun(spotifriedStats2.hours, fSunScale, false, sunMotionRememberSunMotion, SizeKt.fillMaxSize(companion, 1.0f), false, (Integer) null, (Function1) null, (String) null, false, composerImpl3, 805331328, 480);
                        composerImpl3.end(true);
                        composerImpl3.end(true);
                        composerImpl3.end(true);
                        final boolean z2 = z;
                        CardsKt.CardColumn(Expect_jvmKt.rememberComposableLambda(-1160546759, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda43
                            /* JADX WARN: Code duplicated, block: B:19:0x005c  */
                            /* JADX WARN: Code duplicated, block: B:20:0x005f  */
                            /* JADX WARN: Code duplicated, block: B:22:0x0065  */
                            public final Object invoke(Object obj6, Object obj7, Object obj8) {
                                String strM;
                                ComposerImpl composerImpl4 = (ComposerImpl) obj7;
                                int iIntValue2 = ((Integer) obj8).intValue();
                                ((ColumnScopeInstance) obj6).getClass();
                                if (composerImpl4.shouldExecute(iIntValue2 & 1, (iIntValue2 & 17) != 16)) {
                                    AnnotatedString.Builder builder = new AnnotatedString.Builder();
                                    String string = spotifriedStats2.period.label;
                                    if (string.length() == 4) {
                                        int i3 = 0;
                                        while (true) {
                                            if (i3 >= string.length()) {
                                                strM = string.concat(",");
                                            } else if (Character.isDigit(string.charAt(i3))) {
                                                i3++;
                                            } else if (string.equals("All time")) {
                                                strM = "Everything,";
                                            } else {
                                                if (string.length() > 0) {
                                                    StringBuilder sb = new StringBuilder();
                                                    String strValueOf = String.valueOf(string.charAt(0));
                                                    strValueOf.getClass();
                                                    String lowerCase = strValueOf.toLowerCase(Locale.ROOT);
                                                    lowerCase.getClass();
                                                    sb.append((Object) lowerCase);
                                                    sb.append(string.substring(1));
                                                    string = sb.toString();
                                                }
                                                strM = OperationKt$.ExternalSyntheticLambda0.m("Your ", string, ",");
                                            }
                                        }
                                    } else if (string.equals("All time")) {
                                        strM = "Everything,";
                                    } else {
                                        if (string.length() > 0) {
                                            StringBuilder sb2 = new StringBuilder();
                                            String strValueOf2 = String.valueOf(string.charAt(0));
                                            strValueOf2.getClass();
                                            String lowerCase2 = strValueOf2.toLowerCase(Locale.ROOT);
                                            lowerCase2.getClass();
                                            sb2.append((Object) lowerCase2);
                                            sb2.append(string.substring(1));
                                            string = sb2.toString();
                                        }
                                        strM = OperationKt$.ExternalSyntheticLambda0.m("Your ", string, ",");
                                    }
                                    builder.append(strM);
                                    builder.append("\nplayed\n");
                                    int iPushStyle = builder.pushStyle(new SpanStyle(j4, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
                                    try {
                                        builder.append("back.");
                                        builder.pop(iPushStyle);
                                        AnnotatedString annotatedString = builder.toAnnotatedString();
                                        Modifier.Companion companion2 = Modifier.Companion.$$INSTANCE;
                                        boolean z3 = z2;
                                        TextKt.Text-Z58ophY(annotatedString, CardsKt.rise(companion2, 0, z3, composerImpl4, 54), 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, CardsKt.Headline, composerImpl4, 0, 100663296, 262140);
                                        TextKt.Text-Nvy7gAk("Tap to start. This one is about you.", CardsKt.rise(OffsetKt.padding-qDBjuR0$default(companion2, 0.0f, 14.0f, 0.0f, 0.0f, 13), 1, z3, composerImpl4, 54), CardsKt.soft(composerImpl4), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, CardsKt.Sub, composerImpl4, 6, 12582912, 131064);
                                    } catch (Throwable th) {
                                        builder.pop(iPushStyle);
                                        throw th;
                                    }
                                } else {
                                    composerImpl4.skipToGroupEnd();
                                }
                                return Unit.INSTANCE;
                            }
                        }, composerImpl3), composerImpl3, 6);
                    } else {
                        composerImpl3.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }, composerImpl2), composerImpl2, 3078, 6);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 5);
        }
    }

    public static final void IntroCard(SpotifriedStats spotifriedStats, boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        composerImpl.startRestartGroup(1072830128);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changed(z) ? 32 : 16;
        }
        boolean zRememberNoMotion = true;
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            if (z) {
                composerImpl.startReplaceGroup(1830790330);
            } else {
                composerImpl.startReplaceGroup(197605346);
                zRememberNoMotion = SunKt.rememberNoMotion(composerImpl);
            }
            composerImpl.end(false);
            composerImpl.startMovableGroup(197606102, composerImpl.joinKey(spotifriedStats.period, Boolean.valueOf(zRememberNoMotion)));
            Intro(spotifriedStats, zRememberNoMotion, composerImpl, i2 & 14);
            composerImpl.end(false);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 7);
        }
    }

    public static final void Months(final SpotifriedStats spotifriedStats, final boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        final boolean z2;
        composerImpl.startRestartGroup(-1623517661);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changed(z) ? 32 : 16;
        }
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            StaticProvidableCompositionLocal staticProvidableCompositionLocal = ColorSchemeKt.LocalColorScheme;
            final long j = ((ColorScheme) composerImpl.consume(staticProvidableCompositionLocal)).primary;
            final long j2 = Color.copy-wmQWz5c$default(0.14f, ((ColorScheme) composerImpl.consume(staticProvidableCompositionLocal)).onBackground);
            ArrayList arrayList = spotifriedStats.months;
            String str = spotifriedStats.period.label;
            YearMonth yearMonth = spotifriedStats.changeMonth;
            Iterator it = arrayList.iterator();
            int i3 = 0;
            while (true) {
                if (!it.hasNext()) {
                    i3 = -1;
                    break;
                } else if (((MonthTop) it.next()).month.equals(yearMonth)) {
                    break;
                } else {
                    i3++;
                }
            }
            Integer numValueOf = Integer.valueOf(i3);
            if (i3 < 0) {
                numValueOf = null;
            }
            int iMin = Math.min(arrayList.size() - 12, numValueOf != null ? numValueOf.intValue() : arrayList.size());
            if (iMin < 0) {
                iMin = 0;
            }
            final List listTake = CollectionsKt.take(CollectionsKt.drop(arrayList, iMin), 12);
            final boolean z3 = ((MonthTop) CollectionsKt.first(listTake)).month.getYear() != ((MonthTop) CollectionsKt.last(listTake)).month.getYear();
            final DateTimeFormatter dateTimeFormatterOfPattern = DateTimeFormatter.ofPattern(z3 ? "MMM ''yy" : "MMM", english);
            if (str.length() != 4) {
                z2 = false;
                break;
            }
            int i4 = 0;
            while (true) {
                if (i4 >= str.length()) {
                    z2 = true;
                    break;
                } else {
                    if (!Character.isDigit(str.charAt(i4))) {
                        z2 = false;
                        break;
                    }
                    i4++;
                }
            }
            final float f = ((Density) composerImpl.consume(CompositionLocalsKt.LocalDensity)).toPx-0680j_4(14.0f);
            CardColumn(Expect_jvmKt.rememberComposableLambda(-1291375200, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda29
                public final Object invoke(Object obj, Object obj2, Object obj3) {
                    ColumnScopeInstance columnScopeInstance = (ColumnScopeInstance) obj;
                    ComposerImpl composerImpl2 = (ComposerImpl) obj2;
                    int iIntValue = ((Integer) obj3).intValue();
                    columnScopeInstance.getClass();
                    if ((iIntValue & 6) == 0) {
                        iIntValue |= composerImpl2.changed(columnScopeInstance) ? 4 : 2;
                    }
                    if (composerImpl2.shouldExecute(iIntValue & 1, (iIntValue & 19) != 18)) {
                        AnnotatedString.Builder builder = new AnnotatedString.Builder();
                        builder.append(z2 ? "Your year,\n" : "Your months,\n");
                        final long j3 = j;
                        int iPushStyle = builder.pushStyle(new SpanStyle(j3, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
                        try {
                            builder.append("in order.");
                            builder.pop(iPushStyle);
                            TextKt.Text-Z58ophY(builder.toAnnotatedString(), (Modifier) null, 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, CardsKt.Headline, composerImpl2, 0, 100663296, 262142);
                            Modifier modifier = OffsetKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth(ColumnScopeInstance.weight$default(columnScopeInstance, 1.0f), 1.0f), 0.0f, 22.0f, 0.0f, 0.0f, 13);
                            final List list = listTake;
                            final SpotifriedStats spotifriedStats2 = spotifriedStats;
                            final boolean z4 = z;
                            final float f2 = f;
                            final long j4 = j2;
                            final DateTimeFormatter dateTimeFormatter = dateTimeFormatterOfPattern;
                            final boolean z5 = z3;
                            OffsetKt.BoxWithConstraints(modifier, (BiasAlignment) null, Expect_jvmKt.rememberComposableLambda(-2001370358, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda46
                                public final Object invoke(Object obj4, Object obj5, Object obj6) {
                                    boolean z6;
                                    CardsKt$$ExternalSyntheticLambda46 cardsKt$$ExternalSyntheticLambda46 = this;
                                    BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl = (BoxWithConstraintsScopeImpl) obj4;
                                    ComposerImpl composerImpl3 = (ComposerImpl) obj5;
                                    int iIntValue2 = ((Integer) obj6).intValue();
                                    boxWithConstraintsScopeImpl.getClass();
                                    byte b = 2;
                                    if ((iIntValue2 & 6) == 0) {
                                        iIntValue2 |= composerImpl3.changed(boxWithConstraintsScopeImpl) ? 4 : 2;
                                    }
                                    boolean z7 = false;
                                    boolean z8 = true;
                                    if (composerImpl3.shouldExecute(iIntValue2 & 1, (iIntValue2 & 19) != 18)) {
                                        float f3 = boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM();
                                        List list2 = list;
                                        Dp dp = new Dp(f3 / list2.size());
                                        Dp dp2 = new Dp(72.0f);
                                        if (dp.compareTo(dp2) > 0) {
                                            dp = dp2;
                                        }
                                        FontListFontFamily fontListFontFamily = TypeKt.Albert;
                                        FontWeight fontWeight = FontWeight.ExtraBold;
                                        float f4 = dp.value;
                                        float f5 = 12.0f;
                                        TextStyle textStyle = new TextStyle(0L, UnsignedKt.pack(ResultKt.coerceIn(0.45f * f4, 12.0f, 22.0f), 4294967296L), fontWeight, fontListFontFamily, UnsignedKt.getSp(-0.3d), 0, 0L, 0, 16777049);
                                        byte b2 = 14;
                                        TextStyle textStyle2 = TextStyle.copy-p1EtxEg$default(CardsKt.Sub, 0L, UnsignedKt.getSp(12), FontWeight.SemiBold, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, UnsignedKt.getSp(14), (LineHeightStyle) null, 0, 16646137);
                                        ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(OffsetKt.Top, Alignment.Companion.Start, composerImpl3, 0);
                                        int iHashCode = Long.hashCode(composerImpl3.compositeKeyHashCode);
                                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl3.currentCompositionLocalScope();
                                        Modifier modifier2 = Modifier.Companion.$$INSTANCE;
                                        Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl3, modifier2);
                                        ComposeUiNode.Companion.getClass();
                                        LayoutNode.Companion.Constructor.1 r14 = ComposeUiNode.Companion.Constructor;
                                        composerImpl3.startReusableNode();
                                        if (composerImpl3.inserting) {
                                            composerImpl3.createNode(r14);
                                        } else {
                                            composerImpl3.useNode();
                                        }
                                        AnchoredGroupPath.set-impl(composerImpl3, columnMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
                                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope, ComposeUiNode.Companion.SetResolvedCompositionLocals);
                                        ComposeUiNode.Companion.SetModifier.1 r9 = ComposeUiNode.Companion.SetCompositeKeyHash;
                                        if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode))) {
                                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl3, iHashCode, r9);
                                        }
                                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier, ComposeUiNode.Companion.SetModifier);
                                        composerImpl3.startReplaceGroup(2012960091);
                                        int i5 = 0;
                                        for (Object obj7 : list2) {
                                            int i6 = i5 + 1;
                                            if (i5 < 0) {
                                                ByteStreamsKt.throwIndexOverflow();
                                                throw null;
                                            }
                                            MonthTop monthTop = (MonthTop) obj7;
                                            boolean zEquals = monthTop.month.equals(spotifriedStats2.changeMonth);
                                            Animatable animatableProgress = CardsKt.progress((i5 * 90) + 200, 700, 384, composerImpl3, z4);
                                            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.height-3ABfNKs(SizeKt.fillMaxWidth(modifier2, 1.0f), f4), zEquals ? "change_month" : "month");
                                            boolean zChangedInstance = composerImpl3.changedInstance(animatableProgress);
                                            float f6 = f2;
                                            boolean zChanged = zChangedInstance | composerImpl3.changed(f6);
                                            Object objRememberedValue = composerImpl3.rememberedValue();
                                            Object obj8 = Composer.Companion.Empty;
                                            if (zChanged || objRememberedValue == obj8) {
                                                objRememberedValue = new CardsKt$$ExternalSyntheticLambda37(animatableProgress, f6, b);
                                                composerImpl3.updateRememberedValue(objRememberedValue);
                                            }
                                            Modifier modifierGraphicsLayer = ColorKt.graphicsLayer(modifierTestTag, (Function1) objRememberedValue);
                                            long j5 = j4;
                                            boolean zChanged2 = composerImpl3.changed(j5);
                                            Object objRememberedValue2 = composerImpl3.rememberedValue();
                                            if (zChanged2 || objRememberedValue2 == obj8) {
                                                objRememberedValue2 = new MainActivityKt$.ExternalSyntheticLambda140(j5, b2);
                                                composerImpl3.updateRememberedValue(objRememberedValue2);
                                            }
                                            Modifier modifierDrawBehind = ClipKt.drawBehind(modifierGraphicsLayer, (Function1) objRememberedValue2);
                                            RowMeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(new Arrangement.SpacedAligned(f5, new SaversKt$.ExternalSyntheticLambda0((byte) 3)), Alignment.Companion.CenterVertically, composerImpl3, 54);
                                            int iHashCode2 = Long.hashCode(composerImpl3.compositeKeyHashCode);
                                            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope2 = composerImpl3.currentCompositionLocalScope();
                                            Modifier modifierMaterializeModifier2 = AbsoluteAlignment.materializeModifier(composerImpl3, modifierDrawBehind);
                                            ComposeUiNode.Companion.getClass();
                                            LayoutNode.Companion.Constructor.1 r15 = ComposeUiNode.Companion.Constructor;
                                            composerImpl3.startReusableNode();
                                            if (composerImpl3.inserting) {
                                                composerImpl3.createNode(r15);
                                            } else {
                                                composerImpl3.useNode();
                                            }
                                            AnchoredGroupPath.set-impl(composerImpl3, rowMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
                                            AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope2, ComposeUiNode.Companion.SetResolvedCompositionLocals);
                                            ComposeUiNode.Companion.SetModifier.1 r7 = ComposeUiNode.Companion.SetCompositeKeyHash;
                                            if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode2))) {
                                                OperationKt$.ExternalSyntheticLambda0.m(iHashCode2, composerImpl3, iHashCode2, r7);
                                            }
                                            AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier2, ComposeUiNode.Companion.SetModifier);
                                            String str2 = monthTop.month.format(dateTimeFormatter);
                                            str2.getClass();
                                            float f7 = f4;
                                            byte b3 = b;
                                            ComposerImpl composerImpl4 = composerImpl3;
                                            byte b4 = b2;
                                            Modifier modifier3 = modifier2;
                                            TextKt.Text-Nvy7gAk(str2, SizeKt.width-3ABfNKs(modifier2, z5 ? 52.0f : 32.0f), CardsKt.soft(composerImpl3), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 1, 0, (Function1) null, textStyle2, composerImpl4, 0, 24576, 114680);
                                            TextStyle textStyle3 = textStyle2;
                                            String str3 = monthTop.song.title;
                                            LayoutWeightElement layoutWeightElement = new LayoutWeightElement(1.0f, true);
                                            cardsKt$$ExternalSyntheticLambda46 = this;
                                            long j6 = j3;
                                            TextKt.Text-Nvy7gAk(str3, layoutWeightElement, zEquals ? j6 : Color.Unspecified, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 2, false, 1, 0, (Function1) null, textStyle, composerImpl4, 0, 24960, 110584);
                                            composerImpl3 = composerImpl4;
                                            if (zEquals) {
                                                composerImpl3.startReplaceGroup(-1217594055);
                                                TextKt.Text-Nvy7gAk("taste changed", (Modifier) null, j6, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(textStyle3, 0L, UnsignedKt.getSp(11), (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, 0L, (LineHeightStyle) null, 0, 16777213), composerImpl3, 6, 0, 131066);
                                                composerImpl3 = composerImpl3;
                                                z6 = false;
                                            } else {
                                                z6 = false;
                                                composerImpl3.startReplaceGroup(871373396);
                                            }
                                            composerImpl3.end(z6);
                                            composerImpl3.end(true);
                                            z8 = true;
                                            z7 = z6;
                                            textStyle2 = textStyle3;
                                            i5 = i6;
                                            b2 = b4;
                                            modifier2 = modifier3;
                                            b = b3;
                                            f4 = f7;
                                            f5 = 12.0f;
                                        }
                                        composerImpl3.end(z7);
                                        composerImpl3.end(z8);
                                    } else {
                                        composerImpl3.skipToGroupEnd();
                                    }
                                    return Unit.INSTANCE;
                                }
                            }, composerImpl2), composerImpl2, 3072, 6);
                        } catch (Throwable th) {
                            builder.pop(iPushStyle);
                            throw th;
                        }
                    } else {
                        composerImpl2.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }, composerImpl), composerImpl, 6);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 6);
        }
    }

    public static final void MonthsCard(SpotifriedStats spotifriedStats, boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup;
        CardsKt$$ExternalSyntheticLambda0 cardsKt$$ExternalSyntheticLambda0;
        boolean zRememberNoMotion;
        composerImpl.startRestartGroup(-312595245);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changed(z) ? 32 : 16;
        }
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            if (spotifriedStats.months.isEmpty()) {
                recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
                if (recomposeScopeImplEndRestartGroup == null) {
                    return;
                } else {
                    cardsKt$$ExternalSyntheticLambda0 = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 12);
                }
            } else {
                if (z) {
                    composerImpl.startReplaceGroup(-1035713737);
                    composerImpl.end(false);
                    zRememberNoMotion = true;
                } else {
                    composerImpl.startReplaceGroup(243684805);
                    zRememberNoMotion = SunKt.rememberNoMotion(composerImpl);
                    composerImpl.end(false);
                }
                composerImpl.startMovableGroup(243685562, composerImpl.joinKey(spotifriedStats.period, Boolean.valueOf(zRememberNoMotion)));
                Months(spotifriedStats, zRememberNoMotion, composerImpl, i2 & 14);
                composerImpl.end(false);
            }
            recomposeScopeImplEndRestartGroup.block = cardsKt$$ExternalSyntheticLambda0;
        }
        composerImpl.skipToGroupEnd();
        recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            cardsKt$$ExternalSyntheticLambda0 = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 1);
            recomposeScopeImplEndRestartGroup.block = cardsKt$$ExternalSyntheticLambda0;
        }
    }

    public static final void SunCard(SpotifriedStats spotifriedStats, boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        composerImpl.startRestartGroup(973200144);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changed(z) ? 32 : 16;
        }
        boolean zRememberNoMotion = true;
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            if (z) {
                composerImpl.startReplaceGroup(1576336538);
            } else {
                composerImpl.startReplaceGroup(-1057528830);
                zRememberNoMotion = SunKt.rememberNoMotion(composerImpl);
            }
            composerImpl.end(false);
            composerImpl.startMovableGroup(-1057528068, composerImpl.joinKey(spotifriedStats.period, Boolean.valueOf(zRememberNoMotion)));
            SunPortrait(spotifriedStats, zRememberNoMotion, composerImpl, i2 & 14);
            composerImpl.end(false);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 8);
        }
    }

    /* JADX WARN: Code duplicated, block: B:36:0x012c  */
    /* JADX WARN: Code duplicated, block: B:37:0x0130  */
    /* JADX WARN: Code duplicated, block: B:42:0x014b  */
    /* JADX WARN: Code duplicated, block: B:45:0x0161  */
    /* JADX WARN: Code duplicated, block: B:48:0x0168  */
    /* JADX WARN: Code duplicated, block: B:50:0x0172 A[LOOP:0: B:46:0x0162->B:50:0x0172, LOOP_END] */
    /* JADX WARN: Code duplicated, block: B:52:0x0178  */
    /* JADX WARN: Code duplicated, block: B:54:0x0180  */
    /* JADX WARN: Code duplicated, block: B:55:0x0183  */
    /* JADX WARN: Code duplicated, block: B:57:0x018b  */
    /* JADX WARN: Code duplicated, block: B:58:0x018e  */
    /* JADX WARN: Code duplicated, block: B:72:0x0178 A[SYNTHETIC] */
    /* JADX WARN: Code duplicated, block: B:73:0x0175 A[SYNTHETIC] */
    public static final void SunPortrait(final SpotifriedStats spotifriedStats, boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        byte b;
        boolean z2;
        SunMotion sunMotion;
        int iHashCode;
        AnnotatedString.Builder builder;
        String str;
        String str2;
        int iPushStyle;
        int i3;
        ComposerImpl composerImpl2 = composerImpl;
        composerImpl2.startRestartGroup(-1338794341);
        if ((i & 6) == 0) {
            i2 = i | (composerImpl2.changedInstance(spotifriedStats) ? 4 : 2);
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl2.changed(z) ? 32 : 16;
        }
        if (composerImpl2.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            final long j = ((ColorScheme) composerImpl2.consume(ColorSchemeKt.LocalColorScheme)).primary;
            final float fSunScale = Log.sunScale(Log.minutesOf(spotifriedStats.seconds));
            int i4 = (i2 << 3) & 896;
            SunMotion sunMotionRememberSunMotion = rememberSunMotion(spotifriedStats.hours, fSunScale, z, composerImpl2);
            final Animatable animatableClock = clock(z, 2300.0f, composerImpl2, ((i2 >> 3) & 14) | 48);
            final TextStyle textStyle = TextStyle.copy-p1EtxEg$default(Sub, 0L, UnsignedKt.getSp(11), FontWeight.SemiBold, (FontStyle) null, (FontFamily) null, 0L, new Shadow(2, Color.Black), UnsignedKt.getSp(14), (LineHeightStyle) null, 0, 16637945);
            Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
            Modifier modifier = OffsetKt.padding-qDBjuR0$default(SizeKt.fillMaxSize(companion, 1.0f), 0.0f, 20.0f, 0.0f, 28.0f, 5);
            Arrangement.Top.1 r9 = OffsetKt.Top;
            BiasAlignment.Horizontal horizontal = Alignment.Companion.Start;
            ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(r9, horizontal, composerImpl2, 0);
            int iHashCode2 = Long.hashCode(composerImpl2.compositeKeyHashCode);
            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl2.currentCompositionLocalScope();
            Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl2, modifier);
            ComposeUiNode.Companion.getClass();
            LayoutNode.Companion.Constructor.1 r2 = ComposeUiNode.Companion.Constructor;
            composerImpl2.startReusableNode();
            if (composerImpl2.inserting) {
                composerImpl2.createNode(r2);
            } else {
                composerImpl2.useNode();
            }
            ComposeUiNode.Companion.SetModifier.1 r0 = ComposeUiNode.Companion.SetMeasurePolicy;
            AnchoredGroupPath.set-impl(composerImpl2, columnMeasurePolicy, r0);
            ComposeUiNode.Companion.SetModifier.1 r1 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
            AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope, r1);
            ComposeUiNode.Companion.SetModifier.1 r8 = ComposeUiNode.Companion.SetCompositeKeyHash;
            try {
                if (composerImpl2.inserting) {
                    sunMotion = sunMotionRememberSunMotion;
                } else {
                    sunMotion = sunMotionRememberSunMotion;
                    if (!Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                    }
                    ComposeUiNode.Companion.SetModifier.1 r5 = ComposeUiNode.Companion.SetModifier;
                    AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier, r5);
                    Modifier modifier2 = OffsetKt.padding-VpY3zN4$default(companion, 26.0f, 0.0f, 2);
                    ColumnMeasurePolicy columnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(r9, horizontal, composerImpl2, 0);
                    iHashCode = Long.hashCode(composerImpl2.compositeKeyHashCode);
                    PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope2 = composerImpl2.currentCompositionLocalScope();
                    Modifier modifierMaterializeModifier2 = AbsoluteAlignment.materializeModifier(composerImpl2, modifier2);
                    composerImpl2.startReusableNode();
                    if (composerImpl2.inserting) {
                        composerImpl2.createNode(r2);
                    } else {
                        composerImpl2.useNode();
                    }
                    AnchoredGroupPath.set-impl(composerImpl2, columnMeasurePolicy2, r0);
                    AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope2, r1);
                    if (composerImpl2.inserting || !Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode))) {
                        OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl2, iHashCode, r8);
                    }
                    AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier2, r5);
                    builder = new AnnotatedString.Builder();
                    str = spotifriedStats.period.label;
                    if (str.length() == 4) {
                        i3 = 0;
                        while (true) {
                            if (i3 < str.length()) {
                                str2 = "This is your year as ";
                            } else if (Character.isDigit(str.charAt(i3))) {
                                i3++;
                            } else if (str.equals("Last 12 months")) {
                                str2 = "This is your twelve months as ";
                            } else if (str.equals("All time")) {
                                str2 = "This is all your listening as ";
                            } else {
                                str2 = "This is your listening as ";
                            }
                        }
                    } else if (str.equals("Last 12 months")) {
                        str2 = "This is your twelve months as ";
                    } else if (str.equals("All time")) {
                        str2 = "This is all your listening as ";
                    } else {
                        str2 = "This is your listening as ";
                    }
                    builder.append(str2);
                    iPushStyle = builder.pushStyle(new SpanStyle(j, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
                    builder.append("a sun.");
                    builder.pop(iPushStyle);
                    AnnotatedString annotatedString = builder.toAnnotatedString();
                    int i5 = i4 | 54;
                    TextKt.Text-Z58ophY(annotatedString, rise(companion, 0, z, composerImpl2, i5), 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, Headline, composerImpl2, 0, 100663296, 262140);
                    TextKt.Text-Nvy7gAk("Each ray is one hour of your day. Longer means you listened more. Nobody else has this one.", rise(OffsetKt.padding-qDBjuR0$default(companion, 0.0f, 14.0f, 0.0f, 0.0f, 13), 1, z, composerImpl2, i5), soft(composerImpl2), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, Sub, composerImpl2, 6, 12582912, 131064);
                    composerImpl2.end(true);
                    Modifier modifier3 = OffsetKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth(new LayoutWeightElement(1.0f, true), 1.0f), 0.0f, 12.0f, 0.0f, 0.0f, 13);
                    BiasAlignment biasAlignment = Alignment.Companion.Center;
                    b = 2;
                    final SunMotion sunMotion2 = sunMotion;
                    ComposableLambdaImpl composableLambdaImplRememberComposableLambda = Expect_jvmKt.rememberComposableLambda(-917368985, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda15
                        public final Object invoke(Object obj, Object obj2, Object obj3) {
                            Object obj4;
                            BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl = (BoxWithConstraintsScopeImpl) obj;
                            ComposerImpl composerImpl3 = (ComposerImpl) obj2;
                            int iIntValue = ((Integer) obj3).intValue();
                            boxWithConstraintsScopeImpl.getClass();
                            if ((iIntValue & 6) == 0) {
                                iIntValue |= composerImpl3.changed(boxWithConstraintsScopeImpl) ? 4 : 2;
                            }
                            if (composerImpl3.shouldExecute(iIntValue & 1, (iIntValue & 19) != 18)) {
                                Dp dp = new Dp(boxWithConstraintsScopeImpl.getMaxWidth-D9Ej5fM() * 1.08f);
                                Dp dp2 = new Dp(boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM());
                                if (dp.compareTo(dp2) > 0) {
                                    dp = dp2;
                                }
                                Modifier modifier4 = Modifier.Companion.$$INSTANCE;
                                float f = dp.value;
                                Modifier modifier5 = SizeKt.requiredSize-3ABfNKs(modifier4, f);
                                Animatable animatable = animatableClock;
                                boolean zChangedInstance = composerImpl3.changedInstance(animatable);
                                Object objRememberedValue = composerImpl3.rememberedValue();
                                Object obj5 = Composer.Companion.Empty;
                                if (zChangedInstance || objRememberedValue == obj5) {
                                    objRememberedValue = new FadeInKt$.ExternalSyntheticLambda1(animatable, (byte) 3);
                                    composerImpl3.updateRememberedValue(objRememberedValue);
                                }
                                Modifier modifierGraphicsLayer = ColorKt.graphicsLayer(modifier5, (Function1) objRememberedValue);
                                long j2 = j;
                                boolean zChanged = composerImpl3.changed(j2);
                                Object objRememberedValue2 = composerImpl3.rememberedValue();
                                if (zChanged || objRememberedValue2 == obj5) {
                                    objRememberedValue2 = new MainActivityKt$.ExternalSyntheticLambda140(j2, (byte) 11);
                                    composerImpl3.updateRememberedValue(objRememberedValue2);
                                }
                                ImageKt.Canvas(modifierGraphicsLayer, (Function1) objRememberedValue2, composerImpl3, 0);
                                Modifier modifierTestTag = TestTagKt.testTag(SizeKt.requiredSize-3ABfNKs(modifier4, f), "sun");
                                boolean zChangedInstance2 = composerImpl3.changedInstance(animatable);
                                Object objRememberedValue3 = composerImpl3.rememberedValue();
                                if (zChangedInstance2 || objRememberedValue3 == obj5) {
                                    objRememberedValue3 = new FadeInKt$.ExternalSyntheticLambda1(animatable, (byte) 4);
                                    composerImpl3.updateRememberedValue(objRememberedValue3);
                                }
                                Modifier modifierDrawWithContent = ClipKt.drawWithContent(modifierTestTag, (Function1) objRememberedValue3);
                                MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.Companion.TopStart, false);
                                int iHashCode3 = Long.hashCode(composerImpl3.compositeKeyHashCode);
                                PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl3.currentCompositionLocalScope();
                                Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl3, modifierDrawWithContent);
                                ComposeUiNode.Companion.getClass();
                                LayoutNode.Companion.Constructor.1 r11 = ComposeUiNode.Companion.Constructor;
                                composerImpl3.startReusableNode();
                                if (composerImpl3.inserting) {
                                    composerImpl3.createNode(r11);
                                } else {
                                    composerImpl3.useNode();
                                }
                                AnchoredGroupPath.set-impl(composerImpl3, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
                                AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, ComposeUiNode.Companion.SetResolvedCompositionLocals);
                                ComposeUiNode.Companion.SetModifier.1 r6 = ComposeUiNode.Companion.SetCompositeKeyHash;
                                if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
                                    OperationKt$.ExternalSyntheticLambda0.m(iHashCode3, composerImpl3, iHashCode3, r6);
                                }
                                AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier3, ComposeUiNode.Companion.SetModifier);
                                List list = spotifriedStats.hours;
                                Modifier modifierFillMaxSize = SizeKt.fillMaxSize(modifier4, 1.0f);
                                float f2 = fSunScale;
                                Modifier modifier6 = modifier4;
                                byte b2 = 0;
                                Object obj6 = obj5;
                                Animatable animatable2 = animatable;
                                SunKt.Sun(list, f2, false, sunMotion2, modifierFillMaxSize, false, (Integer) null, (Function1) null, (String) null, false, composerImpl3, 805331328, 480);
                                composerImpl3.end(true);
                                float f3 = 0.44f * f;
                                Density density = (Density) composerImpl3.consume(CompositionLocalsKt.LocalDensity);
                                TextStyle textStyle2 = textStyle;
                                float f4 = density.toDp-GaN1DYA(textStyle2.paragraphStyle.lineHeight) / 2.0f;
                                float f5 = (boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM() / 2.0f) - f4;
                                Dp dp3 = new Dp(f3);
                                float f6 = 8.0f;
                                Dp dp4 = new Dp((SunKt.sunReach(list, f2, true) * f) + 8.0f + f4);
                                if (dp3.compareTo(dp4) < 0) {
                                    dp3 = dp4;
                                }
                                Dp dp5 = new Dp(f5);
                                if (dp3.compareTo(dp5) > 0) {
                                    dp3 = dp5;
                                }
                                Dp dp6 = new Dp(f3);
                                Dp dp7 = new Dp((SunKt.sunReach(list, f2, false) * f) + 8.0f + f4);
                                if (dp6.compareTo(dp7) < 0) {
                                    dp6 = dp7;
                                }
                                Dp dp8 = new Dp(f5);
                                if (dp6.compareTo(dp8) > 0) {
                                    dp6 = dp8;
                                }
                                float f7 = 0.0f;
                                for (Pair pair : ByteStreamsKt.listOf(new Pair[]{new Pair(0, new Pair(new Dp(0.0f), new Dp(-dp3.value))), new Pair(6, new Pair(new Dp(f3), new Dp(0.0f))), new Pair(12, new Pair(new Dp(0.0f), dp6)), new Pair(18, new Pair(new Dp(-f3), new Dp(0.0f)))})) {
                                    int iIntValue2 = ((Number) pair.first).intValue();
                                    Pair pair2 = (Pair) pair.second;
                                    String strHourName = Log.hourName(iIntValue2);
                                    Modifier modifier7 = modifier6;
                                    Modifier modifierLayout = RulerKt.layout(OffsetKt.padding-VpY3zN4$default(OffsetKt.offset-VpY3zN4$default(modifier7, f7, ((Dp) pair2.second).value, 1), f6, f7, 2), new CardsKt$$ExternalSyntheticLambda50(((boxWithConstraintsScopeImpl.getMaxWidth-D9Ej5fM() / 2.0f) - f6) + ((Dp) pair2.first).value, 0.5f));
                                    Animatable animatable3 = animatable2;
                                    boolean zChangedInstance3 = composerImpl3.changedInstance(animatable3) | composerImpl3.changed(iIntValue2);
                                    Object objRememberedValue4 = composerImpl3.rememberedValue();
                                    if (zChangedInstance3) {
                                        obj4 = obj6;
                                    } else {
                                        obj4 = obj6;
                                        if (objRememberedValue4 == obj4) {
                                        }
                                        ComposerImpl composerImpl4 = composerImpl3;
                                        TextStyle textStyle3 = textStyle2;
                                        TextKt.Text-Nvy7gAk(strHourName, ColorKt.graphicsLayer(modifierLayout, (Function1) objRememberedValue4), CardsKt.soft(composerImpl3), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 1, 0, (Function1) null, textStyle3, composerImpl4, 0, 24576, 114680);
                                        modifier6 = modifier7;
                                        textStyle2 = textStyle3;
                                        composerImpl3 = composerImpl4;
                                        f7 = f7;
                                        obj6 = obj4;
                                        animatable2 = animatable3;
                                        b2 = b2;
                                        f6 = f6;
                                    }
                                    objRememberedValue4 = new CardsKt$$ExternalSyntheticLambda36(animatable3, iIntValue2, b2);
                                    composerImpl3.updateRememberedValue(objRememberedValue4);
                                    ComposerImpl composerImpl5 = composerImpl3;
                                    TextStyle textStyle4 = textStyle2;
                                    TextKt.Text-Nvy7gAk(strHourName, ColorKt.graphicsLayer(modifierLayout, (Function1) objRememberedValue4), CardsKt.soft(composerImpl3), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 1, 0, (Function1) null, textStyle4, composerImpl5, 0, 24576, 114680);
                                    modifier6 = modifier7;
                                    textStyle2 = textStyle4;
                                    composerImpl3 = composerImpl5;
                                    f7 = f7;
                                    obj6 = obj4;
                                    animatable2 = animatable3;
                                    b2 = b2;
                                    f6 = f6;
                                }
                            } else {
                                composerImpl3.skipToGroupEnd();
                            }
                            return Unit.INSTANCE;
                        }
                    }, composerImpl2);
                    composerImpl2 = composerImpl2;
                    OffsetKt.BoxWithConstraints(modifier3, biasAlignment, composableLambdaImplRememberComposableLambda, composerImpl2, 3120, 4);
                    composerImpl2.end(true);
                    z2 = z;
                }
                builder.append("a sun.");
                builder.pop(iPushStyle);
                AnnotatedString annotatedString2 = builder.toAnnotatedString();
                int i6 = i4 | 54;
                TextKt.Text-Z58ophY(annotatedString2, rise(companion, 0, z, composerImpl2, i6), 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, Headline, composerImpl2, 0, 100663296, 262140);
                TextKt.Text-Nvy7gAk("Each ray is one hour of your day. Longer means you listened more. Nobody else has this one.", rise(OffsetKt.padding-qDBjuR0$default(companion, 0.0f, 14.0f, 0.0f, 0.0f, 13), 1, z, composerImpl2, i6), soft(composerImpl2), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, Sub, composerImpl2, 6, 12582912, 131064);
                composerImpl2.end(true);
                Modifier modifier4 = OffsetKt.padding-qDBjuR0$default(SizeKt.fillMaxWidth(new LayoutWeightElement(1.0f, true), 1.0f), 0.0f, 12.0f, 0.0f, 0.0f, 13);
                BiasAlignment biasAlignment2 = Alignment.Companion.Center;
                b = 2;
                final SunMotion sunMotion3 = sunMotion;
                ComposableLambdaImpl composableLambdaImplRememberComposableLambda2 = Expect_jvmKt.rememberComposableLambda(-917368985, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda15
                    public final Object invoke(Object obj, Object obj2, Object obj3) {
                        Object obj4;
                        BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl = (BoxWithConstraintsScopeImpl) obj;
                        ComposerImpl composerImpl3 = (ComposerImpl) obj2;
                        int iIntValue = ((Integer) obj3).intValue();
                        boxWithConstraintsScopeImpl.getClass();
                        if ((iIntValue & 6) == 0) {
                            iIntValue |= composerImpl3.changed(boxWithConstraintsScopeImpl) ? 4 : 2;
                        }
                        if (composerImpl3.shouldExecute(iIntValue & 1, (iIntValue & 19) != 18)) {
                            Dp dp = new Dp(boxWithConstraintsScopeImpl.getMaxWidth-D9Ej5fM() * 1.08f);
                            Dp dp2 = new Dp(boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM());
                            if (dp.compareTo(dp2) > 0) {
                                dp = dp2;
                            }
                            Modifier modifier5 = Modifier.Companion.$$INSTANCE;
                            float f = dp.value;
                            Modifier modifier6 = SizeKt.requiredSize-3ABfNKs(modifier5, f);
                            Animatable animatable = animatableClock;
                            boolean zChangedInstance = composerImpl3.changedInstance(animatable);
                            Object objRememberedValue = composerImpl3.rememberedValue();
                            Object obj5 = Composer.Companion.Empty;
                            if (zChangedInstance || objRememberedValue == obj5) {
                                objRememberedValue = new FadeInKt$.ExternalSyntheticLambda1(animatable, (byte) 3);
                                composerImpl3.updateRememberedValue(objRememberedValue);
                            }
                            Modifier modifierGraphicsLayer = ColorKt.graphicsLayer(modifier6, (Function1) objRememberedValue);
                            long j2 = j;
                            boolean zChanged = composerImpl3.changed(j2);
                            Object objRememberedValue2 = composerImpl3.rememberedValue();
                            if (zChanged || objRememberedValue2 == obj5) {
                                objRememberedValue2 = new MainActivityKt$.ExternalSyntheticLambda140(j2, (byte) 11);
                                composerImpl3.updateRememberedValue(objRememberedValue2);
                            }
                            ImageKt.Canvas(modifierGraphicsLayer, (Function1) objRememberedValue2, composerImpl3, 0);
                            Modifier modifierTestTag = TestTagKt.testTag(SizeKt.requiredSize-3ABfNKs(modifier5, f), "sun");
                            boolean zChangedInstance2 = composerImpl3.changedInstance(animatable);
                            Object objRememberedValue3 = composerImpl3.rememberedValue();
                            if (zChangedInstance2 || objRememberedValue3 == obj5) {
                                objRememberedValue3 = new FadeInKt$.ExternalSyntheticLambda1(animatable, (byte) 4);
                                composerImpl3.updateRememberedValue(objRememberedValue3);
                            }
                            Modifier modifierDrawWithContent = ClipKt.drawWithContent(modifierTestTag, (Function1) objRememberedValue3);
                            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.Companion.TopStart, false);
                            int iHashCode3 = Long.hashCode(composerImpl3.compositeKeyHashCode);
                            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl3.currentCompositionLocalScope();
                            Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl3, modifierDrawWithContent);
                            ComposeUiNode.Companion.getClass();
                            LayoutNode.Companion.Constructor.1 r11 = ComposeUiNode.Companion.Constructor;
                            composerImpl3.startReusableNode();
                            if (composerImpl3.inserting) {
                                composerImpl3.createNode(r11);
                            } else {
                                composerImpl3.useNode();
                            }
                            AnchoredGroupPath.set-impl(composerImpl3, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
                            AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, ComposeUiNode.Companion.SetResolvedCompositionLocals);
                            ComposeUiNode.Companion.SetModifier.1 r6 = ComposeUiNode.Companion.SetCompositeKeyHash;
                            if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode3))) {
                                OperationKt$.ExternalSyntheticLambda0.m(iHashCode3, composerImpl3, iHashCode3, r6);
                            }
                            AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier3, ComposeUiNode.Companion.SetModifier);
                            List list = spotifriedStats.hours;
                            Modifier modifierFillMaxSize = SizeKt.fillMaxSize(modifier5, 1.0f);
                            float f2 = fSunScale;
                            Modifier modifier7 = modifier5;
                            byte b2 = 0;
                            Object obj6 = obj5;
                            Animatable animatable2 = animatable;
                            SunKt.Sun(list, f2, false, sunMotion3, modifierFillMaxSize, false, (Integer) null, (Function1) null, (String) null, false, composerImpl3, 805331328, 480);
                            composerImpl3.end(true);
                            float f3 = 0.44f * f;
                            Density density = (Density) composerImpl3.consume(CompositionLocalsKt.LocalDensity);
                            TextStyle textStyle2 = textStyle;
                            float f4 = density.toDp-GaN1DYA(textStyle2.paragraphStyle.lineHeight) / 2.0f;
                            float f5 = (boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM() / 2.0f) - f4;
                            Dp dp3 = new Dp(f3);
                            float f6 = 8.0f;
                            Dp dp4 = new Dp((SunKt.sunReach(list, f2, true) * f) + 8.0f + f4);
                            if (dp3.compareTo(dp4) < 0) {
                                dp3 = dp4;
                            }
                            Dp dp5 = new Dp(f5);
                            if (dp3.compareTo(dp5) > 0) {
                                dp3 = dp5;
                            }
                            Dp dp6 = new Dp(f3);
                            Dp dp7 = new Dp((SunKt.sunReach(list, f2, false) * f) + 8.0f + f4);
                            if (dp6.compareTo(dp7) < 0) {
                                dp6 = dp7;
                            }
                            Dp dp8 = new Dp(f5);
                            if (dp6.compareTo(dp8) > 0) {
                                dp6 = dp8;
                            }
                            float f7 = 0.0f;
                            for (Pair pair : ByteStreamsKt.listOf(new Pair[]{new Pair(0, new Pair(new Dp(0.0f), new Dp(-dp3.value))), new Pair(6, new Pair(new Dp(f3), new Dp(0.0f))), new Pair(12, new Pair(new Dp(0.0f), dp6)), new Pair(18, new Pair(new Dp(-f3), new Dp(0.0f)))})) {
                                int iIntValue2 = ((Number) pair.first).intValue();
                                Pair pair2 = (Pair) pair.second;
                                String strHourName = Log.hourName(iIntValue2);
                                Modifier modifier8 = modifier7;
                                Modifier modifierLayout = RulerKt.layout(OffsetKt.padding-VpY3zN4$default(OffsetKt.offset-VpY3zN4$default(modifier8, f7, ((Dp) pair2.second).value, 1), f6, f7, 2), new CardsKt$$ExternalSyntheticLambda50(((boxWithConstraintsScopeImpl.getMaxWidth-D9Ej5fM() / 2.0f) - f6) + ((Dp) pair2.first).value, 0.5f));
                                Animatable animatable3 = animatable2;
                                boolean zChangedInstance3 = composerImpl3.changedInstance(animatable3) | composerImpl3.changed(iIntValue2);
                                Object objRememberedValue4 = composerImpl3.rememberedValue();
                                if (zChangedInstance3) {
                                    obj4 = obj6;
                                } else {
                                    obj4 = obj6;
                                    if (objRememberedValue4 == obj4) {
                                    }
                                    ComposerImpl composerImpl5 = composerImpl3;
                                    TextStyle textStyle4 = textStyle2;
                                    TextKt.Text-Nvy7gAk(strHourName, ColorKt.graphicsLayer(modifierLayout, (Function1) objRememberedValue4), CardsKt.soft(composerImpl3), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 1, 0, (Function1) null, textStyle4, composerImpl5, 0, 24576, 114680);
                                    modifier7 = modifier8;
                                    textStyle2 = textStyle4;
                                    composerImpl3 = composerImpl5;
                                    f7 = f7;
                                    obj6 = obj4;
                                    animatable2 = animatable3;
                                    b2 = b2;
                                    f6 = f6;
                                }
                                objRememberedValue4 = new CardsKt$$ExternalSyntheticLambda36(animatable3, iIntValue2, b2);
                                composerImpl3.updateRememberedValue(objRememberedValue4);
                                ComposerImpl composerImpl6 = composerImpl3;
                                TextStyle textStyle5 = textStyle2;
                                TextKt.Text-Nvy7gAk(strHourName, ColorKt.graphicsLayer(modifierLayout, (Function1) objRememberedValue4), CardsKt.soft(composerImpl3), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 1, 0, (Function1) null, textStyle5, composerImpl6, 0, 24576, 114680);
                                modifier7 = modifier8;
                                textStyle2 = textStyle5;
                                composerImpl3 = composerImpl6;
                                f7 = f7;
                                obj6 = obj4;
                                animatable2 = animatable3;
                                b2 = b2;
                                f6 = f6;
                            }
                        } else {
                            composerImpl3.skipToGroupEnd();
                        }
                        return Unit.INSTANCE;
                    }
                }, composerImpl2);
                composerImpl2 = composerImpl2;
                OffsetKt.BoxWithConstraints(modifier4, biasAlignment2, composableLambdaImplRememberComposableLambda2, composerImpl2, 3120, 4);
                composerImpl2.end(true);
                z2 = z;
            } catch (Throwable th) {
                builder.pop(iPushStyle);
                throw th;
            }
            OperationKt$.ExternalSyntheticLambda0.m(iHashCode2, composerImpl2, iHashCode2, r8);
            ComposeUiNode.Companion.SetModifier.1 r6 = ComposeUiNode.Companion.SetModifier;
            AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier, r6);
            Modifier modifier5 = OffsetKt.padding-VpY3zN4$default(companion, 26.0f, 0.0f, 2);
            ColumnMeasurePolicy columnMeasurePolicy3 = ColumnKt.columnMeasurePolicy(r9, horizontal, composerImpl2, 0);
            iHashCode = Long.hashCode(composerImpl2.compositeKeyHashCode);
            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl2.currentCompositionLocalScope();
            Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl2, modifier5);
            composerImpl2.startReusableNode();
            if (composerImpl2.inserting) {
                composerImpl2.createNode(r2);
            } else {
                composerImpl2.useNode();
            }
            AnchoredGroupPath.set-impl(composerImpl2, columnMeasurePolicy3, r0);
            AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, r1);
            if (composerImpl2.inserting) {
                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl2, iHashCode, r8);
            } else {
                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl2, iHashCode, r8);
            }
            AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier3, r6);
            builder = new AnnotatedString.Builder();
            str = spotifriedStats.period.label;
            if (str.length() == 4) {
                i3 = 0;
                while (true) {
                    if (i3 < str.length()) {
                        str2 = "This is your year as ";
                    } else if (Character.isDigit(str.charAt(i3))) {
                        i3++;
                    } else if (str.equals("Last 12 months")) {
                        str2 = "This is your twelve months as ";
                    } else if (str.equals("All time")) {
                        str2 = "This is all your listening as ";
                    } else {
                        str2 = "This is your listening as ";
                    }
                }
            } else if (str.equals("Last 12 months")) {
                str2 = "This is your twelve months as ";
            } else if (str.equals("All time")) {
                str2 = "This is all your listening as ";
            } else {
                str2 = "This is your listening as ";
            }
            builder.append(str2);
            iPushStyle = builder.pushStyle(new SpanStyle(j, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
        } else {
            b = 2;
            z2 = z;
            composerImpl2.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl2.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z2, i, b);
        }
    }

    public static final void TopSong(final TopSong topSong, final boolean z, ComposerImpl composerImpl, int i) {
        byte b;
        Object obj;
        long j;
        InfiniteTransition.TransitionAnimationState transitionAnimationStateAnimateFloat;
        long j2;
        composerImpl.startRestartGroup(-400904898);
        int i2 = (composerImpl.changedInstance(topSong) ? 4 : 2) | i | (composerImpl.changed(z) ? 32 : 16);
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            long j3 = ((ColorScheme) composerImpl.consume(ColorSchemeKt.LocalColorScheme)).primary;
            final CountUp countUp = countUp(topSong.plays, 700, (i2 & 112) | 384, composerImpl, z);
            if (z) {
                composerImpl.startReplaceGroup(946480991);
                composerImpl.end(false);
                j = j3;
                transitionAnimationStateAnimateFloat = null;
                obj = null;
            } else {
                composerImpl.startReplaceGroup(1277459206);
                obj = null;
                j = j3;
                transitionAnimationStateAnimateFloat = ArcSplineKt.animateFloat(ArcSplineKt.rememberInfiniteTransition("rings", composerImpl, 0), 0.0f, 1.0f, ArcSplineKt.infiniteRepeatable-9IiC70o$default(ArcSplineKt.tween$default(3200, 0, EasingKt.LinearEasing, 2), RepeatMode.Restart, 0L, 4), "ring", composerImpl, 29112, 0);
                composerImpl.end(false);
            }
            final RoundedCornerShape roundedCornerShape = RoundedCornerShapeKt.RoundedCornerShape-0680j_4(18.0f);
            Object objRememberedValue = composerImpl.rememberedValue();
            NeverEqualPolicy neverEqualPolicy = Composer.Companion.Empty;
            if (objRememberedValue == neverEqualPolicy) {
                objRememberedValue = AnchoredGroupPath.mutableStateOf$default(obj);
                composerImpl.updateRememberedValue(objRememberedValue);
            }
            MutableState mutableState = (MutableState) objRememberedValue;
            Object objRememberedValue2 = composerImpl.rememberedValue();
            if (objRememberedValue2 == neverEqualPolicy) {
                objRememberedValue2 = AnchoredGroupPath.mutableStateOf$default(obj);
                composerImpl.updateRememberedValue(objRememberedValue2);
            }
            final MutableState mutableState2 = (MutableState) objRememberedValue2;
            Modifier modifierFillMaxSize = SizeKt.fillMaxSize(Modifier.Companion.$$INSTANCE, 1.0f);
            Object objRememberedValue3 = composerImpl.rememberedValue();
            if (objRememberedValue3 == neverEqualPolicy) {
                objRememberedValue3 = new MainActivityKt$.ExternalSyntheticLambda30(mutableState, (byte) 27);
                composerImpl.updateRememberedValue(objRememberedValue3);
            }
            Modifier modifierOnPlaced = RulerKt.onPlaced(modifierFillMaxSize, (Function1) objRememberedValue3);
            boolean zChanged = composerImpl.changed(transitionAnimationStateAnimateFloat) | composerImpl.changed(j);
            Object objRememberedValue4 = composerImpl.rememberedValue();
            if (zChanged || objRememberedValue4 == neverEqualPolicy) {
                j2 = j;
                MultiParagraph$.ExternalSyntheticLambda0 externalSyntheticLambda0 = new MultiParagraph$.ExternalSyntheticLambda0(transitionAnimationStateAnimateFloat, mutableState, mutableState2, j2);
                composerImpl.updateRememberedValue(externalSyntheticLambda0);
                objRememberedValue4 = externalSyntheticLambda0;
            } else {
                j2 = j;
            }
            Modifier modifierDrawBehind = ClipKt.drawBehind(modifierOnPlaced, (Function1) objRememberedValue4);
            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.Companion.TopStart, false);
            int iHashCode = Long.hashCode(composerImpl.compositeKeyHashCode);
            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl.currentCompositionLocalScope();
            Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl, modifierDrawBehind);
            ComposeUiNode.Companion.getClass();
            LayoutNode.Companion.Constructor.1 r9 = ComposeUiNode.Companion.Constructor;
            composerImpl.startReusableNode();
            if (composerImpl.inserting) {
                composerImpl.createNode(r9);
            } else {
                composerImpl.useNode();
            }
            AnchoredGroupPath.set-impl(composerImpl, measurePolicyMaybeCachedBoxMeasurePolicy, ComposeUiNode.Companion.SetMeasurePolicy);
            AnchoredGroupPath.set-impl(composerImpl, persistentCompositionLocalHashMapCurrentCompositionLocalScope, ComposeUiNode.Companion.SetResolvedCompositionLocals);
            ComposeUiNode.Companion.SetModifier.1 r4 = ComposeUiNode.Companion.SetCompositeKeyHash;
            if (composerImpl.inserting || !Intrinsics.areEqual(composerImpl.rememberedValue(), Integer.valueOf(iHashCode))) {
                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl, iHashCode, r4);
            }
            AnchoredGroupPath.set-impl(composerImpl, modifierMaterializeModifier, ComposeUiNode.Companion.SetModifier);
            final long j4 = j2;
            b = 6;
            CardColumn(Expect_jvmKt.rememberComposableLambda(1195084967, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda27
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    CardsKt$$ExternalSyntheticLambda27 cardsKt$$ExternalSyntheticLambda27;
                    Function0 function0;
                    ComposeUiNode.Companion.SetModifier.1 r6;
                    ColumnScopeInstance columnScopeInstance = (ColumnScopeInstance) obj2;
                    ComposerImpl composerImpl2 = (ComposerImpl) obj3;
                    int iIntValue = ((Integer) obj4).intValue();
                    columnScopeInstance.getClass();
                    if ((iIntValue & 6) == 0) {
                        iIntValue |= composerImpl2.changed(columnScopeInstance) ? 4 : 2;
                    }
                    if (composerImpl2.shouldExecute(iIntValue & 1, (iIntValue & 19) != 18)) {
                        Modifier modifierWeight$default = ColumnScopeInstance.weight$default(columnScopeInstance, 1.0f);
                        ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(OffsetKt.Top, Alignment.Companion.Start, composerImpl2, 0);
                        int iHashCode2 = Long.hashCode(composerImpl2.compositeKeyHashCode);
                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope2 = composerImpl2.currentCompositionLocalScope();
                        Modifier modifierMaterializeModifier2 = AbsoluteAlignment.materializeModifier(composerImpl2, modifierWeight$default);
                        ComposeUiNode.Companion.getClass();
                        Function0 function1 = ComposeUiNode.Companion.Constructor;
                        composerImpl2.startReusableNode();
                        if (composerImpl2.inserting) {
                            composerImpl2.createNode(function1);
                        } else {
                            composerImpl2.useNode();
                        }
                        ComposeUiNode.Companion.SetModifier.1 r11 = ComposeUiNode.Companion.SetMeasurePolicy;
                        AnchoredGroupPath.set-impl(composerImpl2, columnMeasurePolicy, r11);
                        ComposeUiNode.Companion.SetModifier.1 r3 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
                        AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope2, r3);
                        ComposeUiNode.Companion.SetModifier.1 r8 = ComposeUiNode.Companion.SetCompositeKeyHash;
                        if (composerImpl2.inserting || !Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode2))) {
                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode2, composerImpl2, iHashCode2, r8);
                        }
                        ComposeUiNode.Companion.SetModifier.1 r5 = ComposeUiNode.Companion.SetModifier;
                        AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier2, r5);
                        Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
                        boolean z2 = z;
                        TextKt.Text-Nvy7gAk("You couldn't leave this one alone.", CardsKt.rise(companion, 0, z2, composerImpl2, 54), 0L, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 2, false, 3, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(CardsKt.Headline, 0L, UnsignedKt.getSp(38), (FontWeight) null, (FontStyle) null, (FontFamily) null, UnsignedKt.getSp(-1.3d), (Shadow) null, UnsignedKt.getSp(37), (LineHeightStyle) null, 0, 16646013), composerImpl2, 6, 24960, 110588);
                        Modifier modifierAspectRatio = OffsetKt.aspectRatio(SizeKt.widthIn-VpY3zN4$default(OffsetKt.padding-qDBjuR0$default(new HorizontalAlignElement(Alignment.Companion.CenterHorizontally), 0.0f, 20.0f, 0.0f, 0.0f, 13).then(new LayoutWeightElement(1.0f, false)), 300.0f, 1), 1.0f, true);
                        Object objRememberedValue5 = composerImpl2.rememberedValue();
                        NeverEqualPolicy neverEqualPolicy2 = Composer.Companion.Empty;
                        if (objRememberedValue5 == neverEqualPolicy2) {
                            cardsKt$$ExternalSyntheticLambda27 = this;
                            objRememberedValue5 = new MainActivityKt$.ExternalSyntheticLambda30(mutableState2, (byte) 28);
                            composerImpl2.updateRememberedValue(objRememberedValue5);
                        } else {
                            cardsKt$$ExternalSyntheticLambda27 = this;
                        }
                        Modifier modifierRise = CardsKt.rise(TestTagKt.testTag(RulerKt.onPlaced(modifierAspectRatio, (Function1) objRememberedValue5), "top_cover"), 1, z2, composerImpl2, 48);
                        MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(Alignment.Companion.TopStart, false);
                        int iHashCode3 = Long.hashCode(composerImpl2.compositeKeyHashCode);
                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl2.currentCompositionLocalScope();
                        Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl2, modifierRise);
                        composerImpl2.startReusableNode();
                        if (composerImpl2.inserting) {
                            function0 = function1;
                            composerImpl2.createNode(function0);
                        } else {
                            function0 = function1;
                            composerImpl2.useNode();
                        }
                        AnchoredGroupPath.set-impl(composerImpl2, measurePolicyMaybeCachedBoxMeasurePolicy2, r11);
                        AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, r3);
                        if (composerImpl2.inserting || !Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode3))) {
                            r6 = r8;
                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode3, composerImpl2, iHashCode3, r6);
                        } else {
                            r6 = r8;
                        }
                        AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier3, r5);
                        int i3 = Build.VERSION.SDK_INT;
                        long j5 = j4;
                        ComposeUiNode.Companion.SetModifier.1 r35 = r6;
                        RoundedCornerShape roundedCornerShape2 = roundedCornerShape;
                        if (i3 >= 31) {
                            composerImpl2.startReplaceGroup(1165100379);
                            BoxKt.Box(ImageKt.background-bw27NRU(ColorKt.graphicsLayer(OffsetKt.padding-VpY3zN4(OffsetKt.offset-VpY3zN4$default(BoxScopeInstance.INSTANCE.matchParentSize(), 0.0f, 24.0f, 1), 18.0f, 18.0f), new BlurKt.blur.1(3, false)), Color.copy-wmQWz5c$default(0.45f, j5), roundedCornerShape2), composerImpl2, 0);
                        } else {
                            composerImpl2.startReplaceGroup(1741732831);
                        }
                        composerImpl2.end(false);
                        TopSong topSong2 = topSong;
                        SongEntity songEntity = topSong2.song;
                        Function0 function2 = function0;
                        CoverKt.CoverArt(songEntity.id, songEntity.thumbnailUrl, songEntity.thumbPath, SizeKt.fillMaxSize(companion, 1.0f), roundedCornerShape2, false, false, composerImpl2, 3072, 96);
                        composerImpl2.end(true);
                        String str = songEntity.title;
                        Modifier modifierRise2 = CardsKt.rise(OffsetKt.padding-qDBjuR0$default(companion, 0.0f, 20.0f, 0.0f, 0.0f, 13), 2, z2, composerImpl2, 54);
                        FontListFontFamily fontListFontFamily = TypeKt.Albert;
                        TextKt.Text-Nvy7gAk(str, modifierRise2, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 2, false, 2, 0, (Function1) null, new TextStyle(0L, UnsignedKt.getSp(26), FontWeight.ExtraBold, fontListFontFamily, UnsignedKt.getSp(-0.65d), 0, UnsignedKt.getSp(27), 0, 16645977), composerImpl2, 0, 24960, 110588);
                        String strCleanArtist = Log.cleanArtist(songEntity.artist);
                        Modifier modifierRise3 = CardsKt.rise(OffsetKt.padding-qDBjuR0$default(companion, 0.0f, 4.0f, 0.0f, 0.0f, 13), 2, z2, composerImpl2, 54);
                        long jSoft = CardsKt.soft(composerImpl2);
                        TextStyle textStyle = CardsKt.Sub;
                        TextKt.Text-Nvy7gAk(strCleanArtist, modifierRise3, jSoft, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 2, false, 1, 0, (Function1) null, TextStyle.copy-p1EtxEg$default(textStyle, 0L, UnsignedKt.getSp(14), (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, 0L, (LineHeightStyle) null, 0, 16777213), composerImpl2, 0, 24960, 110584);
                        composerImpl2.end(true);
                        Modifier modifierRise4 = CardsKt.rise(companion, 3, z2, composerImpl2, 54);
                        RowMeasurePolicy rowMeasurePolicy = RowKt.rowMeasurePolicy(new Arrangement.SpacedAligned(8.0f, new SaversKt$.ExternalSyntheticLambda0((byte) 3)), Alignment.Companion.Top, composerImpl2, 6);
                        int iHashCode4 = Long.hashCode(composerImpl2.compositeKeyHashCode);
                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope4 = composerImpl2.currentCompositionLocalScope();
                        Modifier modifierMaterializeModifier4 = AbsoluteAlignment.materializeModifier(composerImpl2, modifierRise4);
                        composerImpl2.startReusableNode();
                        if (composerImpl2.inserting) {
                            composerImpl2.createNode(function2);
                        } else {
                            composerImpl2.useNode();
                        }
                        AnchoredGroupPath.set-impl(composerImpl2, rowMeasurePolicy, r11);
                        AnchoredGroupPath.set-impl(composerImpl2, persistentCompositionLocalHashMapCurrentCompositionLocalScope4, r3);
                        if (composerImpl2.inserting || !Intrinsics.areEqual(composerImpl2.rememberedValue(), Integer.valueOf(iHashCode4))) {
                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode4, composerImpl2, iHashCode4, r35);
                        }
                        AnchoredGroupPath.set-impl(composerImpl2, modifierMaterializeModifier4, r5);
                        CountUp countUp2 = countUp;
                        String str2 = countUp2.text;
                        HorizontalAlignmentLine horizontalAlignmentLine = AlignmentLineKt.FirstBaseline;
                        WithAlignmentLineElement withAlignmentLineElement = new WithAlignmentLineElement(horizontalAlignmentLine);
                        boolean zChanged2 = composerImpl2.changed(countUp2);
                        Object objRememberedValue6 = composerImpl2.rememberedValue();
                        if (zChanged2 || objRememberedValue6 == neverEqualPolicy2) {
                            objRememberedValue6 = new AbstractMap$.ExternalSyntheticLambda0(countUp2, (byte) 1);
                            composerImpl2.updateRememberedValue(objRememberedValue6);
                        }
                        TextKt.Text-Nvy7gAk(str2, ColorKt.graphicsLayer(withAlignmentLineElement, (Function1) objRememberedValue6), j5, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, new TextStyle(0L, UnsignedKt.getSp(64), FontWeight.Black, fontListFontFamily, UnsignedKt.getSp(-3.2d), 0, UnsignedKt.getSp(58), 0, 16645913), composerImpl2, 0, 0, 131064);
                        TextKt.Text-Nvy7gAk(topSong2.plays == 1 ? "play" : "plays", new WithAlignmentLineElement(horizontalAlignmentLine), CardsKt.soft(composerImpl2), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, textStyle, composerImpl2, 0, 12582912, 131064);
                        composerImpl2.end(true);
                    } else {
                        composerImpl2.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }, composerImpl), composerImpl, 6);
            composerImpl.end(true);
        } else {
            b = 6;
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new SliderDefaults$.ExternalSyntheticLambda4(topSong, z, i, b);
        }
    }

    public static final void TopSongCard(SpotifriedStats spotifriedStats, boolean z, ComposerImpl composerImpl, int i) {
        int i2;
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup;
        CardsKt$$ExternalSyntheticLambda0 cardsKt$$ExternalSyntheticLambda0;
        composerImpl.startRestartGroup(387465422);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changed(z) ? 32 : 16;
        }
        boolean zRememberNoMotion = true;
        if (composerImpl.shouldExecute(i2 & 1, (i2 & 19) != 18)) {
            TopSong topSong = spotifriedStats.topSong;
            if (topSong == null) {
                recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
                if (recomposeScopeImplEndRestartGroup == null) {
                    return;
                } else {
                    cardsKt$$ExternalSyntheticLambda0 = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 0);
                }
            } else {
                if (z) {
                    composerImpl.startReplaceGroup(-1889572516);
                } else {
                    composerImpl.startReplaceGroup(-1307879680);
                    zRememberNoMotion = SunKt.rememberNoMotion(composerImpl);
                }
                composerImpl.end(false);
                composerImpl.startMovableGroup(-1307878920, composerImpl.joinKey(spotifriedStats.period, Boolean.valueOf(zRememberNoMotion)));
                TopSong(topSong, zRememberNoMotion, composerImpl, 0);
                composerImpl.end(false);
            }
            recomposeScopeImplEndRestartGroup.block = cardsKt$$ExternalSyntheticLambda0;
        }
        composerImpl.skipToGroupEnd();
        recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            cardsKt$$ExternalSyntheticLambda0 = new CardsKt$$ExternalSyntheticLambda0(spotifriedStats, z, i, (byte) 4);
            recomposeScopeImplEndRestartGroup.block = cardsKt$$ExternalSyntheticLambda0;
        }
    }

    public static final void Type(final SpotifriedStats spotifriedStats, final Function0 function0, final boolean z, final boolean z2, final boolean z3, String str, ComposerImpl composerImpl, int i) {
        int i2;
        long j;
        String strM;
        String str2;
        float f;
        ComposerImpl composerImpl2 = composerImpl;
        composerImpl2.startRestartGroup(-601975689);
        if ((i & 6) == 0) {
            i2 = (composerImpl2.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl2.changedInstance(function0) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= composerImpl2.changed(z) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i2 |= composerImpl2.changed(z2) ? 2048 : 1024;
        }
        if ((i & 24576) == 0) {
            i2 |= composerImpl2.changed(z3) ? 16384 : 8192;
        }
        if ((196608 & i) == 0) {
            i2 |= composerImpl2.changed(str) ? 131072 : 65536;
        }
        if (composerImpl2.shouldExecute(i2 & 1, (74899 & i2) != 74898)) {
            StaticProvidableCompositionLocal staticProvidableCompositionLocal = ColorSchemeKt.LocalColorScheme;
            final long j2 = ((ColorScheme) composerImpl2.consume(staticProvidableCompositionLocal)).primary;
            final long j3 = ((ColorScheme) composerImpl2.consume(staticProvidableCompositionLocal)).onBackground;
            long j4 = spotifriedStats.seconds;
            ListenerType listenerType = ByteStreamsKt.listenerType(spotifriedStats);
            final String strConcat = (listenerType == ListenerType.REGULAR ? OperationKt$.ExternalSyntheticLambda0.m("The ", Log.hourKind(ByteStreamsKt.peakHour(spotifriedStats)), " Regular") : listenerType.title).concat(".");
            str.getClass();
            final String strConcat2 = str.length() == 0 ? "You are" : str.concat(", you are");
            boolean zChanged = composerImpl2.changed(spotifriedStats);
            Object objRememberedValue = composerImpl2.rememberedValue();
            NeverEqualPolicy neverEqualPolicy = Composer.Companion.Empty;
            int i3 = i2;
            if (zChanged || objRememberedValue == neverEqualPolicy) {
                ListenerType listenerType2 = ByteStreamsKt.listenerType(spotifriedStats);
                int i4 = spotifriedStats.plays;
                int i5 = spotifriedStats.newSongs;
                AgeStats ageStats = spotifriedStats.age;
                int i6 = spotifriedStats.replayedSongs;
                int i7 = spotifriedStats.songs;
                j = j4;
                String strConcat3 = "Your busiest hour was ".concat(Log.hourName(ByteStreamsKt.peakHour(spotifriedStats)));
                if (!strConcat3.endsWith(".")) {
                    strConcat3 = strConcat3.concat(".");
                }
                Locale locale = Locale.US;
                Long l = (Long) CollectionsKt.maxOrNull(spotifriedStats.daySeconds);
                String str3 = String.format(locale, "%.1f", Arrays.copyOf(new Object[]{Double.valueOf((l != null ? l.longValue() : 0L) / 3600.0d)}, 1));
                String strM2 = OperationKt$.ExternalSyntheticLambda0.m("You played ", ByteStreamsKt.count(i4, "song"), " in total.");
                switch (listenerType2.ordinal()) {
                    case 0:
                        objRememberedValue = ByteStreamsKt.listOf(new String[]{FieldSet$.ExternalSyntheticOutline0.m(MathKt.roundToInt(spotifriedStats.nightShare * 100.0f), "% of your plays started between midnight and 5 a.m."), i6 == 0 ? "You never replayed a song." : OperationKt$.ExternalSyntheticLambda0.m("You replayed ", ByteStreamsKt.count(i6, "song"), "."), strConcat3});
                        break;
                    case 1:
                        Object obj = ageStats.typicalYear;
                        if (obj == null) {
                            obj = "an unknown year";
                        }
                        String str4 = "A typical song of yours came out in " + obj + ".";
                        String strM3 = FieldSet$.ExternalSyntheticOutline0.m("Release years are known for ", ByteStreamsKt.num(ageStats.songsWithYear), " of ", ByteStreamsKt.count(ageStats.songsTotal, "song"), ".");
                        Integer num = ageStats.oldestYear;
                        if (num != null) {
                            strM = OperationKt$.ExternalSyntheticLambda0.m(num.intValue(), "Your oldest song is from ", ".");
                        } else {
                            Integer num2 = ageStats.age;
                            strM = OperationKt$.ExternalSyntheticLambda0.m(num2 != null ? num2.intValue() : 0, "Your listening age is ", ".");
                        }
                        objRememberedValue = ByteStreamsKt.listOf(new String[]{str4, strM3, strM});
                        break;
                    case 2:
                        objRememberedValue = ByteStreamsKt.listOf(new String[]{OperationKt$.ExternalSyntheticLambda0.m("You listened ", ByteStreamsKt.count(spotifriedStats.longestStreak, "day"), " in a row."), strM2, OperationKt$.ExternalSyntheticLambda0.m("Your longest day was ", str3, " hours of music.")});
                        break;
                    case 3:
                        StringBuilder sbM = FieldSet$.ExternalSyntheticOutline0.m(ByteStreamsKt.num(i5), " of ", ByteStreamsKt.count(i7, "song"), " ", i5 == 1 ? "was" : "were");
                        sbM.append(" new to you.");
                        objRememberedValue = ByteStreamsKt.listOf(new String[]{sbM.toString(), OperationKt$.ExternalSyntheticLambda0.m(i7 == 0 ? 0 : MathKt.roundToInt((i5 / i7) * 100.0f), "That is ", "% fresh music."), i6 == 0 ? "None of your songs got a replay." : OperationKt$.ExternalSyntheticLambda0.m("Only ", ByteStreamsKt.count(i6, "song"), " got a replay.")});
                        break;
                    case 4:
                        ArtistShare artistShare = spotifriedStats.topArtist;
                        if (artistShare == null || (str2 = artistShare.name) == null) {
                            str2 = "One artist";
                        }
                        objRememberedValue = ByteStreamsKt.listOf(new String[]{str2 + " took " + MathKt.roundToInt((artistShare != null ? artistShare.share : 0.0f) * 100.0f) + "% of your listening.", OperationKt$.ExternalSyntheticLambda0.m("You played ", ByteStreamsKt.count(i7, "different song"), " in total."), i6 == 0 ? "You never replayed any of them." : OperationKt$.ExternalSyntheticLambda0.m("You replayed ", ByteStreamsKt.num(i6), " of them.")});
                        break;
                    case 5:
                        objRememberedValue = ByteStreamsKt.listOf(new String[]{OperationKt$.ExternalSyntheticLambda0.m("Your longest day was ", str3, " hours of music."), OperationKt$.ExternalSyntheticLambda0.m("In all you listened for ", ByteStreamsKt.count((int) (j / 3600), "hour"), "."), strM2});
                        break;
                    case 6:
                        objRememberedValue = ByteStreamsKt.listOf(new String[]{FieldSet$.ExternalSyntheticOutline0.m(MathKt.roundToInt(spotifriedStats.earlyShare * 100.0f), "% of your plays started before 9 a.m."), strConcat3, strM2});
                        break;
                    case 7:
                        objRememberedValue = ByteStreamsKt.listOf(new String[]{strConcat3, OperationKt$.ExternalSyntheticLambda0.m("You played ", ByteStreamsKt.count(i4, "song"), "."), FieldSet$.ExternalSyntheticOutline0.m("That was ", ByteStreamsKt.count(i7, "different song"), ", and ", i6 == 0 ? "none came back." : ByteStreamsKt.num(i6).concat(" came back."))});
                        break;
                    default:
                        MediaSessionStub$.ExternalSyntheticLambda8.m();
                        return;
                }
                composerImpl2 = composerImpl;
                composerImpl2.updateRememberedValue(objRememberedValue);
            } else {
                j = j4;
            }
            final List list = (List) objRememberedValue;
            final float fSunScale = Log.sunScale(Log.minutesOf(j));
            final SunMotion sunMotionRememberSunMotion = rememberSunMotion(spotifriedStats.hours, fSunScale, z, composerImpl2);
            int i8 = ((i3 >> 6) & 14) | 432;
            final Animatable animatableProgress = progress(0, 1400, i8, composerImpl2, z);
            final Animatable animatableProgress2 = progress(1900, 800, i8, composerImpl2, z);
            Object objRememberedValue2 = composerImpl2.rememberedValue();
            if (objRememberedValue2 == neverEqualPolicy) {
                objRememberedValue2 = SnapshotStateKt__DerivedStateKt.derivedStateOf(new CardsKt$$ExternalSyntheticLambda11(animatableProgress2, (byte) 0));
                composerImpl2.updateRememberedValue(objRememberedValue2);
            }
            final State state = (State) objRememberedValue2;
            Object objRememberedValue3 = composerImpl2.rememberedValue();
            if (objRememberedValue3 == neverEqualPolicy) {
                objRememberedValue3 = new ParcelableSnapshotMutableLongState(-1000L);
                composerImpl2.updateRememberedValue(objRememberedValue3);
            }
            final ParcelableSnapshotMutableLongState parcelableSnapshotMutableLongState = (ParcelableSnapshotMutableLongState) objRememberedValue3;
            Object objRememberedValue4 = composerImpl2.rememberedValue();
            if (objRememberedValue4 == neverEqualPolicy) {
                f = 0.0f;
                objRememberedValue4 = new ParcelableSnapshotMutableFloatState(0.0f);
                composerImpl2.updateRememberedValue(objRememberedValue4);
            } else {
                f = 0.0f;
            }
            final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState = (ParcelableSnapshotMutableFloatState) objRememberedValue4;
            Object objRememberedValue5 = composerImpl2.rememberedValue();
            if (objRememberedValue5 == neverEqualPolicy) {
                objRememberedValue5 = new ParcelableSnapshotMutableFloatState(f);
                composerImpl2.updateRememberedValue(objRememberedValue5);
            }
            final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState2 = (ParcelableSnapshotMutableFloatState) objRememberedValue5;
            Modifier modifierClipToBounds = ClipKt.clipToBounds(SizeKt.fillMaxSize(Modifier.Companion.$$INSTANCE, 1.0f));
            Object objRememberedValue6 = composerImpl2.rememberedValue();
            if (objRememberedValue6 == neverEqualPolicy) {
                objRememberedValue6 = new CardsKt$$ExternalSyntheticLambda12(parcelableSnapshotMutableFloatState, (byte) 0);
                composerImpl2.updateRememberedValue(objRememberedValue6);
            }
            OffsetKt.BoxWithConstraints(RulerKt.onGloballyPositioned(modifierClipToBounds, (Function1) objRememberedValue6), (BiasAlignment) null, Expect_jvmKt.rememberComposableLambda(989203405, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda13
                /* JADX WARN: Code duplicated, block: B:34:0x0123  */
                /* JADX WARN: Code duplicated, block: B:37:0x0159  */
                /* JADX WARN: Code duplicated, block: B:38:0x015d  */
                /* JADX WARN: Code duplicated, block: B:43:0x0178  */
                /* JADX WARN: Code duplicated, block: B:47:0x0194  */
                public final Object invoke(Object obj2, Object obj3, Object obj4) {
                    List list2;
                    final Animatable animatable;
                    boolean zChangedInstance;
                    Object objRememberedValue7;
                    ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState3;
                    final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState4;
                    int iHashCode;
                    final long j5;
                    boolean zChanged2;
                    Object objRememberedValue8;
                    List list3 = spotifriedStats.hours;
                    BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl = (BoxWithConstraintsScopeImpl) obj2;
                    ComposerImpl composerImpl3 = (ComposerImpl) obj3;
                    int iIntValue = ((Integer) obj4).intValue();
                    boxWithConstraintsScopeImpl.getClass();
                    if ((iIntValue & 6) == 0) {
                        iIntValue |= composerImpl3.changed(boxWithConstraintsScopeImpl) ? 4 : 2;
                    }
                    if (composerImpl3.shouldExecute(iIntValue & 1, (iIntValue & 19) != 18)) {
                        final float f2 = boxWithConstraintsScopeImpl.getMaxWidth-D9Ej5fM() * 1.72f;
                        final float f3 = boxWithConstraintsScopeImpl.getMaxHeight-D9Ej5fM();
                        boolean zChanged3 = composerImpl3.changed(list3);
                        float f4 = fSunScale;
                        boolean zChanged4 = zChanged3 | composerImpl3.changed(f4);
                        Object objRememberedValue9 = composerImpl3.rememberedValue();
                        Object obj5 = Composer.Companion.Empty;
                        if (zChanged4 || objRememberedValue9 == obj5) {
                            objRememberedValue9 = Float.valueOf(SunKt.sunReach(list3, f4, true));
                            composerImpl3.updateRememberedValue(objRememberedValue9);
                        }
                        final float fFloatValue = ((Number) objRememberedValue9).floatValue();
                        Modifier.Companion companion = Modifier.Companion.$$INSTANCE;
                        Modifier modifierDrawWithContent = ClipKt.drawWithContent(ColorKt.graphicsLayer(SizeKt.fillMaxSize(companion, 1.0f), new SunKt$.ExternalSyntheticLambda1((byte) 13)), new SunKt$.ExternalSyntheticLambda1((byte) 14));
                        BiasAlignment biasAlignment = Alignment.Companion.TopStart;
                        MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy = BoxKt.maybeCachedBoxMeasurePolicy(biasAlignment, false);
                        int iHashCode2 = Long.hashCode(composerImpl3.compositeKeyHashCode);
                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope = composerImpl3.currentCompositionLocalScope();
                        Modifier modifierMaterializeModifier = AbsoluteAlignment.materializeModifier(composerImpl3, modifierDrawWithContent);
                        ComposeUiNode.Companion.getClass();
                        LayoutNode.Companion.Constructor.1 r13 = ComposeUiNode.Companion.Constructor;
                        composerImpl3.startReusableNode();
                        if (composerImpl3.inserting) {
                            composerImpl3.createNode(r13);
                        } else {
                            composerImpl3.useNode();
                        }
                        ComposeUiNode.Companion.SetModifier.1 r9 = ComposeUiNode.Companion.SetMeasurePolicy;
                        AnchoredGroupPath.set-impl(composerImpl3, measurePolicyMaybeCachedBoxMeasurePolicy, r9);
                        ComposeUiNode.Companion.SetModifier.1 r14 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope, r14);
                        ComposeUiNode.Companion.SetModifier.1 r7 = ComposeUiNode.Companion.SetCompositeKeyHash;
                        if (composerImpl3.inserting) {
                            list2 = list3;
                        } else {
                            list2 = list3;
                            if (!Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode2))) {
                            }
                            ComposeUiNode.Companion.SetModifier.1 r2 = ComposeUiNode.Companion.SetModifier;
                            AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier, r2);
                            Modifier modifier = SizeKt.requiredSize-3ABfNKs(OffsetKt.offset-VpY3zN4$default(BoxScopeInstance.INSTANCE.align(companion, Alignment.Companion.BottomCenter), 0.0f, (f2 / 2.0f) - 60.0f, 1), f2);
                            animatable = animatableProgress;
                            zChangedInstance = composerImpl3.changedInstance(animatable) | composerImpl3.changed(f3) | composerImpl3.changed(f2) | composerImpl3.changed(fFloatValue);
                            objRememberedValue7 = composerImpl3.rememberedValue();
                            parcelableSnapshotMutableFloatState3 = parcelableSnapshotMutableFloatState2;
                            if (!zChangedInstance || objRememberedValue7 == obj5) {
                                final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState5 = parcelableSnapshotMutableFloatState;
                                parcelableSnapshotMutableFloatState4 = parcelableSnapshotMutableFloatState3;
                                objRememberedValue7 = new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda47
                                    public final Object invoke(Object obj6) {
                                        ReusableGraphicsLayerScope reusableGraphicsLayerScope = (ReusableGraphicsLayerScope) obj6;
                                        reusableGraphicsLayerScope.getClass();
                                        reusableGraphicsLayerScope.setAlpha(((Number) animatable.getValue()).floatValue() * 0.55f);
                                        float density = ((reusableGraphicsLayerScope.graphicsDensity.getDensity() * 24.0f) + (parcelableSnapshotMutableFloatState4.getFloatValue() - parcelableSnapshotMutableFloatState5.getFloatValue())) - (((reusableGraphicsLayerScope.graphicsDensity.getDensity() * f3) - (reusableGraphicsLayerScope.graphicsDensity.getDensity() * 60.0f)) - ((reusableGraphicsLayerScope.graphicsDensity.getDensity() * f2) * fFloatValue));
                                        if (density < 0.0f) {
                                            density = 0.0f;
                                        }
                                        reusableGraphicsLayerScope.setTranslationY(density);
                                        return Unit.INSTANCE;
                                    }
                                };
                                composerImpl3.updateRememberedValue(objRememberedValue7);
                            } else {
                                parcelableSnapshotMutableFloatState4 = parcelableSnapshotMutableFloatState3;
                            }
                            Modifier modifierGraphicsLayer = ColorKt.graphicsLayer(modifier, (Function1) objRememberedValue7);
                            MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy2 = BoxKt.maybeCachedBoxMeasurePolicy(biasAlignment, false);
                            iHashCode = Long.hashCode(composerImpl3.compositeKeyHashCode);
                            PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope2 = composerImpl3.currentCompositionLocalScope();
                            Modifier modifierMaterializeModifier2 = AbsoluteAlignment.materializeModifier(composerImpl3, modifierGraphicsLayer);
                            composerImpl3.startReusableNode();
                            if (composerImpl3.inserting) {
                                composerImpl3.createNode(r13);
                            } else {
                                composerImpl3.useNode();
                            }
                            AnchoredGroupPath.set-impl(composerImpl3, measurePolicyMaybeCachedBoxMeasurePolicy2, r9);
                            AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope2, r14);
                            if (composerImpl3.inserting || !Intrinsics.areEqual(composerImpl3.rememberedValue(), Integer.valueOf(iHashCode))) {
                                OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl3, iHashCode, r7);
                            }
                            AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier2, r2);
                            Modifier modifierFillMaxSize = SizeKt.fillMaxSize(companion, 1.0f);
                            j5 = j2;
                            zChanged2 = composerImpl3.changed(j5);
                            objRememberedValue8 = composerImpl3.rememberedValue();
                            if (zChanged2 || objRememberedValue8 == obj5) {
                                objRememberedValue8 = new MainActivityKt$.ExternalSyntheticLambda140(j5, (byte) 13);
                                composerImpl3.updateRememberedValue(objRememberedValue8);
                            }
                            ImageKt.Canvas(modifierFillMaxSize, (Function1) objRememberedValue8, composerImpl3, 6);
                            SunKt.Sun(list2, f4, false, sunMotionRememberSunMotion, SizeKt.fillMaxSize(companion, 1.0f), false, (Integer) null, (Function1) null, (String) null, false, composerImpl3, 805331328, 480);
                            composerImpl3.end(true);
                            composerImpl3.end(true);
                            final Function0 function1 = function0;
                            final Animatable animatable2 = animatableProgress2;
                            final boolean z4 = z2;
                            final boolean z5 = z3;
                            final long j6 = j3;
                            final String str5 = strConcat;
                            final String str6 = strConcat2;
                            final List list4 = list;
                            final boolean z6 = z;
                            final ParcelableSnapshotMutableLongState parcelableSnapshotMutableLongState2 = parcelableSnapshotMutableLongState;
                            final State state2 = state;
                            final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState6 = parcelableSnapshotMutableFloatState4;
                            CardsKt.CardColumn(Expect_jvmKt.rememberComposableLambda(1706848304, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda49
                                public final Object invoke(Object obj6, Object obj7, Object obj8) {
                                    Object obj9;
                                    boolean z7;
                                    boolean z8;
                                    Modifier modifier2;
                                    ColumnScopeInstance columnScopeInstance = (ColumnScopeInstance) obj6;
                                    ComposerImpl composerImpl4 = (ComposerImpl) obj7;
                                    int iIntValue2 = ((Integer) obj8).intValue();
                                    columnScopeInstance.getClass();
                                    if ((iIntValue2 & 6) == 0) {
                                        iIntValue2 |= composerImpl4.changed(columnScopeInstance) ? 4 : 2;
                                    }
                                    if (composerImpl4.shouldExecute(iIntValue2 & 1, (iIntValue2 & 19) != 18)) {
                                        Modifier modifierFillMaxWidth = SizeKt.fillMaxWidth(ColumnScopeInstance.weight$default(columnScopeInstance, 1.0f), 1.0f);
                                        final String str7 = str5;
                                        final String str8 = str6;
                                        final List list5 = list4;
                                        final boolean z9 = z6;
                                        final long j7 = j5;
                                        final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState7 = parcelableSnapshotMutableFloatState6;
                                        final long j8 = j6;
                                        OffsetKt.BoxWithConstraints(modifierFillMaxWidth, (BiasAlignment) null, Expect_jvmKt.rememberComposableLambda(-1155470202, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda56
                                            public final Object invoke(Object obj10, Object obj11, Object obj12) {
                                                String str9;
                                                String str10;
                                                TextStyle textStyle;
                                                List list6;
                                                String str11;
                                                Object next;
                                                BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl2 = (BoxWithConstraintsScopeImpl) obj10;
                                                ComposerImpl composerImpl5 = (ComposerImpl) obj11;
                                                int iIntValue3 = ((Integer) obj12).intValue();
                                                boxWithConstraintsScopeImpl2.getClass();
                                                long j9 = boxWithConstraintsScopeImpl2.constraints;
                                                if ((iIntValue3 & 6) == 0) {
                                                    iIntValue3 |= composerImpl5.changed(boxWithConstraintsScopeImpl2) ? 4 : 2;
                                                }
                                                if (composerImpl5.shouldExecute(iIntValue3 & 1, (iIntValue3 & 19) != 18)) {
                                                    TextMeasurer textMeasurerRememberTextMeasurer = ParagraphKt.rememberTextMeasurer(0, composerImpl5, 0, 1);
                                                    Density density = (Density) composerImpl5.consume(CompositionLocalsKt.LocalDensity);
                                                    TextStyle textStyle2 = TextStyle.copy-p1EtxEg$default(CardsKt.Headline, 0L, UnsignedKt.getSp(56), (FontWeight) null, (FontStyle) null, (FontFamily) null, UnsignedKt.getSp(-2), (Shadow) null, UnsignedKt.getSp(55), (LineHeightStyle) null, 0, 16646013);
                                                    int iMin = Math.min(Constraints.getMaxWidth-impl(j9), density.roundToPx-0680j_4(280.0f));
                                                    int i9 = Constraints.getMaxWidth-impl(j9);
                                                    String str12 = str7;
                                                    boolean zChanged5 = composerImpl5.changed(str12) | composerImpl5.changed(textMeasurerRememberTextMeasurer) | composerImpl5.changed(i9);
                                                    Object objRememberedValue10 = composerImpl5.rememberedValue();
                                                    Object obj13 = Composer.Companion.Empty;
                                                    if (zChanged5 || objRememberedValue10 == obj13) {
                                                        float f5 = Constraints.getMaxWidth-impl(j9) * 0.98f;
                                                        Iterator it = StringsKt.split$default(str12, new char[]{' '}).iterator();
                                                        if (!it.hasNext()) {
                                                            MediaSessionStub$.ExternalSyntheticLambda8.m$1();
                                                            return null;
                                                        }
                                                        str9 = str12;
                                                        int i10 = (int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, (String) it.next(), textStyle2, 0, 0L, 1020).size >> 32);
                                                        while (it.hasNext()) {
                                                            int i11 = i10;
                                                            i10 = (int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, (String) it.next(), textStyle2, 0, 0L, 1020).size >> 32);
                                                            if (i11 >= i10) {
                                                                i10 = i11;
                                                            }
                                                        }
                                                        int i12 = i10;
                                                        objRememberedValue10 = Float.valueOf(Math.min(1.0f, f5 / (i12 < 1 ? 1 : i12)));
                                                        composerImpl5.updateRememberedValue(objRememberedValue10);
                                                    } else {
                                                        str9 = str12;
                                                    }
                                                    float fFloatValue2 = ((Number) objRememberedValue10).floatValue();
                                                    boolean zChanged6 = composerImpl5.changed(str9);
                                                    String str13 = str8;
                                                    boolean zChanged7 = zChanged6 | composerImpl5.changed(str13);
                                                    List list7 = list5;
                                                    boolean zChanged8 = zChanged7 | composerImpl5.changed(list7) | composerImpl5.changed(textMeasurerRememberTextMeasurer) | composerImpl5.changed(j9);
                                                    Object objRememberedValue11 = composerImpl5.rememberedValue();
                                                    String str14 = str9;
                                                    if (zChanged8 || objRememberedValue11 == obj13) {
                                                        FilteringSequence.iterator.1 r6 = new FilteringSequence.iterator.1(new TakeWhileSequence(SequencesKt.generateSequence(Float.valueOf(1.0f), new SunKt$.ExternalSyntheticLambda1((byte) 17)), new SunKt$.ExternalSyntheticLambda1((byte) 18), (byte) 0));
                                                        while (true) {
                                                            if (!r6.hasNext()) {
                                                                str10 = str13;
                                                                textStyle = textStyle2;
                                                                list6 = list7;
                                                                str11 = str14;
                                                                next = null;
                                                                break;
                                                            }
                                                            next = r6.next();
                                                            float fFloatValue3 = ((Number) next).floatValue();
                                                            long j10 = j9;
                                                            FilteringSequence.iterator.1 r22 = r6;
                                                            list6 = list7;
                                                            textStyle = textStyle2;
                                                            str10 = str13;
                                                            int i13 = density.roundToPx-0680j_4(26.0f) + density.roundToPx-0680j_4(6.0f) + ((int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, str13, CardsKt.Sub, 3, ConstraintsKt.Constraints$default(Constraints.getMaxWidth-impl(j10), 0, 13), 972).size & 4294967295L)) + ((int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, str14, CardsKt.Type$lambda$235$lambda$234$lambda$220$titleStyle(textStyle, fFloatValue2, fFloatValue3), 3, ConstraintsKt.Constraints$default(Constraints.getMaxWidth-impl(j10), 0, 13), 972).size & 4294967295L));
                                                            Iterator it2 = list6.iterator();
                                                            int i14 = 0;
                                                            while (it2.hasNext()) {
                                                                i14 += (int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, (String) it2.next(), CardsKt.Type$lambda$235$lambda$234$lambda$220$factStyle(fFloatValue3), 0, ConstraintsKt.Constraints$default(iMin, 0, 13), 988).size & 4294967295L);
                                                            }
                                                            str11 = str14;
                                                            if (density.roundToPx-0680j_4(CardsKt.RISE) + i13 + i14 + (density.roundToPx-0680j_4(12.0f) << 1) <= Constraints.getMaxHeight-impl(j10)) {
                                                                break;
                                                            }
                                                            textStyle2 = textStyle;
                                                            j9 = j10;
                                                            r6 = r22;
                                                            str13 = str10;
                                                            list7 = list6;
                                                            str14 = str11;
                                                        }
                                                        Float f6 = (Float) next;
                                                        objRememberedValue11 = Float.valueOf(f6 != null ? f6.floatValue() : 0.5f);
                                                        composerImpl5.updateRememberedValue(objRememberedValue11);
                                                    } else {
                                                        str10 = str13;
                                                        textStyle = textStyle2;
                                                        list6 = list7;
                                                        str11 = str14;
                                                    }
                                                    float fFloatValue4 = ((Number) objRememberedValue11).floatValue();
                                                    ScrollState scrollStateRememberScrollState = ImageKt.rememberScrollState(composerImpl5);
                                                    Modifier.Companion companion2 = Modifier.Companion.$$INSTANCE;
                                                    Modifier modifier3 = OffsetKt.padding-qDBjuR0$default(ImageKt.scroll$default(companion2, scrollStateRememberScrollState, true), 0.0f, 0.0f, 0.0f, CardsKt.RISE, 7);
                                                    Arrangement.Top.1 r10 = OffsetKt.Top;
                                                    BiasAlignment.Horizontal horizontal = Alignment.Companion.Start;
                                                    ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(r10, horizontal, composerImpl5, 0);
                                                    int iHashCode3 = Long.hashCode(composerImpl5.compositeKeyHashCode);
                                                    PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl5.currentCompositionLocalScope();
                                                    Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl5, modifier3);
                                                    ComposeUiNode.Companion.getClass();
                                                    LayoutNode.Companion.Constructor.1 r15 = ComposeUiNode.Companion.Constructor;
                                                    composerImpl5.startReusableNode();
                                                    if (composerImpl5.inserting) {
                                                        composerImpl5.createNode(r15);
                                                    } else {
                                                        composerImpl5.useNode();
                                                    }
                                                    ComposeUiNode.Companion.SetModifier.1 r16 = ComposeUiNode.Companion.SetMeasurePolicy;
                                                    AnchoredGroupPath.set-impl(composerImpl5, columnMeasurePolicy, r16);
                                                    ComposeUiNode.Companion.SetModifier.1 r11 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
                                                    AnchoredGroupPath.set-impl(composerImpl5, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, r11);
                                                    ComposeUiNode.Companion.SetModifier.1 r17 = ComposeUiNode.Companion.SetCompositeKeyHash;
                                                    if (composerImpl5.inserting || !Intrinsics.areEqual(composerImpl5.rememberedValue(), Integer.valueOf(iHashCode3))) {
                                                        OperationKt$.ExternalSyntheticLambda0.m(iHashCode3, composerImpl5, iHashCode3, r17);
                                                    }
                                                    ComposeUiNode.Companion.SetModifier.1 r4 = ComposeUiNode.Companion.SetModifier;
                                                    AnchoredGroupPath.set-impl(composerImpl5, modifierMaterializeModifier3, r4);
                                                    boolean z10 = z9;
                                                    TextStyle textStyle3 = textStyle;
                                                    TextKt.Text-Nvy7gAk(str10, CardsKt.rise(companion2, 0, z10, composerImpl5, 54), CardsKt.soft(composerImpl5), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 2, false, 3, 0, (Function1) null, CardsKt.Sub, composerImpl5, 0, 12607872, 110584);
                                                    String str15 = str11;
                                                    int iLastIndexOf$default = StringsKt.lastIndexOf$default(str15, ' ', 0, 6) + 1;
                                                    AnnotatedString.Builder builder = new AnnotatedString.Builder();
                                                    builder.append(StringsKt.take(iLastIndexOf$default, str15));
                                                    long j11 = j7;
                                                    int iPushStyle = builder.pushStyle(new SpanStyle(j11, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
                                                    try {
                                                        builder.append(StringsKt.drop(iLastIndexOf$default, str15));
                                                        builder.pop(iPushStyle);
                                                        TextKt.Text-Z58ophY(builder.toAnnotatedString(), CardsKt.rise(OffsetKt.padding-qDBjuR0$default(companion2, 0.0f, 6.0f, 0.0f, 0.0f, 13), 0, z10, composerImpl5, 54), 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 3, 0, (Map) null, (Function1) null, CardsKt.Type$lambda$235$lambda$234$lambda$220$titleStyle(textStyle3, fFloatValue2, fFloatValue4), composerImpl5, 0, 24576, 245756);
                                                        ComposerImpl composerImpl6 = composerImpl5;
                                                        Modifier modifier4 = SizeKt.widthIn-VpY3zN4$default(OffsetKt.padding-qDBjuR0$default(companion2, 0.0f, 26.0f, 0.0f, 0.0f, 13), 280.0f, 1);
                                                        Object objRememberedValue12 = composerImpl6.rememberedValue();
                                                        if (objRememberedValue12 == obj13) {
                                                            objRememberedValue12 = new CardsKt$$ExternalSyntheticLambda12(parcelableSnapshotMutableFloatState7, (byte) 2);
                                                            composerImpl6.updateRememberedValue(objRememberedValue12);
                                                        }
                                                        Modifier modifierOnGloballyPositioned = RulerKt.onGloballyPositioned(modifier4, (Function1) objRememberedValue12);
                                                        ColumnMeasurePolicy columnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(new Arrangement.SpacedAligned(12.0f, new SaversKt$.ExternalSyntheticLambda0((byte) 3)), horizontal, composerImpl6, 6);
                                                        int iHashCode4 = Long.hashCode(composerImpl6.compositeKeyHashCode);
                                                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope4 = composerImpl6.currentCompositionLocalScope();
                                                        Modifier modifierMaterializeModifier4 = AbsoluteAlignment.materializeModifier(composerImpl6, modifierOnGloballyPositioned);
                                                        composerImpl6.startReusableNode();
                                                        if (composerImpl6.inserting) {
                                                            composerImpl6.createNode(r15);
                                                        } else {
                                                            composerImpl6.useNode();
                                                        }
                                                        AnchoredGroupPath.set-impl(composerImpl6, columnMeasurePolicy2, r16);
                                                        AnchoredGroupPath.set-impl(composerImpl6, persistentCompositionLocalHashMapCurrentCompositionLocalScope4, r11);
                                                        if (composerImpl6.inserting || !Intrinsics.areEqual(composerImpl6.rememberedValue(), Integer.valueOf(iHashCode4))) {
                                                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode4, composerImpl6, iHashCode4, r17);
                                                        }
                                                        AnchoredGroupPath.set-impl(composerImpl6, modifierMaterializeModifier4, r4);
                                                        composerImpl6.startReplaceGroup(-1706632590);
                                                        int i15 = 0;
                                                        for (Object obj14 : list6) {
                                                            int i16 = i15 + 1;
                                                            if (i15 < 0) {
                                                                ByteStreamsKt.throwIndexOverflow();
                                                                throw null;
                                                            }
                                                            String str16 = (String) obj14;
                                                            str16.getClass();
                                                            Pattern patternCompile = Pattern.compile("\\d+(?:[.,]\\d+)*%");
                                                            patternCompile.getClass();
                                                            Matcher matcher = patternCompile.matcher(str16);
                                                            matcher.getClass();
                                                            MatcherMatchResult matcherMatchResultFindNext = RegexKt.findNext(matcher, 0, str16);
                                                            if (matcherMatchResultFindNext == null) {
                                                                Pattern patternCompile2 = Pattern.compile("\\d+(?:[.,]\\d+)*(?: [ap]\\.m\\.)?");
                                                                patternCompile2.getClass();
                                                                Matcher matcher2 = patternCompile2.matcher(str16);
                                                                matcher2.getClass();
                                                                matcherMatchResultFindNext = RegexKt.findNext(matcher2, 0, str16);
                                                            }
                                                            IntRange range = matcherMatchResultFindNext != null ? matcherMatchResultFindNext.getRange() : null;
                                                            AnnotatedString.Builder builder2 = new AnnotatedString.Builder();
                                                            if (range == null) {
                                                                builder2.append(str16);
                                                            } else {
                                                                int i17 = ((IntProgression) range).last;
                                                                int i18 = ((IntProgression) range).first;
                                                                builder2.append(str16.substring(0, i18));
                                                                int iPushStyle2 = builder2.pushStyle(new SpanStyle(j11, 0L, FontWeight.ExtraBold, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65530));
                                                                int i19 = i17 + 1;
                                                                try {
                                                                    builder2.append(str16.substring(i18, i19));
                                                                    builder2.pop(iPushStyle2);
                                                                    builder2.append(str16.substring(i19));
                                                                } catch (Throwable th) {
                                                                    builder2.pop(iPushStyle2);
                                                                    throw th;
                                                                }
                                                            }
                                                            ComposerImpl composerImpl7 = composerImpl6;
                                                            TextKt.Text-Z58ophY(builder2.toAnnotatedString(), CardsKt.riseAt(companion2, (i15 * 250) + 1000, z10, composerImpl6, 3078, 0), j8, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, CardsKt.Type$lambda$235$lambda$234$lambda$220$factStyle(fFloatValue4), composerImpl7, 0, 0, 262136);
                                                            composerImpl6 = composerImpl7;
                                                            i15 = i16;
                                                        }
                                                        composerImpl6.end(false);
                                                        composerImpl6.end(true);
                                                        composerImpl6.end(true);
                                                    } catch (Throwable th2) {
                                                        builder.pop(iPushStyle);
                                                        throw th2;
                                                    }
                                                } else {
                                                    composerImpl5.skipToGroupEnd();
                                                }
                                                return Unit.INSTANCE;
                                            }
                                        }, composerImpl4), composerImpl4, 3072, 6);
                                        float f5 = ((Density) composerImpl4.consume(CompositionLocalsKt.LocalDensity)).toPx-0680j_4(18.0f);
                                        StaticProvidableCompositionLocal staticProvidableCompositionLocal2 = ColorSchemeKt.LocalColorScheme;
                                        long j9 = ((ColorScheme) composerImpl4.consume(staticProvidableCompositionLocal2)).background;
                                        Function0 function2 = function1;
                                        Object obj10 = Composer.Companion.Empty;
                                        Modifier modifier3 = Modifier.Companion.$$INSTANCE;
                                        if (function2 != null) {
                                            composerImpl4.startReplaceGroup(-396159543);
                                            boolean zChanged5 = composerImpl4.changed(function2);
                                            Object objRememberedValue10 = composerImpl4.rememberedValue();
                                            if (zChanged5 || objRememberedValue10 == obj10) {
                                                objRememberedValue10 = new Regex$.ExternalSyntheticLambda0(function2, parcelableSnapshotMutableLongState2, (byte) 28);
                                                composerImpl4.updateRememberedValue(objRememberedValue10);
                                            }
                                            Function0 function3 = (Function0) objRememberedValue10;
                                            Modifier modifier4 = SizeKt.heightIn-VpY3zN4(OffsetKt.padding-qDBjuR0$default(modifier3, 0.0f, 12.0f, 0.0f, 0.0f, 13), 48.0f, Float.NaN);
                                            Animatable animatable3 = animatable2;
                                            boolean zChangedInstance2 = composerImpl4.changedInstance(animatable3) | composerImpl4.changed(f5);
                                            Object objRememberedValue11 = composerImpl4.rememberedValue();
                                            if (zChangedInstance2 || objRememberedValue11 == obj10) {
                                                objRememberedValue11 = new CardsKt$$ExternalSyntheticLambda37(animatable3, f5, (byte) 3);
                                                composerImpl4.updateRememberedValue(objRememberedValue11);
                                            }
                                            Modifier modifierGraphicsLayer2 = ColorKt.graphicsLayer(modifier4, (Function1) objRememberedValue11);
                                            boolean zChanged6 = composerImpl4.changed(j9);
                                            Object objRememberedValue12 = composerImpl4.rememberedValue();
                                            if (zChanged6 || objRememberedValue12 == obj10) {
                                                objRememberedValue12 = new MainActivityKt$.ExternalSyntheticLambda140(j9, (byte) 15);
                                                composerImpl4.updateRememberedValue(objRememberedValue12);
                                            }
                                            Modifier modifierDrawBehind = ClipKt.drawBehind(modifierGraphicsLayer2, (Function1) objRememberedValue12);
                                            State state3 = state2;
                                            if (((Boolean) state3.getValue()).booleanValue()) {
                                                composerImpl4.startReplaceGroup(-396126824);
                                                composerImpl4.end(false);
                                                modifier2 = modifier3;
                                            } else {
                                                composerImpl4.startReplaceGroup(-396126073);
                                                Object objRememberedValue13 = composerImpl4.rememberedValue();
                                                if (objRememberedValue13 == obj10) {
                                                    objRememberedValue13 = new SunKt$.ExternalSyntheticLambda1((byte) 15);
                                                    composerImpl4.updateRememberedValue(objRememberedValue13);
                                                }
                                                Modifier modifierClearAndSetSemantics = SemanticsModifierKt.clearAndSetSemantics(modifier3, (Function1) objRememberedValue13);
                                                composerImpl4.end(false);
                                                modifier2 = modifierClearAndSetSemantics;
                                            }
                                            Modifier modifierThen = modifierDrawBehind.then(modifier2);
                                            boolean zBooleanValue = ((Boolean) state3.getValue()).booleanValue();
                                            boolean z10 = z4;
                                            boolean z11 = zBooleanValue && !z10;
                                            PaddingValuesImpl paddingValuesImpl = ButtonDefaults.ContentPadding;
                                            modifier3 = modifier3;
                                            obj9 = obj10;
                                            MenuKt.Button(function3, modifierThen, z11, (Shape) null, ButtonDefaults.buttonColors-ro_MJ88(j7, ((ColorScheme) composerImpl4.consume(staticProvidableCompositionLocal2)).onPrimary, j7, ((ColorScheme) composerImpl4.consume(staticProvidableCompositionLocal2)).onPrimary, composerImpl4, 0), (ButtonElevation) null, (BorderStroke) null, OffsetKt.PaddingValues-YgX7TsA$default(22.0f, 2), Expect_jvmKt.rememberComposableLambda(1942550907, new PageScreenKt$.ExternalSyntheticLambda5((byte) 3, z10), composerImpl4), composerImpl4, 817889280, 360);
                                            composerImpl4 = composerImpl4;
                                            z7 = false;
                                        } else {
                                            obj9 = obj10;
                                            z7 = false;
                                            composerImpl4.startReplaceGroup(554610226);
                                        }
                                        composerImpl4.end(z7);
                                        if (z5) {
                                            composerImpl4.startReplaceGroup(-396105249);
                                            Modifier modifier5 = OffsetKt.padding-qDBjuR0$default(modifier3, 0.0f, 8.0f, 0.0f, 0.0f, 13);
                                            Object objRememberedValue14 = composerImpl4.rememberedValue();
                                            if (objRememberedValue14 == obj9) {
                                                objRememberedValue14 = new SunKt$.ExternalSyntheticLambda1((byte) 16);
                                                composerImpl4.updateRememberedValue(objRememberedValue14);
                                            }
                                            z8 = false;
                                            ComposerImpl composerImpl5 = composerImpl4;
                                            TextKt.Text-Nvy7gAk("Couldn't make the pictures. Try again.", SemanticsModifierKt.semantics(modifier5, false, (Function1) objRememberedValue14), j8, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, CardsKt.Sub, composerImpl5, 6, 12582912, 131064);
                                            composerImpl4 = composerImpl5;
                                        } else {
                                            z8 = false;
                                            composerImpl4.startReplaceGroup(554610226);
                                        }
                                        composerImpl4.end(z8);
                                    } else {
                                        composerImpl4.skipToGroupEnd();
                                    }
                                    return Unit.INSTANCE;
                                }
                            }, composerImpl3), composerImpl3, 6);
                        }
                        OperationKt$.ExternalSyntheticLambda0.m(iHashCode2, composerImpl3, iHashCode2, r7);
                        ComposeUiNode.Companion.SetModifier.1 r3 = ComposeUiNode.Companion.SetModifier;
                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier, r3);
                        Modifier modifier2 = SizeKt.requiredSize-3ABfNKs(OffsetKt.offset-VpY3zN4$default(BoxScopeInstance.INSTANCE.align(companion, Alignment.Companion.BottomCenter), 0.0f, (f2 / 2.0f) - 60.0f, 1), f2);
                        animatable = animatableProgress;
                        zChangedInstance = composerImpl3.changedInstance(animatable) | composerImpl3.changed(f3) | composerImpl3.changed(f2) | composerImpl3.changed(fFloatValue);
                        objRememberedValue7 = composerImpl3.rememberedValue();
                        parcelableSnapshotMutableFloatState3 = parcelableSnapshotMutableFloatState2;
                        if (zChangedInstance) {
                            final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState7 = parcelableSnapshotMutableFloatState;
                            parcelableSnapshotMutableFloatState4 = parcelableSnapshotMutableFloatState3;
                            objRememberedValue7 = new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda47
                                public final Object invoke(Object obj6) {
                                    ReusableGraphicsLayerScope reusableGraphicsLayerScope = (ReusableGraphicsLayerScope) obj6;
                                    reusableGraphicsLayerScope.getClass();
                                    reusableGraphicsLayerScope.setAlpha(((Number) animatable.getValue()).floatValue() * 0.55f);
                                    float density = ((reusableGraphicsLayerScope.graphicsDensity.getDensity() * 24.0f) + (parcelableSnapshotMutableFloatState4.getFloatValue() - parcelableSnapshotMutableFloatState7.getFloatValue())) - (((reusableGraphicsLayerScope.graphicsDensity.getDensity() * f3) - (reusableGraphicsLayerScope.graphicsDensity.getDensity() * 60.0f)) - ((reusableGraphicsLayerScope.graphicsDensity.getDensity() * f2) * fFloatValue));
                                    if (density < 0.0f) {
                                        density = 0.0f;
                                    }
                                    reusableGraphicsLayerScope.setTranslationY(density);
                                    return Unit.INSTANCE;
                                }
                            };
                            composerImpl3.updateRememberedValue(objRememberedValue7);
                        } else {
                            final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState8 = parcelableSnapshotMutableFloatState;
                            parcelableSnapshotMutableFloatState4 = parcelableSnapshotMutableFloatState3;
                            objRememberedValue7 = new Function1() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda47
                                public final Object invoke(Object obj6) {
                                    ReusableGraphicsLayerScope reusableGraphicsLayerScope = (ReusableGraphicsLayerScope) obj6;
                                    reusableGraphicsLayerScope.getClass();
                                    reusableGraphicsLayerScope.setAlpha(((Number) animatable.getValue()).floatValue() * 0.55f);
                                    float density = ((reusableGraphicsLayerScope.graphicsDensity.getDensity() * 24.0f) + (parcelableSnapshotMutableFloatState4.getFloatValue() - parcelableSnapshotMutableFloatState8.getFloatValue())) - (((reusableGraphicsLayerScope.graphicsDensity.getDensity() * f3) - (reusableGraphicsLayerScope.graphicsDensity.getDensity() * 60.0f)) - ((reusableGraphicsLayerScope.graphicsDensity.getDensity() * f2) * fFloatValue));
                                    if (density < 0.0f) {
                                        density = 0.0f;
                                    }
                                    reusableGraphicsLayerScope.setTranslationY(density);
                                    return Unit.INSTANCE;
                                }
                            };
                            composerImpl3.updateRememberedValue(objRememberedValue7);
                        }
                        Modifier modifierGraphicsLayer2 = ColorKt.graphicsLayer(modifier2, (Function1) objRememberedValue7);
                        MeasurePolicy measurePolicyMaybeCachedBoxMeasurePolicy3 = BoxKt.maybeCachedBoxMeasurePolicy(biasAlignment, false);
                        iHashCode = Long.hashCode(composerImpl3.compositeKeyHashCode);
                        PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope3 = composerImpl3.currentCompositionLocalScope();
                        Modifier modifierMaterializeModifier3 = AbsoluteAlignment.materializeModifier(composerImpl3, modifierGraphicsLayer2);
                        composerImpl3.startReusableNode();
                        if (composerImpl3.inserting) {
                            composerImpl3.createNode(r13);
                        } else {
                            composerImpl3.useNode();
                        }
                        AnchoredGroupPath.set-impl(composerImpl3, measurePolicyMaybeCachedBoxMeasurePolicy3, r9);
                        AnchoredGroupPath.set-impl(composerImpl3, persistentCompositionLocalHashMapCurrentCompositionLocalScope3, r14);
                        if (composerImpl3.inserting) {
                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl3, iHashCode, r7);
                        } else {
                            OperationKt$.ExternalSyntheticLambda0.m(iHashCode, composerImpl3, iHashCode, r7);
                        }
                        AnchoredGroupPath.set-impl(composerImpl3, modifierMaterializeModifier3, r3);
                        Modifier modifierFillMaxSize2 = SizeKt.fillMaxSize(companion, 1.0f);
                        j5 = j2;
                        zChanged2 = composerImpl3.changed(j5);
                        objRememberedValue8 = composerImpl3.rememberedValue();
                        if (zChanged2) {
                            objRememberedValue8 = new MainActivityKt$.ExternalSyntheticLambda140(j5, (byte) 13);
                            composerImpl3.updateRememberedValue(objRememberedValue8);
                        } else {
                            objRememberedValue8 = new MainActivityKt$.ExternalSyntheticLambda140(j5, (byte) 13);
                            composerImpl3.updateRememberedValue(objRememberedValue8);
                        }
                        ImageKt.Canvas(modifierFillMaxSize2, (Function1) objRememberedValue8, composerImpl3, 6);
                        SunKt.Sun(list2, f4, false, sunMotionRememberSunMotion, SizeKt.fillMaxSize(companion, 1.0f), false, (Integer) null, (Function1) null, (String) null, false, composerImpl3, 805331328, 480);
                        composerImpl3.end(true);
                        composerImpl3.end(true);
                        final Function0 function2 = function0;
                        final Animatable animatable3 = animatableProgress2;
                        final boolean z7 = z2;
                        final boolean z8 = z3;
                        final long j7 = j3;
                        final String str7 = strConcat;
                        final String str8 = strConcat2;
                        final List list5 = list;
                        final boolean z9 = z;
                        final ParcelableSnapshotMutableLongState parcelableSnapshotMutableLongState3 = parcelableSnapshotMutableLongState;
                        final State state3 = state;
                        final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState9 = parcelableSnapshotMutableFloatState4;
                        CardsKt.CardColumn(Expect_jvmKt.rememberComposableLambda(1706848304, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda49
                            public final Object invoke(Object obj6, Object obj7, Object obj8) {
                                Object obj9;
                                boolean z10;
                                boolean z11;
                                Modifier modifier3;
                                ColumnScopeInstance columnScopeInstance = (ColumnScopeInstance) obj6;
                                ComposerImpl composerImpl4 = (ComposerImpl) obj7;
                                int iIntValue2 = ((Integer) obj8).intValue();
                                columnScopeInstance.getClass();
                                if ((iIntValue2 & 6) == 0) {
                                    iIntValue2 |= composerImpl4.changed(columnScopeInstance) ? 4 : 2;
                                }
                                if (composerImpl4.shouldExecute(iIntValue2 & 1, (iIntValue2 & 19) != 18)) {
                                    Modifier modifierFillMaxWidth = SizeKt.fillMaxWidth(ColumnScopeInstance.weight$default(columnScopeInstance, 1.0f), 1.0f);
                                    final String str9 = str7;
                                    final String str10 = str8;
                                    final List list6 = list5;
                                    final boolean z12 = z9;
                                    final long j8 = j5;
                                    final ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState10 = parcelableSnapshotMutableFloatState9;
                                    final long j9 = j7;
                                    OffsetKt.BoxWithConstraints(modifierFillMaxWidth, (BiasAlignment) null, Expect_jvmKt.rememberComposableLambda(-1155470202, new Function3() { // from class: com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda56
                                        public final Object invoke(Object obj10, Object obj11, Object obj12) {
                                            String str11;
                                            String str12;
                                            TextStyle textStyle;
                                            List list7;
                                            String str13;
                                            Object next;
                                            BoxWithConstraintsScopeImpl boxWithConstraintsScopeImpl2 = (BoxWithConstraintsScopeImpl) obj10;
                                            ComposerImpl composerImpl5 = (ComposerImpl) obj11;
                                            int iIntValue3 = ((Integer) obj12).intValue();
                                            boxWithConstraintsScopeImpl2.getClass();
                                            long j10 = boxWithConstraintsScopeImpl2.constraints;
                                            if ((iIntValue3 & 6) == 0) {
                                                iIntValue3 |= composerImpl5.changed(boxWithConstraintsScopeImpl2) ? 4 : 2;
                                            }
                                            if (composerImpl5.shouldExecute(iIntValue3 & 1, (iIntValue3 & 19) != 18)) {
                                                TextMeasurer textMeasurerRememberTextMeasurer = ParagraphKt.rememberTextMeasurer(0, composerImpl5, 0, 1);
                                                Density density = (Density) composerImpl5.consume(CompositionLocalsKt.LocalDensity);
                                                TextStyle textStyle2 = TextStyle.copy-p1EtxEg$default(CardsKt.Headline, 0L, UnsignedKt.getSp(56), (FontWeight) null, (FontStyle) null, (FontFamily) null, UnsignedKt.getSp(-2), (Shadow) null, UnsignedKt.getSp(55), (LineHeightStyle) null, 0, 16646013);
                                                int iMin = Math.min(Constraints.getMaxWidth-impl(j10), density.roundToPx-0680j_4(280.0f));
                                                int i9 = Constraints.getMaxWidth-impl(j10);
                                                String str14 = str9;
                                                boolean zChanged5 = composerImpl5.changed(str14) | composerImpl5.changed(textMeasurerRememberTextMeasurer) | composerImpl5.changed(i9);
                                                Object objRememberedValue10 = composerImpl5.rememberedValue();
                                                Object obj13 = Composer.Companion.Empty;
                                                if (zChanged5 || objRememberedValue10 == obj13) {
                                                    float f5 = Constraints.getMaxWidth-impl(j10) * 0.98f;
                                                    Iterator it = StringsKt.split$default(str14, new char[]{' '}).iterator();
                                                    if (!it.hasNext()) {
                                                        MediaSessionStub$.ExternalSyntheticLambda8.m$1();
                                                        return null;
                                                    }
                                                    str11 = str14;
                                                    int i10 = (int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, (String) it.next(), textStyle2, 0, 0L, 1020).size >> 32);
                                                    while (it.hasNext()) {
                                                        int i11 = i10;
                                                        i10 = (int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, (String) it.next(), textStyle2, 0, 0L, 1020).size >> 32);
                                                        if (i11 >= i10) {
                                                            i10 = i11;
                                                        }
                                                    }
                                                    int i12 = i10;
                                                    objRememberedValue10 = Float.valueOf(Math.min(1.0f, f5 / (i12 < 1 ? 1 : i12)));
                                                    composerImpl5.updateRememberedValue(objRememberedValue10);
                                                } else {
                                                    str11 = str14;
                                                }
                                                float fFloatValue2 = ((Number) objRememberedValue10).floatValue();
                                                boolean zChanged6 = composerImpl5.changed(str11);
                                                String str15 = str10;
                                                boolean zChanged7 = zChanged6 | composerImpl5.changed(str15);
                                                List list8 = list6;
                                                boolean zChanged8 = zChanged7 | composerImpl5.changed(list8) | composerImpl5.changed(textMeasurerRememberTextMeasurer) | composerImpl5.changed(j10);
                                                Object objRememberedValue11 = composerImpl5.rememberedValue();
                                                String str16 = str11;
                                                if (zChanged8 || objRememberedValue11 == obj13) {
                                                    FilteringSequence.iterator.1 r6 = new FilteringSequence.iterator.1(new TakeWhileSequence(SequencesKt.generateSequence(Float.valueOf(1.0f), new SunKt$.ExternalSyntheticLambda1((byte) 17)), new SunKt$.ExternalSyntheticLambda1((byte) 18), (byte) 0));
                                                    while (true) {
                                                        if (!r6.hasNext()) {
                                                            str12 = str15;
                                                            textStyle = textStyle2;
                                                            list7 = list8;
                                                            str13 = str16;
                                                            next = null;
                                                            break;
                                                        }
                                                        next = r6.next();
                                                        float fFloatValue3 = ((Number) next).floatValue();
                                                        long j11 = j10;
                                                        FilteringSequence.iterator.1 r22 = r6;
                                                        list7 = list8;
                                                        textStyle = textStyle2;
                                                        str12 = str15;
                                                        int i13 = density.roundToPx-0680j_4(26.0f) + density.roundToPx-0680j_4(6.0f) + ((int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, str15, CardsKt.Sub, 3, ConstraintsKt.Constraints$default(Constraints.getMaxWidth-impl(j11), 0, 13), 972).size & 4294967295L)) + ((int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, str16, CardsKt.Type$lambda$235$lambda$234$lambda$220$titleStyle(textStyle, fFloatValue2, fFloatValue3), 3, ConstraintsKt.Constraints$default(Constraints.getMaxWidth-impl(j11), 0, 13), 972).size & 4294967295L));
                                                        Iterator it2 = list7.iterator();
                                                        int i14 = 0;
                                                        while (it2.hasNext()) {
                                                            i14 += (int) (TextMeasurer.measure-wNUYSr0$default(textMeasurerRememberTextMeasurer, (String) it2.next(), CardsKt.Type$lambda$235$lambda$234$lambda$220$factStyle(fFloatValue3), 0, ConstraintsKt.Constraints$default(iMin, 0, 13), 988).size & 4294967295L);
                                                        }
                                                        str13 = str16;
                                                        if (density.roundToPx-0680j_4(CardsKt.RISE) + i13 + i14 + (density.roundToPx-0680j_4(12.0f) << 1) <= Constraints.getMaxHeight-impl(j11)) {
                                                            break;
                                                        }
                                                        textStyle2 = textStyle;
                                                        j10 = j11;
                                                        r6 = r22;
                                                        str15 = str12;
                                                        list8 = list7;
                                                        str16 = str13;
                                                    }
                                                    Float f6 = (Float) next;
                                                    objRememberedValue11 = Float.valueOf(f6 != null ? f6.floatValue() : 0.5f);
                                                    composerImpl5.updateRememberedValue(objRememberedValue11);
                                                } else {
                                                    str12 = str15;
                                                    textStyle = textStyle2;
                                                    list7 = list8;
                                                    str13 = str16;
                                                }
                                                float fFloatValue4 = ((Number) objRememberedValue11).floatValue();
                                                ScrollState scrollStateRememberScrollState = ImageKt.rememberScrollState(composerImpl5);
                                                Modifier.Companion companion2 = Modifier.Companion.$$INSTANCE;
                                                Modifier modifier4 = OffsetKt.padding-qDBjuR0$default(ImageKt.scroll$default(companion2, scrollStateRememberScrollState, true), 0.0f, 0.0f, 0.0f, CardsKt.RISE, 7);
                                                Arrangement.Top.1 r10 = OffsetKt.Top;
                                                BiasAlignment.Horizontal horizontal = Alignment.Companion.Start;
                                                ColumnMeasurePolicy columnMeasurePolicy = ColumnKt.columnMeasurePolicy(r10, horizontal, composerImpl5, 0);
                                                int iHashCode3 = Long.hashCode(composerImpl5.compositeKeyHashCode);
                                                PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope4 = composerImpl5.currentCompositionLocalScope();
                                                Modifier modifierMaterializeModifier4 = AbsoluteAlignment.materializeModifier(composerImpl5, modifier4);
                                                ComposeUiNode.Companion.getClass();
                                                LayoutNode.Companion.Constructor.1 r15 = ComposeUiNode.Companion.Constructor;
                                                composerImpl5.startReusableNode();
                                                if (composerImpl5.inserting) {
                                                    composerImpl5.createNode(r15);
                                                } else {
                                                    composerImpl5.useNode();
                                                }
                                                ComposeUiNode.Companion.SetModifier.1 r16 = ComposeUiNode.Companion.SetMeasurePolicy;
                                                AnchoredGroupPath.set-impl(composerImpl5, columnMeasurePolicy, r16);
                                                ComposeUiNode.Companion.SetModifier.1 r11 = ComposeUiNode.Companion.SetResolvedCompositionLocals;
                                                AnchoredGroupPath.set-impl(composerImpl5, persistentCompositionLocalHashMapCurrentCompositionLocalScope4, r11);
                                                ComposeUiNode.Companion.SetModifier.1 r17 = ComposeUiNode.Companion.SetCompositeKeyHash;
                                                if (composerImpl5.inserting || !Intrinsics.areEqual(composerImpl5.rememberedValue(), Integer.valueOf(iHashCode3))) {
                                                    OperationKt$.ExternalSyntheticLambda0.m(iHashCode3, composerImpl5, iHashCode3, r17);
                                                }
                                                ComposeUiNode.Companion.SetModifier.1 r4 = ComposeUiNode.Companion.SetModifier;
                                                AnchoredGroupPath.set-impl(composerImpl5, modifierMaterializeModifier4, r4);
                                                boolean z13 = z12;
                                                TextStyle textStyle3 = textStyle;
                                                TextKt.Text-Nvy7gAk(str12, CardsKt.rise(companion2, 0, z13, composerImpl5, 54), CardsKt.soft(composerImpl5), 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 2, false, 3, 0, (Function1) null, CardsKt.Sub, composerImpl5, 0, 12607872, 110584);
                                                String str17 = str13;
                                                int iLastIndexOf$default = StringsKt.lastIndexOf$default(str17, ' ', 0, 6) + 1;
                                                AnnotatedString.Builder builder = new AnnotatedString.Builder();
                                                builder.append(StringsKt.take(iLastIndexOf$default, str17));
                                                long j12 = j8;
                                                int iPushStyle = builder.pushStyle(new SpanStyle(j12, 0L, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65534));
                                                try {
                                                    builder.append(StringsKt.drop(iLastIndexOf$default, str17));
                                                    builder.pop(iPushStyle);
                                                    TextKt.Text-Z58ophY(builder.toAnnotatedString(), CardsKt.rise(OffsetKt.padding-qDBjuR0$default(companion2, 0.0f, 6.0f, 0.0f, 0.0f, 13), 0, z13, composerImpl5, 54), 0L, 0L, (FontWeight) null, 0L, 0L, 0, false, 3, 0, (Map) null, (Function1) null, CardsKt.Type$lambda$235$lambda$234$lambda$220$titleStyle(textStyle3, fFloatValue2, fFloatValue4), composerImpl5, 0, 24576, 245756);
                                                    ComposerImpl composerImpl6 = composerImpl5;
                                                    Modifier modifier5 = SizeKt.widthIn-VpY3zN4$default(OffsetKt.padding-qDBjuR0$default(companion2, 0.0f, 26.0f, 0.0f, 0.0f, 13), 280.0f, 1);
                                                    Object objRememberedValue12 = composerImpl6.rememberedValue();
                                                    if (objRememberedValue12 == obj13) {
                                                        objRememberedValue12 = new CardsKt$$ExternalSyntheticLambda12(parcelableSnapshotMutableFloatState10, (byte) 2);
                                                        composerImpl6.updateRememberedValue(objRememberedValue12);
                                                    }
                                                    Modifier modifierOnGloballyPositioned = RulerKt.onGloballyPositioned(modifier5, (Function1) objRememberedValue12);
                                                    ColumnMeasurePolicy columnMeasurePolicy2 = ColumnKt.columnMeasurePolicy(new Arrangement.SpacedAligned(12.0f, new SaversKt$.ExternalSyntheticLambda0((byte) 3)), horizontal, composerImpl6, 6);
                                                    int iHashCode4 = Long.hashCode(composerImpl6.compositeKeyHashCode);
                                                    PersistentCompositionLocalHashMap persistentCompositionLocalHashMapCurrentCompositionLocalScope5 = composerImpl6.currentCompositionLocalScope();
                                                    Modifier modifierMaterializeModifier5 = AbsoluteAlignment.materializeModifier(composerImpl6, modifierOnGloballyPositioned);
                                                    composerImpl6.startReusableNode();
                                                    if (composerImpl6.inserting) {
                                                        composerImpl6.createNode(r15);
                                                    } else {
                                                        composerImpl6.useNode();
                                                    }
                                                    AnchoredGroupPath.set-impl(composerImpl6, columnMeasurePolicy2, r16);
                                                    AnchoredGroupPath.set-impl(composerImpl6, persistentCompositionLocalHashMapCurrentCompositionLocalScope5, r11);
                                                    if (composerImpl6.inserting || !Intrinsics.areEqual(composerImpl6.rememberedValue(), Integer.valueOf(iHashCode4))) {
                                                        OperationKt$.ExternalSyntheticLambda0.m(iHashCode4, composerImpl6, iHashCode4, r17);
                                                    }
                                                    AnchoredGroupPath.set-impl(composerImpl6, modifierMaterializeModifier5, r4);
                                                    composerImpl6.startReplaceGroup(-1706632590);
                                                    int i15 = 0;
                                                    for (Object obj14 : list7) {
                                                        int i16 = i15 + 1;
                                                        if (i15 < 0) {
                                                            ByteStreamsKt.throwIndexOverflow();
                                                            throw null;
                                                        }
                                                        String str18 = (String) obj14;
                                                        str18.getClass();
                                                        Pattern patternCompile = Pattern.compile("\\d+(?:[.,]\\d+)*%");
                                                        patternCompile.getClass();
                                                        Matcher matcher = patternCompile.matcher(str18);
                                                        matcher.getClass();
                                                        MatcherMatchResult matcherMatchResultFindNext = RegexKt.findNext(matcher, 0, str18);
                                                        if (matcherMatchResultFindNext == null) {
                                                            Pattern patternCompile2 = Pattern.compile("\\d+(?:[.,]\\d+)*(?: [ap]\\.m\\.)?");
                                                            patternCompile2.getClass();
                                                            Matcher matcher2 = patternCompile2.matcher(str18);
                                                            matcher2.getClass();
                                                            matcherMatchResultFindNext = RegexKt.findNext(matcher2, 0, str18);
                                                        }
                                                        IntRange range = matcherMatchResultFindNext != null ? matcherMatchResultFindNext.getRange() : null;
                                                        AnnotatedString.Builder builder2 = new AnnotatedString.Builder();
                                                        if (range == null) {
                                                            builder2.append(str18);
                                                        } else {
                                                            int i17 = ((IntProgression) range).last;
                                                            int i18 = ((IntProgression) range).first;
                                                            builder2.append(str18.substring(0, i18));
                                                            int iPushStyle2 = builder2.pushStyle(new SpanStyle(j12, 0L, FontWeight.ExtraBold, (FontStyle) null, (FontSynthesis) null, (FontFamily) null, (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, 65530));
                                                            int i19 = i17 + 1;
                                                            try {
                                                                builder2.append(str18.substring(i18, i19));
                                                                builder2.pop(iPushStyle2);
                                                                builder2.append(str18.substring(i19));
                                                            } catch (Throwable th) {
                                                                builder2.pop(iPushStyle2);
                                                                throw th;
                                                            }
                                                        }
                                                        ComposerImpl composerImpl7 = composerImpl6;
                                                        TextKt.Text-Z58ophY(builder2.toAnnotatedString(), CardsKt.riseAt(companion2, (i15 * 250) + 1000, z13, composerImpl6, 3078, 0), j9, 0L, (FontWeight) null, 0L, 0L, 0, false, 0, 0, (Map) null, (Function1) null, CardsKt.Type$lambda$235$lambda$234$lambda$220$factStyle(fFloatValue4), composerImpl7, 0, 0, 262136);
                                                        composerImpl6 = composerImpl7;
                                                        i15 = i16;
                                                    }
                                                    composerImpl6.end(false);
                                                    composerImpl6.end(true);
                                                    composerImpl6.end(true);
                                                } catch (Throwable th2) {
                                                    builder.pop(iPushStyle);
                                                    throw th2;
                                                }
                                            } else {
                                                composerImpl5.skipToGroupEnd();
                                            }
                                            return Unit.INSTANCE;
                                        }
                                    }, composerImpl4), composerImpl4, 3072, 6);
                                    float f5 = ((Density) composerImpl4.consume(CompositionLocalsKt.LocalDensity)).toPx-0680j_4(18.0f);
                                    StaticProvidableCompositionLocal staticProvidableCompositionLocal2 = ColorSchemeKt.LocalColorScheme;
                                    long j10 = ((ColorScheme) composerImpl4.consume(staticProvidableCompositionLocal2)).background;
                                    Function0 function3 = function2;
                                    Object obj10 = Composer.Companion.Empty;
                                    Modifier modifier4 = Modifier.Companion.$$INSTANCE;
                                    if (function3 != null) {
                                        composerImpl4.startReplaceGroup(-396159543);
                                        boolean zChanged5 = composerImpl4.changed(function3);
                                        Object objRememberedValue10 = composerImpl4.rememberedValue();
                                        if (zChanged5 || objRememberedValue10 == obj10) {
                                            objRememberedValue10 = new Regex$.ExternalSyntheticLambda0(function3, parcelableSnapshotMutableLongState3, (byte) 28);
                                            composerImpl4.updateRememberedValue(objRememberedValue10);
                                        }
                                        Function0 function4 = (Function0) objRememberedValue10;
                                        Modifier modifier5 = SizeKt.heightIn-VpY3zN4(OffsetKt.padding-qDBjuR0$default(modifier4, 0.0f, 12.0f, 0.0f, 0.0f, 13), 48.0f, Float.NaN);
                                        Animatable animatable4 = animatable3;
                                        boolean zChangedInstance2 = composerImpl4.changedInstance(animatable4) | composerImpl4.changed(f5);
                                        Object objRememberedValue11 = composerImpl4.rememberedValue();
                                        if (zChangedInstance2 || objRememberedValue11 == obj10) {
                                            objRememberedValue11 = new CardsKt$$ExternalSyntheticLambda37(animatable4, f5, (byte) 3);
                                            composerImpl4.updateRememberedValue(objRememberedValue11);
                                        }
                                        Modifier modifierGraphicsLayer3 = ColorKt.graphicsLayer(modifier5, (Function1) objRememberedValue11);
                                        boolean zChanged6 = composerImpl4.changed(j10);
                                        Object objRememberedValue12 = composerImpl4.rememberedValue();
                                        if (zChanged6 || objRememberedValue12 == obj10) {
                                            objRememberedValue12 = new MainActivityKt$.ExternalSyntheticLambda140(j10, (byte) 15);
                                            composerImpl4.updateRememberedValue(objRememberedValue12);
                                        }
                                        Modifier modifierDrawBehind = ClipKt.drawBehind(modifierGraphicsLayer3, (Function1) objRememberedValue12);
                                        State state4 = state3;
                                        if (((Boolean) state4.getValue()).booleanValue()) {
                                            composerImpl4.startReplaceGroup(-396126824);
                                            composerImpl4.end(false);
                                            modifier3 = modifier4;
                                        } else {
                                            composerImpl4.startReplaceGroup(-396126073);
                                            Object objRememberedValue13 = composerImpl4.rememberedValue();
                                            if (objRememberedValue13 == obj10) {
                                                objRememberedValue13 = new SunKt$.ExternalSyntheticLambda1((byte) 15);
                                                composerImpl4.updateRememberedValue(objRememberedValue13);
                                            }
                                            Modifier modifierClearAndSetSemantics = SemanticsModifierKt.clearAndSetSemantics(modifier4, (Function1) objRememberedValue13);
                                            composerImpl4.end(false);
                                            modifier3 = modifierClearAndSetSemantics;
                                        }
                                        Modifier modifierThen = modifierDrawBehind.then(modifier3);
                                        boolean zBooleanValue = ((Boolean) state4.getValue()).booleanValue();
                                        boolean z13 = z7;
                                        boolean z14 = zBooleanValue && !z13;
                                        PaddingValuesImpl paddingValuesImpl = ButtonDefaults.ContentPadding;
                                        modifier4 = modifier4;
                                        obj9 = obj10;
                                        MenuKt.Button(function4, modifierThen, z14, (Shape) null, ButtonDefaults.buttonColors-ro_MJ88(j8, ((ColorScheme) composerImpl4.consume(staticProvidableCompositionLocal2)).onPrimary, j8, ((ColorScheme) composerImpl4.consume(staticProvidableCompositionLocal2)).onPrimary, composerImpl4, 0), (ButtonElevation) null, (BorderStroke) null, OffsetKt.PaddingValues-YgX7TsA$default(22.0f, 2), Expect_jvmKt.rememberComposableLambda(1942550907, new PageScreenKt$.ExternalSyntheticLambda5((byte) 3, z13), composerImpl4), composerImpl4, 817889280, 360);
                                        composerImpl4 = composerImpl4;
                                        z10 = false;
                                    } else {
                                        obj9 = obj10;
                                        z10 = false;
                                        composerImpl4.startReplaceGroup(554610226);
                                    }
                                    composerImpl4.end(z10);
                                    if (z8) {
                                        composerImpl4.startReplaceGroup(-396105249);
                                        Modifier modifier6 = OffsetKt.padding-qDBjuR0$default(modifier4, 0.0f, 8.0f, 0.0f, 0.0f, 13);
                                        Object objRememberedValue14 = composerImpl4.rememberedValue();
                                        if (objRememberedValue14 == obj9) {
                                            objRememberedValue14 = new SunKt$.ExternalSyntheticLambda1((byte) 16);
                                            composerImpl4.updateRememberedValue(objRememberedValue14);
                                        }
                                        z11 = false;
                                        ComposerImpl composerImpl5 = composerImpl4;
                                        TextKt.Text-Nvy7gAk("Couldn't make the pictures. Try again.", SemanticsModifierKt.semantics(modifier6, false, (Function1) objRememberedValue14), j9, 0L, (FontStyle) null, (FontWeight) null, (FontListFontFamily) null, 0L, (TextAlign) null, 0L, 0, false, 0, 0, (Function1) null, CardsKt.Sub, composerImpl5, 6, 12582912, 131064);
                                        composerImpl4 = composerImpl5;
                                    } else {
                                        z11 = false;
                                        composerImpl4.startReplaceGroup(554610226);
                                    }
                                    composerImpl4.end(z11);
                                } else {
                                    composerImpl4.skipToGroupEnd();
                                }
                                return Unit.INSTANCE;
                            }
                        }, composerImpl3), composerImpl3, 6);
                    } else {
                        composerImpl3.skipToGroupEnd();
                    }
                    return Unit.INSTANCE;
                }
            }, composerImpl), composerImpl, 3078, 6);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda8(spotifriedStats, function0, z, z2, z3, str, i, (byte) 1);
        }
    }

    public static final TextStyle Type$lambda$235$lambda$234$lambda$220$factStyle(float f) {
        TextStyle textStyle = Sub;
        long j = textStyle.spanStyle.fontSize;
        UnsignedKt.checkArithmetic--R2X_6o(j);
        long jPack = UnsignedKt.pack(TextUnit.getValue-impl(j) * f, j & 1095216660480L);
        long sp = UnsignedKt.getSp(20);
        UnsignedKt.checkArithmetic--R2X_6o(sp);
        return TextStyle.copy-p1EtxEg$default(textStyle, 0L, jPack, (FontWeight) null, (FontStyle) null, (FontFamily) null, 0L, (Shadow) null, UnsignedKt.pack(TextUnit.getValue-impl(sp) * f, 1095216660480L & sp), (LineHeightStyle) null, 0, 16646141);
    }

    public static final TextStyle Type$lambda$235$lambda$234$lambda$220$titleStyle(TextStyle textStyle, float f, float f2) {
        SpanStyle spanStyle = textStyle.spanStyle;
        long j = spanStyle.fontSize;
        UnsignedKt.checkArithmetic--R2X_6o(j);
        long jPack = UnsignedKt.pack(TextUnit.getValue-impl(j) * f, j & 1095216660480L);
        UnsignedKt.checkArithmetic--R2X_6o(jPack);
        long jPack2 = UnsignedKt.pack(TextUnit.getValue-impl(jPack) * f2, jPack & 1095216660480L);
        long j2 = textStyle.paragraphStyle.lineHeight;
        UnsignedKt.checkArithmetic--R2X_6o(j2);
        long jPack3 = UnsignedKt.pack(TextUnit.getValue-impl(j2) * f, j2 & 1095216660480L);
        UnsignedKt.checkArithmetic--R2X_6o(jPack3);
        long jPack4 = UnsignedKt.pack(TextUnit.getValue-impl(jPack3) * f2, jPack3 & 1095216660480L);
        long j3 = spanStyle.letterSpacing;
        UnsignedKt.checkArithmetic--R2X_6o(j3);
        long jPack5 = UnsignedKt.pack(TextUnit.getValue-impl(j3) * f, j3 & 1095216660480L);
        UnsignedKt.checkArithmetic--R2X_6o(jPack5);
        return TextStyle.copy-p1EtxEg$default(textStyle, 0L, jPack2, (FontWeight) null, (FontStyle) null, (FontFamily) null, UnsignedKt.pack(TextUnit.getValue-impl(jPack5) * f2, 1095216660480L & jPack5), (Shadow) null, jPack4, (LineHeightStyle) null, 0, 16646013);
    }

    public static final void TypeCard(SpotifriedStats spotifriedStats, Function0 function0, boolean z, boolean z2, boolean z3, String str, ComposerImpl composerImpl, int i) {
        int i2;
        composerImpl.startRestartGroup(-535142585);
        if ((i & 6) == 0) {
            i2 = (composerImpl.changedInstance(spotifriedStats) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 48) == 0) {
            i2 |= composerImpl.changedInstance(function0) ? 32 : 16;
        }
        if ((i & 384) == 0) {
            i2 |= composerImpl.changed(z) ? 256 : 128;
        }
        if ((i & 3072) == 0) {
            i2 |= composerImpl.changed(z2) ? 2048 : 1024;
        }
        if ((i & 24576) == 0) {
            i2 |= composerImpl.changed(z3) ? 16384 : 8192;
        }
        if ((196608 & i) == 0) {
            i2 |= composerImpl.changed(str) ? 131072 : 65536;
        }
        boolean zRememberNoMotion = true;
        if (composerImpl.shouldExecute(i2 & 1, (74899 & i2) != 74898)) {
            if (z) {
                composerImpl.startReplaceGroup(486041891);
            } else {
                composerImpl.startReplaceGroup(1124057689);
                zRememberNoMotion = SunKt.rememberNoMotion(composerImpl);
            }
            composerImpl.end(false);
            boolean z4 = zRememberNoMotion;
            composerImpl.startMovableGroup(1124058476, composerImpl.joinKey(spotifriedStats.period, Boolean.valueOf(z4)));
            Type(spotifriedStats, function0, z4, z2, z3, str, composerImpl, i2 & 523390);
            composerImpl.end(false);
        } else {
            composerImpl.skipToGroupEnd();
        }
        RecomposeScopeImpl recomposeScopeImplEndRestartGroup = composerImpl.endRestartGroup();
        if (recomposeScopeImplEndRestartGroup != null) {
            recomposeScopeImplEndRestartGroup.block = new CardsKt$$ExternalSyntheticLambda8(spotifriedStats, function0, z, z2, z3, str, i, (byte) 0);
        }
    }

    public static final Animatable clock(boolean z, float f, ComposerImpl composerImpl, int i) {
        Object objRememberedValue = composerImpl.rememberedValue();
        NeverEqualPolicy neverEqualPolicy = Composer.Companion.Empty;
        if (objRememberedValue == neverEqualPolicy) {
            objRememberedValue = ArcSplineKt.Animatable$default(z ? f : 0.0f);
            composerImpl.updateRememberedValue(objRememberedValue);
        }
        Animatable animatable = (Animatable) objRememberedValue;
        boolean zChangedInstance = composerImpl.changedInstance(animatable) | ((((i & 112) ^ 48) > 32 && composerImpl.changed(f)) || (i & 48) == 32);
        Object objRememberedValue2 = composerImpl.rememberedValue();
        if (zChangedInstance || objRememberedValue2 == neverEqualPolicy) {
            objRememberedValue2 = new CardsKt$clock$1$1(animatable, f, null, (byte) 0);
            composerImpl.updateRememberedValue(objRememberedValue2);
        }
        AnchoredGroupPath.LaunchedEffect(composerImpl, animatable, (Function2) objRememberedValue2);
        return animatable;
    }

    public static final void countSpan(AnnotatedString.Builder builder, CountUp countUp, SpanStyle spanStyle, String str) {
        if (!countUp.started) {
            spanStyle = SpanStyle.copy-GSF8kmg$default(spanStyle, Color.Transparent, 65534);
        }
        int iPushStyle = builder.pushStyle(spanStyle);
        try {
            builder.append(str);
        } finally {
            builder.pop(iPushStyle);
        }
    }

    public static final CountUp countUp(int i, int i2, int i3, ComposerImpl composerImpl, boolean z) {
        int i4 = i3 >> 3;
        float fFloatValue = ((Number) progress(i2, 900, (i4 & 14) | 384 | (i4 & 112), composerImpl, z).getValue()).floatValue();
        return new CountUp(ListeningScreenKt.count(MathKt.roundToInt(i * fFloatValue)), fFloatValue > 0.0f);
    }

    public static final String plural(int i, String str) {
        return i + " " + str + (i == 1 ? "" : "s");
    }

    public static final Animatable progress(int i, int i2, int i3, ComposerImpl composerImpl, boolean z) {
        Object objRememberedValue = composerImpl.rememberedValue();
        NeverEqualPolicy neverEqualPolicy = Composer.Companion.Empty;
        if (objRememberedValue == neverEqualPolicy) {
            objRememberedValue = ArcSplineKt.Animatable$default(z ? 1.0f : 0.0f);
            composerImpl.updateRememberedValue(objRememberedValue);
        }
        Animatable animatable = (Animatable) objRememberedValue;
        boolean zChangedInstance = composerImpl.changedInstance(animatable) | ((((i3 & 896) ^ 384) > 256 && composerImpl.changed(i2)) || (i3 & 384) == 256) | ((((i3 & 112) ^ 48) > 32 && composerImpl.changed(i)) || (i3 & 48) == 32);
        Object objRememberedValue2 = composerImpl.rememberedValue();
        if (zChangedInstance || objRememberedValue2 == neverEqualPolicy) {
            objRememberedValue2 = new CardsKt$progress$1$1(animatable, i2, i, null);
            composerImpl.updateRememberedValue(objRememberedValue2);
        }
        AnchoredGroupPath.LaunchedEffect(composerImpl, animatable, (Function2) objRememberedValue2);
        return animatable;
    }

    public static final SunMotion rememberSunMotion(List list, float f, boolean z, ComposerImpl composerImpl) {
        Object objRememberedValue = composerImpl.rememberedValue();
        Object obj = objRememberedValue;
        if (objRememberedValue == Composer.Companion.Empty) {
            SunMotion sunMotion = new SunMotion();
            if (z) {
                Long l = (Long) CollectionsKt.maxOrNull(list);
                long jLongValue = l != null ? l.longValue() : 0L;
                if (jLongValue < 1) {
                    jLongValue = 1;
                }
                float f2 = jLongValue;
                int i = 0;
                for (Object obj2 : list) {
                    int i2 = i + 1;
                    if (i < 0) {
                        ByteStreamsKt.throwIndexOverflow();
                        throw null;
                    }
                    sunMotion.now[i] = ((Number) obj2).longValue() / f2;
                    i = i2;
                }
                sunMotion.scale = f;
            }
            composerImpl.updateRememberedValue(sunMotion);
            obj = sunMotion;
        }
        return (SunMotion) obj;
    }

    public static final Modifier rise(Modifier modifier, int i, boolean z, ComposerImpl composerImpl, int i2) {
        return riseAt(modifier, i * 180, z, composerImpl, i2 & 910, 4);
    }

    public static final Modifier riseAt(Modifier modifier, int i, boolean z, ComposerImpl composerImpl, int i2, int i3) {
        Animatable animatableProgress = progress(i, (i3 & 4) != 0 ? 900 : 800, ((i2 >> 6) & 14) | (i2 & 112) | ((i2 >> 3) & 896), composerImpl, z);
        float f = ((Density) composerImpl.consume(CompositionLocalsKt.LocalDensity)).toPx-0680j_4(RISE);
        boolean zChangedInstance = composerImpl.changedInstance(animatableProgress) | composerImpl.changed(f);
        Object objRememberedValue = composerImpl.rememberedValue();
        if (zChangedInstance || objRememberedValue == Composer.Companion.Empty) {
            objRememberedValue = new CardsKt$$ExternalSyntheticLambda37(animatableProgress, f, (byte) 0);
            composerImpl.updateRememberedValue(objRememberedValue);
        }
        return ColorKt.graphicsLayer(modifier, (Function1) objRememberedValue);
    }

    public static final long soft(ComposerImpl composerImpl) {
        return Color.copy-wmQWz5c$default(0.64f, ((ColorScheme) composerImpl.consume(ColorSchemeKt.LocalColorScheme)).onBackground);
    }

    public static final float stepAt(float f, float f2, float f3) {
        return Ease.transform(ResultKt.coerceIn((f - f2) / f3, 0.0f, 1.0f));
    }
}
