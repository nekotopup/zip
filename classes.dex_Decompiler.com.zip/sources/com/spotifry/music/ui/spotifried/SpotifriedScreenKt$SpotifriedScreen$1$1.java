package com.spotifry.music.ui.spotifried;

import android.app.Activity;
import com.spotifry.music.AppContainer;
import com.spotifry.music.MusicApp;
import com.spotifry.music.data.Settings;
import com.spotifry.music.data.spotifried.CardId;
import com.spotifry.music.ui.components.CoverKt;
import com.spotifry.music.ui.home.MoodViewModel;
import com.spotifry.music.ui.theme.Accent;
import com.spotifry.music.ui.theme.AccentChoice;
import com.spotifry.music.ui.theme.AccentKt;
import java.util.concurrent.TimeUnit;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.intrinsics.CoroutineSingletons;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function4;
import kotlinx.coroutines.AwaitKt;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.internal.MainDispatcherLoader;
import kotlinx.coroutines.scheduling.DefaultScheduler;
import okhttp3.OkHttpClient;
import okhttp3.internal.Util;
import okio.ByteString;
import org.jsoup.parser.CharacterReader$;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final class SpotifriedScreenKt$SpotifriedScreen$1$1 extends SuspendLambda implements Function4 {
    public /* synthetic */ Activity L$0;
    public /* synthetic */ CardId L$1;
    public /* synthetic */ SpotifriedState L$2;
    public boolean label;

    public final Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
        SpotifriedScreenKt$SpotifriedScreen$1$1 spotifriedScreenKt$SpotifriedScreen$1$1 = new SpotifriedScreenKt$SpotifriedScreen$1$1(4, (Continuation) obj4);
        spotifriedScreenKt$SpotifriedScreen$1$1.L$0 = (Activity) obj;
        spotifriedScreenKt$SpotifriedScreen$1$1.L$1 = (CardId) obj2;
        spotifriedScreenKt$SpotifriedScreen$1$1.L$2 = (SpotifriedState) obj3;
        return spotifriedScreenKt$SpotifriedScreen$1$1.invokeSuspend(Unit.INSTANCE);
    }

    public final Object invokeSuspend(Object obj) {
        Activity activity = this.L$0;
        CardId cardId = this.L$1;
        SpotifriedState spotifriedState = this.L$2;
        boolean z = this.label;
        if (z) {
            if (z) {
                ResultKt.throwOnFailure(obj);
                return obj;
            }
            CharacterReader$.ExternalSyntheticLambda2.m$2("call to 'resume' before 'invoke' with coroutine");
            return null;
        }
        ResultKt.throwOnFailure(obj);
        this.L$0 = null;
        this.L$1 = null;
        this.L$2 = null;
        this.label = true;
        MusicApp application = activity.getApplication();
        application.getClass();
        AppContainer container = application.getContainer();
        ByteString.Companion companion = AccentChoice.Companion;
        Settings settings = container.settings;
        String str = (String) settings.accent.getValue();
        companion.getClass();
        Accent accentAccentFor = AccentKt.accentFor(ByteString.Companion.of(str), ((Number) settings.accentColor.getValue()).intValue(), activity);
        OkHttpClient.Builder builderNewBuilder = container.imageClient.newBuilder();
        TimeUnit timeUnit = TimeUnit.SECONDS;
        timeUnit.getClass();
        builderNewBuilder.callTimeout = Util.checkDuration(5L, timeUnit);
        MoodViewModel.load.1 r5 = new MoodViewModel.load.1(new OkHttpClient(builderNewBuilder), activity, (Continuation) null, (byte) 3);
        DefaultScheduler defaultScheduler = Dispatchers.Default;
        Object objWithContext = AwaitKt.withContext(MainDispatcherLoader.dispatcher, new CoverKt.load.2(spotifriedState, cardId, activity, accentAccentFor, r5, (Continuation) null, (byte) 15), this);
        CoroutineSingletons coroutineSingletons = CoroutineSingletons.COROUTINE_SUSPENDED;
        return objWithContext == coroutineSingletons ? coroutineSingletons : objWithContext;
    }
}
