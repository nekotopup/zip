package com.spotifry.music.ui.spotifried;

import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelKt;
import androidx.media3.session.MediaSessionStub$;
import androidx.room.coroutines.FlowUtil$createFlow$;
import com.spotifry.music.data.Backups$applyTheRest$;
import com.spotifry.music.data.Log;
import com.spotifry.music.data.PlaylistOrder$arrange$;
import com.spotifry.music.data.TopSong;
import com.spotifry.music.data.db.ListenRow;
import com.spotifry.music.data.db.SongEntity;
import com.spotifry.music.data.spotifried.AgeStats;
import com.spotifry.music.data.spotifried.ArtistShare;
import com.spotifry.music.data.spotifried.MonthTop;
import com.spotifry.music.data.spotifried.ObsessionDay;
import com.spotifry.music.data.spotifried.SpotifriedStats;
import com.spotifry.music.data.spotifried.SpotifriedStatsKt;
import com.spotifry.music.data.spotifried.WrappedPeriod;
import java.time.Instant;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.chrono.ChronoLocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import kotlin.Pair;
import kotlin.ResultKt;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.CollectionsKt__IterablesKt;
import kotlin.collections.EmptyList;
import kotlin.collections.IntIterator;
import kotlin.collections.MapsKt__MapsKt;
import kotlin.io.ByteStreamsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.Intrinsics;
import kotlin.ranges.IntProgressionIterator;
import kotlin.ranges.IntRange;
import kotlinx.coroutines.Dispatchers;
import kotlinx.coroutines.flow.Flow;
import kotlinx.coroutines.flow.FlowKt__LimitKt$dropWhile$;
import kotlinx.coroutines.flow.ReadonlyStateFlow;
import kotlinx.coroutines.flow.StartedWhileSubscribed;
import kotlinx.coroutines.flow.StateFlowImpl;
import kotlinx.coroutines.flow.StateFlowKt;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final class SpotifriedViewModel extends ViewModel {
    public final StateFlowImpl picked;
    public final ReadonlyStateFlow state;
    public final Function0 today;
    public final ZoneId zone;

    /* JADX INFO: renamed from: com.spotifry.music.ui.spotifried.SpotifriedViewModel$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
    public final /* synthetic */ class AnonymousClass1 extends FunctionReferenceImpl implements Function0 {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1(0, LocalDate.class, "now", "now()Ljava/time/LocalDate;", 0);

        public final Object invoke() {
            return LocalDate.now();
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public SpotifriedViewModel(FlowUtil$createFlow$.inlined.map.1 r11, FlowUtil$createFlow$.inlined.map.1 r12, StateFlowImpl stateFlowImpl) {
        AnonymousClass1 anonymousClass1 = AnonymousClass1.INSTANCE;
        stateFlowImpl.getClass();
        this.today = anonymousClass1;
        StateFlowImpl stateFlowImplMutableStateFlow = StateFlowKt.MutableStateFlow((Object) null);
        this.picked = stateFlowImplMutableStateFlow;
        this.zone = ZoneId.systemDefault();
        this.state = StateFlowKt.stateIn(StateFlowKt.flowOn(new FlowKt__LimitKt$dropWhile$.inlined.unsafeFlow.1(new Flow[]{r11, r12, stateFlowImplMutableStateFlow, stateFlowImpl}, new SpotifriedViewModel$state$1(5, this, SpotifriedViewModel.class, "build", "build(Ljava/util/List;Ljava/util/List;Lcom/spotifry/music/data/spotifried/WrappedPeriod;Ljava/lang/String;)Lcom/spotifry/music/ui/spotifried/SpotifriedState;", 4), (byte) 8), Dispatchers.Default), ViewModelKt.getViewModelScope(this), new StartedWhileSubscribed(5000L), (Object) null);
    }

    /* JADX WARN: Code duplicated, block: B:256:0x081f  */
    /* JADX WARN: Code duplicated, block: B:350:0x0a7e  */
    public static final SpotifriedStats build$statsOf(List list, Map map, SpotifriedViewModel spotifriedViewModel, Set set, WrappedPeriod wrappedPeriod) {
        LocalDate localDate;
        ObsessionDay obsessionDay;
        EmptyList emptyList;
        Object next;
        int i;
        int i2;
        Object next2;
        ArtistShare artistShare;
        Object next3;
        int i3;
        Integer numValueOf;
        Integer numValueOf2;
        SongEntity songEntity;
        Object next4;
        LocalDate localDatePlusDays;
        int i4;
        int i5;
        LocalDate localDate2;
        SpotifriedStatsKt.spotifriedStats.Line line;
        ZoneId zoneId = spotifriedViewModel.zone;
        zoneId.getClass();
        LocalDate localDate3 = wrappedPeriod.to;
        LocalDate localDate4 = wrappedPeriod.from;
        ArrayList arrayList = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list, 10));
        Iterator it = list.iterator();
        while (it.hasNext()) {
            ListenRow listenRow = (ListenRow) it.next();
            ZonedDateTime zonedDateTimeAtZone = Instant.ofEpochMilli(listenRow.startedAt).atZone(zoneId);
            LocalDate localDate5 = zonedDateTimeAtZone.toLocalDate();
            localDate5.getClass();
            arrayList.add(new SpotifriedStatsKt.spotifriedStats.Line(listenRow, localDate5, zonedDateTimeAtZone.getHour(), (zonedDateTimeAtZone.getSecond() / 3600.0f) + (zonedDateTimeAtZone.getMinute() / 60.0f) + zonedDateTimeAtZone.getHour()));
        }
        ArrayList<SpotifriedStatsKt.spotifriedStats.Line> arrayList2 = new ArrayList();
        for (Object obj : arrayList) {
            SpotifriedStatsKt.spotifriedStats.Line line2 = (SpotifriedStatsKt.spotifriedStats.Line) obj;
            if (line2.date.compareTo((ChronoLocalDate) localDate4) >= 0 && line2.date.compareTo((ChronoLocalDate) localDate3) <= 0) {
                arrayList2.add(obj);
            }
        }
        Iterator it2 = arrayList.iterator();
        if (it2.hasNext()) {
            localDate = ((SpotifriedStatsKt.spotifriedStats.Line) it2.next()).date;
            while (it2.hasNext()) {
                LocalDate localDate6 = ((SpotifriedStatsKt.spotifriedStats.Line) it2.next()).date;
                if (localDate.compareTo((Object) localDate6) > 0) {
                    localDate = localDate6;
                }
            }
        } else {
            localDate = null;
        }
        if (localDate == null || localDate4.compareTo((Object) localDate) >= 0) {
            localDate = localDate4;
        }
        ArrayList arrayList3 = new ArrayList();
        for (Object obj2 : arrayList2) {
            if (((SpotifriedStatsKt.spotifriedStats.Line) obj2).row.secondsHeard >= 30) {
                arrayList3.add(obj2);
            }
        }
        ArrayList arrayList4 = new ArrayList();
        for (Object obj3 : arrayList3) {
            if (((SpotifriedStatsKt.spotifriedStats.Line) obj3).row.song != null) {
                arrayList4.add(obj3);
            }
        }
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        for (Object obj4 : arrayList4) {
            String str = ((SpotifriedStatsKt.spotifriedStats.Line) obj4).row.songId;
            Object arrayList5 = linkedHashMap.get(str);
            if (arrayList5 == null) {
                arrayList5 = new ArrayList();
                linkedHashMap.put(str, arrayList5);
            }
            ((List) arrayList5).add(obj4);
        }
        Collection<List> collectionValues = linkedHashMap.values();
        ArrayList arrayList6 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(collectionValues, 10));
        for (List list2 : collectionValues) {
            SongEntity songEntity2 = ((SpotifriedStatsKt.spotifriedStats.Line) CollectionsKt.last(list2)).row.song;
            songEntity2.getClass();
            Iterator it3 = list2.iterator();
            long j = 0;
            while (it3.hasNext()) {
                j += (long) ((SpotifriedStatsKt.spotifriedStats.Line) it3.next()).row.secondsHeard;
                arrayList3 = arrayList3;
            }
            arrayList6.add(new TopSong(songEntity2, j, list2.size()));
            arrayList3 = arrayList3;
        }
        ArrayList arrayList7 = arrayList3;
        TopSong topSong = (TopSong) CollectionsKt.maxWithOrNull(arrayList6, new PlaylistOrder$arrange$.inlined.thenBy.1(new Backups$applyTheRest$.inlined.sortedBy.1((byte) 19), (byte) 4));
        int i6 = 1;
        int i7 = 0;
        int iMax = Math.max(0, ((int) ChronoUnit.DAYS.between(localDate, localDate3)) + 1);
        long[] jArr = new long[iMax];
        for (SpotifriedStatsKt.spotifriedStats.Line line3 : arrayList2) {
            int iCoerceIn = ResultKt.coerceIn((int) ChronoUnit.DAYS.between(localDate, line3.date), i7, iMax - 1);
            jArr[iCoerceIn] = jArr[iCoerceIn] + ((long) line3.row.secondsHeard);
            i6 = i6;
            i7 = 0;
        }
        int i8 = i6;
        long[] jArr2 = new long[24];
        for (SpotifriedStatsKt.spotifriedStats.Line line4 : arrayList2) {
            int i9 = line4.hour;
            jArr2[i9] = jArr2[i9] + ((long) line4.row.secondsHeard);
            localDate3 = localDate3;
        }
        LocalDate localDate7 = localDate3;
        ArrayList arrayList8 = new ArrayList();
        for (Object obj5 : arrayList7) {
            if (((SpotifriedStatsKt.spotifriedStats.Line) obj5).row.song != null) {
                arrayList8.add(obj5);
            }
        }
        LinkedHashMap linkedHashMap2 = new LinkedHashMap();
        for (Object obj6 : arrayList8) {
            SpotifriedStatsKt.spotifriedStats.Line line5 = (SpotifriedStatsKt.spotifriedStats.Line) obj6;
            Pair pair = new Pair(line5.row.songId, line5.date);
            Object arrayList9 = linkedHashMap2.get(pair);
            if (arrayList9 == null) {
                arrayList9 = new ArrayList();
                linkedHashMap2.put(pair, arrayList9);
            }
            ((List) arrayList9).add(obj6);
        }
        List list3 = (List) CollectionsKt.maxWithOrNull(linkedHashMap2.values(), new PlaylistOrder$arrange$.inlined.thenBy.1(new Backups$applyTheRest$.inlined.sortedBy.1((byte) 20), (byte) 5));
        if (list3 != null) {
            SongEntity songEntity3 = ((SpotifriedStatsKt.spotifriedStats.Line) CollectionsKt.last(list3)).row.song;
            songEntity3.getClass();
            LocalDate localDate8 = ((SpotifriedStatsKt.spotifriedStats.Line) CollectionsKt.first(list3)).date;
            int size = list3.size();
            ArrayList arrayList10 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(list3, 10));
            Iterator it4 = list3.iterator();
            while (it4.hasNext()) {
                arrayList10.add(Float.valueOf(((SpotifriedStatsKt.spotifriedStats.Line) it4.next()).hourF));
            }
            obsessionDay = new ObsessionDay(songEntity3, localDate8, size, arrayList10);
        } else {
            obsessionDay = null;
        }
        LinkedHashMap linkedHashMap3 = new LinkedHashMap();
        for (Object obj7 : arrayList8) {
            YearMonth yearMonthFrom = YearMonth.from(((SpotifriedStatsKt.spotifriedStats.Line) obj7).date);
            Object arrayList11 = linkedHashMap3.get(yearMonthFrom);
            if (arrayList11 == null) {
                arrayList11 = new ArrayList();
                linkedHashMap3.put(yearMonthFrom, arrayList11);
            }
            ((List) arrayList11).add(obj7);
        }
        TreeMap treeMap = new TreeMap(linkedHashMap3);
        LinkedHashMap linkedHashMap4 = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(treeMap.size()));
        for (Map.Entry entry : treeMap.entrySet()) {
            Object key = entry.getKey();
            List list4 = (List) entry.getValue();
            list4.getClass();
            LinkedHashMap linkedHashMap5 = new LinkedHashMap();
            for (Object obj8 : list4) {
                ObsessionDay obsessionDay2 = obsessionDay;
                String str2 = ((SpotifriedStatsKt.spotifriedStats.Line) obj8).row.songId;
                Object obj9 = linkedHashMap5.get(str2);
                ArrayList arrayList12 = arrayList;
                if (obj9 == null) {
                    ArrayList arrayList13 = new ArrayList();
                    linkedHashMap5.put(str2, arrayList13);
                    obj9 = arrayList13;
                }
                ((List) obj9).add(obj8);
                obsessionDay = obsessionDay2;
                arrayList = arrayList12;
            }
            linkedHashMap4.put(key, CollectionsKt.sortedWith(linkedHashMap5.values(), new PlaylistOrder$arrange$.inlined.thenBy.1(new Backups$applyTheRest$.inlined.sortedBy.1((byte) 21), (byte) 6)));
            obsessionDay = obsessionDay;
            arrayList = arrayList;
        }
        ObsessionDay obsessionDay3 = obsessionDay;
        ArrayList arrayList14 = arrayList;
        ArrayList arrayList15 = new ArrayList(linkedHashMap4.size());
        for (Map.Entry entry2 : linkedHashMap4.entrySet()) {
            YearMonth yearMonth = (YearMonth) entry2.getKey();
            List list5 = (List) entry2.getValue();
            yearMonth.getClass();
            SongEntity songEntity4 = ((SpotifriedStatsKt.spotifriedStats.Line) CollectionsKt.last((List) CollectionsKt.first(list5))).row.song;
            songEntity4.getClass();
            arrayList15.add(new MonthTop(yearMonth, songEntity4, ((List) CollectionsKt.first(list5)).size()));
        }
        LinkedHashMap linkedHashMap6 = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(linkedHashMap4.size()));
        for (Map.Entry entry3 : linkedHashMap4.entrySet()) {
            Object key2 = entry3.getKey();
            List listTake = CollectionsKt.take((List) entry3.getValue(), 5);
            ArrayList arrayList16 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(listTake, 10));
            Iterator it5 = listTake.iterator();
            while (it5.hasNext()) {
                arrayList16.add(((SpotifriedStatsKt.spotifriedStats.Line) CollectionsKt.first((List) it5.next())).row.songId);
            }
            linkedHashMap6.put(key2, CollectionsKt.toSet(arrayList16));
        }
        Set setKeySet = linkedHashMap6.keySet();
        setKeySet.getClass();
        Iterator it6 = setKeySet.iterator();
        if (it6.hasNext()) {
            EmptyList arrayList17 = new ArrayList();
            Object next5 = it6.next();
            while (it6.hasNext()) {
                Object next6 = it6.next();
                arrayList17.add(new Pair(next5, next6));
                next5 = next6;
            }
            emptyList = arrayList17;
        } else {
            emptyList = EmptyList.INSTANCE;
        }
        Iterator it7 = emptyList.iterator();
        if (it7.hasNext()) {
            next = it7.next();
            if (it7.hasNext()) {
                Pair pair2 = (Pair) next;
                int size2 = CollectionsKt.intersect((Iterable) MapsKt__MapsKt.getValue((YearMonth) pair2.first, linkedHashMap6), (Iterable) MapsKt__MapsKt.getValue((YearMonth) pair2.second, linkedHashMap6)).size();
                while (true) {
                    Object next7 = it7.next();
                    Pair pair3 = (Pair) next7;
                    int size3 = CollectionsKt.intersect((Iterable) MapsKt__MapsKt.getValue((YearMonth) pair3.first, linkedHashMap6), (Iterable) MapsKt__MapsKt.getValue((YearMonth) pair3.second, linkedHashMap6)).size();
                    if (size2 > size3) {
                        next = next7;
                        size2 = size3;
                    }
                    if (!it7.hasNext()) {
                        break;
                    }
                    topSong = topSong;
                }
            }
        } else {
            next = null;
        }
        Pair pair4 = (Pair) next;
        YearMonth yearMonth2 = pair4 != null ? (YearMonth) pair4.second : null;
        ArrayList arrayList18 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList2, 10));
        Iterator it8 = arrayList2.iterator();
        while (it8.hasNext()) {
            arrayList18.add(((SpotifriedStatsKt.spotifriedStats.Line) it8.next()).date);
        }
        Iterator it9 = CollectionsKt.sorted(CollectionsKt.distinct(arrayList18)).iterator();
        int i10 = 0;
        int iMax2 = 0;
        LocalDate localDate9 = null;
        while (it9.hasNext()) {
            LocalDate localDate10 = (LocalDate) it9.next();
            ArrayList arrayList19 = arrayList2;
            Iterator it10 = it9;
            i10 = Intrinsics.areEqual(localDate9 != null ? localDate9.plusDays(1L) : null, localDate10) ? i10 + 1 : i8;
            iMax2 = Math.max(iMax2, i10);
            localDate9 = localDate10;
            arrayList2 = arrayList19;
            it9 = it10;
        }
        ArrayList arrayList20 = arrayList2;
        ArrayList arrayList21 = new ArrayList();
        for (Object obj10 : arrayList14) {
            if (((SpotifriedStatsKt.spotifriedStats.Line) obj10).row.secondsHeard >= 30) {
                arrayList21.add(obj10);
            }
        }
        LinkedHashMap linkedHashMap7 = new LinkedHashMap();
        for (Object obj11 : arrayList21) {
            String str3 = ((SpotifriedStatsKt.spotifriedStats.Line) obj11).row.songId;
            Object arrayList22 = linkedHashMap7.get(str3);
            if (arrayList22 == null) {
                arrayList22 = new ArrayList();
                linkedHashMap7.put(str3, arrayList22);
            }
            ((List) arrayList22).add(obj11);
        }
        LinkedHashMap linkedHashMap8 = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(linkedHashMap7.size()));
        Iterator it11 = linkedHashMap7.entrySet().iterator();
        while (it11.hasNext()) {
            Map.Entry entry4 = (Map.Entry) it11.next();
            Object key3 = entry4.getKey();
            Iterator it12 = ((List) entry4.getValue()).iterator();
            if (!it12.hasNext()) {
                MediaSessionStub$.ExternalSyntheticLambda8.m$1();
                return null;
            }
            LocalDate localDate11 = ((SpotifriedStatsKt.spotifriedStats.Line) it12.next()).date;
            while (it12.hasNext()) {
                Iterator it13 = it11;
                LocalDate localDate12 = ((SpotifriedStatsKt.spotifriedStats.Line) it12.next()).date;
                if (localDate11.compareTo((Object) localDate12) > 0) {
                    localDate11 = localDate12;
                }
                it11 = it13;
            }
            linkedHashMap8.put(key3, localDate11);
        }
        ArrayList arrayList23 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList7, 10));
        Iterator it14 = arrayList7.iterator();
        while (it14.hasNext()) {
            arrayList23.add(((SpotifriedStatsKt.spotifriedStats.Line) it14.next()).row.songId);
        }
        List listDistinct = CollectionsKt.distinct(arrayList23);
        if (listDistinct.isEmpty()) {
            i = 0;
        } else {
            Iterator it15 = listDistinct.iterator();
            i = 0;
            while (it15.hasNext()) {
                Object obj12 = linkedHashMap8.get((String) it15.next());
                obj12.getClass();
                if (((LocalDate) obj12).compareTo((ChronoLocalDate) localDate4) >= 0 && (i = i + 1) < 0) {
                    ByteStreamsKt.throwCountOverflow();
                    throw null;
                }
            }
        }
        LinkedHashMap linkedHashMap9 = new LinkedHashMap();
        Iterator it16 = arrayList7.iterator();
        while (it16.hasNext()) {
            Object next8 = it16.next();
            String str4 = ((SpotifriedStatsKt.spotifriedStats.Line) next8).row.songId;
            Object obj13 = linkedHashMap9.get(str4);
            Iterator it17 = it16;
            if (obj13 == null) {
                ArrayList arrayList24 = new ArrayList();
                linkedHashMap9.put(str4, arrayList24);
                obj13 = arrayList24;
            }
            ((List) obj13).add(next8);
            it16 = it17;
        }
        if (linkedHashMap9.isEmpty()) {
            i2 = 0;
        } else {
            Iterator it18 = linkedHashMap9.entrySet().iterator();
            i2 = 0;
            while (it18.hasNext()) {
                if (((List) ((Map.Entry) it18.next()).getValue()).size() >= 2) {
                    i2++;
                }
            }
        }
        char c = 2;
        int i11 = i;
        long j2 = 0;
        for (Iterator it19 = arrayList20.iterator(); it19.hasNext(); it19 = it19) {
            j2 += (long) ((SpotifriedStatsKt.spotifriedStats.Line) it19.next()).row.secondsHeard;
            i2 = i2;
            c = c;
        }
        int i12 = i2;
        ArrayList arrayList25 = new ArrayList();
        Iterator it20 = arrayList20.iterator();
        while (it20.hasNext()) {
            Object next9 = it20.next();
            Iterator it21 = it20;
            if (((SpotifriedStatsKt.spotifriedStats.Line) next9).row.song != null) {
                arrayList25.add(next9);
            }
            it20 = it21;
        }
        LinkedHashMap linkedHashMap10 = new LinkedHashMap();
        Iterator it22 = arrayList25.iterator();
        while (it22.hasNext()) {
            Object next10 = it22.next();
            Iterator it23 = it22;
            SongEntity songEntity5 = ((SpotifriedStatsKt.spotifriedStats.Line) next10).row.song;
            songEntity5.getClass();
            String strCleanArtist = Log.cleanArtist(songEntity5.artist);
            Object obj14 = linkedHashMap10.get(strCleanArtist);
            int i13 = iMax;
            if (obj14 == null) {
                ArrayList arrayList26 = new ArrayList();
                linkedHashMap10.put(strCleanArtist, arrayList26);
                obj14 = arrayList26;
            }
            ((List) obj14).add(next10);
            it22 = it23;
            iMax = i13;
        }
        int i14 = iMax;
        LinkedHashMap linkedHashMap11 = new LinkedHashMap(MapsKt__MapsKt.mapCapacity(linkedHashMap10.size()));
        Iterator it24 = linkedHashMap10.entrySet().iterator();
        while (it24.hasNext()) {
            Map.Entry entry5 = (Map.Entry) it24.next();
            Object key4 = entry5.getKey();
            long j3 = 0;
            for (Iterator it25 = ((List) entry5.getValue()).iterator(); it25.hasNext(); it25 = it25) {
                j3 += (long) ((SpotifriedStatsKt.spotifriedStats.Line) it25.next()).row.secondsHeard;
                topSong = topSong;
                it24 = it24;
            }
            linkedHashMap11.put(key4, Long.valueOf(j3));
            it24 = it24;
        }
        TopSong topSong2 = topSong;
        Iterator it26 = linkedHashMap11.entrySet().iterator();
        if (it26.hasNext()) {
            next2 = it26.next();
            if (it26.hasNext()) {
                long jLongValue = ((Number) ((Map.Entry) next2).getValue()).longValue();
                while (true) {
                    Object next11 = it26.next();
                    long jLongValue2 = ((Number) ((Map.Entry) next11).getValue()).longValue();
                    if (jLongValue < jLongValue2) {
                        next2 = next11;
                        jLongValue = jLongValue2;
                    }
                    if (!it26.hasNext()) {
                        break;
                    }
                    yearMonth2 = yearMonth2;
                    iMax2 = iMax2;
                    i12 = i12;
                }
            }
        } else {
            next2 = null;
        }
        Map.Entry entry6 = (Map.Entry) next2;
        if (entry6 == null) {
            artistShare = null;
        } else {
            if (j2 <= 0) {
                entry6 = null;
            }
            if (entry6 != null) {
                artistShare = new ArtistShare((String) entry6.getKey(), ((Number) entry6.getValue()).longValue() / j2);
            } else {
                artistShare = null;
            }
        }
        ArrayList arrayList27 = new ArrayList();
        for (Object obj15 : arrayList7) {
            if (((SpotifriedStatsKt.spotifriedStats.Line) obj15).row.song != null) {
                arrayList27.add(obj15);
            }
        }
        ArrayList arrayList28 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList27, 10));
        Iterator it27 = arrayList27.iterator();
        while (it27.hasNext()) {
            arrayList28.add(((SpotifriedStatsKt.spotifriedStats.Line) it27.next()).row.songId);
        }
        List listDistinct2 = CollectionsKt.distinct(arrayList28);
        ArrayList arrayList29 = new ArrayList();
        for (Object obj16 : listDistinct2) {
            if (map.containsKey((String) obj16)) {
                arrayList29.add(obj16);
            }
        }
        ArrayList arrayList30 = new ArrayList(CollectionsKt__IterablesKt.collectionSizeOrDefault(arrayList29, 10));
        Iterator it28 = arrayList29.iterator();
        while (it28.hasNext()) {
            arrayList30.add(Integer.valueOf(((Number) MapsKt__MapsKt.getValue((String) it28.next(), map)).intValue()));
        }
        Iterator it29 = arrayList29.iterator();
        if (it29.hasNext()) {
            next3 = it29.next();
            if (it29.hasNext()) {
                int iIntValue = ((Number) MapsKt__MapsKt.getValue((String) next3, map)).intValue();
                while (true) {
                    Object next12 = it29.next();
                    int iIntValue2 = ((Number) MapsKt__MapsKt.getValue((String) next12, map)).intValue();
                    if (iIntValue > iIntValue2) {
                        next3 = next12;
                        iIntValue = iIntValue2;
                    }
                    if (!it29.hasNext()) {
                        break;
                    }
                    yearMonth2 = yearMonth2;
                    iMax2 = iMax2;
                    i12 = i12;
                }
            }
        } else {
            next3 = null;
        }
        String str5 = (String) next3;
        int i15 = arrayList30.size() >= 20 ? i8 : 0;
        int size4 = arrayList30.size();
        int size5 = listDistinct2.size();
        if (listDistinct2.isEmpty()) {
            i3 = 0;
        } else {
            Iterator it30 = listDistinct2.iterator();
            int i16 = 0;
            while (it30.hasNext()) {
                if (!set.contains((String) it30.next()) && (i16 = i16 + 1) < 0) {
                    ByteStreamsKt.throwCountOverflow();
                    throw null;
                }
            }
            i3 = i16;
        }
        List listSorted = CollectionsKt.sorted(arrayList30);
        if (i15 != 0) {
            numValueOf = Integer.valueOf(((Number) CollectionsKt.sorted(arrayList30).get((arrayList30.size() - 1) / 2)).intValue());
            numValueOf2 = Integer.valueOf((localDate7.getYear() - ((Number) CollectionsKt.sorted(arrayList30).get((arrayList30.size() - 1) / 2)).intValue()) + 14);
        } else {
            numValueOf = null;
            numValueOf2 = null;
        }
        Integer numValueOf3 = str5 != null ? Integer.valueOf(((Number) MapsKt__MapsKt.getValue(str5, map)).intValue()) : null;
        if (str5 != null) {
            ListIterator listIterator = arrayList7.listIterator(arrayList7.size());
            do {
                if (!listIterator.hasPrevious()) {
                    MediaSessionStub$.ExternalSyntheticLambda8.m("List contains no element matching the predicate.");
                    return null;
                }
                line = (SpotifriedStatsKt.spotifriedStats.Line) listIterator.previous();
            } while (!Intrinsics.areEqual(line.row.songId, str5));
            songEntity = line.row.song;
        } else {
            songEntity = null;
        }
        AgeStats ageStats = new AgeStats(size4, size5, i3, listSorted, numValueOf, numValueOf2, numValueOf3, songEntity);
        int size6 = arrayList7.size();
        Iterator it31 = arrayList20.iterator();
        long j4 = 0;
        while (it31.hasNext()) {
            j4 += (long) ((SpotifriedStatsKt.spotifriedStats.Line) it31.next()).row.secondsHeard;
        }
        HashSet hashSet = new HashSet();
        ArrayList arrayList31 = new ArrayList();
        for (Object obj17 : arrayList7) {
            if (hashSet.add(((SpotifriedStatsKt.spotifriedStats.Line) obj17).row.songId)) {
                arrayList31.add(obj17);
            }
        }
        int size7 = arrayList31.size();
        List list6 = ArraysKt.toList(jArr);
        IntIterator it32 = new IntRange(0, i14 - 1, i8).iterator();
        IntProgressionIterator intProgressionIterator = (IntProgressionIterator) it32;
        if (intProgressionIterator.hasNext) {
            IntIterator intIterator = it32;
            next4 = intIterator.next();
            if (intProgressionIterator.hasNext) {
                long j5 = jArr[((Number) next4).intValue()];
                while (true) {
                    Object next13 = intIterator.next();
                    long j6 = jArr[((Number) next13).intValue()];
                    if (j5 < j6) {
                        next4 = next13;
                        j5 = j6;
                    }
                    if (!intProgressionIterator.hasNext) {
                        break;
                    }
                    size6 = size6;
                    artistShare = artistShare;
                    arrayList15 = arrayList15;
                    yearMonth2 = yearMonth2;
                    iMax2 = iMax2;
                    i12 = i12;
                }
            }
        } else {
            next4 = null;
        }
        Integer num = (Integer) next4;
        if (num == null) {
            localDatePlusDays = null;
        } else {
            if (jArr[num.intValue()] <= 0) {
                num = null;
            }
            if (num != null) {
                localDatePlusDays = localDate.plusDays(num.intValue());
            } else {
                localDatePlusDays = null;
            }
        }
        List list7 = ArraysKt.toList(jArr2);
        if (arrayList7.isEmpty()) {
            i4 = 0;
        } else {
            Iterator it33 = arrayList7.iterator();
            i4 = 0;
            while (it33.hasNext()) {
                if (((SpotifriedStatsKt.spotifriedStats.Line) it33.next()).hour < 9 && (i4 = i4 + 1) < 0) {
                    ByteStreamsKt.throwCountOverflow();
                    throw null;
                }
            }
        }
        float size8 = arrayList7.isEmpty() ? 0.0f : i4 / arrayList7.size();
        if (arrayList7.isEmpty()) {
            i5 = 0;
        } else {
            Iterator it34 = arrayList7.iterator();
            int i17 = 0;
            while (it34.hasNext()) {
                if (((SpotifriedStatsKt.spotifriedStats.Line) it34.next()).hour < 5 && (i17 = i17 + 1) < 0) {
                    ByteStreamsKt.throwCountOverflow();
                    throw null;
                }
            }
            i5 = i17;
        }
        float size9 = arrayList7.isEmpty() ? 0.0f : i5 / arrayList7.size();
        Iterator it35 = arrayList14.iterator();
        if (it35.hasNext()) {
            LocalDate localDate13 = ((SpotifriedStatsKt.spotifriedStats.Line) it35.next()).date;
            while (it35.hasNext()) {
                LocalDate localDate14 = ((SpotifriedStatsKt.spotifriedStats.Line) it35.next()).date;
                if (localDate13.compareTo((Object) localDate14) > 0) {
                    localDate13 = localDate14;
                }
            }
            localDate2 = localDate13;
        } else {
            localDate2 = null;
        }
        return new SpotifriedStats(wrappedPeriod, localDate, size6, j4, size7, topSong2, list6, localDatePlusDays, list7, obsessionDay3, arrayList15, yearMonth2, iMax2, i11, i12, artistShare, size8, size9, ageStats, localDate2);
    }
}
