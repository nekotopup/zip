package com.spotifry.music.ui.spotifried;

import androidx.compose.runtime.AnchoredGroupPath;
import androidx.compose.runtime.ComposerImpl;
import com.spotifry.music.data.spotifried.SpotifriedStats;
import kotlin.Unit;
import kotlin.jvm.functions.Function2;
import kotlin.text.RegexKt;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda0 implements Function2 {
    public final /* synthetic */ byte $r8$classId;
    public final /* synthetic */ Object f$0;
    public final /* synthetic */ boolean f$1;
    public final /* synthetic */ int f$2;

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda0(boolean z, Function2 function2, int i) {
        this.$r8$classId = (byte) 13;
        this.f$1 = z;
        this.f$0 = function2;
        this.f$2 = i;
    }

    public final Object invoke(Object obj, Object obj2) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        int i = this.f$2;
        Object obj3 = this.f$0;
        boolean z = this.f$1;
        switch (b) {
            case 0:
                ((Integer) obj2).getClass();
                CardsKt.TopSongCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 1:
                ((Integer) obj2).getClass();
                CardsKt.MonthsCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 2:
                ((Integer) obj2).getClass();
                CardsKt.SunPortrait((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 3:
                ((Integer) obj2).getClass();
                CardsKt.Hours((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 4:
                ((Integer) obj2).getClass();
                CardsKt.TopSongCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 5:
                ((Integer) obj2).getClass();
                CardsKt.Intro((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 6:
                ((Integer) obj2).getClass();
                CardsKt.Months((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 7:
                ((Integer) obj2).getClass();
                CardsKt.IntroCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 8:
                ((Integer) obj2).getClass();
                CardsKt.SunCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 9:
                ((Integer) obj2).getClass();
                CardsKt.DayCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 10:
                ((Integer) obj2).getClass();
                CardsKt.DayCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 11:
                ((Integer) obj2).getClass();
                CardsKt.HoursCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            case 12:
                ((Integer) obj2).getClass();
                CardsKt.MonthsCard((SpotifriedStats) obj3, z, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
            default:
                ((Integer) obj2).getClass();
                RegexKt.PredictiveBackHandler(z, (Function2) obj3, (ComposerImpl) obj, AnchoredGroupPath.updateChangedFlags(i | 1));
                break;
        }
        return unit;
    }

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda0(SpotifriedStats spotifriedStats, boolean z, int i, byte b) {
        this.$r8$classId = b;
        this.f$0 = spotifriedStats;
        this.f$1 = z;
        this.f$2 = i;
    }
}
