package com.spotifry.music.ui.spotifried;

import androidx.compose.animation.core.Animatable;
import androidx.compose.ui.graphics.ReusableGraphicsLayerScope;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda37 implements Function1 {
    public final /* synthetic */ byte $r8$classId;
    public final /* synthetic */ Animatable f$0;
    public final /* synthetic */ float f$1;

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda37(Animatable animatable, float f, byte b) {
        this.$r8$classId = b;
        this.f$0 = animatable;
        this.f$1 = f;
    }

    public final Object invoke(Object obj) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        float f = this.f$1;
        Animatable animatable = this.f$0;
        ReusableGraphicsLayerScope reusableGraphicsLayerScope = (ReusableGraphicsLayerScope) obj;
        reusableGraphicsLayerScope.getClass();
        switch (b) {
            case 0:
                reusableGraphicsLayerScope.setAlpha(((Number) animatable.getValue()).floatValue());
                reusableGraphicsLayerScope.setTranslationY((1.0f - ((Number) animatable.getValue()).floatValue()) * f);
                break;
            case 1:
                reusableGraphicsLayerScope.setTranslationY((1.0f - ((Number) animatable.getValue()).floatValue()) * f);
                reusableGraphicsLayerScope.setAlpha(((Number) animatable.getValue()).floatValue());
                break;
            case 2:
                reusableGraphicsLayerScope.setAlpha(((Number) animatable.getValue()).floatValue());
                reusableGraphicsLayerScope.setTranslationX((1.0f - ((Number) animatable.getValue()).floatValue()) * (-f));
                break;
            case 3:
                reusableGraphicsLayerScope.setAlpha(((Number) animatable.getValue()).floatValue());
                reusableGraphicsLayerScope.setTranslationY((1.0f - ((Number) animatable.getValue()).floatValue()) * f);
                break;
            default:
                float fStepAt = CardsKt.stepAt(((Number) animatable.getValue()).floatValue(), 2800.0f, 600.0f);
                reusableGraphicsLayerScope.setAlpha(fStepAt);
                reusableGraphicsLayerScope.setTranslationY((1.0f - fStepAt) * f);
                break;
        }
        return unit;
    }
}
