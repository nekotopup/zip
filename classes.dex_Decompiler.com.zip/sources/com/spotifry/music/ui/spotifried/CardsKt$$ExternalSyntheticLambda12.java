package com.spotifry.music.ui.spotifried;

import androidx.compose.runtime.ParcelableSnapshotMutableFloatState;
import androidx.compose.ui.graphics.ReusableGraphicsLayerScope;
import androidx.compose.ui.layout.LayoutCoordinates;
import androidx.compose.ui.layout.RulerKt;
import com.spotifry.music.ui.listening.SpotifriedGateKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;

/* JADX INFO: compiled from: r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28 */
/* JADX INFO: loaded from: /tmp/decompiler/2195fa968c9e4aafb3ea7e5c2e163024/classes.dex */
public final /* synthetic */ class CardsKt$$ExternalSyntheticLambda12 implements Function1 {
    public final /* synthetic */ byte $r8$classId;
    public final /* synthetic */ ParcelableSnapshotMutableFloatState f$0;

    public /* synthetic */ CardsKt$$ExternalSyntheticLambda12(ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState, byte b) {
        this.$r8$classId = b;
        this.f$0 = parcelableSnapshotMutableFloatState;
    }

    public final Object invoke(Object obj) {
        byte b = this.$r8$classId;
        Unit unit = Unit.INSTANCE;
        ParcelableSnapshotMutableFloatState parcelableSnapshotMutableFloatState = this.f$0;
        switch (b) {
            case 0:
                LayoutCoordinates layoutCoordinates = (LayoutCoordinates) obj;
                layoutCoordinates.getClass();
                parcelableSnapshotMutableFloatState.setFloatValue(RulerKt.findRootCoordinates(layoutCoordinates).localBoundingBoxOf(layoutCoordinates, true).top);
                break;
            case 1:
                ReusableGraphicsLayerScope reusableGraphicsLayerScope = (ReusableGraphicsLayerScope) obj;
                reusableGraphicsLayerScope.getClass();
                reusableGraphicsLayerScope.setRotationZ(parcelableSnapshotMutableFloatState.getFloatValue());
                reusableGraphicsLayerScope.setTransformOrigin-__ExYCQ(SpotifriedGateKt.discOrigin-uvyYCjk(reusableGraphicsLayerScope.size));
                break;
            default:
                LayoutCoordinates layoutCoordinates2 = (LayoutCoordinates) obj;
                layoutCoordinates2.getClass();
                parcelableSnapshotMutableFloatState.setFloatValue(RulerKt.findRootCoordinates(layoutCoordinates2).localBoundingBoxOf(layoutCoordinates2, true).bottom);
                break;
        }
        return unit;
    }
}
