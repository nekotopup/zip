###### Class com.spotifry.music.ui.spotifried.CardsKt (com.spotifry.music.ui.spotifried.CardsKt)
.class public abstract Lcom/spotifry/music/ui/spotifried/CardsKt;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"


# static fields
.field public static final Ease:Landroidx/compose/animation/core/CubicBezierEasing;

.field public static final Headline:Landroidx/compose/ui/text/TextStyle;

.field public static final RISE:F

.field public static final Sub:Landroidx/compose/ui/text/TextStyle;

.field public static final WIDE_BAR:F

.field public static final english:Ljava/util/Locale;


# direct methods
.method static constructor <clinit>()V
    .registers 18

    .line 1
    new-instance v0, Landroidx/compose/animation/core/CubicBezierEasing;

    .line 3
    const/high16 v1, 0x3f800000    # 1.0f

    .line 5
    const v2, 0x3e99999a    # 0.3f

    .line 8
    const v3, 0x3e23d70a    # 0.16f

    .line 11
    invoke-direct {v0, v3, v1, v2, v1}, Landroidx/compose/animation/core/CubicBezierEasing;-><init>(FFFF)V

    .line 14
    sput-object v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->Ease:Landroidx/compose/animation/core/CubicBezierEasing;

    .line 16
    sget-object v10, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 18
    sget-object v9, Landroidx/compose/ui/text/font/FontWeight;->Black:Landroidx/compose/ui/text/font/FontWeight;

    .line 20
    const/16 v0, 0x2e

    .line 22
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 25
    move-result-wide v7

    .line 26
    const/16 v0, 0x2d

    .line 28
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 31
    move-result-wide v14

    .line 32
    const-wide v0, -0x4006666666666666L    # -1.6

    .line 37
    invoke-static {v0, v1}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 40
    move-result-wide v11

    .line 41
    new-instance v4, Landroidx/compose/ui/text/TextStyle;

    .line 43
    const/16 v16, 0x0

    .line 45
    const v17, 0xfdff59

    .line 48
    const-wide/16 v5, 0x0

    .line 50
    const/4 v13, 0x0

    .line 51
    invoke-direct/range {v4 .. v17}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 54
    sput-object v4, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 56
    const/16 v0, 0xf

    .line 58
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 61
    move-result-wide v7

    .line 62
    const/16 v0, 0x16

    .line 64
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 67
    move-result-wide v14

    .line 68
    new-instance v4, Landroidx/compose/ui/text/TextStyle;

    .line 70
    const v17, 0xfdffdd

    .line 73
    const/4 v9, 0x0

    .line 74
    const-wide/16 v11, 0x0

    .line 76
    invoke-direct/range {v4 .. v17}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 79
    sput-object v4, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 81
    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 83
    sput-object v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 85
    const/high16 v0, 0x41600000    # 14.0f

    .line 87
    sput v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->WIDE_BAR:F

    .line 89
    const/high16 v0, 0x41900000    # 18.0f

    .line 91
    sput v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->RISE:F

    .line 93
    return-void
.end method

.method public static final Age(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 31

    .line 1
    move-object/from16 v1, p0

    .line 3
    move/from16 v4, p3

    .line 5
    move-object/from16 v8, p4

    .line 7
    move/from16 v0, p5

    .line 9
    const v2, 0x43ca2b59

    .line 12
    invoke-virtual {v8, v2}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 15
    and-int/lit8 v2, v0, 0x6

    .line 17
    if-nez v2, :cond_1d

    .line 19
    invoke-virtual {v8, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_1a

    .line 25
    const/4 v2, 0x4

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v2, 0x2

    .line 28
    :goto_1b
    or-int/2addr v2, v0

    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move v2, v0

    .line 31
    :goto_1e
    and-int/lit8 v3, v0, 0x30

    .line 33
    move/from16 v14, p1

    .line 35
    if-nez v3, :cond_30

    .line 37
    invoke-virtual {v8, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 40
    move-result v3

    .line 41
    if-eqz v3, :cond_2d

    .line 43
    const/16 v3, 0x20

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    const/16 v3, 0x10

    .line 48
    :goto_2f
    or-int/2addr v2, v3

    .line 49
    :cond_30
    and-int/lit16 v3, v0, 0x180

    .line 51
    move/from16 v15, p2

    .line 53
    if-nez v3, :cond_42

    .line 55
    invoke-virtual {v8, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 58
    move-result v3

    .line 59
    if-eqz v3, :cond_3f

    .line 61
    const/16 v3, 0x100

    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    const/16 v3, 0x80

    .line 66
    :goto_41
    or-int/2addr v2, v3

    .line 67
    :cond_42
    and-int/lit16 v3, v0, 0xc00

    .line 69
    if-nez v3, :cond_52

    .line 71
    invoke-virtual {v8, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 74
    move-result v3

    .line 75
    if-eqz v3, :cond_4f

    .line 77
    const/16 v3, 0x800

    .line 79
    goto :goto_51

    .line 80
    :cond_4f
    const/16 v3, 0x400

    .line 82
    :goto_51
    or-int/2addr v2, v3

    .line 83
    :cond_52
    and-int/lit16 v3, v2, 0x493

    .line 85
    const/16 v5, 0x492

    .line 87
    if-eq v3, v5, :cond_5a

    .line 89
    const/4 v3, 0x1

    .line 90
    goto :goto_5b

    .line 91
    :cond_5a
    const/4 v3, 0x0

    .line 92
    :goto_5b
    and-int/lit8 v5, v2, 0x1

    .line 94
    invoke-virtual {v8, v5, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 97
    move-result v3

    .line 98
    if-eqz v3, :cond_1c6

    .line 100
    sget-object v3, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 102
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 105
    move-result-object v5

    .line 106
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 108
    iget-wide v9, v5, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 110
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 113
    move-result-object v3

    .line 114
    check-cast v3, Landroidx/compose/material3/ColorScheme;

    .line 116
    iget-wide v11, v3, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 118
    const v3, 0x3e0f5c29    # 0.14f

    .line 121
    invoke-static {v3, v11, v12}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 124
    move-result-wide v16

    .line 125
    move-wide/from16 v23, v11

    .line 127
    iget-object v12, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->age:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 129
    iget-object v3, v12, Lcom/spotifry/music/data/spotifried/AgeStats;->typicalYear:Ljava/lang/Integer;

    .line 131
    iget-object v5, v12, Lcom/spotifry/music/data/spotifried/AgeStats;->years:Ljava/util/List;

    .line 133
    iget-object v7, v12, Lcom/spotifry/music/data/spotifried/AgeStats;->age:Ljava/lang/Integer;

    .line 135
    if-nez v7, :cond_89

    .line 137
    const/4 v3, 0x0

    .line 138
    :cond_89
    invoke-virtual {v8, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 141
    move-result v7

    .line 142
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 145
    move-result-object v11

    .line 146
    if-nez v7, :cond_9d

    .line 148
    sget-object v7, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 150
    if-eq v11, v7, :cond_9d

    .line 152
    move/from16 v19, v2

    .line 154
    move-object/from16 v21, v3

    .line 156
    goto/16 :goto_14b

    .line 158
    :cond_9d
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    .line 161
    move-result-object v7

    .line 162
    new-instance v11, Ljava/util/LinkedHashMap;

    .line 164
    invoke-direct {v11}, Ljava/util/LinkedHashMap;-><init>()V

    .line 167
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 170
    move-result-object v7

    .line 171
    :goto_aa
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 174
    move-result v18

    .line 175
    if-eqz v18, :cond_d8

    .line 177
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 180
    move-result-object v6

    .line 181
    move-object/from16 v19, v6

    .line 183
    check-cast v19, Ljava/lang/Number;

    .line 185
    invoke-virtual/range {v19 .. v19}, Ljava/lang/Number;->intValue()I

    .line 188
    move-result v19

    .line 189
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 192
    move-result-object v13

    .line 193
    invoke-virtual {v11, v13}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    move-result-object v19

    .line 197
    if-nez v19, :cond_d0

    .line 199
    new-instance v0, Ljava/util/ArrayList;

    .line 201
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 204
    invoke-interface {v11, v13, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 207
    move-object/from16 v19, v0

    .line 209
    :cond_d0
    move-object/from16 v0, v19

    .line 211
    check-cast v0, Ljava/util/List;

    .line 213
    invoke-interface {v0, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 216
    goto :goto_aa

    .line 217
    :cond_d8
    new-instance v0, Ljava/util/ArrayList;

    .line 219
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 222
    invoke-virtual {v11}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 225
    move-result-object v6

    .line 226
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 229
    move-result-object v6

    .line 230
    :goto_e5
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 233
    move-result v7

    .line 234
    if-eqz v7, :cond_143

    .line 236
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 239
    move-result-object v7

    .line 240
    check-cast v7, Ljava/util/Map$Entry;

    .line 242
    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 245
    move-result-object v11

    .line 246
    check-cast v11, Ljava/lang/Number;

    .line 248
    invoke-virtual {v11}, Ljava/lang/Number;->intValue()I

    .line 251
    move-result v11

    .line 252
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 255
    move-result-object v7

    .line 256
    check-cast v7, Ljava/util/List;

    .line 258
    invoke-static {v7}, Lkotlin/io/ByteStreamsKt;->getIndices(Ljava/util/Collection;)Lkotlin/ranges/IntRange;

    .line 261
    move-result-object v7

    .line 262
    new-instance v13, Ljava/util/ArrayList;

    .line 264
    move/from16 v19, v2

    .line 266
    move-object/from16 v21, v3

    .line 268
    const/16 v2, 0xa

    .line 270
    invoke-static {v7, v2}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 273
    move-result v3

    .line 274
    invoke-direct {v13, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 277
    invoke-virtual {v7}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 280
    move-result-object v2

    .line 281
    :goto_118
    move-object v3, v2

    .line 282
    check-cast v3, Lkotlin/ranges/IntProgressionIterator;

    .line 284
    iget-boolean v3, v3, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 286
    if-eqz v3, :cond_13b

    .line 288
    move-object v3, v2

    .line 289
    check-cast v3, Lkotlin/collections/IntIterator;

    .line 291
    invoke-virtual {v3}, Lkotlin/collections/IntIterator;->nextInt()I

    .line 294
    move-result v3

    .line 295
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 298
    move-result-object v7

    .line 299
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 302
    move-result-object v3

    .line 303
    move-object/from16 v22, v2

    .line 305
    new-instance v2, Lkotlin/Pair;

    .line 307
    invoke-direct {v2, v7, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 310
    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 313
    move-object/from16 v2, v22

    .line 315
    goto :goto_118

    .line 316
    :cond_13b
    invoke-static {v13, v0}, Lkotlin/collections/CollectionsKt__MutableCollectionsKt;->addAll$1(Ljava/lang/Iterable;Ljava/util/Collection;)V

    .line 319
    move/from16 v2, v19

    .line 321
    move-object/from16 v3, v21

    .line 323
    goto :goto_e5

    .line 324
    :cond_143
    move/from16 v19, v2

    .line 326
    move-object/from16 v21, v3

    .line 328
    invoke-virtual {v8, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 331
    move-object v11, v0

    .line 332
    :goto_14b
    check-cast v11, Ljava/util/List;

    .line 334
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->minOrNull(Ljava/lang/Iterable;)Ljava/lang/Comparable;

    .line 337
    move-result-object v0

    .line 338
    check-cast v0, Ljava/lang/Integer;

    .line 340
    const/16 v2, 0x7a8

    .line 342
    if-eqz v0, :cond_15e

    .line 344
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 347
    move-result v0

    .line 348
    :goto_15b
    const/16 v20, 0xa

    .line 350
    goto :goto_160

    .line 351
    :cond_15e
    move v0, v2

    .line 352
    goto :goto_15b

    .line 353
    :goto_160
    div-int/lit8 v0, v0, 0xa

    .line 355
    mul-int/lit8 v0, v0, 0xa

    .line 357
    invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I

    .line 360
    move-result v0

    .line 361
    iget-object v2, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 363
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->to:Ljava/time/LocalDate;

    .line 365
    invoke-virtual {v2}, Ljava/time/LocalDate;->getYear()I

    .line 368
    move-result v2

    .line 369
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->maxOrNull(Ljava/lang/Iterable;)Ljava/lang/Comparable;

    .line 372
    move-result-object v3

    .line 373
    check-cast v3, Ljava/lang/Integer;

    .line 375
    if-eqz v3, :cond_17d

    .line 377
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 380
    move-result v6

    .line 381
    goto :goto_17e

    .line 382
    :cond_17d
    const/4 v6, 0x0

    .line 383
    :goto_17e
    add-int/lit8 v3, v0, 0x14

    .line 385
    invoke-static {v6, v3}, Ljava/lang/Math;->max(II)I

    .line 388
    move-result v3

    .line 389
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 392
    move-result v22

    .line 393
    shr-int/lit8 v2, v19, 0x9

    .line 395
    and-int/lit8 v2, v2, 0xe

    .line 397
    or-int/lit8 v2, v2, 0x30

    .line 399
    const v3, 0x458fc000    # 4600.0f

    .line 402
    invoke-static {v4, v3, v8, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->clock(ZFLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/Animatable;

    .line 405
    move-result-object v13

    .line 406
    sget-object v2, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 408
    invoke-virtual {v8, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 411
    move-result-object v2

    .line 412
    check-cast v2, Landroidx/compose/ui/unit/Density;

    .line 414
    invoke-interface {v2}, Landroidx/compose/ui/unit/Density;->getFontScale()F

    .line 417
    move-result v2

    .line 418
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 420
    const/high16 v5, 0x3f800000    # 1.0f

    .line 422
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 425
    move-result-object v5

    .line 426
    move-wide/from16 v18, v9

    .line 428
    new-instance v9, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;

    .line 430
    move-object/from16 v20, v11

    .line 432
    move-object/from16 v10, v21

    .line 434
    move/from16 v21, v0

    .line 436
    move v11, v2

    .line 437
    invoke-direct/range {v9 .. v24}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;-><init>(Ljava/lang/Integer;FLcom/spotifry/music/data/spotifried/AgeStats;Landroidx/compose/animation/core/Animatable;IIJJLjava/util/List;IIJ)V

    .line 440
    const v0, -0x68baddd1

    .line 443
    invoke-static {v0, v9, v8}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 446
    move-result-object v7

    .line 447
    const/16 v9, 0xc06

    .line 449
    const/4 v10, 0x6

    .line 450
    const/4 v6, 0x0

    .line 451
    invoke-static/range {v5 .. v10}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 454
    goto :goto_1c9

    .line 455
    :cond_1c6
    invoke-virtual/range {p4 .. p4}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 458
    :goto_1c9
    invoke-virtual/range {p4 .. p4}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 461
    move-result-object v7

    .line 462
    if-eqz v7, :cond_1dd

    .line 464
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;

    .line 466
    const/4 v6, 0x1

    .line 467
    move/from16 v2, p1

    .line 469
    move/from16 v3, p2

    .line 471
    move/from16 v5, p5

    .line 473
    invoke-direct/range {v0 .. v6}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZIB)V

    .line 476
    iput-object v0, v7, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 478
    :cond_1dd
    return-void
.end method

.method public static final Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F
    .registers 5

    .line 1
    invoke-virtual {p0}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 4
    move-result p0

    .line 5
    const/high16 v0, 0x41000000    # 8.0f

    .line 7
    sub-float/2addr p0, v0

    .line 8
    sub-int/2addr p3, p1

    .line 9
    int-to-float p3, p3

    .line 10
    sub-int/2addr p2, p1

    .line 11
    int-to-float p1, p2

    .line 12
    div-float/2addr p3, p1

    .line 13
    mul-float/2addr p3, p0

    .line 14
    const/high16 p0, 0x40800000    # 4.0f

    .line 16
    add-float/2addr p3, p0

    .line 17
    return p3
.end method

.method public static final AgeCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 14

    .line 1
    const v0, 0x71655a09

    .line 4
    invoke-virtual {p4, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p5, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p4, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p5

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p5

    .line 23
    :goto_16
    and-int/lit8 v1, p5, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p4, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit16 v1, p5, 0x180

    .line 41
    if-nez v1, :cond_36

    .line 43
    invoke-virtual {p4, p2}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 46
    move-result v1

    .line 47
    if-eqz v1, :cond_33

    .line 49
    const/16 v1, 0x100

    .line 51
    goto :goto_35

    .line 52
    :cond_33
    const/16 v1, 0x80

    .line 54
    :goto_35
    or-int/2addr v0, v1

    .line 55
    :cond_36
    and-int/lit16 v1, p5, 0xc00

    .line 57
    if-nez v1, :cond_46

    .line 59
    invoke-virtual {p4, p3}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 62
    move-result v1

    .line 63
    if-eqz v1, :cond_43

    .line 65
    const/16 v1, 0x800

    .line 67
    goto :goto_45

    .line 68
    :cond_43
    const/16 v1, 0x400

    .line 70
    :goto_45
    or-int/2addr v0, v1

    .line 71
    :cond_46
    and-int/lit16 v1, v0, 0x493

    .line 73
    const/16 v2, 0x492

    .line 75
    const/4 v3, 0x1

    .line 76
    const/4 v7, 0x0

    .line 77
    if-eq v1, v2, :cond_50

    .line 79
    move v1, v3

    .line 80
    goto :goto_51

    .line 81
    :cond_50
    move v1, v7

    .line 82
    :goto_51
    and-int/lit8 v2, v0, 0x1

    .line 84
    invoke-virtual {p4, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 87
    move-result v1

    .line 88
    if-eqz v1, :cond_a0

    .line 90
    if-eqz p3, :cond_66

    .line 92
    const v1, 0x16a6341

    .line 95
    invoke-virtual {p4, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 98
    invoke-virtual {p4, v7}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 101
    move v1, v3

    .line 102
    goto :goto_73

    .line 103
    :cond_66
    const v1, -0x5288f385

    .line 106
    invoke-virtual {p4, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 109
    invoke-static {p4}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 112
    move-result v1

    .line 113
    invoke-virtual {p4, v7}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 116
    :goto_73
    iget-object v2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 118
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 121
    move-result-object v5

    .line 122
    invoke-virtual {p4, v2, v5}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 125
    move-result-object v2

    .line 126
    iget-object v5, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->age:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 128
    iget-object v5, v5, Lcom/spotifry/music/data/spotifried/AgeStats;->age:Ljava/lang/Integer;

    .line 130
    if-nez v5, :cond_84

    .line 132
    move v3, v7

    .line 133
    :cond_84
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 136
    move-result-object v3

    .line 137
    invoke-virtual {p4, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 140
    move-result-object v2

    .line 141
    const v3, -0x5288e28c

    .line 144
    invoke-virtual {p4, v3, v2}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 147
    and-int/lit16 v5, v0, 0x3fe

    .line 149
    move-object v0, p0

    .line 150
    move v2, p2

    .line 151
    move-object v4, p4

    .line 152
    move v3, v1

    .line 153
    move v1, p1

    .line 154
    invoke-static/range {v0 .. v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 157
    invoke-virtual {p4, v7}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 160
    goto :goto_a3

    .line 161
    :cond_a0
    invoke-virtual {p4}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 164
    :goto_a3
    invoke-virtual {p4}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 167
    move-result-object v7

    .line 168
    if-eqz v7, :cond_b6

    .line 170
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;

    .line 172
    const/4 v6, 0x0

    .line 173
    move-object v1, p0

    .line 174
    move v2, p1

    .line 175
    move v3, p2

    .line 176
    move v4, p3

    .line 177
    move v5, p5

    .line 178
    invoke-direct/range {v0 .. v6}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZIB)V

    .line 181
    iput-object v0, v7, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 183
    :cond_b6
    return-void
.end method

.method public static final CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 10

    .line 1
    const v0, -0x7effe444

    .line 4
    invoke-virtual {p1, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p2, 0x3

    .line 9
    const/4 v1, 0x0

    .line 10
    const/4 v2, 0x2

    .line 11
    const/4 v3, 0x1

    .line 12
    if-eq v0, v2, :cond_f

    .line 14
    move v0, v3

    .line 15
    goto :goto_10

    .line 16
    :cond_f
    move v0, v1

    .line 17
    :goto_10
    and-int/lit8 v2, p2, 0x1

    .line 19
    invoke-virtual {p1, v2, v0}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_8a

    .line 25
    sget-object v0, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 27
    const/high16 v2, 0x3f800000    # 1.0f

    .line 29
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 32
    move-result-object v0

    .line 33
    const/high16 v2, 0x41a00000    # 20.0f

    .line 35
    const/high16 v4, 0x41e00000    # 28.0f

    .line 37
    const/high16 v5, 0x41d00000    # 26.0f

    .line 39
    invoke-static {v0, v5, v2, v5, v4}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0(Landroidx/compose/ui/Modifier;FFFF)Landroidx/compose/ui/Modifier;

    .line 42
    move-result-object v0

    .line 43
    sget-object v2, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 45
    sget-object v4, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 47
    invoke-static {v2, v4, p1, v1}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 50
    move-result-object v1

    .line 51
    iget-wide v4, p1, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 53
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 56
    move-result v2

    .line 57
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 60
    move-result-object v4

    .line 61
    invoke-static {p1, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 64
    move-result-object v0

    .line 65
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 67
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 72
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 75
    iget-boolean v6, p1, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 77
    if-eqz v6, :cond_52

    .line 79
    invoke-virtual {p1, v5}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 82
    goto :goto_55

    .line 83
    :cond_52
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 86
    :goto_55
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 88
    invoke-static {p1, v1, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 91
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 93
    invoke-static {p1, v4, v1}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 96
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 98
    iget-boolean v4, p1, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 100
    if-nez v4, :cond_73

    .line 102
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 105
    move-result-object v4

    .line 106
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    move-result-object v5

    .line 110
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 113
    move-result v4

    .line 114
    if-nez v4, :cond_76

    .line 116
    :cond_73
    invoke-static {v2, p1, v2, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 119
    :cond_76
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 121
    invoke-static {p1, v0, v1}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 124
    const/16 v0, 0x36

    .line 126
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 129
    move-result-object v0

    .line 130
    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 132
    invoke-virtual {p0, v1, p1, v0}, Landroidx/compose/runtime/internal/ComposableLambdaImpl;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    invoke-virtual {p1, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 138
    goto :goto_8d

    .line 139
    :cond_8a
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 142
    :goto_8d
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 145
    move-result-object p1

    .line 146
    if-eqz p1, :cond_9b

    .line 148
    new-instance v0, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda137;

    .line 150
    const/4 v1, 0x7

    .line 151
    invoke-direct {v0, p0, p2, v1}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda137;-><init>(Landroidx/compose/runtime/internal/ComposableLambdaImpl;IB)V

    .line 154
    iput-object v0, p1, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 156
    :cond_9b
    return-void
.end method

.method public static final Day(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lcom/spotifry/music/data/spotifried/ObsessionDay;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 23

    .line 1
    move-object/from16 v3, p0

    .line 3
    move-object/from16 v2, p1

    .line 5
    move/from16 v1, p2

    .line 7
    move-object/from16 v14, p3

    .line 9
    move/from16 v15, p4

    .line 11
    const v0, 0x34ffe115

    .line 14
    invoke-virtual {v14, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 17
    and-int/lit8 v0, v15, 0x6

    .line 19
    if-nez v0, :cond_1f

    .line 21
    invoke-virtual {v14, v3}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1c

    .line 27
    const/4 v0, 0x4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v0, 0x2

    .line 30
    :goto_1d
    or-int/2addr v0, v15

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v0, v15

    .line 33
    :goto_20
    and-int/lit8 v4, v15, 0x30

    .line 35
    if-nez v4, :cond_30

    .line 37
    invoke-virtual {v14, v2}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 40
    move-result v4

    .line 41
    if-eqz v4, :cond_2d

    .line 43
    const/16 v4, 0x20

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    const/16 v4, 0x10

    .line 48
    :goto_2f
    or-int/2addr v0, v4

    .line 49
    :cond_30
    and-int/lit16 v4, v15, 0x180

    .line 51
    if-nez v4, :cond_40

    .line 53
    invoke-virtual {v14, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 56
    move-result v4

    .line 57
    if-eqz v4, :cond_3d

    .line 59
    const/16 v4, 0x100

    .line 61
    goto :goto_3f

    .line 62
    :cond_3d
    const/16 v4, 0x80

    .line 64
    :goto_3f
    or-int/2addr v0, v4

    .line 65
    :cond_40
    and-int/lit16 v4, v0, 0x93

    .line 67
    const/16 v5, 0x92

    .line 69
    const/4 v6, 0x1

    .line 70
    if-eq v4, v5, :cond_49

    .line 72
    move v4, v6

    .line 73
    goto :goto_4a

    .line 74
    :cond_49
    const/4 v4, 0x0

    .line 75
    :goto_4a
    and-int/lit8 v5, v0, 0x1

    .line 77
    invoke-virtual {v14, v5, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 80
    move-result v4

    .line 81
    if-eqz v4, :cond_d1

    .line 83
    sget-object v4, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 85
    invoke-virtual {v14, v4}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 88
    move-result-object v5

    .line 89
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 91
    iget-wide v7, v5, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 93
    invoke-virtual {v14, v4}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 96
    move-result-object v4

    .line 97
    check-cast v4, Landroidx/compose/material3/ColorScheme;

    .line 99
    iget-wide v4, v4, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 101
    const v9, 0x3e0f5c29    # 0.14f

    .line 104
    invoke-static {v9, v4, v5}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 107
    move-result-wide v9

    .line 108
    invoke-virtual {v14, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 111
    move-result v11

    .line 112
    invoke-virtual {v14}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 115
    move-result-object v12

    .line 116
    if-nez v11, :cond_79

    .line 118
    sget-object v11, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 120
    if-ne v12, v11, :cond_82

    .line 122
    :cond_79
    iget-object v11, v2, Lcom/spotifry/music/data/spotifried/ObsessionDay;->startHours:Ljava/util/ArrayList;

    .line 124
    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    .line 127
    move-result-object v12

    .line 128
    invoke-virtual {v14, v12}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 131
    :cond_82
    move-object v11, v12

    .line 132
    check-cast v11, Ljava/util/List;

    .line 134
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 137
    move-result v12

    .line 138
    if-lt v12, v6, :cond_8c

    .line 140
    move v6, v12

    .line 141
    :cond_8c
    int-to-float v6, v6

    .line 142
    const/high16 v12, 0x44fa0000    # 2000.0f

    .line 144
    div-float/2addr v12, v6

    .line 145
    const/high16 v6, 0x428c0000    # 70.0f

    .line 147
    invoke-static {v6, v12}, Ljava/lang/Math;->min(FF)F

    .line 150
    move-result v13

    .line 151
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 154
    move-result v6

    .line 155
    int-to-float v6, v6

    .line 156
    mul-float/2addr v6, v13

    .line 157
    const/high16 v12, 0x43fa0000    # 500.0f

    .line 159
    add-float/2addr v6, v12

    .line 160
    const v12, 0x44098000    # 550.0f

    .line 163
    add-float/2addr v6, v12

    .line 164
    shr-int/lit8 v12, v0, 0x6

    .line 166
    and-int/lit8 v12, v12, 0xe

    .line 168
    invoke-static {v1, v6, v14, v12}, Lcom/spotifry/music/ui/spotifried/CardsKt;->clock(ZFLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/Animatable;

    .line 171
    move-result-object v12

    .line 172
    iget v6, v2, Lcom/spotifry/music/data/spotifried/ObsessionDay;->plays:I

    .line 174
    shr-int/lit8 v0, v0, 0x3

    .line 176
    and-int/lit8 v0, v0, 0x70

    .line 178
    or-int/lit16 v0, v0, 0x180

    .line 180
    const/16 v2, 0x1c2

    .line 182
    invoke-static {v6, v2, v0, v14, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countUp(IIILandroidx/compose/runtime/ComposerImpl;Z)Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 185
    move-result-object v6

    .line 186
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;

    .line 188
    move-wide/from16 v16, v7

    .line 190
    move-wide v7, v4

    .line 191
    move-wide/from16 v4, v16

    .line 193
    move-object/from16 v2, p1

    .line 195
    invoke-direct/range {v0 .. v13}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;-><init>(ZLcom/spotifry/music/data/spotifried/ObsessionDay;Lcom/spotifry/music/data/spotifried/SpotifriedStats;JLcom/spotifry/music/ui/spotifried/CountUp;JJLjava/util/List;Landroidx/compose/animation/core/Animatable;F)V

    .line 198
    const v4, 0x39868052

    .line 201
    invoke-static {v4, v0, v14}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 204
    move-result-object v0

    .line 205
    const/4 v4, 0x6

    .line 206
    invoke-static {v0, v14, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 209
    goto :goto_d4

    .line 210
    :cond_d1
    invoke-virtual {v14}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 213
    :goto_d4
    invoke-virtual {v14}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 216
    move-result-object v0

    .line 217
    if-eqz v0, :cond_e1

    .line 219
    new-instance v4, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;

    .line 221
    invoke-direct {v4, v3, v2, v1, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lcom/spotifry/music/data/spotifried/ObsessionDay;ZI)V

    .line 224
    iput-object v4, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 226
    :cond_e1
    return-void
.end method

.method public static final DayCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 10

    .line 1
    const v0, 0x36a75860

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_7d

    .line 58
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->obsession:Lcom/spotifry/music/data/spotifried/ObsessionDay;

    .line 60
    if-nez v1, :cond_4d

    .line 62
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 65
    move-result-object p2

    .line 66
    if-eqz p2, :cond_8e

    .line 68
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 70
    const/16 v1, 0x9

    .line 72
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 75
    :goto_4a
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 77
    return-void

    .line 78
    :cond_4d
    if-eqz p1, :cond_59

    .line 80
    const v2, 0x1c2748ca

    .line 83
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 86
    :goto_55
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 89
    goto :goto_64

    .line 90
    :cond_59
    const v2, 0x2a32d1d2

    .line 93
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 96
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 99
    move-result v3

    .line 100
    goto :goto_55

    .line 101
    :goto_64
    iget-object v2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 103
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 106
    move-result-object v5

    .line 107
    invoke-virtual {p2, v2, v5}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 110
    move-result-object v2

    .line 111
    const v5, 0x2a32d4c9

    .line 114
    invoke-virtual {p2, v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 117
    and-int/lit8 v0, v0, 0xe

    .line 119
    invoke-static {p0, v1, v3, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Day(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lcom/spotifry/music/data/spotifried/ObsessionDay;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 122
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 125
    goto :goto_80

    .line 126
    :cond_7d
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 129
    :goto_80
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 132
    move-result-object p2

    .line 133
    if-eqz p2, :cond_8e

    .line 135
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 137
    const/16 v1, 0xa

    .line 139
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 142
    goto :goto_4a

    .line 143
    :cond_8e
    return-void
.end method

.method public static final Hours(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 24

    .line 1
    move-object/from16 v2, p0

    .line 3
    move/from16 v1, p1

    .line 5
    move-object/from16 v12, p2

    .line 7
    move/from16 v13, p3

    .line 9
    iget-wide v3, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 11
    const v0, 0x77d49923

    .line 14
    invoke-virtual {v12, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 17
    and-int/lit8 v0, v13, 0x6

    .line 19
    if-nez v0, :cond_1f

    .line 21
    invoke-virtual {v12, v2}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1c

    .line 27
    const/4 v0, 0x4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v0, 0x2

    .line 30
    :goto_1d
    or-int/2addr v0, v13

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v0, v13

    .line 33
    :goto_20
    and-int/lit8 v5, v13, 0x30

    .line 35
    if-nez v5, :cond_30

    .line 37
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 40
    move-result v5

    .line 41
    if-eqz v5, :cond_2d

    .line 43
    const/16 v5, 0x20

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    const/16 v5, 0x10

    .line 48
    :goto_2f
    or-int/2addr v0, v5

    .line 49
    :cond_30
    and-int/lit8 v5, v0, 0x13

    .line 51
    const/16 v6, 0x12

    .line 53
    const/4 v8, 0x1

    .line 54
    if-eq v5, v6, :cond_39

    .line 56
    move v5, v8

    .line 57
    goto :goto_3a

    .line 58
    :cond_39
    const/4 v5, 0x0

    .line 59
    :goto_3a
    and-int/lit8 v6, v0, 0x1

    .line 61
    invoke-virtual {v12, v6, v5}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 64
    move-result v5

    .line 65
    if-eqz v5, :cond_10e

    .line 67
    sget-object v5, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 69
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 72
    move-result-object v6

    .line 73
    check-cast v6, Landroidx/compose/material3/ColorScheme;

    .line 75
    iget-wide v9, v6, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 77
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 80
    move-result-object v5

    .line 81
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 83
    iget-wide v5, v5, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 85
    const v11, 0x3e4ccccd    # 0.2f

    .line 88
    invoke-static {v11, v5, v6}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 91
    move-result-wide v5

    .line 92
    long-to-double v14, v3

    .line 93
    const-wide v16, 0x40ac200000000000L    # 3600.0

    .line 98
    div-double v14, v14, v16

    .line 100
    invoke-static {v14, v15}, Lkotlin/math/MathKt;->roundToInt(D)I

    .line 103
    move-result v11

    .line 104
    if-lt v11, v8, :cond_7a

    .line 106
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    move-result-object v3

    .line 110
    if-ne v11, v8, :cond_72

    .line 112
    const-string v4, "hour."

    .line 114
    goto :goto_74

    .line 115
    :cond_72
    const-string v4, "hours."

    .line 117
    :goto_74
    new-instance v8, Lkotlin/Pair;

    .line 119
    invoke-direct {v8, v3, v4}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 122
    goto :goto_8e

    .line 123
    :cond_7a
    invoke-static {v3, v4}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 126
    move-result v3

    .line 127
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 130
    move-result-object v4

    .line 131
    if-ne v3, v8, :cond_87

    .line 133
    const-string v3, "minute."

    .line 135
    goto :goto_89

    .line 136
    :cond_87
    const-string v3, "minutes."

    .line 138
    :goto_89
    new-instance v8, Lkotlin/Pair;

    .line 140
    invoke-direct {v8, v4, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 143
    :goto_8e
    iget-object v3, v8, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 145
    check-cast v3, Ljava/lang/Number;

    .line 147
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 150
    move-result v3

    .line 151
    iget-object v4, v8, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 153
    check-cast v4, Ljava/lang/String;

    .line 155
    and-int/lit8 v0, v0, 0x70

    .line 157
    or-int/lit16 v0, v0, 0x180

    .line 159
    const/16 v8, 0x1c2

    .line 161
    invoke-static {v3, v8, v0, v12, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countUp(IIILandroidx/compose/runtime/ComposerImpl;Z)Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 164
    move-result-object v0

    .line 165
    iget-object v3, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->daySeconds:Ljava/util/List;

    .line 167
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 170
    move-result v8

    .line 171
    iget-object v3, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->longestDay:Ljava/time/LocalDate;

    .line 173
    const/4 v11, 0x0

    .line 174
    if-eqz v3, :cond_c2

    .line 176
    sget-object v14, Ljava/time/temporal/ChronoUnit;->DAYS:Ljava/time/temporal/ChronoUnit;

    .line 178
    iget-object v15, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->start:Ljava/time/LocalDate;

    .line 180
    invoke-virtual {v14, v15, v3}, Ljava/time/temporal/ChronoUnit;->between(Ljava/time/temporal/Temporal;Ljava/time/temporal/Temporal;)J

    .line 183
    move-result-wide v14

    .line 184
    long-to-int v3, v14

    .line 185
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 188
    move-result-object v14

    .line 189
    if-ltz v3, :cond_c2

    .line 191
    if-ge v3, v8, :cond_c2

    .line 193
    move-object v3, v14

    .line 194
    goto :goto_c3

    .line 195
    :cond_c2
    move-object v3, v11

    .line 196
    :goto_c3
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 199
    move-result-object v14

    .line 200
    sget-object v15, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 202
    if-ne v14, v15, :cond_d9

    .line 204
    if-eqz v1, :cond_d1

    .line 206
    const v14, 0x451c4000    # 2500.0f

    .line 209
    goto :goto_d2

    .line 210
    :cond_d1
    const/4 v14, 0x0

    .line 211
    :goto_d2
    invoke-static {v14}, Landroidx/compose/animation/core/ArcSplineKt;->Animatable$default(F)Landroidx/compose/animation/core/Animatable;

    .line 214
    move-result-object v14

    .line 215
    invoke-virtual {v12, v14}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 218
    :cond_d9
    check-cast v14, Landroidx/compose/animation/core/Animatable;

    .line 220
    invoke-virtual {v12, v14}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 223
    move-result v16

    .line 224
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 227
    move-result-object v7

    .line 228
    if-nez v16, :cond_e7

    .line 230
    if-ne v7, v15, :cond_f0

    .line 232
    :cond_e7
    new-instance v7, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;

    .line 234
    const/4 v15, 0x0

    .line 235
    invoke-direct {v7, v14, v11, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;-><init>(Landroidx/compose/animation/core/Animatable;Lkotlin/coroutines/Continuation;B)V

    .line 238
    invoke-virtual {v12, v7}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 241
    :cond_f0
    check-cast v7, Lkotlin/jvm/functions/Function2;

    .line 243
    invoke-static {v12, v14, v7}, Landroidx/compose/runtime/AnchoredGroupPath;->LaunchedEffect(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 246
    move-object v7, v4

    .line 247
    move-wide/from16 v18, v5

    .line 249
    move-object v6, v0

    .line 250
    move-wide v4, v9

    .line 251
    move-wide/from16 v10, v18

    .line 253
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;

    .line 255
    move-object v9, v14

    .line 256
    invoke-direct/range {v0 .. v11}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;-><init>(ZLcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/lang/Integer;JLcom/spotifry/music/ui/spotifried/CountUp;Ljava/lang/String;ILandroidx/compose/animation/core/Animatable;J)V

    .line 259
    const v3, -0x366e1fa

    .line 262
    invoke-static {v3, v0, v12}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 265
    move-result-object v0

    .line 266
    const/4 v3, 0x6

    .line 267
    invoke-static {v0, v12, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 270
    goto :goto_111

    .line 271
    :cond_10e
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 274
    :goto_111
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 277
    move-result-object v0

    .line 278
    if-eqz v0, :cond_11f

    .line 280
    new-instance v3, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 282
    const/4 v4, 0x3

    .line 283
    invoke-direct {v3, v2, v1, v13, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 286
    iput-object v3, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 288
    :cond_11f
    return-void
.end method

.method public static final HoursCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 9

    .line 1
    const v0, 0x77e2fd3

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_69

    .line 58
    if-eqz p1, :cond_45

    .line 60
    const v1, -0xa7f2b49

    .line 63
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 66
    :goto_41
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 69
    goto :goto_50

    .line 70
    :cond_45
    const v1, 0x20b19445

    .line 73
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 76
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 79
    move-result v3

    .line 80
    goto :goto_41

    .line 81
    :goto_50
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 83
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {p2, v1, v2}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 90
    move-result-object v1

    .line 91
    const v2, 0x20b19739

    .line 94
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 97
    and-int/lit8 v0, v0, 0xe

    .line 99
    invoke-static {p0, v3, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Hours(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 102
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 105
    goto :goto_6c

    .line 106
    :cond_69
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 109
    :goto_6c
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 112
    move-result-object p2

    .line 113
    if-eqz p2, :cond_7b

    .line 115
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 117
    const/16 v1, 0xb

    .line 119
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 122
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 124
    :cond_7b
    return-void
.end method

.method public static final Intro(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 24

    .line 1
    move-object/from16 v5, p0

    .line 3
    move/from16 v8, p1

    .line 5
    move-object/from16 v9, p2

    .line 7
    move/from16 v10, p3

    .line 9
    const v0, -0x419f8980

    .line 12
    invoke-virtual {v9, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 15
    and-int/lit8 v0, v10, 0x6

    .line 17
    if-nez v0, :cond_1d

    .line 19
    invoke-virtual {v9, v5}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_1a

    .line 25
    const/4 v0, 0x4

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v0, 0x2

    .line 28
    :goto_1b
    or-int/2addr v0, v10

    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move v0, v10

    .line 31
    :goto_1e
    and-int/lit8 v1, v10, 0x30

    .line 33
    if-nez v1, :cond_2e

    .line 35
    invoke-virtual {v9, v8}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_2b

    .line 41
    const/16 v1, 0x20

    .line 43
    goto :goto_2d

    .line 44
    :cond_2b
    const/16 v1, 0x10

    .line 46
    :goto_2d
    or-int/2addr v0, v1

    .line 47
    :cond_2e
    and-int/lit8 v1, v0, 0x13

    .line 49
    const/16 v2, 0x12

    .line 51
    if-eq v1, v2, :cond_36

    .line 53
    const/4 v1, 0x1

    .line 54
    goto :goto_37

    .line 55
    :cond_36
    const/4 v1, 0x0

    .line 56
    :goto_37
    and-int/lit8 v2, v0, 0x1

    .line 58
    invoke-virtual {v9, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 61
    move-result v1

    .line 62
    if-eqz v1, :cond_ef

    .line 64
    sget-object v1, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 66
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 69
    move-result-object v1

    .line 70
    check-cast v1, Landroidx/compose/material3/ColorScheme;

    .line 72
    iget-wide v1, v1, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 74
    iget-wide v6, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 76
    iget-object v4, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 78
    invoke-static {v6, v7}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 81
    move-result v6

    .line 82
    invoke-static {v6}, Lcom/spotifry/music/data/Log;->sunScale(I)F

    .line 85
    move-result v6

    .line 86
    invoke-static {v4, v6, v8, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rememberSunMotion(Ljava/util/List;FZLandroidx/compose/runtime/ComposerImpl;)Lcom/spotifry/music/ui/listening/SunMotion;

    .line 89
    move-result-object v7

    .line 90
    invoke-static {v4}, Lkotlin/io/ByteStreamsKt;->getIndices(Ljava/util/Collection;)Lkotlin/ranges/IntRange;

    .line 93
    move-result-object v11

    .line 94
    invoke-virtual {v11}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 97
    move-result-object v11

    .line 98
    move-object v12, v11

    .line 99
    check-cast v12, Lkotlin/ranges/IntProgressionIterator;

    .line 101
    iget-boolean v13, v12, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 103
    if-nez v13, :cond_6a

    .line 105
    const/4 v4, 0x0

    .line 106
    goto :goto_a8

    .line 107
    :cond_6a
    check-cast v11, Lkotlin/collections/IntIterator;

    .line 109
    invoke-virtual {v11}, Lkotlin/collections/IntIterator;->next()Ljava/lang/Object;

    .line 112
    move-result-object v13

    .line 113
    iget-boolean v14, v12, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 115
    if-eqz v14, :cond_a7

    .line 117
    move-object v14, v13

    .line 118
    check-cast v14, Ljava/lang/Number;

    .line 120
    invoke-virtual {v14}, Ljava/lang/Number;->intValue()I

    .line 123
    move-result v14

    .line 124
    invoke-interface {v4, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 127
    move-result-object v14

    .line 128
    check-cast v14, Ljava/lang/Number;

    .line 130
    invoke-virtual {v14}, Ljava/lang/Number;->longValue()J

    .line 133
    move-result-wide v14

    .line 134
    :goto_85
    invoke-virtual {v11}, Lkotlin/collections/IntIterator;->next()Ljava/lang/Object;

    .line 137
    move-result-object v16

    .line 138
    move-object/from16 v17, v16

    .line 140
    check-cast v17, Ljava/lang/Number;

    .line 142
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->intValue()I

    .line 145
    move-result v3

    .line 146
    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 149
    move-result-object v3

    .line 150
    check-cast v3, Ljava/lang/Number;

    .line 152
    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    .line 155
    move-result-wide v18

    .line 156
    cmp-long v3, v14, v18

    .line 158
    if-gez v3, :cond_a3

    .line 160
    move-object/from16 v13, v16

    .line 162
    move-wide/from16 v14, v18

    .line 164
    :cond_a3
    iget-boolean v3, v12, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 166
    if-nez v3, :cond_ea

    .line 168
    :cond_a7
    move-object v4, v13

    .line 169
    :goto_a8
    check-cast v4, Ljava/lang/Integer;

    .line 171
    if-eqz v4, :cond_b1

    .line 173
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 176
    move-result v3

    .line 177
    goto :goto_b2

    .line 178
    :cond_b1
    const/4 v3, 0x0

    .line 179
    :goto_b2
    neg-int v3, v3

    .line 180
    int-to-float v3, v3

    .line 181
    const/high16 v4, 0x41700000    # 15.0f

    .line 183
    mul-float/2addr v4, v3

    .line 184
    shr-int/lit8 v0, v0, 0x3

    .line 186
    and-int/lit8 v0, v0, 0xe

    .line 188
    or-int/lit16 v0, v0, 0x1b0

    .line 190
    const/16 v3, 0xc8

    .line 192
    const/16 v11, 0x578

    .line 194
    invoke-static {v3, v11, v0, v9, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 197
    move-result-object v0

    .line 198
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 200
    const/high16 v11, 0x3f800000    # 1.0f

    .line 202
    invoke-static {v3, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 205
    move-result-object v3

    .line 206
    invoke-static {v3}, Landroidx/compose/ui/draw/ClipKt;->clipToBounds(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 209
    move-result-object v11

    .line 210
    move-wide v2, v1

    .line 211
    move-object v1, v0

    .line 212
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;

    .line 214
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;-><init>(Landroidx/compose/animation/core/Animatable;JFLcom/spotifry/music/data/spotifried/SpotifriedStats;FLcom/spotifry/music/ui/listening/SunMotion;Z)V

    .line 217
    move-object v6, v5

    .line 218
    const v1, 0x2bbac5d6

    .line 221
    invoke-static {v1, v0, v9}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 224
    move-result-object v2

    .line 225
    const/16 v4, 0xc06

    .line 227
    const/4 v5, 0x6

    .line 228
    const/4 v1, 0x0

    .line 229
    move-object v3, v9

    .line 230
    move-object v0, v11

    .line 231
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 234
    goto :goto_f3

    .line 235
    :cond_ea
    move-wide v2, v1

    .line 236
    move-object/from16 v9, p2

    .line 238
    move-wide v1, v2

    .line 239
    goto :goto_85

    .line 240
    :cond_ef
    move-object v6, v5

    .line 241
    invoke-virtual/range {p2 .. p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 244
    :goto_f3
    invoke-virtual/range {p2 .. p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 247
    move-result-object v0

    .line 248
    if-eqz v0, :cond_101

    .line 250
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 252
    const/4 v2, 0x5

    .line 253
    invoke-direct {v1, v6, v8, v10, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 256
    iput-object v1, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 258
    :cond_101
    return-void
.end method

.method public static final IntroCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 9

    .line 1
    const v0, 0x3ff216b0

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_69

    .line 58
    if-eqz p1, :cond_45

    .line 60
    const v1, 0x6d1fa4ba

    .line 63
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 66
    :goto_41
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 69
    goto :goto_50

    .line 70
    :cond_45
    const v1, 0xbc737e2

    .line 73
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 76
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 79
    move-result v3

    .line 80
    goto :goto_41

    .line 81
    :goto_50
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 83
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {p2, v1, v2}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 90
    move-result-object v1

    .line 91
    const v2, 0xbc73ad6

    .line 94
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 97
    and-int/lit8 v0, v0, 0xe

    .line 99
    invoke-static {p0, v3, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Intro(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 102
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 105
    goto :goto_6c

    .line 106
    :cond_69
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 109
    :goto_6c
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 112
    move-result-object p2

    .line 113
    if-eqz p2, :cond_7a

    .line 115
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 117
    const/4 v1, 0x7

    .line 118
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 121
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 123
    :cond_7a
    return-void
.end method

.method public static final Months(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 22

    .line 1
    move-object/from16 v5, p0

    .line 3
    move/from16 v6, p1

    .line 5
    move-object/from16 v12, p2

    .line 7
    move/from16 v13, p3

    .line 9
    const v0, -0x60c4e9dd

    .line 12
    invoke-virtual {v12, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 15
    and-int/lit8 v0, v13, 0x6

    .line 17
    const/4 v1, 0x4

    .line 18
    if-nez v0, :cond_1e

    .line 20
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1b

    .line 26
    move v0, v1

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    const/4 v0, 0x2

    .line 29
    :goto_1c
    or-int/2addr v0, v13

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v0, v13

    .line 32
    :goto_1f
    and-int/lit8 v2, v13, 0x30

    .line 34
    if-nez v2, :cond_2f

    .line 36
    invoke-virtual {v12, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_2c

    .line 42
    const/16 v2, 0x20

    .line 44
    goto :goto_2e

    .line 45
    :cond_2c
    const/16 v2, 0x10

    .line 47
    :goto_2e
    or-int/2addr v0, v2

    .line 48
    :cond_2f
    and-int/lit8 v2, v0, 0x13

    .line 50
    const/16 v3, 0x12

    .line 52
    const/4 v7, 0x1

    .line 53
    if-eq v2, v3, :cond_38

    .line 55
    move v2, v7

    .line 56
    goto :goto_39

    .line 57
    :cond_38
    const/4 v2, 0x0

    .line 58
    :goto_39
    and-int/2addr v0, v7

    .line 59
    invoke-virtual {v12, v0, v2}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 62
    move-result v0

    .line 63
    const/4 v14, 0x6

    .line 64
    if-eqz v0, :cond_111

    .line 66
    sget-object v0, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 68
    invoke-virtual {v12, v0}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 71
    move-result-object v2

    .line 72
    check-cast v2, Landroidx/compose/material3/ColorScheme;

    .line 74
    iget-wide v2, v2, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 76
    invoke-virtual {v12, v0}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Landroidx/compose/material3/ColorScheme;

    .line 82
    iget-wide v8, v0, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 84
    const v0, 0x3e0f5c29    # 0.14f

    .line 87
    invoke-static {v0, v8, v9}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 90
    move-result-wide v8

    .line 91
    iget-object v0, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->months:Ljava/util/ArrayList;

    .line 93
    iget-object v10, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 95
    iget-object v10, v10, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->label:Ljava/lang/String;

    .line 97
    iget-object v11, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->changeMonth:Ljava/time/YearMonth;

    .line 99
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 102
    move-result-object v15

    .line 103
    const/16 v16, 0x0

    .line 105
    :goto_68
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    .line 108
    move-result v17

    .line 109
    if-eqz v17, :cond_81

    .line 111
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 114
    move-result-object v17

    .line 115
    move-object/from16 v4, v17

    .line 117
    check-cast v4, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 119
    iget-object v4, v4, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 121
    invoke-virtual {v4, v11}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 124
    move-result v4

    .line 125
    if-nez v4, :cond_83

    .line 127
    add-int/lit8 v16, v16, 0x1

    .line 129
    goto :goto_68

    .line 130
    :cond_81
    const/16 v16, -0x1

    .line 132
    :cond_83
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 135
    move-result-object v4

    .line 136
    if-gez v16, :cond_8a

    .line 138
    const/4 v4, 0x0

    .line 139
    :cond_8a
    if-eqz v4, :cond_91

    .line 141
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 144
    move-result v4

    .line 145
    goto :goto_95

    .line 146
    :cond_91
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 149
    move-result v4

    .line 150
    :goto_95
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 153
    move-result v11

    .line 154
    const/16 v15, 0xc

    .line 156
    sub-int/2addr v11, v15

    .line 157
    invoke-static {v11, v4}, Ljava/lang/Math;->min(II)I

    .line 160
    move-result v4

    .line 161
    if-gez v4, :cond_a3

    .line 163
    const/4 v4, 0x0

    .line 164
    :cond_a3
    invoke-static {v0, v4}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 167
    move-result-object v0

    .line 168
    invoke-static {v0, v15}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 171
    move-result-object v4

    .line 172
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 175
    move-result-object v0

    .line 176
    check-cast v0, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 178
    iget-object v0, v0, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 180
    invoke-virtual {v0}, Ljava/time/YearMonth;->getYear()I

    .line 183
    move-result v0

    .line 184
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 187
    move-result-object v11

    .line 188
    check-cast v11, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 190
    iget-object v11, v11, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 192
    invoke-virtual {v11}, Ljava/time/YearMonth;->getYear()I

    .line 195
    move-result v11

    .line 196
    if-eq v0, v11, :cond_c7

    .line 198
    move v11, v7

    .line 199
    goto :goto_c8

    .line 200
    :cond_c7
    const/4 v11, 0x0

    .line 201
    :goto_c8
    if-eqz v11, :cond_cd

    .line 203
    const-string v0, "MMM \'\'yy"

    .line 205
    goto :goto_cf

    .line 206
    :cond_cd
    const-string v0, "MMM"

    .line 208
    :goto_cf
    sget-object v15, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 210
    invoke-static {v0, v15}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    .line 213
    move-result-object v0

    .line 214
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 217
    move-result v15

    .line 218
    if-ne v15, v1, :cond_f1

    .line 220
    const/4 v1, 0x0

    .line 221
    :goto_dc
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 224
    move-result v15

    .line 225
    if-ge v1, v15, :cond_ef

    .line 227
    invoke-virtual {v10, v1}, Ljava/lang/String;->charAt(I)C

    .line 230
    move-result v15

    .line 231
    invoke-static {v15}, Ljava/lang/Character;->isDigit(C)Z

    .line 234
    move-result v15

    .line 235
    if-eqz v15, :cond_f1

    .line 237
    add-int/lit8 v1, v1, 0x1

    .line 239
    goto :goto_dc

    .line 240
    :cond_ef
    move v1, v7

    .line 241
    goto :goto_f2

    .line 242
    :cond_f1
    const/4 v1, 0x0

    .line 243
    :goto_f2
    sget-object v7, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 245
    invoke-virtual {v12, v7}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 248
    move-result-object v7

    .line 249
    check-cast v7, Landroidx/compose/ui/unit/Density;

    .line 251
    const/high16 v10, 0x41600000    # 14.0f

    .line 253
    invoke-interface {v7, v10}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 256
    move-result v7

    .line 257
    move-object v10, v0

    .line 258
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;

    .line 260
    invoke-direct/range {v0 .. v11}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;-><init>(ZJLjava/util/List;Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZFJLjava/time/format/DateTimeFormatter;Z)V

    .line 263
    const v1, -0x4cf8d260

    .line 266
    invoke-static {v1, v0, v12}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 269
    move-result-object v0

    .line 270
    invoke-static {v0, v12, v14}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 273
    goto :goto_114

    .line 274
    :cond_111
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 277
    :goto_114
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 280
    move-result-object v0

    .line 281
    if-eqz v0, :cond_121

    .line 283
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 285
    invoke-direct {v1, v5, v6, v13, v14}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 288
    iput-object v1, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 290
    :cond_121
    return-void
.end method

.method public static final MonthsCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 10

    .line 1
    const v0, -0x12a1d32d

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_84

    .line 58
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->months:Ljava/util/ArrayList;

    .line 60
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_51

    .line 66
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 69
    move-result-object p2

    .line 70
    if-eqz p2, :cond_93

    .line 72
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 74
    const/16 v1, 0xc

    .line 76
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 79
    :goto_4e
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 81
    return-void

    .line 82
    :cond_51
    if-eqz p1, :cond_5e

    .line 84
    const v1, -0x3dbbbcc9

    .line 87
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 90
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 93
    move v1, v3

    .line 94
    goto :goto_6b

    .line 95
    :cond_5e
    const v1, 0xe8655c5

    .line 98
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 101
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 104
    move-result v1

    .line 105
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 108
    :goto_6b
    iget-object v2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 110
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 113
    move-result-object v5

    .line 114
    invoke-virtual {p2, v2, v5}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 117
    move-result-object v2

    .line 118
    const v5, 0xe8658ba

    .line 121
    invoke-virtual {p2, v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 124
    and-int/lit8 v0, v0, 0xe

    .line 126
    invoke-static {p0, v1, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Months(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 129
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 132
    goto :goto_87

    .line 133
    :cond_84
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 136
    :goto_87
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 139
    move-result-object p2

    .line 140
    if-eqz p2, :cond_93

    .line 142
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 144
    invoke-direct {v0, p0, p1, p3, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 147
    goto :goto_4e

    .line 148
    :cond_93
    return-void
.end method

.method public static final SunCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 9

    .line 1
    const v0, 0x3a01db10

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_69

    .line 58
    if-eqz p1, :cond_45

    .line 60
    const v1, 0x5df4fc9a

    .line 63
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 66
    :goto_41
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 69
    goto :goto_50

    .line 70
    :cond_45
    const v1, -0x3f089bfe

    .line 73
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 76
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 79
    move-result v3

    .line 80
    goto :goto_41

    .line 81
    :goto_50
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 83
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {p2, v1, v2}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 90
    move-result-object v1

    .line 91
    const v2, -0x3f089904

    .line 94
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 97
    and-int/lit8 v0, v0, 0xe

    .line 99
    invoke-static {p0, v3, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->SunPortrait(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 102
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 105
    goto :goto_6c

    .line 106
    :cond_69
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 109
    :goto_6c
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 112
    move-result-object p2

    .line 113
    if-eqz p2, :cond_7b

    .line 115
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 117
    const/16 v1, 0x8

    .line 119
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 122
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 124
    :cond_7b
    return-void
.end method

.method public static final SunPortrait(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 42

    .line 1
    move-object/from16 v4, p0

    .line 3
    move/from16 v8, p1

    .line 5
    move-object/from16 v3, p2

    .line 7
    const v0, -0x4fcc6165

    .line 10
    invoke-virtual {v3, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 13
    and-int/lit8 v0, p3, 0x6

    .line 15
    const/4 v2, 0x2

    .line 16
    if-nez v0, :cond_1d

    .line 18
    invoke-virtual {v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_19

    .line 24
    const/4 v0, 0x4

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    move v0, v2

    .line 27
    :goto_1a
    or-int v0, p3, v0

    .line 29
    goto :goto_1f

    .line 30
    :cond_1d
    move/from16 v0, p3

    .line 32
    :goto_1f
    and-int/lit8 v5, p3, 0x30

    .line 34
    if-nez v5, :cond_2f

    .line 36
    invoke-virtual {v3, v8}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 39
    move-result v5

    .line 40
    if-eqz v5, :cond_2c

    .line 42
    const/16 v5, 0x20

    .line 44
    goto :goto_2e

    .line 45
    :cond_2c
    const/16 v5, 0x10

    .line 47
    :goto_2e
    or-int/2addr v0, v5

    .line 48
    :cond_2f
    and-int/lit8 v5, v0, 0x13

    .line 50
    const/16 v6, 0x12

    .line 52
    const/4 v7, 0x0

    .line 53
    if-eq v5, v6, :cond_38

    .line 55
    const/4 v5, 0x1

    .line 56
    goto :goto_39

    .line 57
    :cond_38
    move v5, v7

    .line 58
    :goto_39
    and-int/lit8 v6, v0, 0x1

    .line 60
    invoke-virtual {v3, v6, v5}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 63
    move-result v5

    .line 64
    if-eqz v5, :cond_280

    .line 66
    sget-object v5, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 68
    invoke-virtual {v3, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 71
    move-result-object v5

    .line 72
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 74
    iget-wide v11, v5, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 76
    iget-wide v5, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 78
    invoke-static {v5, v6}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 81
    move-result v5

    .line 82
    invoke-static {v5}, Lcom/spotifry/music/data/Log;->sunScale(I)F

    .line 85
    move-result v5

    .line 86
    iget-object v6, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 88
    shl-int/lit8 v10, v0, 0x3

    .line 90
    and-int/lit16 v10, v10, 0x380

    .line 92
    invoke-static {v6, v5, v8, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rememberSunMotion(Ljava/util/List;FZLandroidx/compose/runtime/ComposerImpl;)Lcom/spotifry/music/ui/listening/SunMotion;

    .line 95
    move-result-object v6

    .line 96
    shr-int/lit8 v0, v0, 0x3

    .line 98
    const/16 v13, 0xe

    .line 100
    and-int/2addr v0, v13

    .line 101
    or-int/lit8 v0, v0, 0x30

    .line 103
    const v14, 0x450fc000    # 2300.0f

    .line 106
    invoke-static {v8, v14, v3, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->clock(ZFLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/Animatable;

    .line 109
    move-result-object v0

    .line 110
    const/16 v14, 0xb

    .line 112
    invoke-static {v14}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 115
    move-result-wide v18

    .line 116
    invoke-static {v13}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 119
    move-result-wide v26

    .line 120
    sget-object v20, Landroidx/compose/ui/text/font/FontWeight;->SemiBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 122
    new-instance v13, Landroidx/compose/ui/graphics/Shadow;

    .line 124
    sget-wide v14, Landroidx/compose/ui/graphics/Color;->Black:J

    .line 126
    invoke-direct {v13, v2, v14, v15}, Landroidx/compose/ui/graphics/Shadow;-><init>(IJ)V

    .line 129
    const/16 v29, 0x0

    .line 131
    const v30, 0xfddff9

    .line 134
    sget-object v15, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 136
    const-wide/16 v16, 0x0

    .line 138
    const/16 v21, 0x0

    .line 140
    const/16 v22, 0x0

    .line 142
    const-wide/16 v23, 0x0

    .line 144
    const/16 v28, 0x0

    .line 146
    move-object/from16 v25, v13

    .line 148
    invoke-static/range {v15 .. v30}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 151
    move-result-object v33

    .line 152
    sget-object v13, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 154
    const/high16 v14, 0x3f800000    # 1.0f

    .line 156
    invoke-static {v13, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 159
    move-result-object v15

    .line 160
    const/high16 v19, 0x41e00000    # 28.0f

    .line 162
    const/16 v20, 0x5

    .line 164
    const/16 v16, 0x0

    .line 166
    const/high16 v17, 0x41a00000    # 20.0f

    .line 168
    const/16 v18, 0x0

    .line 170
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 173
    move-result-object v15

    .line 174
    sget-object v9, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 176
    sget-object v14, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 178
    invoke-static {v9, v14, v3, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 181
    move-result-object v1

    .line 182
    iget-wide v7, v3, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 184
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 187
    move-result v7

    .line 188
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 191
    move-result-object v8

    .line 192
    invoke-static {v3, v15}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 195
    move-result-object v15

    .line 196
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 198
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 201
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 203
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 206
    move-object/from16 v35, v0

    .line 208
    iget-boolean v0, v3, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 210
    if-eqz v0, :cond_d7

    .line 212
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 215
    goto :goto_da

    .line 216
    :cond_d7
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 219
    :goto_da
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 221
    invoke-static {v3, v1, v0}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 224
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 226
    invoke-static {v3, v8, v1}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 229
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 231
    move/from16 v36, v5

    .line 233
    iget-boolean v5, v3, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 235
    if-nez v5, :cond_fd

    .line 237
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 240
    move-result-object v5

    .line 241
    move-object/from16 v37, v6

    .line 243
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 246
    move-result-object v6

    .line 247
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 250
    move-result v5

    .line 251
    if-nez v5, :cond_102

    .line 253
    goto :goto_ff

    .line 254
    :cond_fd
    move-object/from16 v37, v6

    .line 256
    :goto_ff
    invoke-static {v7, v3, v7, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 259
    :cond_102
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 261
    invoke-static {v3, v15, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 264
    const/high16 v6, 0x41d00000    # 26.0f

    .line 266
    const/4 v7, 0x0

    .line 267
    const/4 v15, 0x2

    .line 268
    invoke-static {v13, v6, v7, v15}, Landroidx/compose/foundation/layout/OffsetKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 271
    move-result-object v6

    .line 272
    const/4 v7, 0x0

    .line 273
    invoke-static {v9, v14, v3, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 276
    move-result-object v9

    .line 277
    move v7, v10

    .line 278
    move-wide/from16 v18, v11

    .line 280
    iget-wide v10, v3, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 282
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 285
    move-result v10

    .line 286
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 289
    move-result-object v11

    .line 290
    invoke-static {v3, v6}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 293
    move-result-object v6

    .line 294
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 297
    iget-boolean v12, v3, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 299
    if-eqz v12, :cond_130

    .line 301
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 304
    goto :goto_133

    .line 305
    :cond_130
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 308
    :goto_133
    invoke-static {v3, v9, v0}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 311
    invoke-static {v3, v11, v1}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 314
    iget-boolean v0, v3, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 316
    if-nez v0, :cond_14b

    .line 318
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 321
    move-result-object v0

    .line 322
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 325
    move-result-object v1

    .line 326
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 329
    move-result v0

    .line 330
    if-nez v0, :cond_14e

    .line 332
    :cond_14b
    invoke-static {v10, v3, v10, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 335
    :cond_14e
    invoke-static {v3, v6, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 338
    new-instance v1, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 340
    invoke-direct {v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 343
    iget-object v0, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 345
    iget-object v0, v0, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->label:Ljava/lang/String;

    .line 347
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 350
    move-result v2

    .line 351
    const/4 v5, 0x4

    .line 352
    if-ne v2, v5, :cond_178

    .line 354
    const/4 v2, 0x0

    .line 355
    :goto_162
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 358
    move-result v5

    .line 359
    if-ge v2, v5, :cond_175

    .line 361
    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    .line 364
    move-result v5

    .line 365
    invoke-static {v5}, Ljava/lang/Character;->isDigit(C)Z

    .line 368
    move-result v5

    .line 369
    if-eqz v5, :cond_178

    .line 371
    add-int/lit8 v2, v2, 0x1

    .line 373
    goto :goto_162

    .line 374
    :cond_175
    const-string v0, "This is your year as "

    .line 376
    goto :goto_190

    .line 377
    :cond_178
    const-string v2, "Last 12 months"

    .line 379
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 382
    move-result v2

    .line 383
    if-eqz v2, :cond_183

    .line 385
    const-string v0, "This is your twelve months as "

    .line 387
    goto :goto_190

    .line 388
    :cond_183
    const-string v2, "All time"

    .line 390
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 393
    move-result v0

    .line 394
    if-eqz v0, :cond_18e

    .line 396
    const-string v0, "This is all your listening as "

    .line 398
    goto :goto_190

    .line 399
    :cond_18e
    const-string v0, "This is your listening as "

    .line 401
    :goto_190
    invoke-virtual {v1, v0}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 404
    new-instance v10, Landroidx/compose/ui/text/SpanStyle;

    .line 406
    const/16 v28, 0x0

    .line 408
    const v29, 0xfffe

    .line 411
    move-object v0, v13

    .line 412
    const-wide/16 v13, 0x0

    .line 414
    move/from16 v34, v15

    .line 416
    const/4 v15, 0x0

    .line 417
    const/high16 v2, 0x3f800000    # 1.0f

    .line 419
    const/16 v16, 0x0

    .line 421
    const/16 v17, 0x0

    .line 423
    move-wide/from16 v11, v18

    .line 425
    const/16 v18, 0x0

    .line 427
    const/16 v19, 0x0

    .line 429
    const-wide/16 v20, 0x0

    .line 431
    const/16 v22, 0x0

    .line 433
    const/16 v23, 0x0

    .line 435
    const/16 v24, 0x0

    .line 437
    const-wide/16 v25, 0x0

    .line 439
    const/16 v27, 0x0

    .line 441
    invoke-direct/range {v10 .. v29}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 444
    move-wide v5, v11

    .line 445
    invoke-virtual {v1, v10}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 448
    move-result v8

    .line 449
    :try_start_1c0
    const-string v9, "a sun."

    .line 451
    invoke-virtual {v1, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_1c5
    .catchall {:try_start_1c0 .. :try_end_1c5} :catchall_27b

    .line 454
    invoke-virtual {v1, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 457
    invoke-virtual {v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 460
    move-result-object v9

    .line 461
    or-int/lit8 v1, v7, 0x36

    .line 463
    move/from16 v8, p1

    .line 465
    const/4 v7, 0x0

    .line 466
    invoke-static {v0, v7, v8, v3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 469
    move-result-object v10

    .line 470
    const/high16 v29, 0x6000000

    .line 472
    const/4 v7, 0x1

    .line 473
    const v30, 0x3fffc

    .line 476
    const-wide/16 v11, 0x0

    .line 478
    const-wide/16 v13, 0x0

    .line 480
    const/4 v15, 0x0

    .line 481
    const-wide/16 v16, 0x0

    .line 483
    const-wide/16 v18, 0x0

    .line 485
    const/16 v20, 0x0

    .line 487
    const/16 v21, 0x0

    .line 489
    const/16 v22, 0x0

    .line 491
    const/16 v23, 0x0

    .line 493
    const/16 v24, 0x0

    .line 495
    const/16 v25, 0x0

    .line 497
    sget-object v26, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 499
    const/16 v28, 0x0

    .line 501
    move-object/from16 v27, v3

    .line 503
    move v3, v7

    .line 504
    invoke-static/range {v9 .. v30}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 507
    move-object/from16 v7, v27

    .line 509
    const/16 v17, 0x0

    .line 511
    const/16 v18, 0xd

    .line 513
    const/4 v14, 0x0

    .line 514
    const/high16 v15, 0x41600000    # 14.0f

    .line 516
    const/16 v16, 0x0

    .line 518
    move-object v13, v0

    .line 519
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 522
    move-result-object v0

    .line 523
    invoke-static {v0, v3, v8, v7, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 526
    move-result-object v10

    .line 527
    invoke-static {v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 530
    move-result-wide v11

    .line 531
    const/high16 v31, 0xc00000

    .line 533
    const v32, 0x1fff8

    .line 536
    const-string v9, "Each ray is one hour of your day. Longer means you listened more. Nobody else has this one."

    .line 538
    const-wide/16 v13, 0x0

    .line 540
    const/4 v15, 0x0

    .line 541
    const/16 v16, 0x0

    .line 543
    const/16 v17, 0x0

    .line 545
    const-wide/16 v18, 0x0

    .line 547
    const/16 v20, 0x0

    .line 549
    const-wide/16 v21, 0x0

    .line 551
    const/16 v24, 0x0

    .line 553
    const/16 v25, 0x0

    .line 555
    const/16 v26, 0x0

    .line 557
    const/16 v27, 0x0

    .line 559
    sget-object v28, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 561
    const/16 v30, 0x6

    .line 563
    move-object/from16 v29, v7

    .line 565
    invoke-static/range {v9 .. v32}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 568
    move-object/from16 v9, v29

    .line 570
    invoke-virtual {v9, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 573
    new-instance v0, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 575
    invoke-direct {v0, v2, v3}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 578
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 581
    move-result-object v10

    .line 582
    const/4 v14, 0x0

    .line 583
    const/16 v15, 0xd

    .line 585
    const/4 v11, 0x0

    .line 586
    const/high16 v12, 0x41400000    # 12.0f

    .line 588
    const/4 v13, 0x0

    .line 589
    invoke-static/range {v10 .. v15}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 592
    move-result-object v10

    .line 593
    sget-object v11, Landroidx/compose/ui/Alignment$Companion;->Center:Landroidx/compose/ui/BiasAlignment;

    .line 595
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;

    .line 597
    move/from16 v12, p3

    .line 599
    move v13, v3

    .line 600
    move-wide v2, v5

    .line 601
    move-object/from16 v7, v33

    .line 603
    move/from16 v15, v34

    .line 605
    move-object/from16 v1, v35

    .line 607
    move/from16 v5, v36

    .line 609
    move-object/from16 v6, v37

    .line 611
    invoke-direct/range {v0 .. v7}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;-><init>(Landroidx/compose/animation/core/Animatable;JLcom/spotifry/music/data/spotifried/SpotifriedStats;FLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/text/TextStyle;)V

    .line 614
    move-object v6, v4

    .line 615
    const v1, -0x36adf099

    .line 618
    invoke-static {v1, v0, v9}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 621
    move-result-object v2

    .line 622
    const/16 v4, 0xc30

    .line 624
    const/4 v5, 0x4

    .line 625
    move-object v3, v9

    .line 626
    move-object v0, v10

    .line 627
    move-object v1, v11

    .line 628
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 631
    invoke-virtual {v3, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 634
    move v0, v8

    .line 635
    goto :goto_288

    .line 636
    :catchall_27b
    move-exception v0

    .line 637
    invoke-virtual {v1, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 640
    throw v0

    .line 641
    :cond_280
    move/from16 v12, p3

    .line 643
    move v15, v2

    .line 644
    move-object v6, v4

    .line 645
    move v0, v8

    .line 646
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 649
    :goto_288
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 652
    move-result-object v1

    .line 653
    if-eqz v1, :cond_295

    .line 655
    new-instance v2, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 657
    invoke-direct {v2, v6, v0, v12, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 660
    iput-object v2, v1, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 662
    :cond_295
    return-void
.end method

.method public static final TopSong(Lcom/spotifry/music/data/TopSong;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 25

    .line 1
    move-object/from16 v2, p0

    .line 3
    move/from16 v1, p1

    .line 5
    move-object/from16 v8, p2

    .line 7
    move/from16 v11, p3

    .line 9
    const v0, -0x17e552c2

    .line 12
    invoke-virtual {v8, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 15
    invoke-virtual {v8, v2}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 18
    move-result v0

    .line 19
    const/4 v3, 0x4

    .line 20
    const/4 v4, 0x2

    .line 21
    if-eqz v0, :cond_18

    .line 23
    move v0, v3

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    move v0, v4

    .line 26
    :goto_19
    or-int/2addr v0, v11

    .line 27
    invoke-virtual {v8, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v5

    .line 31
    if-eqz v5, :cond_23

    .line 33
    const/16 v5, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v5, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v5

    .line 39
    and-int/lit8 v5, v0, 0x13

    .line 41
    const/16 v6, 0x12

    .line 43
    const/4 v12, 0x1

    .line 44
    const/4 v13, 0x0

    .line 45
    if-eq v5, v6, :cond_30

    .line 47
    move v5, v12

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v5, v13

    .line 50
    :goto_31
    and-int/lit8 v6, v0, 0x1

    .line 52
    invoke-virtual {v8, v6, v5}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_169

    .line 58
    sget-object v5, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 60
    invoke-virtual {v8, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 63
    move-result-object v5

    .line 64
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 66
    iget-wide v5, v5, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 68
    iget v7, v2, Lcom/spotifry/music/data/TopSong;->plays:I

    .line 70
    and-int/lit8 v0, v0, 0x70

    .line 72
    or-int/lit16 v0, v0, 0x180

    .line 74
    const/16 v9, 0x2bc

    .line 76
    invoke-static {v7, v9, v0, v8, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countUp(IIILandroidx/compose/runtime/ComposerImpl;Z)Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 79
    move-result-object v0

    .line 80
    if-eqz v1, :cond_5f

    .line 82
    const v3, 0x386a275f

    .line 85
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 88
    invoke-virtual {v8, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 91
    move-wide v14, v5

    .line 92
    const/4 v3, 0x0

    .line 93
    const/16 v16, 0x0

    .line 95
    goto :goto_92

    .line 96
    :cond_5f
    const v7, 0x4c247b06    # 4.311759E7f

    .line 99
    invoke-virtual {v8, v7}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 102
    const-string v7, "rings"

    .line 104
    invoke-static {v7, v8, v13}, Landroidx/compose/animation/core/ArcSplineKt;->rememberInfiniteTransition(Ljava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/InfiniteTransition;

    .line 107
    move-result-object v7

    .line 108
    const/16 v9, 0xc80

    .line 110
    sget-object v10, Landroidx/compose/animation/core/EasingKt;->LinearEasing:Landroidx/collection/ArrayMap$$ExternalSyntheticBUOutline0;

    .line 112
    invoke-static {v9, v13, v10, v4}, Landroidx/compose/animation/core/ArcSplineKt;->tween$default(IILandroidx/compose/animation/core/Easing;I)Landroidx/compose/animation/core/TweenSpec;

    .line 115
    move-result-object v4

    .line 116
    sget-object v9, Landroidx/compose/animation/core/RepeatMode;->Restart:Landroidx/compose/animation/core/RepeatMode;

    .line 118
    const/16 v16, 0x0

    .line 120
    const-wide/16 v14, 0x0

    .line 122
    invoke-static {v4, v9, v14, v15, v3}, Landroidx/compose/animation/core/ArcSplineKt;->infiniteRepeatable-9IiC70o$default(Landroidx/compose/animation/core/DurationBasedAnimationSpec;Landroidx/compose/animation/core/RepeatMode;JI)Landroidx/compose/animation/core/InfiniteRepeatableSpec;

    .line 125
    move-result-object v3

    .line 126
    const/16 v9, 0x71b8

    .line 128
    const/4 v10, 0x0

    .line 129
    const/4 v4, 0x0

    .line 130
    move-wide/from16 v19, v5

    .line 132
    const/high16 v5, 0x3f800000    # 1.0f

    .line 134
    move-object v6, v3

    .line 135
    move-object v3, v7

    .line 136
    const-string v7, "ring"

    .line 138
    move-wide/from16 v14, v19

    .line 140
    invoke-static/range {v3 .. v10}, Landroidx/compose/animation/core/ArcSplineKt;->animateFloat(Landroidx/compose/animation/core/InfiniteTransition;FFLandroidx/compose/animation/core/InfiniteRepeatableSpec;Ljava/lang/String;Landroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/animation/core/InfiniteTransition$TransitionAnimationState;

    .line 143
    move-result-object v3

    .line 144
    invoke-virtual {v8, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 147
    :goto_92
    const/high16 v4, 0x41900000    # 18.0f

    .line 149
    invoke-static {v4}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    .line 152
    move-result-object v6

    .line 153
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 156
    move-result-object v4

    .line 157
    sget-object v5, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 159
    if-ne v4, v5, :cond_a7

    .line 161
    invoke-static/range {v16 .. v16}, Landroidx/compose/runtime/AnchoredGroupPath;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 164
    move-result-object v4

    .line 165
    invoke-virtual {v8, v4}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 168
    :cond_a7
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .line 170
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 173
    move-result-object v7

    .line 174
    if-ne v7, v5, :cond_b6

    .line 176
    invoke-static/range {v16 .. v16}, Landroidx/compose/runtime/AnchoredGroupPath;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 179
    move-result-object v7

    .line 180
    invoke-virtual {v8, v7}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 183
    :cond_b6
    move-object/from16 v18, v7

    .line 185
    check-cast v18, Landroidx/compose/runtime/MutableState;

    .line 187
    sget-object v7, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 189
    const/high16 v9, 0x3f800000    # 1.0f

    .line 191
    invoke-static {v7, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 194
    move-result-object v7

    .line 195
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 198
    move-result-object v9

    .line 199
    if-ne v9, v5, :cond_d2

    .line 201
    new-instance v9, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda30;

    .line 203
    const/16 v10, 0x1b

    .line 205
    invoke-direct {v9, v4, v10}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda30;-><init>(Landroidx/compose/runtime/MutableState;B)V

    .line 208
    invoke-virtual {v8, v9}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 211
    :cond_d2
    check-cast v9, Lkotlin/jvm/functions/Function1;

    .line 213
    invoke-static {v7, v9}, Landroidx/compose/ui/layout/RulerKt;->onPlaced(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 216
    move-result-object v7

    .line 217
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 220
    move-result v9

    .line 221
    invoke-virtual {v8, v14, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 224
    move-result v10

    .line 225
    or-int/2addr v9, v10

    .line 226
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 229
    move-result-object v10

    .line 230
    if-nez v9, :cond_ec

    .line 232
    if-eq v10, v5, :cond_ec

    .line 234
    move-wide/from16 v19, v14

    .line 236
    goto :goto_fb

    .line 237
    :cond_ec
    move-wide/from16 v19, v14

    .line 239
    new-instance v15, Landroidx/compose/ui/text/MultiParagraph$$ExternalSyntheticLambda0;

    .line 241
    move-object/from16 v16, v3

    .line 243
    move-object/from16 v17, v4

    .line 245
    invoke-direct/range {v15 .. v20}, Landroidx/compose/ui/text/MultiParagraph$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/animation/core/InfiniteTransition$TransitionAnimationState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;J)V

    .line 248
    invoke-virtual {v8, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 251
    move-object v10, v15

    .line 252
    :goto_fb
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 254
    invoke-static {v7, v10}, Landroidx/compose/ui/draw/ClipKt;->drawBehind(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 257
    move-result-object v3

    .line 258
    sget-object v4, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 260
    invoke-static {v4, v13}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 263
    move-result-object v4

    .line 264
    iget-wide v9, v8, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 266
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 269
    move-result v5

    .line 270
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 273
    move-result-object v7

    .line 274
    invoke-static {v8, v3}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 277
    move-result-object v3

    .line 278
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 280
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 283
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 285
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 288
    iget-boolean v10, v8, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 290
    if-eqz v10, :cond_127

    .line 292
    invoke-virtual {v8, v9}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 295
    goto :goto_12a

    .line 296
    :cond_127
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 299
    :goto_12a
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 301
    invoke-static {v8, v4, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 304
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 306
    invoke-static {v8, v7, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 309
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 311
    iget-boolean v7, v8, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 313
    if-nez v7, :cond_148

    .line 315
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 318
    move-result-object v7

    .line 319
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 322
    move-result-object v9

    .line 323
    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 326
    move-result v7

    .line 327
    if-nez v7, :cond_14b

    .line 329
    :cond_148
    invoke-static {v5, v8, v5, v4}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 332
    :cond_14b
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 334
    invoke-static {v8, v3, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 337
    move-object v7, v0

    .line 338
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;

    .line 340
    move-object/from16 v3, v18

    .line 342
    move-wide/from16 v4, v19

    .line 344
    invoke-direct/range {v0 .. v7}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;-><init>(ZLcom/spotifry/music/data/TopSong;Landroidx/compose/runtime/MutableState;JLandroidx/compose/foundation/shape/RoundedCornerShape;Lcom/spotifry/music/ui/spotifried/CountUp;)V

    .line 347
    const v3, 0x473b8ca7

    .line 350
    invoke-static {v3, v0, v8}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 353
    move-result-object v0

    .line 354
    const/4 v3, 0x6

    .line 355
    invoke-static {v0, v8, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 358
    invoke-virtual {v8, v12}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 361
    goto :goto_16d

    .line 362
    :cond_169
    const/4 v3, 0x6

    .line 363
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 366
    :goto_16d
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 369
    move-result-object v0

    .line 370
    if-eqz v0, :cond_17a

    .line 372
    new-instance v4, Landroidx/compose/material3/SliderDefaults$$ExternalSyntheticLambda4;

    .line 374
    invoke-direct {v4, v2, v1, v11, v3}, Landroidx/compose/material3/SliderDefaults$$ExternalSyntheticLambda4;-><init>(Ljava/lang/Object;ZIB)V

    .line 377
    iput-object v4, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 379
    :cond_17a
    return-void
.end method

.method public static final TopSongCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 10

    .line 1
    const v0, 0x171840ce

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    const/4 v1, 0x4

    .line 10
    if-nez v0, :cond_16

    .line 12
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_13

    .line 18
    move v0, v1

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 v0, 0x2

    .line 21
    :goto_14
    or-int/2addr v0, p3

    .line 22
    goto :goto_17

    .line 23
    :cond_16
    move v0, p3

    .line 24
    :goto_17
    and-int/lit8 v2, p3, 0x30

    .line 26
    if-nez v2, :cond_27

    .line 28
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_24

    .line 34
    const/16 v2, 0x20

    .line 36
    goto :goto_26

    .line 37
    :cond_24
    const/16 v2, 0x10

    .line 39
    :goto_26
    or-int/2addr v0, v2

    .line 40
    :cond_27
    and-int/lit8 v2, v0, 0x13

    .line 42
    const/16 v3, 0x12

    .line 44
    const/4 v4, 0x1

    .line 45
    const/4 v5, 0x0

    .line 46
    if-eq v2, v3, :cond_31

    .line 48
    move v2, v4

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v2, v5

    .line 51
    :goto_32
    and-int/2addr v0, v4

    .line 52
    invoke-virtual {p2, v0, v2}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_79

    .line 58
    iget-object v0, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->topSong:Lcom/spotifry/music/data/TopSong;

    .line 60
    if-nez v0, :cond_4b

    .line 62
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 65
    move-result-object p2

    .line 66
    if-eqz p2, :cond_88

    .line 68
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 70
    invoke-direct {v0, p0, p1, p3, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 73
    :goto_48
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 75
    return-void

    .line 76
    :cond_4b
    if-eqz p1, :cond_57

    .line 78
    const v2, -0x70a096a4

    .line 81
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 84
    :goto_53
    invoke-virtual {p2, v5}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 87
    goto :goto_62

    .line 88
    :cond_57
    const v2, -0x4df4a900

    .line 91
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 94
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 97
    move-result v4

    .line 98
    goto :goto_53

    .line 99
    :goto_62
    iget-object v2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 101
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 104
    move-result-object v3

    .line 105
    invoke-virtual {p2, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 108
    move-result-object v2

    .line 109
    const v3, -0x4df4a608

    .line 112
    invoke-virtual {p2, v3, v2}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 115
    invoke-static {v0, v4, p2, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->TopSong(Lcom/spotifry/music/data/TopSong;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 118
    invoke-virtual {p2, v5}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 121
    goto :goto_7c

    .line 122
    :cond_79
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 125
    :goto_7c
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 128
    move-result-object p2

    .line 129
    if-eqz p2, :cond_88

    .line 131
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 133
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 136
    goto :goto_48

    .line 137
    :cond_88
    return-void
.end method

.method public static final Type(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 41

    .line 1
    move-object/from16 v1, p0

    .line 3
    move/from16 v3, p2

    .line 5
    move-object/from16 v0, p5

    .line 7
    move-object/from16 v2, p6

    .line 9
    move/from16 v4, p7

    .line 11
    const v5, -0x23e16b89

    .line 14
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 17
    and-int/lit8 v5, v4, 0x6

    .line 19
    if-nez v5, :cond_1f

    .line 21
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 24
    move-result v5

    .line 25
    if-eqz v5, :cond_1c

    .line 27
    const/4 v5, 0x4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v5, 0x2

    .line 30
    :goto_1d
    or-int/2addr v5, v4

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v5, v4

    .line 33
    :goto_20
    and-int/lit8 v6, v4, 0x30

    .line 35
    if-nez v6, :cond_32

    .line 37
    move-object/from16 v9, p1

    .line 39
    invoke-virtual {v2, v9}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 42
    move-result v6

    .line 43
    if-eqz v6, :cond_2f

    .line 45
    const/16 v6, 0x20

    .line 47
    goto :goto_31

    .line 48
    :cond_2f
    const/16 v6, 0x10

    .line 50
    :goto_31
    or-int/2addr v5, v6

    .line 51
    :cond_32
    and-int/lit16 v6, v4, 0x180

    .line 53
    if-nez v6, :cond_42

    .line 55
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 58
    move-result v6

    .line 59
    if-eqz v6, :cond_3f

    .line 61
    const/16 v6, 0x100

    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    const/16 v6, 0x80

    .line 66
    :goto_41
    or-int/2addr v5, v6

    .line 67
    :cond_42
    and-int/lit16 v6, v4, 0xc00

    .line 69
    if-nez v6, :cond_54

    .line 71
    move/from16 v11, p3

    .line 73
    invoke-virtual {v2, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 76
    move-result v6

    .line 77
    if-eqz v6, :cond_51

    .line 79
    const/16 v6, 0x800

    .line 81
    goto :goto_53

    .line 82
    :cond_51
    const/16 v6, 0x400

    .line 84
    :goto_53
    or-int/2addr v5, v6

    .line 85
    :cond_54
    and-int/lit16 v6, v4, 0x6000

    .line 87
    if-nez v6, :cond_66

    .line 89
    move/from16 v12, p4

    .line 91
    invoke-virtual {v2, v12}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 94
    move-result v6

    .line 95
    if-eqz v6, :cond_63

    .line 97
    const/16 v6, 0x4000

    .line 99
    goto :goto_65

    .line 100
    :cond_63
    const/16 v6, 0x2000

    .line 102
    :goto_65
    or-int/2addr v5, v6

    .line 103
    :cond_66
    const/high16 v6, 0x30000

    .line 105
    and-int/2addr v6, v4

    .line 106
    if-nez v6, :cond_77

    .line 108
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 111
    move-result v6

    .line 112
    if-eqz v6, :cond_74

    .line 114
    const/high16 v6, 0x20000

    .line 116
    goto :goto_76

    .line 117
    :cond_74
    const/high16 v6, 0x10000

    .line 119
    :goto_76
    or-int/2addr v5, v6

    .line 120
    :cond_77
    const v6, 0x12493

    .line 123
    and-int/2addr v6, v5

    .line 124
    const v7, 0x12492

    .line 127
    if-eq v6, v7, :cond_82

    .line 129
    const/4 v6, 0x1

    .line 130
    goto :goto_83

    .line 131
    :cond_82
    const/4 v6, 0x0

    .line 132
    :goto_83
    and-int/lit8 v7, v5, 0x1

    .line 134
    invoke-virtual {v2, v7, v6}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 137
    move-result v6

    .line 138
    if-eqz v6, :cond_3df

    .line 140
    sget-object v6, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 142
    invoke-virtual {v2, v6}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 145
    move-result-object v7

    .line 146
    check-cast v7, Landroidx/compose/material3/ColorScheme;

    .line 148
    iget-wide v13, v7, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 150
    invoke-virtual {v2, v6}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 153
    move-result-object v6

    .line 154
    check-cast v6, Landroidx/compose/material3/ColorScheme;

    .line 156
    iget-wide v6, v6, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 158
    iget-wide v8, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 160
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->listenerType(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)Lcom/spotifry/music/data/spotifried/ListenerType;

    .line 163
    move-result-object v15

    .line 164
    sget-object v10, Lcom/spotifry/music/data/spotifried/ListenerType;->REGULAR:Lcom/spotifry/music/data/spotifried/ListenerType;

    .line 166
    if-ne v15, v10, :cond_b8

    .line 168
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->peakHour(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)I

    .line 171
    move-result v10

    .line 172
    invoke-static {v10}, Lcom/spotifry/music/data/Log;->hourKind(I)Ljava/lang/String;

    .line 175
    move-result-object v10

    .line 176
    const-string v15, "The "

    .line 178
    const-string v4, " Regular"

    .line 180
    invoke-static {v15, v10, v4}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 183
    move-result-object v4

    .line 184
    goto :goto_ba

    .line 185
    :cond_b8
    iget-object v4, v15, Lcom/spotifry/music/data/spotifried/ListenerType;->title:Ljava/lang/String;

    .line 187
    :goto_ba
    const-string v10, "."

    .line 189
    invoke-virtual {v4, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 192
    move-result-object v4

    .line 193
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 196
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 199
    move-result v15

    .line 200
    if-nez v15, :cond_ce

    .line 202
    const-string v15, "You are"

    .line 204
    :goto_cb
    move-object/from16 v18, v15

    .line 206
    goto :goto_d5

    .line 207
    :cond_ce
    const-string v15, ", you are"

    .line 209
    invoke-virtual {v0, v15}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 212
    move-result-object v15

    .line 213
    goto :goto_cb

    .line 214
    :goto_d5
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 217
    move-result v15

    .line 218
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 221
    move-result-object v0

    .line 222
    move-object/from16 v19, v4

    .line 224
    sget-object v4, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 226
    move/from16 v20, v5

    .line 228
    if-nez v15, :cond_f1

    .line 230
    if-eq v0, v4, :cond_f1

    .line 232
    move-object/from16 v30, v4

    .line 234
    move-wide/from16 v23, v6

    .line 236
    move-wide/from16 v26, v8

    .line 238
    move-wide/from16 v28, v13

    .line 240
    goto/16 :goto_319

    .line 242
    :cond_f1
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->listenerType(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)Lcom/spotifry/music/data/spotifried/ListenerType;

    .line 245
    move-result-object v0

    .line 246
    iget v15, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->plays:I

    .line 248
    iget v5, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->newSongs:I

    .line 250
    move-object/from16 v22, v0

    .line 252
    iget-object v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->age:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 254
    move-wide/from16 v23, v6

    .line 256
    iget v6, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->replayedSongs:I

    .line 258
    iget v7, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->songs:I

    .line 260
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->peakHour(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)I

    .line 263
    move-result v25

    .line 264
    move-wide/from16 v26, v8

    .line 266
    invoke-static/range {v25 .. v25}, Lcom/spotifry/music/data/Log;->hourName(I)Ljava/lang/String;

    .line 269
    move-result-object v8

    .line 270
    const-string v9, "Your busiest hour was "

    .line 272
    invoke-virtual {v9, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 275
    move-result-object v8

    .line 276
    invoke-virtual {v8, v10}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 279
    move-result v9

    .line 280
    if-nez v9, :cond_11d

    .line 282
    invoke-virtual {v8, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 285
    move-result-object v8

    .line 286
    :cond_11d
    sget-object v9, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 288
    iget-object v11, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->daySeconds:Ljava/util/List;

    .line 290
    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->maxOrNull(Ljava/lang/Iterable;)Ljava/lang/Comparable;

    .line 293
    move-result-object v11

    .line 294
    check-cast v11, Ljava/lang/Long;

    .line 296
    if-eqz v11, :cond_130

    .line 298
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    .line 301
    move-result-wide v28

    .line 302
    :goto_12d
    move-wide/from16 v11, v28

    .line 304
    goto :goto_133

    .line 305
    :cond_130
    const-wide/16 v28, 0x0

    .line 307
    goto :goto_12d

    .line 308
    :goto_133
    long-to-double v11, v11

    .line 309
    const-wide v28, 0x40ac200000000000L    # 3600.0

    .line 314
    div-double v11, v11, v28

    .line 316
    invoke-static {v11, v12}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 319
    move-result-object v11

    .line 320
    filled-new-array {v11}, [Ljava/lang/Object;

    .line 323
    move-result-object v11

    .line 324
    const/4 v12, 0x1

    .line 325
    invoke-static {v11, v12}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 328
    move-result-object v11

    .line 329
    const-string v12, "%.1f"

    .line 331
    invoke-static {v9, v12, v11}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 334
    move-result-object v9

    .line 335
    const-string v11, "song"

    .line 337
    invoke-static {v15, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 340
    move-result-object v12

    .line 341
    move-wide/from16 v28, v13

    .line 343
    const-string v13, "You played "

    .line 345
    const-string v14, " in total."

    .line 347
    invoke-static {v13, v12, v14}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 350
    move-result-object v12

    .line 351
    invoke-virtual/range {v22 .. v22}, Ljava/lang/Enum;->ordinal()I

    .line 354
    move-result v22

    .line 355
    const/high16 v25, 0x42c80000    # 100.0f

    .line 357
    move-object/from16 v30, v4

    .line 359
    const-string v4, " of "

    .line 361
    const-string v3, "You replayed "

    .line 363
    const-string v2, " hours of music."

    .line 365
    move-object/from16 v31, v0

    .line 367
    const-string v0, "Your longest day was "

    .line 369
    move/from16 v32, v6

    .line 371
    const-string v6, "different song"

    .line 373
    packed-switch v22, :pswitch_data_400

    .line 376
    invoke-static {}, Landroidx/media3/session/MediaSessionStub$$ExternalSyntheticLambda8;->m()V

    .line 379
    return-void

    .line 380
    :pswitch_17b
    invoke-static {v15, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 383
    move-result-object v0

    .line 384
    invoke-static {v13, v0, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 387
    move-result-object v0

    .line 388
    invoke-static {v7, v6}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 391
    move-result-object v2

    .line 392
    if-nez v32, :cond_18c

    .line 394
    const-string v3, "none came back."

    .line 396
    goto :goto_196

    .line 397
    :cond_18c
    invoke-static/range {v32 .. v32}, Lkotlin/io/ByteStreamsKt;->num(I)Ljava/lang/String;

    .line 400
    move-result-object v3

    .line 401
    const-string v4, " came back."

    .line 403
    invoke-virtual {v3, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 406
    move-result-object v3

    .line 407
    :goto_196
    const-string v4, "That was "

    .line 409
    const-string v5, ", and "

    .line 411
    invoke-static {v4, v2, v5, v3}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 414
    move-result-object v2

    .line 415
    filled-new-array {v8, v0, v2}, [Ljava/lang/String;

    .line 418
    move-result-object v0

    .line 419
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 422
    move-result-object v0

    .line 423
    :goto_1a6
    move-object/from16 v2, p6

    .line 425
    goto/16 :goto_316

    .line 427
    :pswitch_1aa
    iget v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->earlyShare:F

    .line 429
    mul-float v0, v0, v25

    .line 431
    invoke-static {v0}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 434
    move-result v0

    .line 435
    const-string v2, "% of your plays started before 9 a.m."

    .line 437
    invoke-static {v0, v2}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 440
    move-result-object v0

    .line 441
    filled-new-array {v0, v8, v12}, [Ljava/lang/String;

    .line 444
    move-result-object v0

    .line 445
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 448
    move-result-object v0

    .line 449
    goto :goto_1a6

    .line 450
    :pswitch_1c1
    invoke-static {v0, v9, v2}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 453
    move-result-object v0

    .line 454
    const-wide/16 v2, 0xe10

    .line 456
    div-long v8, v26, v2

    .line 458
    long-to-int v2, v8

    .line 459
    const-string v3, "hour"

    .line 461
    invoke-static {v2, v3}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 464
    move-result-object v2

    .line 465
    const-string v3, "In all you listened for "

    .line 467
    invoke-static {v3, v2, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 470
    move-result-object v2

    .line 471
    filled-new-array {v0, v2, v12}, [Ljava/lang/String;

    .line 474
    move-result-object v0

    .line 475
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 478
    move-result-object v0

    .line 479
    goto :goto_1a6

    .line 480
    :pswitch_1df
    iget-object v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->topArtist:Lcom/spotifry/music/data/spotifried/ArtistShare;

    .line 482
    if-eqz v0, :cond_1e7

    .line 484
    iget-object v2, v0, Lcom/spotifry/music/data/spotifried/ArtistShare;->name:Ljava/lang/String;

    .line 486
    if-nez v2, :cond_1e9

    .line 488
    :cond_1e7
    const-string v2, "One artist"

    .line 490
    :cond_1e9
    if-eqz v0, :cond_1ee

    .line 492
    iget v0, v0, Lcom/spotifry/music/data/spotifried/ArtistShare;->share:F

    .line 494
    goto :goto_1ef

    .line 495
    :cond_1ee
    const/4 v0, 0x0

    .line 496
    :goto_1ef
    mul-float v0, v0, v25

    .line 498
    invoke-static {v0}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 501
    move-result v0

    .line 502
    new-instance v4, Ljava/lang/StringBuilder;

    .line 504
    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 507
    const-string v2, " took "

    .line 509
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 512
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 515
    const-string v0, "% of your listening."

    .line 517
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 520
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 523
    move-result-object v0

    .line 524
    invoke-static {v7, v6}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 527
    move-result-object v2

    .line 528
    invoke-static {v13, v2, v14}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 531
    move-result-object v2

    .line 532
    if-nez v32, :cond_218

    .line 534
    const-string v3, "You never replayed any of them."

    .line 536
    goto :goto_222

    .line 537
    :cond_218
    invoke-static/range {v32 .. v32}, Lkotlin/io/ByteStreamsKt;->num(I)Ljava/lang/String;

    .line 540
    move-result-object v4

    .line 541
    const-string v5, " of them."

    .line 543
    invoke-static {v3, v4, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 546
    move-result-object v3

    .line 547
    :goto_222
    filled-new-array {v0, v2, v3}, [Ljava/lang/String;

    .line 550
    move-result-object v0

    .line 551
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 554
    move-result-object v0

    .line 555
    goto/16 :goto_1a6

    .line 557
    :pswitch_22c
    invoke-static {v5}, Lkotlin/io/ByteStreamsKt;->num(I)Ljava/lang/String;

    .line 560
    move-result-object v0

    .line 561
    invoke-static {v7, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 564
    move-result-object v2

    .line 565
    const/4 v12, 0x1

    .line 566
    if-ne v5, v12, :cond_23a

    .line 568
    const-string v3, "was"

    .line 570
    goto :goto_23c

    .line 571
    :cond_23a
    const-string v3, "were"

    .line 573
    :goto_23c
    const-string v6, " "

    .line 575
    invoke-static {v0, v4, v2, v6, v3}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 578
    move-result-object v0

    .line 579
    const-string v2, " new to you."

    .line 581
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 584
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 587
    move-result-object v0

    .line 588
    if-nez v7, :cond_24f

    .line 590
    const/4 v15, 0x0

    .line 591
    goto :goto_258

    .line 592
    :cond_24f
    int-to-float v2, v5

    .line 593
    int-to-float v3, v7

    .line 594
    div-float/2addr v2, v3

    .line 595
    mul-float v2, v2, v25

    .line 597
    invoke-static {v2}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 600
    move-result v15

    .line 601
    :goto_258
    const-string v2, "That is "

    .line 603
    const-string v3, "% fresh music."

    .line 605
    invoke-static {v15, v2, v3}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 608
    move-result-object v2

    .line 609
    if-nez v32, :cond_265

    .line 611
    const-string v3, "None of your songs got a replay."

    .line 613
    goto :goto_273

    .line 614
    :cond_265
    move/from16 v4, v32

    .line 616
    invoke-static {v4, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 619
    move-result-object v3

    .line 620
    const-string v4, "Only "

    .line 622
    const-string v5, " got a replay."

    .line 624
    invoke-static {v4, v3, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 627
    move-result-object v3

    .line 628
    :goto_273
    filled-new-array {v0, v2, v3}, [Ljava/lang/String;

    .line 631
    move-result-object v0

    .line 632
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 635
    move-result-object v0

    .line 636
    goto/16 :goto_1a6

    .line 638
    :pswitch_27d
    iget v3, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->longestStreak:I

    .line 640
    const-string v4, "day"

    .line 642
    invoke-static {v3, v4}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 645
    move-result-object v3

    .line 646
    const-string v4, "You listened "

    .line 648
    const-string v5, " in a row."

    .line 650
    invoke-static {v4, v3, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 653
    move-result-object v3

    .line 654
    invoke-static {v0, v9, v2}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 657
    move-result-object v0

    .line 658
    filled-new-array {v3, v12, v0}, [Ljava/lang/String;

    .line 661
    move-result-object v0

    .line 662
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 665
    move-result-object v0

    .line 666
    goto/16 :goto_1a6

    .line 668
    :pswitch_29b
    move-object/from16 v0, v31

    .line 670
    iget-object v2, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->typicalYear:Ljava/lang/Integer;

    .line 672
    if-nez v2, :cond_2a3

    .line 674
    const-string v2, "an unknown year"

    .line 676
    :cond_2a3
    new-instance v3, Ljava/lang/StringBuilder;

    .line 678
    const-string v5, "A typical song of yours came out in "

    .line 680
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 683
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 686
    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 689
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 692
    move-result-object v2

    .line 693
    iget v3, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->songsWithYear:I

    .line 695
    invoke-static {v3}, Lkotlin/io/ByteStreamsKt;->num(I)Ljava/lang/String;

    .line 698
    move-result-object v3

    .line 699
    iget v5, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->songsTotal:I

    .line 701
    invoke-static {v5, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 704
    move-result-object v5

    .line 705
    const-string v6, "Release years are known for "

    .line 707
    invoke-static {v6, v3, v4, v5, v10}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 710
    move-result-object v3

    .line 711
    iget-object v4, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->oldestYear:Ljava/lang/Integer;

    .line 713
    if-eqz v4, :cond_2d5

    .line 715
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 718
    move-result v0

    .line 719
    const-string v4, "Your oldest song is from "

    .line 721
    invoke-static {v0, v4, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 724
    move-result-object v0

    .line 725
    goto :goto_2e5

    .line 726
    :cond_2d5
    iget-object v0, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->age:Ljava/lang/Integer;

    .line 728
    if-eqz v0, :cond_2de

    .line 730
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 733
    move-result v15

    .line 734
    goto :goto_2df

    .line 735
    :cond_2de
    const/4 v15, 0x0

    .line 736
    :goto_2df
    const-string v0, "Your listening age is "

    .line 738
    invoke-static {v15, v0, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 741
    move-result-object v0

    .line 742
    :goto_2e5
    filled-new-array {v2, v3, v0}, [Ljava/lang/String;

    .line 745
    move-result-object v0

    .line 746
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 749
    move-result-object v0

    .line 750
    goto/16 :goto_1a6

    .line 752
    :pswitch_2ef
    move/from16 v4, v32

    .line 754
    iget v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->nightShare:F

    .line 756
    mul-float v0, v0, v25

    .line 758
    invoke-static {v0}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 761
    move-result v0

    .line 762
    const-string v2, "% of your plays started between midnight and 5 a.m."

    .line 764
    invoke-static {v0, v2}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 767
    move-result-object v0

    .line 768
    if-nez v4, :cond_304

    .line 770
    const-string v2, "You never replayed a song."

    .line 772
    goto :goto_30c

    .line 773
    :cond_304
    invoke-static {v4, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 776
    move-result-object v2

    .line 777
    invoke-static {v3, v2, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 780
    move-result-object v2

    .line 781
    :goto_30c
    filled-new-array {v0, v2, v8}, [Ljava/lang/String;

    .line 784
    move-result-object v0

    .line 785
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 788
    move-result-object v0

    .line 789
    goto/16 :goto_1a6

    .line 791
    :goto_316
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 794
    :goto_319
    move-object/from16 v17, v0

    .line 796
    check-cast v17, Ljava/util/List;

    .line 798
    invoke-static/range {v26 .. v27}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 801
    move-result v0

    .line 802
    invoke-static {v0}, Lcom/spotifry/music/data/Log;->sunScale(I)F

    .line 805
    move-result v0

    .line 806
    iget-object v3, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 808
    move/from16 v4, p2

    .line 810
    invoke-static {v3, v0, v4, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rememberSunMotion(Ljava/util/List;FZLandroidx/compose/runtime/ComposerImpl;)Lcom/spotifry/music/ui/listening/SunMotion;

    .line 813
    move-result-object v8

    .line 814
    shr-int/lit8 v5, v20, 0x6

    .line 816
    and-int/lit8 v5, v5, 0xe

    .line 818
    or-int/lit16 v5, v5, 0x1b0

    .line 820
    const/16 v3, 0x578

    .line 822
    const/4 v15, 0x0

    .line 823
    invoke-static {v15, v3, v5, v2, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 826
    move-result-object v3

    .line 827
    const/16 v6, 0x76c

    .line 829
    const/16 v7, 0x320

    .line 831
    invoke-static {v6, v7, v5, v2, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 834
    move-result-object v10

    .line 835
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 838
    move-result-object v5

    .line 839
    move-object/from16 v6, v30

    .line 841
    if-ne v5, v6, :cond_356

    .line 843
    new-instance v5, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda11;

    .line 845
    invoke-direct {v5, v10, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda11;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 848
    invoke-static {v5}, Landroidx/compose/runtime/SnapshotStateKt__DerivedStateKt;->derivedStateOf(Lkotlin/jvm/functions/Function0;)Landroidx/compose/runtime/DerivedSnapshotState;

    .line 851
    move-result-object v5

    .line 852
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 855
    :cond_356
    move-object/from16 v20, v5

    .line 857
    check-cast v20, Landroidx/compose/runtime/State;

    .line 859
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 862
    move-result-object v5

    .line 863
    if-ne v5, v6, :cond_36a

    .line 865
    new-instance v5, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 867
    const-wide/16 v11, -0x3e8

    .line 869
    invoke-direct {v5, v11, v12}, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;-><init>(J)V

    .line 872
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 875
    :cond_36a
    check-cast v5, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 877
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 880
    move-result-object v7

    .line 881
    if-ne v7, v6, :cond_37c

    .line 883
    new-instance v7, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 885
    const/4 v9, 0x0

    .line 886
    invoke-direct {v7, v9}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;-><init>(F)V

    .line 889
    invoke-virtual {v2, v7}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 892
    goto :goto_37d

    .line 893
    :cond_37c
    const/4 v9, 0x0

    .line 894
    :goto_37d
    check-cast v7, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 896
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 899
    move-result-object v11

    .line 900
    if-ne v11, v6, :cond_38d

    .line 902
    new-instance v11, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 904
    invoke-direct {v11, v9}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;-><init>(F)V

    .line 907
    invoke-virtual {v2, v11}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 910
    :cond_38d
    check-cast v11, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 912
    sget-object v9, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 914
    const/high16 v12, 0x3f800000    # 1.0f

    .line 916
    invoke-static {v9, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 919
    move-result-object v9

    .line 920
    invoke-static {v9}, Landroidx/compose/ui/draw/ClipKt;->clipToBounds(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 923
    move-result-object v9

    .line 924
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 927
    move-result-object v12

    .line 928
    if-ne v12, v6, :cond_3aa

    .line 930
    new-instance v12, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda12;

    .line 932
    const/4 v15, 0x0

    .line 933
    invoke-direct {v12, v7, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda12;-><init>(Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;B)V

    .line 936
    invoke-virtual {v2, v12}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 939
    :cond_3aa
    check-cast v12, Lkotlin/jvm/functions/Function1;

    .line 941
    invoke-static {v9, v12}, Landroidx/compose/ui/layout/RulerKt;->onGloballyPositioned(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 944
    move-result-object v21

    .line 945
    move v2, v0

    .line 946
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;

    .line 948
    move-object/from16 v9, p1

    .line 950
    move/from16 v12, p4

    .line 952
    move-object/from16 v16, v18

    .line 954
    move-object/from16 v15, v19

    .line 956
    move-wide/from16 v13, v23

    .line 958
    move/from16 v18, v4

    .line 960
    move-object/from16 v19, v5

    .line 962
    move-object v5, v7

    .line 963
    move-object v4, v11

    .line 964
    move-wide/from16 v6, v28

    .line 966
    move/from16 v11, p3

    .line 968
    invoke-direct/range {v0 .. v20}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;FLandroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;JLcom/spotifry/music/ui/listening/SunMotion;Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/core/Animatable;ZZJLjava/lang/String;Ljava/lang/String;Ljava/util/List;ZLandroidx/compose/runtime/ParcelableSnapshotMutableLongState;Landroidx/compose/runtime/State;)V

    .line 971
    const v1, 0x3af60bcd

    .line 974
    move-object/from16 v2, p6

    .line 976
    invoke-static {v1, v0, v2}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 979
    move-result-object v0

    .line 980
    const/16 v4, 0xc06

    .line 982
    const/4 v5, 0x6

    .line 983
    const/4 v1, 0x0

    .line 984
    move-object v3, v2

    .line 985
    move-object v2, v0

    .line 986
    move-object/from16 v0, v21

    .line 988
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 991
    goto :goto_3e2

    .line 992
    :cond_3df
    invoke-virtual/range {p6 .. p6}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 995
    :goto_3e2
    invoke-virtual/range {p6 .. p6}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 998
    move-result-object v9

    .line 999
    if-eqz v9, :cond_3fe

    .line 1001
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;

    .line 1003
    const/4 v8, 0x1

    .line 1004
    move-object/from16 v1, p0

    .line 1006
    move-object/from16 v2, p1

    .line 1008
    move/from16 v3, p2

    .line 1010
    move/from16 v4, p3

    .line 1012
    move/from16 v5, p4

    .line 1014
    move-object/from16 v6, p5

    .line 1016
    move/from16 v7, p7

    .line 1018
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;IB)V

    .line 1021
    iput-object v0, v9, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 1023
    :cond_3fe
    return-void

    nop

    .line 1025
    :pswitch_data_400
    .packed-switch 0x0
        :pswitch_2ef
        :pswitch_29b
        :pswitch_27d
        :pswitch_22c
        :pswitch_1df
        :pswitch_1c1
        :pswitch_1aa
        :pswitch_17b
    .end packed-switch
.end method

.method public static final Type$lambda$235$lambda$234$lambda$220$factStyle(F)Landroidx/compose/ui/text/TextStyle;
    .registers 18

    .line 1
    sget-object v1, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 3
    iget-object v0, v1, Landroidx/compose/ui/text/TextStyle;->spanStyle:Landroidx/compose/ui/text/SpanStyle;

    .line 5
    iget-wide v2, v0, Landroidx/compose/ui/text/SpanStyle;->fontSize:J

    .line 7
    invoke-static {v2, v3}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 10
    const-wide v4, 0xff00000000L

    .line 15
    and-long v6, v2, v4

    .line 17
    invoke-static {v2, v3}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 20
    move-result v0

    .line 21
    mul-float v0, v0, p0

    .line 23
    invoke-static {v0, v6, v7}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 26
    move-result-wide v2

    .line 27
    const/16 v0, 0x14

    .line 29
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 32
    move-result-wide v6

    .line 33
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 36
    and-long/2addr v4, v6

    .line 37
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 40
    move-result v0

    .line 41
    mul-float v0, v0, p0

    .line 43
    invoke-static {v0, v4, v5}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 46
    move-result-wide v12

    .line 47
    const/4 v15, 0x0

    .line 48
    const v16, 0xfdfffd

    .line 51
    move-wide v4, v2

    .line 52
    const-wide/16 v2, 0x0

    .line 54
    const/4 v6, 0x0

    .line 55
    const/4 v7, 0x0

    .line 56
    const/4 v8, 0x0

    .line 57
    const-wide/16 v9, 0x0

    .line 59
    const/4 v11, 0x0

    .line 60
    const/4 v14, 0x0

    .line 61
    invoke-static/range {v1 .. v16}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 64
    move-result-object v0

    .line 65
    return-object v0
.end method

.method public static final Type$lambda$235$lambda$234$lambda$220$titleStyle(Landroidx/compose/ui/text/TextStyle;FF)Landroidx/compose/ui/text/TextStyle;
    .registers 20

    .line 1
    move-object/from16 v1, p0

    .line 3
    iget-object v0, v1, Landroidx/compose/ui/text/TextStyle;->spanStyle:Landroidx/compose/ui/text/SpanStyle;

    .line 5
    iget-wide v2, v0, Landroidx/compose/ui/text/SpanStyle;->fontSize:J

    .line 7
    invoke-static {v2, v3}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 10
    const-wide v4, 0xff00000000L

    .line 15
    and-long v6, v2, v4

    .line 17
    invoke-static {v2, v3}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 20
    move-result v2

    .line 21
    mul-float v2, v2, p1

    .line 23
    invoke-static {v2, v6, v7}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 26
    move-result-wide v2

    .line 27
    invoke-static {v2, v3}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 30
    and-long v6, v2, v4

    .line 32
    invoke-static {v2, v3}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 35
    move-result v2

    .line 36
    mul-float v2, v2, p2

    .line 38
    invoke-static {v2, v6, v7}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 41
    move-result-wide v2

    .line 42
    iget-object v6, v1, Landroidx/compose/ui/text/TextStyle;->paragraphStyle:Landroidx/compose/ui/text/ParagraphStyle;

    .line 44
    iget-wide v6, v6, Landroidx/compose/ui/text/ParagraphStyle;->lineHeight:J

    .line 46
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 49
    and-long v8, v6, v4

    .line 51
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 54
    move-result v6

    .line 55
    mul-float v6, v6, p1

    .line 57
    invoke-static {v6, v8, v9}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 60
    move-result-wide v6

    .line 61
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 64
    and-long v8, v6, v4

    .line 66
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 69
    move-result v6

    .line 70
    mul-float v6, v6, p2

    .line 72
    invoke-static {v6, v8, v9}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 75
    move-result-wide v12

    .line 76
    iget-wide v6, v0, Landroidx/compose/ui/text/SpanStyle;->letterSpacing:J

    .line 78
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 81
    and-long v8, v6, v4

    .line 83
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 86
    move-result v0

    .line 87
    mul-float v0, v0, p1

    .line 89
    invoke-static {v0, v8, v9}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 92
    move-result-wide v6

    .line 93
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 96
    and-long/2addr v4, v6

    .line 97
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 100
    move-result v0

    .line 101
    mul-float v0, v0, p2

    .line 103
    invoke-static {v0, v4, v5}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 106
    move-result-wide v9

    .line 107
    const/4 v15, 0x0

    .line 108
    const v16, 0xfdff7d

    .line 111
    move-wide v4, v2

    .line 112
    const-wide/16 v2, 0x0

    .line 114
    const/4 v6, 0x0

    .line 115
    const/4 v7, 0x0

    .line 116
    const/4 v8, 0x0

    .line 117
    const/4 v11, 0x0

    .line 118
    const/4 v14, 0x0

    .line 119
    invoke-static/range {v1 .. v16}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 122
    move-result-object v0

    .line 123
    return-object v0
.end method

.method public static final TypeCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 18

    .line 1
    move-object/from16 v6, p6

    .line 3
    move/from16 v8, p7

    .line 5
    const v0, -0x1fe5a0b9

    .line 8
    invoke-virtual {v6, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 11
    and-int/lit8 v0, v8, 0x6

    .line 13
    if-nez v0, :cond_19

    .line 15
    invoke-virtual {v6, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_16

    .line 21
    const/4 v0, 0x4

    .line 22
    goto :goto_17

    .line 23
    :cond_16
    const/4 v0, 0x2

    .line 24
    :goto_17
    or-int/2addr v0, v8

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    move v0, v8

    .line 27
    :goto_1a
    and-int/lit8 v1, v8, 0x30

    .line 29
    if-nez v1, :cond_2a

    .line 31
    invoke-virtual {v6, p1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_27

    .line 37
    const/16 v1, 0x20

    .line 39
    goto :goto_29

    .line 40
    :cond_27
    const/16 v1, 0x10

    .line 42
    :goto_29
    or-int/2addr v0, v1

    .line 43
    :cond_2a
    and-int/lit16 v1, v8, 0x180

    .line 45
    if-nez v1, :cond_3a

    .line 47
    invoke-virtual {v6, p2}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_37

    .line 53
    const/16 v1, 0x100

    .line 55
    goto :goto_39

    .line 56
    :cond_37
    const/16 v1, 0x80

    .line 58
    :goto_39
    or-int/2addr v0, v1

    .line 59
    :cond_3a
    and-int/lit16 v1, v8, 0xc00

    .line 61
    if-nez v1, :cond_4a

    .line 63
    invoke-virtual {v6, p3}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 66
    move-result v1

    .line 67
    if-eqz v1, :cond_47

    .line 69
    const/16 v1, 0x800

    .line 71
    goto :goto_49

    .line 72
    :cond_47
    const/16 v1, 0x400

    .line 74
    :goto_49
    or-int/2addr v0, v1

    .line 75
    :cond_4a
    and-int/lit16 v1, v8, 0x6000

    .line 77
    if-nez v1, :cond_5a

    .line 79
    invoke-virtual {v6, p4}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 82
    move-result v1

    .line 83
    if-eqz v1, :cond_57

    .line 85
    const/16 v1, 0x4000

    .line 87
    goto :goto_59

    .line 88
    :cond_57
    const/16 v1, 0x2000

    .line 90
    :goto_59
    or-int/2addr v0, v1

    .line 91
    :cond_5a
    const/high16 v1, 0x30000

    .line 93
    and-int/2addr v1, v8

    .line 94
    if-nez v1, :cond_6b

    .line 96
    invoke-virtual {v6, p5}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 99
    move-result v1

    .line 100
    if-eqz v1, :cond_68

    .line 102
    const/high16 v1, 0x20000

    .line 104
    goto :goto_6a

    .line 105
    :cond_68
    const/high16 v1, 0x10000

    .line 107
    :goto_6a
    or-int/2addr v0, v1

    .line 108
    :cond_6b
    const v1, 0x12493

    .line 111
    and-int/2addr v1, v0

    .line 112
    const v2, 0x12492

    .line 115
    const/4 v7, 0x1

    .line 116
    const/4 v9, 0x0

    .line 117
    if-eq v1, v2, :cond_78

    .line 119
    move v1, v7

    .line 120
    goto :goto_79

    .line 121
    :cond_78
    move v1, v9

    .line 122
    :goto_79
    and-int/lit8 v2, v0, 0x1

    .line 124
    invoke-virtual {v6, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 127
    move-result v1

    .line 128
    if-eqz v1, :cond_ba

    .line 130
    if-eqz p2, :cond_8e

    .line 132
    const v1, 0x1cf86923

    .line 135
    invoke-virtual {v6, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 138
    :goto_89
    invoke-virtual {v6, v9}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 141
    move v2, v7

    .line 142
    goto :goto_99

    .line 143
    :cond_8e
    const v1, 0x42ffc259

    .line 146
    invoke-virtual {v6, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 149
    invoke-static {v6}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 152
    move-result v7

    .line 153
    goto :goto_89

    .line 154
    :goto_99
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 156
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 159
    move-result-object v7

    .line 160
    invoke-virtual {v6, v1, v7}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 163
    move-result-object v1

    .line 164
    const v7, 0x42ffc56c

    .line 167
    invoke-virtual {v6, v7, v1}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 170
    const v1, 0x7fc7e

    .line 173
    and-int v7, v0, v1

    .line 175
    move-object v0, p0

    .line 176
    move-object v1, p1

    .line 177
    move v3, p3

    .line 178
    move v4, p4

    .line 179
    move-object v5, p5

    .line 180
    invoke-static/range {v0 .. v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 183
    invoke-virtual {v6, v9}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 186
    goto :goto_bd

    .line 187
    :cond_ba
    invoke-virtual {v6}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 190
    :goto_bd
    invoke-virtual {v6}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 193
    move-result-object v9

    .line 194
    if-eqz v9, :cond_d3

    .line 196
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;

    .line 198
    const/4 v8, 0x0

    .line 199
    move-object v1, p0

    .line 200
    move-object v2, p1

    .line 201
    move v3, p2

    .line 202
    move v4, p3

    .line 203
    move v5, p4

    .line 204
    move-object v6, p5

    .line 205
    move/from16 v7, p7

    .line 207
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;IB)V

    .line 210
    iput-object v0, v9, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 212
    :cond_d3
    return-void
.end method

.method public static final clock(ZFLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/Animatable;
    .registers 9

    .line 1
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 7
    if-ne v0, v1, :cond_14

    .line 9
    if-eqz p0, :cond_c

    .line 11
    move p0, p1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 p0, 0x0

    .line 14
    :goto_d
    invoke-static {p0}, Landroidx/compose/animation/core/ArcSplineKt;->Animatable$default(F)Landroidx/compose/animation/core/Animatable;

    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 21
    :cond_14
    check-cast v0, Landroidx/compose/animation/core/Animatable;

    .line 23
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 26
    move-result p0

    .line 27
    and-int/lit8 v2, p3, 0x70

    .line 29
    xor-int/lit8 v2, v2, 0x30

    .line 31
    const/4 v3, 0x0

    .line 32
    const/16 v4, 0x20

    .line 34
    if-le v2, v4, :cond_29

    .line 36
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 39
    move-result v2

    .line 40
    if-nez v2, :cond_2d

    .line 42
    :cond_29
    and-int/lit8 p3, p3, 0x30

    .line 44
    if-ne p3, v4, :cond_2f

    .line 46
    :cond_2d
    const/4 p3, 0x1

    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move p3, v3

    .line 49
    :goto_30
    or-int/2addr p0, p3

    .line 50
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 53
    move-result-object p3

    .line 54
    if-nez p0, :cond_39

    .line 56
    if-ne p3, v1, :cond_42

    .line 58
    :cond_39
    new-instance p3, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;

    .line 60
    const/4 p0, 0x0

    .line 61
    invoke-direct {p3, v0, p1, p0, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;-><init>(Ljava/lang/Object;FLkotlin/coroutines/Continuation;B)V

    .line 64
    invoke-virtual {p2, p3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 67
    :cond_42
    check-cast p3, Lkotlin/jvm/functions/Function2;

    .line 69
    invoke-static {p2, v0, p3}, Landroidx/compose/runtime/AnchoredGroupPath;->LaunchedEffect(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 72
    return-object v0
.end method

.method public static final countSpan(Landroidx/compose/ui/text/AnnotatedString$Builder;Lcom/spotifry/music/ui/spotifried/CountUp;Landroidx/compose/ui/text/SpanStyle;Ljava/lang/String;)V
    .registers 6

    .line 1
    iget-boolean p1, p1, Lcom/spotifry/music/ui/spotifried/CountUp;->started:Z

    .line 3
    if-nez p1, :cond_d

    .line 5
    sget-wide v0, Landroidx/compose/ui/graphics/Color;->Transparent:J

    .line 7
    const p1, 0xfffe

    .line 10
    invoke-static {p2, v0, v1, p1}, Landroidx/compose/ui/text/SpanStyle;->copy-GSF8kmg$default(Landroidx/compose/ui/text/SpanStyle;JI)Landroidx/compose/ui/text/SpanStyle;

    .line 13
    move-result-object p2

    .line 14
    :cond_d
    invoke-virtual {p0, p2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 17
    move-result p1

    .line 18
    :try_start_11
    invoke-virtual {p0, p3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_14
    .catchall {:try_start_11 .. :try_end_14} :catchall_18

    .line 21
    invoke-virtual {p0, p1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 24
    return-void

    .line 25
    :catchall_18
    move-exception p2

    .line 26
    invoke-virtual {p0, p1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 29
    throw p2
.end method

.method public static final countUp(IIILandroidx/compose/runtime/ComposerImpl;Z)Lcom/spotifry/music/ui/spotifried/CountUp;
    .registers 6

    .line 1
    shr-int/lit8 p2, p2, 0x3

    .line 3
    and-int/lit8 v0, p2, 0xe

    .line 5
    or-int/lit16 v0, v0, 0x180

    .line 7
    and-int/lit8 p2, p2, 0x70

    .line 9
    or-int/2addr v0, p2

    .line 10
    const/16 p2, 0x384

    .line 12
    invoke-static {p1, p2, v0, p3, p4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 15
    move-result-object p1

    .line 16
    invoke-virtual {p1}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 19
    move-result-object p1

    .line 20
    check-cast p1, Ljava/lang/Number;

    .line 22
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 25
    move-result p1

    .line 26
    new-instance p2, Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 28
    int-to-float p0, p0

    .line 29
    mul-float/2addr p0, p1

    .line 30
    invoke-static {p0}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 33
    move-result p0

    .line 34
    invoke-static {p0}, Lcom/spotifry/music/ui/listening/ListeningScreenKt;->count(I)Ljava/lang/String;

    .line 37
    move-result-object p0

    .line 38
    const/4 p3, 0x0

    .line 39
    cmpl-float p1, p1, p3

    .line 41
    if-lez p1, :cond_2c

    .line 43
    const/4 p1, 0x1

    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    const/4 p1, 0x0

    .line 46
    :goto_2d
    invoke-direct {p2, p0, p1}, Lcom/spotifry/music/ui/spotifried/CountUp;-><init>(Ljava/lang/String;Z)V

    .line 49
    return-object p2
.end method

.method public static final plural(ILjava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, v0, :cond_6

    .line 4
    const-string v0, ""

    .line 6
    goto :goto_8

    .line 7
    :cond_6
    const-string v0, "s"

    .line 9
    :goto_8
    new-instance v1, Ljava/lang/StringBuilder;

    .line 11
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 14
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 17
    const-string p0, " "

    .line 19
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    move-result-object p0

    .line 32
    return-object p0
.end method

.method public static final progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;
    .registers 11

    .line 1
    invoke-virtual {p3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 7
    if-ne v0, v1, :cond_15

    .line 9
    if-eqz p4, :cond_d

    .line 11
    const/high16 p4, 0x3f800000    # 1.0f

    .line 13
    goto :goto_e

    .line 14
    :cond_d
    const/4 p4, 0x0

    .line 15
    :goto_e
    invoke-static {p4}, Landroidx/compose/animation/core/ArcSplineKt;->Animatable$default(F)Landroidx/compose/animation/core/Animatable;

    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 22
    :cond_15
    check-cast v0, Landroidx/compose/animation/core/Animatable;

    .line 24
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 27
    move-result p4

    .line 28
    and-int/lit16 v2, p2, 0x380

    .line 30
    xor-int/lit16 v2, v2, 0x180

    .line 32
    const/4 v3, 0x0

    .line 33
    const/4 v4, 0x1

    .line 34
    const/16 v5, 0x100

    .line 36
    if-le v2, v5, :cond_2b

    .line 38
    invoke-virtual {p3, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 41
    move-result v2

    .line 42
    if-nez v2, :cond_2f

    .line 44
    :cond_2b
    and-int/lit16 v2, p2, 0x180

    .line 46
    if-ne v2, v5, :cond_31

    .line 48
    :cond_2f
    move v2, v4

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v2, v3

    .line 51
    :goto_32
    or-int/2addr p4, v2

    .line 52
    and-int/lit8 v2, p2, 0x70

    .line 54
    xor-int/lit8 v2, v2, 0x30

    .line 56
    const/16 v5, 0x20

    .line 58
    if-le v2, v5, :cond_41

    .line 60
    invoke-virtual {p3, p0}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 63
    move-result v2

    .line 64
    if-nez v2, :cond_45

    .line 66
    :cond_41
    and-int/lit8 p2, p2, 0x30

    .line 68
    if-ne p2, v5, :cond_46

    .line 70
    :cond_45
    move v3, v4

    .line 71
    :cond_46
    or-int/2addr p4, v3

    .line 72
    invoke-virtual {p3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 75
    move-result-object p2

    .line 76
    if-nez p4, :cond_4f

    .line 78
    if-ne p2, v1, :cond_58

    .line 80
    :cond_4f
    new-instance p2, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;

    .line 82
    const/4 p4, 0x0

    .line 83
    invoke-direct {p2, v0, p1, p0, p4}, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;-><init>(Landroidx/compose/animation/core/Animatable;IILkotlin/coroutines/Continuation;)V

    .line 86
    invoke-virtual {p3, p2}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 89
    :cond_58
    check-cast p2, Lkotlin/jvm/functions/Function2;

    .line 91
    invoke-static {p3, v0, p2}, Landroidx/compose/runtime/AnchoredGroupPath;->LaunchedEffect(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 94
    return-object v0
.end method

.method public static final rememberSunMotion(Ljava/util/List;FZLandroidx/compose/runtime/ComposerImpl;)Lcom/spotifry/music/ui/listening/SunMotion;
    .registers 10

    .line 1
    invoke-virtual {p3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 7
    if-ne v0, v1, :cond_51

    .line 9
    new-instance v0, Lcom/spotifry/music/ui/listening/SunMotion;

    .line 11
    invoke-direct {v0}, Lcom/spotifry/music/ui/listening/SunMotion;-><init>()V

    .line 14
    if-eqz p2, :cond_4e

    .line 16
    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->maxOrNull(Ljava/lang/Iterable;)Ljava/lang/Comparable;

    .line 19
    move-result-object p2

    .line 20
    check-cast p2, Ljava/lang/Long;

    .line 22
    if-eqz p2, :cond_1c

    .line 24
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 27
    move-result-wide v1

    .line 28
    goto :goto_1e

    .line 29
    :cond_1c
    const-wide/16 v1, 0x0

    .line 31
    :goto_1e
    const-wide/16 v3, 0x1

    .line 33
    cmp-long p2, v1, v3

    .line 35
    if-gez p2, :cond_25

    .line 37
    move-wide v1, v3

    .line 38
    :cond_25
    long-to-float p2, v1

    .line 39
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 42
    move-result-object p0

    .line 43
    const/4 v1, 0x0

    .line 44
    :goto_2b
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 47
    move-result v2

    .line 48
    if-eqz v2, :cond_4c

    .line 50
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 53
    move-result-object v2

    .line 54
    add-int/lit8 v3, v1, 0x1

    .line 56
    if-ltz v1, :cond_47

    .line 58
    check-cast v2, Ljava/lang/Number;

    .line 60
    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    .line 63
    move-result-wide v4

    .line 64
    long-to-float v2, v4

    .line 65
    div-float/2addr v2, p2

    .line 66
    iget-object v4, v0, Lcom/spotifry/music/ui/listening/SunMotion;->now:[F

    .line 68
    aput v2, v4, v1

    .line 70
    move v1, v3

    .line 71
    goto :goto_2b

    .line 72
    :cond_47
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 75
    const/4 p0, 0x0

    .line 76
    throw p0

    .line 77
    :cond_4c
    iput p1, v0, Lcom/spotifry/music/ui/listening/SunMotion;->scale:F

    .line 79
    :cond_4e
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 82
    :cond_51
    check-cast v0, Lcom/spotifry/music/ui/listening/SunMotion;

    .line 84
    return-object v0
.end method

.method public static final rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;
    .registers 11

    .line 1
    mul-int/lit16 v1, p1, 0xb4

    .line 3
    and-int/lit16 v4, p4, 0x38e

    .line 5
    const/4 v5, 0x4

    .line 6
    move-object v0, p0

    .line 7
    move v2, p2

    .line 8
    move-object v3, p3

    .line 9
    invoke-static/range {v0 .. v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->riseAt(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/Modifier;

    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public static final riseAt(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/Modifier;
    .registers 8

    .line 1
    and-int/lit8 p5, p5, 0x4

    .line 3
    if-eqz p5, :cond_7

    .line 5
    const/16 p5, 0x384

    .line 7
    goto :goto_9

    .line 8
    :cond_7
    const/16 p5, 0x320

    .line 10
    :goto_9
    shr-int/lit8 v0, p4, 0x6

    .line 12
    and-int/lit8 v0, v0, 0xe

    .line 14
    and-int/lit8 v1, p4, 0x70

    .line 16
    or-int/2addr v0, v1

    .line 17
    shr-int/lit8 p4, p4, 0x3

    .line 19
    and-int/lit16 p4, p4, 0x380

    .line 21
    or-int/2addr v0, p4

    .line 22
    invoke-static {p1, p5, v0, p3, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 25
    move-result-object p1

    .line 26
    sget-object p2, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 28
    invoke-virtual {p3, p2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 31
    move-result-object p2

    .line 32
    check-cast p2, Landroidx/compose/ui/unit/Density;

    .line 34
    sget p4, Lcom/spotifry/music/ui/spotifried/CardsKt;->RISE:F

    .line 36
    invoke-interface {p2, p4}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 39
    move-result p2

    .line 40
    invoke-virtual {p3, p1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 43
    move-result p4

    .line 44
    invoke-virtual {p3, p2}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 47
    move-result p5

    .line 48
    or-int/2addr p4, p5

    .line 49
    invoke-virtual {p3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 52
    move-result-object p5

    .line 53
    if-nez p4, :cond_3a

    .line 55
    sget-object p4, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 57
    if-ne p5, p4, :cond_43

    .line 59
    :cond_3a
    new-instance p5, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 61
    const/4 p4, 0x0

    .line 62
    invoke-direct {p5, p1, p2, p4}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 65
    invoke-virtual {p3, p5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 68
    :cond_43
    check-cast p5, Lkotlin/jvm/functions/Function1;

    .line 70
    invoke-static {p0, p5}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 73
    move-result-object p0

    .line 74
    return-object p0
.end method

.method public static final soft(Landroidx/compose/runtime/ComposerImpl;)J
    .registers 3

    .line 1
    sget-object v0, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 3
    invoke-virtual {p0, v0}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Landroidx/compose/material3/ColorScheme;

    .line 9
    iget-wide v0, p0, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 11
    const p0, 0x3f23d70a    # 0.64f

    .line 14
    invoke-static {p0, v0, v1}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 17
    move-result-wide v0

    .line 18
    return-wide v0
.end method

.method public static final stepAt(FFF)F
    .registers 3

    .line 1
    sub-float/2addr p0, p1

    .line 2
    div-float/2addr p0, p2

    .line 3
    const/4 p1, 0x0

    .line 4
    const/high16 p2, 0x3f800000    # 1.0f

    .line 6
    invoke-static {p0, p1, p2}, Lkotlin/ResultKt;->coerceIn(FFF)F

    .line 9
    move-result p0

    .line 10
    sget-object p1, Lcom/spotifry/music/ui/spotifried/CardsKt;->Ease:Landroidx/compose/animation/core/CubicBezierEasing;

    .line 12
    invoke-virtual {p1, p0}, Landroidx/compose/animation/core/CubicBezierEasing;->transform(F)F

    .line 15
    move-result p0

    .line 16
    return p0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda13 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda13)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$1:F

.field public final synthetic f$10:Z

.field public final synthetic f$11:J

.field public final synthetic f$12:Ljava/lang/String;

.field public final synthetic f$13:Ljava/lang/String;

.field public final synthetic f$14:Ljava/util/List;

.field public final synthetic f$15:Z

.field public final synthetic f$16:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

.field public final synthetic f$17:Landroidx/compose/runtime/State;

.field public final synthetic f$2:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$3:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$5:J

.field public final synthetic f$6:Lcom/spotifry/music/ui/listening/SunMotion;

.field public final synthetic f$7:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$8:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$9:Z


# direct methods
.method public synthetic constructor <init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;FLandroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;JLcom/spotifry/music/ui/listening/SunMotion;Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/core/Animatable;ZZJLjava/lang/String;Ljava/lang/String;Ljava/util/List;ZLandroidx/compose/runtime/ParcelableSnapshotMutableLongState;Landroidx/compose/runtime/State;)V
    .registers 21

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 6
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$1:F

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$3:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 12
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 14
    iput-wide p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$5:J

    .line 16
    iput-object p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$6:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 18
    iput-object p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$7:Lkotlin/jvm/functions/Function0;

    .line 20
    iput-object p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$8:Landroidx/compose/animation/core/Animatable;

    .line 22
    iput-boolean p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$9:Z

    .line 24
    iput-boolean p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$10:Z

    .line 26
    iput-wide p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$11:J

    .line 28
    iput-object p15, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$12:Ljava/lang/String;

    .line 30
    move-object/from16 p1, p16

    .line 32
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$13:Ljava/lang/String;

    .line 34
    move-object/from16 p1, p17

    .line 36
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$14:Ljava/util/List;

    .line 38
    move/from16 p1, p18

    .line 40
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$15:Z

    .line 42
    move-object/from16 p1, p19

    .line 44
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$16:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 46
    move-object/from16 p1, p20

    .line 48
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$17:Landroidx/compose/runtime/State;

    .line 50
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 45

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 5
    iget-object v2, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 7
    move-object/from16 v1, p1

    .line 9
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 11
    move-object/from16 v12, p2

    .line 13
    check-cast v12, Landroidx/compose/runtime/ComposerImpl;

    .line 15
    move-object/from16 v3, p3

    .line 17
    check-cast v3, Ljava/lang/Integer;

    .line 19
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 22
    move-result v3

    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    and-int/lit8 v4, v3, 0x6

    .line 28
    if-nez v4, :cond_27

    .line 30
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 33
    move-result v4

    .line 34
    if-eqz v4, :cond_25

    .line 36
    const/4 v4, 0x4

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    const/4 v4, 0x2

    .line 39
    :goto_26
    or-int/2addr v3, v4

    .line 40
    :cond_27
    and-int/lit8 v4, v3, 0x13

    .line 42
    const/16 v5, 0x12

    .line 44
    const/4 v6, 0x0

    .line 45
    const/4 v15, 0x1

    .line 46
    if-eq v4, v5, :cond_31

    .line 48
    move v4, v15

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v4, v6

    .line 51
    :goto_32
    and-int/2addr v3, v15

    .line 52
    invoke-virtual {v12, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v3

    .line 56
    if-eqz v3, :cond_207

    .line 58
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 61
    move-result v3

    .line 62
    const v4, 0x3fdc28f6    # 1.72f

    .line 65
    mul-float/2addr v3, v4

    .line 66
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 69
    move-result v1

    .line 70
    invoke-virtual {v12, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 73
    move-result v4

    .line 74
    iget v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$1:F

    .line 76
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 79
    move-result v7

    .line 80
    or-int/2addr v4, v7

    .line 81
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 84
    move-result-object v7

    .line 85
    sget-object v8, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 87
    if-nez v4, :cond_5a

    .line 89
    if-ne v7, v8, :cond_65

    .line 91
    :cond_5a
    invoke-static {v2, v5, v15}, Lcom/spotifry/music/ui/listening/SunKt;->sunReach(Ljava/util/List;FZ)F

    .line 94
    move-result v4

    .line 95
    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 98
    move-result-object v7

    .line 99
    invoke-virtual {v12, v7}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 102
    :cond_65
    check-cast v7, Ljava/lang/Number;

    .line 104
    invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F

    .line 107
    move-result v4

    .line 108
    sget-object v7, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 110
    const/high16 v9, 0x3f800000    # 1.0f

    .line 112
    invoke-static {v7, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 115
    move-result-object v10

    .line 116
    new-instance v11, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 118
    const/16 v13, 0xd

    .line 120
    invoke-direct {v11, v13}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 123
    invoke-static {v10, v11}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 126
    move-result-object v10

    .line 127
    new-instance v11, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 129
    const/16 v14, 0xe

    .line 131
    invoke-direct {v11, v14}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 134
    invoke-static {v10, v11}, Landroidx/compose/ui/draw/ClipKt;->drawWithContent(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 137
    move-result-object v10

    .line 138
    sget-object v11, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 140
    invoke-static {v11, v6}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 143
    move-result-object v14

    .line 144
    move-object/from16 p2, v7

    .line 146
    iget-wide v6, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 148
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 151
    move-result v6

    .line 152
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 155
    move-result-object v7

    .line 156
    invoke-static {v12, v10}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 159
    move-result-object v10

    .line 160
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 162
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 165
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 167
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 170
    iget-boolean v9, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 172
    if-eqz v9, :cond_b1

    .line 174
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 177
    goto :goto_b4

    .line 178
    :cond_b1
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 181
    :goto_b4
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 183
    invoke-static {v12, v14, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 186
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 188
    invoke-static {v12, v7, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 191
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 193
    iget-boolean v15, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 195
    if-nez v15, :cond_d5

    .line 197
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 200
    move-result-object v15

    .line 201
    move-object/from16 v23, v2

    .line 203
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 206
    move-result-object v2

    .line 207
    invoke-static {v15, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 210
    move-result v2

    .line 211
    if-nez v2, :cond_da

    .line 213
    goto :goto_d7

    .line 214
    :cond_d5
    move-object/from16 v23, v2

    .line 216
    :goto_d7
    invoke-static {v6, v12, v6, v7}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 219
    :cond_da
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 221
    invoke-static {v12, v10, v2}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 224
    sget-object v6, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    .line 226
    sget-object v10, Landroidx/compose/ui/Alignment$Companion;->BottomCenter:Landroidx/compose/ui/BiasAlignment;

    .line 228
    move-object/from16 v15, p2

    .line 230
    invoke-virtual {v6, v15, v10}, Landroidx/compose/foundation/layout/BoxScopeInstance;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;)Landroidx/compose/ui/Modifier;

    .line 233
    move-result-object v6

    .line 234
    const/high16 v10, 0x40000000    # 2.0f

    .line 236
    div-float v10, v3, v10

    .line 238
    const/high16 v16, 0x42700000    # 60.0f

    .line 240
    sub-float v10, v10, v16

    .line 242
    move/from16 p2, v5

    .line 244
    const/4 v5, 0x0

    .line 245
    move-object/from16 v24, v15

    .line 247
    const/4 v15, 0x1

    .line 248
    invoke-static {v6, v5, v10, v15}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 251
    move-result-object v5

    .line 252
    invoke-static {v5, v3}, Landroidx/compose/foundation/layout/SizeKt;->requiredSize-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 255
    move-result-object v5

    .line 256
    iget-object v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 258
    invoke-virtual {v12, v6}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 261
    move-result v10

    .line 262
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 265
    move-result v15

    .line 266
    or-int/2addr v10, v15

    .line 267
    invoke-virtual {v12, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 270
    move-result v15

    .line 271
    or-int/2addr v10, v15

    .line 272
    invoke-virtual {v12, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 275
    move-result v15

    .line 276
    or-int/2addr v10, v15

    .line 277
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 280
    move-result-object v15

    .line 281
    move/from16 v18, v1

    .line 283
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$3:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 285
    if-nez v10, :cond_123

    .line 287
    if-eq v15, v8, :cond_123

    .line 289
    move-object/from16 v21, v1

    .line 291
    goto :goto_139

    .line 292
    :cond_123
    new-instance v16, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;

    .line 294
    iget-object v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 296
    move-object/from16 v21, v1

    .line 298
    move/from16 v19, v3

    .line 300
    move/from16 v20, v4

    .line 302
    move-object/from16 v17, v6

    .line 304
    move-object/from16 v22, v10

    .line 306
    invoke-direct/range {v16 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;-><init>(Landroidx/compose/animation/core/Animatable;FFFLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;)V

    .line 309
    move-object/from16 v15, v16

    .line 311
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 314
    :goto_139
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 316
    invoke-static {v5, v15}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 319
    move-result-object v1

    .line 320
    const/4 v3, 0x0

    .line 321
    invoke-static {v11, v3}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 324
    move-result-object v3

    .line 325
    iget-wide v4, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 327
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 330
    move-result v4

    .line 331
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 334
    move-result-object v5

    .line 335
    invoke-static {v12, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 338
    move-result-object v1

    .line 339
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 342
    iget-boolean v6, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 344
    if-eqz v6, :cond_15d

    .line 346
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 349
    goto :goto_160

    .line 350
    :cond_15d
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 353
    :goto_160
    invoke-static {v12, v3, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 356
    invoke-static {v12, v5, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 359
    iget-boolean v3, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 361
    if-nez v3, :cond_178

    .line 363
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 366
    move-result-object v3

    .line 367
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 370
    move-result-object v5

    .line 371
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 374
    move-result v3

    .line 375
    if-nez v3, :cond_17b

    .line 377
    :cond_178
    invoke-static {v4, v12, v4, v7}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 380
    :cond_17b
    invoke-static {v12, v1, v2}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 383
    move-object/from16 v15, v24

    .line 385
    const/high16 v1, 0x3f800000    # 1.0f

    .line 387
    invoke-static {v15, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 390
    move-result-object v2

    .line 391
    iget-wide v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$5:J

    .line 393
    invoke-virtual {v12, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 396
    move-result v1

    .line 397
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 400
    move-result-object v5

    .line 401
    if-nez v1, :cond_194

    .line 403
    if-ne v5, v8, :cond_19e

    .line 405
    :cond_194
    new-instance v5, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 407
    const/16 v1, 0xd

    .line 409
    invoke-direct {v5, v3, v4, v1}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 412
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 415
    :cond_19e
    check-cast v5, Lkotlin/jvm/functions/Function1;

    .line 417
    const/4 v1, 0x6

    .line 418
    invoke-static {v2, v5, v12, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 421
    const/high16 v2, 0x3f800000    # 1.0f

    .line 423
    invoke-static {v15, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 426
    move-result-object v6

    .line 427
    const v13, 0x30006180

    .line 430
    const/16 v14, 0x1e0

    .line 432
    move-wide/from16 v29, v3

    .line 434
    const/4 v4, 0x0

    .line 435
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$6:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 437
    const/4 v7, 0x0

    .line 438
    const/4 v8, 0x0

    .line 439
    const/4 v9, 0x0

    .line 440
    const/4 v10, 0x0

    .line 441
    const/4 v11, 0x0

    .line 442
    move/from16 v3, p2

    .line 444
    move-object/from16 v2, v23

    .line 446
    invoke-static/range {v2 .. v14}, Lcom/spotifry/music/ui/listening/SunKt;->Sun(Ljava/util/List;FZLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/Modifier;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function1;Ljava/lang/String;ZLandroidx/compose/runtime/ComposerImpl;II)V

    .line 449
    const/4 v15, 0x1

    .line 450
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 453
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 456
    new-instance v25, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;

    .line 458
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$7:Lkotlin/jvm/functions/Function0;

    .line 460
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$8:Landroidx/compose/animation/core/Animatable;

    .line 462
    iget-boolean v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$9:Z

    .line 464
    iget-boolean v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$10:Z

    .line 466
    iget-wide v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$11:J

    .line 468
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$12:Ljava/lang/String;

    .line 470
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$13:Ljava/lang/String;

    .line 472
    iget-object v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$14:Ljava/util/List;

    .line 474
    iget-boolean v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$15:Z

    .line 476
    iget-object v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$16:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 478
    iget-object v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$17:Landroidx/compose/runtime/State;

    .line 480
    move-object/from16 v40, v0

    .line 482
    move-object/from16 v26, v2

    .line 484
    move-object/from16 v27, v3

    .line 486
    move/from16 v28, v4

    .line 488
    move/from16 v31, v5

    .line 490
    move-wide/from16 v32, v6

    .line 492
    move-object/from16 v34, v8

    .line 494
    move-object/from16 v35, v9

    .line 496
    move-object/from16 v36, v10

    .line 498
    move/from16 v37, v11

    .line 500
    move-object/from16 v39, v13

    .line 502
    move-object/from16 v38, v21

    .line 504
    invoke-direct/range {v25 .. v40}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/core/Animatable;ZJZJLjava/lang/String;Ljava/lang/String;Ljava/util/List;ZLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;Landroidx/compose/runtime/State;)V

    .line 507
    move-object/from16 v0, v25

    .line 509
    const v2, 0x65bc7030

    .line 512
    invoke-static {v2, v0, v12}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 515
    move-result-object v0

    .line 516
    invoke-static {v0, v12, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 519
    goto :goto_20a

    .line 520
    :cond_207
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 523
    :goto_20a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 525
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda47 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda47)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$1:F

.field public final synthetic f$2:F

.field public final synthetic f$3:F

.field public final synthetic f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;FFFLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 6
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$1:F

    .line 8
    iput p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$2:F

    .line 10
    iput p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$3:F

    .line 12
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 14
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    check-cast p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 8
    invoke-virtual {v0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/lang/Number;

    .line 14
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 17
    move-result v0

    .line 18
    const v1, 0x3f0ccccd    # 0.55f

    .line 21
    mul-float/2addr v0, v1

    .line 22
    invoke-virtual {p1, v0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 25
    iget-object v0, p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->graphicsDensity:Landroidx/compose/ui/unit/Density;

    .line 27
    invoke-interface {v0}, Landroidx/compose/ui/unit/Density;->getDensity()F

    .line 30
    move-result v0

    .line 31
    iget v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$1:F

    .line 33
    mul-float/2addr v0, v1

    .line 34
    iget-object v1, p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->graphicsDensity:Landroidx/compose/ui/unit/Density;

    .line 36
    invoke-interface {v1}, Landroidx/compose/ui/unit/Density;->getDensity()F

    .line 39
    move-result v1

    .line 40
    const/high16 v2, 0x42700000    # 60.0f

    .line 42
    mul-float/2addr v1, v2

    .line 43
    sub-float/2addr v0, v1

    .line 44
    iget-object v1, p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->graphicsDensity:Landroidx/compose/ui/unit/Density;

    .line 46
    invoke-interface {v1}, Landroidx/compose/ui/unit/Density;->getDensity()F

    .line 49
    move-result v1

    .line 50
    iget v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$2:F

    .line 52
    mul-float/2addr v1, v2

    .line 53
    iget v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$3:F

    .line 55
    mul-float/2addr v1, v2

    .line 56
    sub-float/2addr v0, v1

    .line 57
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 59
    invoke-virtual {v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;->getFloatValue()F

    .line 62
    move-result v1

    .line 63
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 65
    invoke-virtual {p0}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;->getFloatValue()F

    .line 68
    move-result p0

    .line 69
    sub-float/2addr v1, p0

    .line 70
    iget-object p0, p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->graphicsDensity:Landroidx/compose/ui/unit/Density;

    .line 72
    invoke-interface {p0}, Landroidx/compose/ui/unit/Density;->getDensity()F

    .line 75
    move-result p0

    .line 76
    const/high16 v2, 0x41c00000    # 24.0f

    .line 78
    mul-float/2addr p0, v2

    .line 79
    add-float/2addr p0, v1

    .line 80
    sub-float/2addr p0, v0

    .line 81
    const/4 v0, 0x0

    .line 82
    cmpg-float v1, p0, v0

    .line 84
    if-gez v1, :cond_56

    .line 86
    move p0, v0

    .line 87
    :cond_56
    invoke-virtual {p1, p0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setTranslationY(F)V

    .line 90
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 92
    return-object p0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda49 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda49)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$1:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$10:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$11:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

.field public final synthetic f$12:Landroidx/compose/runtime/State;

.field public final synthetic f$2:Z

.field public final synthetic f$3:J

.field public final synthetic f$4:Z

.field public final synthetic f$5:J

.field public final synthetic f$6:Ljava/lang/String;

.field public final synthetic f$7:Ljava/lang/String;

.field public final synthetic f$8:Ljava/util/List;

.field public final synthetic f$9:Z


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/core/Animatable;ZJZJLjava/lang/String;Ljava/lang/String;Ljava/util/List;ZLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;Landroidx/compose/runtime/State;)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$0:Lkotlin/jvm/functions/Function0;

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$1:Landroidx/compose/animation/core/Animatable;

    .line 8
    iput-boolean p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$2:Z

    .line 10
    iput-wide p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$3:J

    .line 12
    iput-boolean p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$4:Z

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$5:J

    .line 16
    iput-object p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$6:Ljava/lang/String;

    .line 18
    iput-object p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$7:Ljava/lang/String;

    .line 20
    iput-object p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$8:Ljava/util/List;

    .line 22
    iput-boolean p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$9:Z

    .line 24
    iput-object p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$10:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 26
    iput-object p14, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$11:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 28
    iput-object p15, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$12:Landroidx/compose/runtime/State;

    .line 30
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 35

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    const/4 v12, 0x2

    .line 25
    if-nez v3, :cond_24

    .line 27
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_22

    .line 33
    const/4 v3, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v3, v12

    .line 36
    :goto_23
    or-int/2addr v2, v3

    .line 37
    :cond_24
    and-int/lit8 v3, v2, 0x13

    .line 39
    const/16 v4, 0x12

    .line 41
    const/4 v8, 0x1

    .line 42
    const/4 v14, 0x0

    .line 43
    if-eq v3, v4, :cond_2e

    .line 45
    move v3, v8

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v3, v14

    .line 48
    :goto_2f
    and-int/2addr v2, v8

    .line 49
    invoke-virtual {v5, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_216

    .line 55
    const/high16 v2, 0x3f800000    # 1.0f

    .line 57
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 60
    move-result-object v1

    .line 61
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 64
    move-result-object v2

    .line 65
    new-instance v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;

    .line 67
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$6:Ljava/lang/String;

    .line 69
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$7:Ljava/lang/String;

    .line 71
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$8:Ljava/util/List;

    .line 73
    iget-boolean v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$9:Z

    .line 75
    iget-wide v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$3:J

    .line 77
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$10:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 79
    move-wide/from16 v20, v9

    .line 81
    iget-wide v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$5:J

    .line 83
    move-object/from16 v16, v1

    .line 85
    move-object/from16 v17, v3

    .line 87
    move-object/from16 v18, v4

    .line 89
    move/from16 v19, v6

    .line 91
    move-object/from16 v22, v7

    .line 93
    move-wide/from16 v23, v8

    .line 95
    invoke-direct/range {v15 .. v24}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZJLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;J)V

    .line 98
    const v1, -0x44df137a

    .line 101
    invoke-static {v1, v15, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 104
    move-result-object v4

    .line 105
    const/16 v6, 0xc00

    .line 107
    const/4 v7, 0x6

    .line 108
    const/4 v3, 0x0

    .line 109
    invoke-static/range {v2 .. v7}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 112
    sget-object v1, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 114
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 117
    move-result-object v1

    .line 118
    check-cast v1, Landroidx/compose/ui/unit/Density;

    .line 120
    const/high16 v2, 0x41900000    # 18.0f

    .line 122
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 125
    move-result v1

    .line 126
    sget-object v2, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 128
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 131
    move-result-object v3

    .line 132
    check-cast v3, Landroidx/compose/material3/ColorScheme;

    .line 134
    iget-wide v3, v3, Landroidx/compose/material3/ColorScheme;->background:J

    .line 136
    iget-object v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$0:Lkotlin/jvm/functions/Function0;

    .line 138
    sget-object v13, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 140
    sget-object v25, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 142
    if-eqz v6, :cond_1aa

    .line 144
    const v7, -0x179cea37

    .line 147
    invoke-virtual {v5, v7}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 150
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 153
    move-result v7

    .line 154
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 157
    move-result-object v8

    .line 158
    if-nez v7, :cond_a1

    .line 160
    if-ne v8, v13, :cond_ad

    .line 162
    :cond_a1
    new-instance v8, Lkotlin/text/Regex$$ExternalSyntheticLambda0;

    .line 164
    const/16 v7, 0x1c

    .line 166
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$11:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 168
    invoke-direct {v8, v6, v9, v7}, Lkotlin/text/Regex$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 171
    invoke-virtual {v5, v8}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 174
    :cond_ad
    move-object/from16 v16, v8

    .line 176
    check-cast v16, Lkotlin/jvm/functions/Function0;

    .line 178
    const/16 v29, 0x0

    .line 180
    const/16 v30, 0xd

    .line 182
    const/16 v26, 0x0

    .line 184
    const/high16 v27, 0x41400000    # 12.0f

    .line 186
    const/16 v28, 0x0

    .line 188
    invoke-static/range {v25 .. v30}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 191
    move-result-object v6

    .line 192
    move-object/from16 v7, v25

    .line 194
    const/high16 v8, 0x42400000    # 48.0f

    .line 196
    const/high16 v9, 0x7fc00000    # Float.NaN

    .line 198
    invoke-static {v6, v8, v9}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    .line 201
    move-result-object v6

    .line 202
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$1:Landroidx/compose/animation/core/Animatable;

    .line 204
    invoke-virtual {v5, v8}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 207
    move-result v9

    .line 208
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 211
    move-result v10

    .line 212
    or-int/2addr v9, v10

    .line 213
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 216
    move-result-object v10

    .line 217
    const/4 v11, 0x3

    .line 218
    if-nez v9, :cond_dd

    .line 220
    if-ne v10, v13, :cond_e5

    .line 222
    :cond_dd
    new-instance v10, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 224
    invoke-direct {v10, v8, v1, v11}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 227
    invoke-virtual {v5, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 230
    :cond_e5
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 232
    invoke-static {v6, v10}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 235
    move-result-object v1

    .line 236
    invoke-virtual {v5, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 239
    move-result v6

    .line 240
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 243
    move-result-object v8

    .line 244
    const/16 v9, 0xf

    .line 246
    if-nez v6, :cond_f9

    .line 248
    if-ne v8, v13, :cond_101

    .line 250
    :cond_f9
    new-instance v8, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 252
    invoke-direct {v8, v3, v4, v9}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 255
    invoke-virtual {v5, v8}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 258
    :cond_101
    check-cast v8, Lkotlin/jvm/functions/Function1;

    .line 260
    invoke-static {v1, v8}, Landroidx/compose/ui/draw/ClipKt;->drawBehind(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 263
    move-result-object v1

    .line 264
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$12:Landroidx/compose/runtime/State;

    .line 266
    invoke-interface {v3}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 269
    move-result-object v4

    .line 270
    check-cast v4, Ljava/lang/Boolean;

    .line 272
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 275
    move-result v4

    .line 276
    if-eqz v4, :cond_120

    .line 278
    const v4, -0x179c6a68

    .line 281
    invoke-virtual {v5, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 284
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 287
    move-object v4, v7

    .line 288
    goto :goto_13f

    .line 289
    :cond_120
    const v4, -0x179c6779

    .line 292
    invoke-virtual {v5, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 295
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 298
    move-result-object v4

    .line 299
    if-ne v4, v13, :cond_134

    .line 301
    new-instance v4, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 303
    invoke-direct {v4, v9}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 306
    invoke-virtual {v5, v4}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 309
    :cond_134
    check-cast v4, Lkotlin/jvm/functions/Function1;

    .line 311
    invoke-static {v7, v4}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->clearAndSetSemantics(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 314
    move-result-object v25

    .line 315
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 318
    move-object/from16 v4, v25

    .line 320
    :goto_13f
    invoke-interface {v1, v4}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 323
    move-result-object v1

    .line 324
    invoke-interface {v3}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 327
    move-result-object v3

    .line 328
    check-cast v3, Ljava/lang/Boolean;

    .line 330
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 333
    move-result v3

    .line 334
    iget-boolean v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$2:Z

    .line 336
    if-eqz v3, :cond_156

    .line 338
    if-nez v4, :cond_156

    .line 340
    const/16 v17, 0x1

    .line 342
    goto :goto_158

    .line 343
    :cond_156
    move/from16 v17, v14

    .line 345
    :goto_158
    sget-object v3, Landroidx/compose/material3/ButtonDefaults;->ContentPadding:Landroidx/compose/foundation/layout/PaddingValuesImpl;

    .line 347
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 350
    move-result-object v3

    .line 351
    check-cast v3, Landroidx/compose/material3/ColorScheme;

    .line 353
    iget-wide v8, v3, Landroidx/compose/material3/ColorScheme;->onPrimary:J

    .line 355
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 358
    move-result-object v2

    .line 359
    check-cast v2, Landroidx/compose/material3/ColorScheme;

    .line 361
    iget-wide v2, v2, Landroidx/compose/material3/ColorScheme;->onPrimary:J

    .line 363
    move v6, v11

    .line 364
    const/4 v11, 0x0

    .line 365
    move v10, v6

    .line 366
    move-object/from16 v25, v7

    .line 368
    move-wide/from16 v6, v20

    .line 370
    move v14, v4

    .line 371
    move v15, v10

    .line 372
    move-object v10, v5

    .line 373
    move-wide v4, v8

    .line 374
    move-wide v8, v2

    .line 375
    move-wide/from16 v2, v20

    .line 377
    invoke-static/range {v2 .. v11}, Landroidx/compose/material3/ButtonDefaults;->buttonColors-ro_MJ88(JJJJLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/material3/ButtonColors;

    .line 380
    move-result-object v6

    .line 381
    move-object v5, v10

    .line 382
    const/high16 v2, 0x41b00000    # 22.0f

    .line 384
    invoke-static {v2, v12}, Landroidx/compose/foundation/layout/OffsetKt;->PaddingValues-YgX7TsA$default(FI)Landroidx/compose/foundation/layout/PaddingValuesImpl;

    .line 387
    move-result-object v9

    .line 388
    new-instance v2, Lcom/spotifry/music/ui/home/PageScreenKt$$ExternalSyntheticLambda5;

    .line 390
    invoke-direct {v2, v15, v14}, Lcom/spotifry/music/ui/home/PageScreenKt$$ExternalSyntheticLambda5;-><init>(BZ)V

    .line 393
    const v3, 0x73c8f97b

    .line 396
    invoke-static {v3, v2, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 399
    move-result-object v10

    .line 400
    const/high16 v12, 0x30c00000

    .line 402
    move-object v2, v13

    .line 403
    const/16 v13, 0x168

    .line 405
    move-object/from16 v22, v5

    .line 407
    const/4 v5, 0x0

    .line 408
    const/4 v7, 0x0

    .line 409
    const/4 v8, 0x0

    .line 410
    move-object v3, v1

    .line 411
    move-object v1, v2

    .line 412
    move-object/from16 v2, v16

    .line 414
    move/from16 v4, v17

    .line 416
    move-object/from16 v11, v22

    .line 418
    invoke-static/range {v2 .. v13}, Landroidx/compose/material3/MenuKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValuesImpl;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 421
    move-object v5, v11

    .line 422
    const/4 v2, 0x0

    .line 423
    :goto_1a6
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 426
    goto :goto_1b3

    .line 427
    :cond_1aa
    move-object v1, v13

    .line 428
    move v2, v14

    .line 429
    const v3, 0x210eae32

    .line 432
    invoke-virtual {v5, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 435
    goto :goto_1a6

    .line 436
    :goto_1b3
    iget-boolean v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$4:Z

    .line 438
    if-eqz v0, :cond_20e

    .line 440
    const v0, -0x179c1621

    .line 443
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 446
    const/16 v29, 0x0

    .line 448
    const/16 v30, 0xd

    .line 450
    const/16 v26, 0x0

    .line 452
    const/high16 v27, 0x41000000    # 8.0f

    .line 454
    const/16 v28, 0x0

    .line 456
    invoke-static/range {v25 .. v30}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 459
    move-result-object v0

    .line 460
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 463
    move-result-object v2

    .line 464
    if-ne v2, v1, :cond_1db

    .line 466
    new-instance v2, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 468
    const/16 v1, 0x10

    .line 470
    invoke-direct {v2, v1}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 473
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 476
    :cond_1db
    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 478
    const/4 v1, 0x0

    .line 479
    invoke-static {v0, v1, v2}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 482
    move-result-object v3

    .line 483
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 485
    move-object/from16 v22, v5

    .line 487
    move-wide/from16 v4, v23

    .line 489
    const/high16 v24, 0xc00000

    .line 491
    const v25, 0x1fff8

    .line 494
    const-string v2, "Couldn\'t make the pictures. Try again."

    .line 496
    const-wide/16 v6, 0x0

    .line 498
    const/4 v8, 0x0

    .line 499
    const/4 v9, 0x0

    .line 500
    const/4 v10, 0x0

    .line 501
    const-wide/16 v11, 0x0

    .line 503
    const/4 v13, 0x0

    .line 504
    const-wide/16 v14, 0x0

    .line 506
    const/16 v16, 0x0

    .line 508
    const/16 v17, 0x0

    .line 510
    const/16 v18, 0x0

    .line 512
    const/16 v19, 0x0

    .line 514
    const/16 v20, 0x0

    .line 516
    const/16 v23, 0x6

    .line 518
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 521
    move-object/from16 v5, v22

    .line 523
    :goto_20a
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 526
    goto :goto_219

    .line 527
    :cond_20e
    const/4 v1, 0x0

    .line 528
    const v3, 0x210eae32

    .line 531
    invoke-virtual {v5, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 534
    goto :goto_20a

    .line 535
    :cond_216
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 538
    :goto_219
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 540
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda56 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda56)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Z

.field public final synthetic f$4:J

.field public final synthetic f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$6:J


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZJLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;J)V
    .registers 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$0:Ljava/lang/String;

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$1:Ljava/lang/String;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$2:Ljava/util/List;

    .line 10
    iput-boolean p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$3:Z

    .line 12
    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$4:J

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 16
    iput-wide p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$6:J

    .line 18
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 99

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    iget-wide v3, v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->constraints:J

    .line 24
    and-int/lit8 v6, v2, 0x6

    .line 26
    if-nez v6, :cond_25

    .line 28
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_23

    .line 34
    const/4 v1, 0x4

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    const/4 v1, 0x2

    .line 37
    :goto_24
    or-int/2addr v2, v1

    .line 38
    :cond_25
    and-int/lit8 v1, v2, 0x13

    .line 40
    const/16 v6, 0x12

    .line 42
    const/4 v8, 0x0

    .line 43
    const/4 v9, 0x1

    .line 44
    if-eq v1, v6, :cond_2f

    .line 46
    move v1, v9

    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move v1, v8

    .line 49
    :goto_30
    and-int/2addr v2, v9

    .line 50
    invoke-virtual {v5, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 53
    move-result v1

    .line 54
    if-eqz v1, :cond_54d

    .line 56
    invoke-static {v8, v5, v8, v9}, Landroidx/compose/ui/text/ParagraphKt;->rememberTextMeasurer(ILandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/text/TextMeasurer;

    .line 59
    move-result-object v10

    .line 60
    sget-object v1, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 62
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 65
    move-result-object v1

    .line 66
    check-cast v1, Landroidx/compose/ui/unit/Density;

    .line 68
    sget-object v11, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 70
    const/16 v2, 0x38

    .line 72
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 75
    move-result-wide v14

    .line 76
    const/16 v2, 0x37

    .line 78
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 81
    move-result-wide v22

    .line 82
    const/4 v2, -0x2

    .line 83
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 86
    move-result-wide v19

    .line 87
    const/16 v25, 0x0

    .line 89
    const v26, 0xfdff7d

    .line 92
    const-wide/16 v12, 0x0

    .line 94
    const/16 v16, 0x0

    .line 96
    const/16 v17, 0x0

    .line 98
    const/16 v18, 0x0

    .line 100
    const/16 v21, 0x0

    .line 102
    const/16 v24, 0x0

    .line 104
    invoke-static/range {v11 .. v26}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 107
    move-result-object v12

    .line 108
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 111
    move-result v2

    .line 112
    const/high16 v11, 0x438c0000    # 280.0f

    .line 114
    invoke-interface {v1, v11}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 117
    move-result v13

    .line 118
    invoke-static {v2, v13}, Ljava/lang/Math;->min(II)I

    .line 121
    move-result v2

    .line 122
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 125
    move-result v13

    .line 126
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$0:Ljava/lang/String;

    .line 128
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 131
    move-result v15

    .line 132
    invoke-virtual {v5, v10}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 135
    move-result v16

    .line 136
    or-int v15, v15, v16

    .line 138
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 141
    move-result v13

    .line 142
    or-int/2addr v15, v13

    .line 143
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 146
    move-result-object v13

    .line 147
    move/from16 p2, v8

    .line 149
    const/16 p3, 0x20

    .line 151
    sget-object v8, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 153
    const/16 v26, 0x0

    .line 155
    if-nez v15, :cond_a1

    .line 157
    if-eq v13, v8, :cond_a1

    .line 159
    move-object v6, v14

    .line 160
    goto/16 :goto_111

    .line 162
    :cond_a1
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 165
    move-result v13

    .line 166
    int-to-float v13, v13

    .line 167
    const v15, 0x3f7ae148    # 0.98f

    .line 170
    mul-float v17, v13, v15

    .line 172
    new-array v13, v9, [C

    .line 174
    aput-char p3, v13, p2

    .line 176
    invoke-static {v14, v13}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 179
    move-result-object v13

    .line 180
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 183
    move-result-object v18

    .line 184
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    .line 187
    move-result v13

    .line 188
    if-eqz v13, :cond_549

    .line 190
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 193
    move-result-object v13

    .line 194
    check-cast v13, Ljava/lang/String;

    .line 196
    move-object/from16 v16, v14

    .line 198
    const-wide/16 v14, 0x0

    .line 200
    move-object/from16 v19, v16

    .line 202
    const/16 v16, 0x3fc

    .line 204
    move-object v11, v13

    .line 205
    const/4 v13, 0x0

    .line 206
    move-object/from16 v6, v19

    .line 208
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 211
    move-result-object v11

    .line 212
    iget-wide v13, v11, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 214
    shr-long v13, v13, p3

    .line 216
    long-to-int v11, v13

    .line 217
    :cond_d8
    :goto_d8
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    .line 220
    move-result v13

    .line 221
    if-eqz v13, :cond_fb

    .line 223
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 226
    move-result-object v13

    .line 227
    check-cast v13, Ljava/lang/String;

    .line 229
    const-wide/16 v14, 0x0

    .line 231
    const/16 v16, 0x3fc

    .line 233
    move/from16 v19, v11

    .line 235
    move-object v11, v13

    .line 236
    const/4 v13, 0x0

    .line 237
    move/from16 v7, v19

    .line 239
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 242
    move-result-object v11

    .line 243
    iget-wide v13, v11, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 245
    shr-long v13, v13, p3

    .line 247
    long-to-int v11, v13

    .line 248
    if-lt v7, v11, :cond_d8

    .line 250
    move v11, v7

    .line 251
    goto :goto_d8

    .line 252
    :cond_fb
    move v7, v11

    .line 253
    if-ge v7, v9, :cond_100

    .line 255
    move v11, v9

    .line 256
    goto :goto_101

    .line 257
    :cond_100
    move v11, v7

    .line 258
    :goto_101
    int-to-float v7, v11

    .line 259
    div-float v7, v17, v7

    .line 261
    const/high16 v11, 0x3f800000    # 1.0f

    .line 263
    invoke-static {v11, v7}, Ljava/lang/Math;->min(FF)F

    .line 266
    move-result v7

    .line 267
    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 270
    move-result-object v13

    .line 271
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 274
    :goto_111
    check-cast v13, Ljava/lang/Number;

    .line 276
    invoke-virtual {v13}, Ljava/lang/Number;->floatValue()F

    .line 279
    move-result v7

    .line 280
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 283
    move-result v11

    .line 284
    move v13, v11

    .line 285
    iget-object v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$1:Ljava/lang/String;

    .line 287
    invoke-virtual {v5, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 290
    move-result v14

    .line 291
    or-int/2addr v13, v14

    .line 292
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$2:Ljava/util/List;

    .line 294
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 297
    move-result v15

    .line 298
    or-int/2addr v13, v15

    .line 299
    invoke-virtual {v5, v10}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 302
    move-result v15

    .line 303
    or-int/2addr v13, v15

    .line 304
    invoke-virtual {v5, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 307
    move-result v15

    .line 308
    or-int/2addr v13, v15

    .line 309
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 312
    move-result-object v15

    .line 313
    move-object/from16 v19, v6

    .line 315
    if-nez v13, :cond_149

    .line 317
    if-eq v15, v8, :cond_149

    .line 319
    move/from16 v17, v9

    .line 321
    move-object/from16 v23, v11

    .line 323
    move-object v3, v12

    .line 324
    move-object/from16 v28, v14

    .line 326
    move-object/from16 v32, v19

    .line 328
    goto/16 :goto_245

    .line 330
    :cond_149
    const/high16 v20, 0x3f800000    # 1.0f

    .line 332
    invoke-static/range {v20 .. v20}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 335
    move-result-object v13

    .line 336
    new-instance v15, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 338
    move/from16 v17, v9

    .line 340
    const/16 v9, 0x11

    .line 342
    invoke-direct {v15, v9}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 345
    invoke-static {v13, v15}, Lkotlin/sequences/SequencesKt;->generateSequence(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    .line 348
    move-result-object v9

    .line 349
    new-instance v13, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 351
    const/16 v15, 0x12

    .line 353
    invoke-direct {v13, v15}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 356
    new-instance v15, Lkotlin/sequences/TakeWhileSequence;

    .line 358
    move/from16 v6, p2

    .line 360
    invoke-direct {v15, v9, v13, v6}, Lkotlin/sequences/TakeWhileSequence;-><init>(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;B)V

    .line 363
    new-instance v6, Lkotlin/sequences/FilteringSequence$iterator$1;

    .line 365
    invoke-direct {v6, v15}, Lkotlin/sequences/FilteringSequence$iterator$1;-><init>(Lkotlin/sequences/TakeWhileSequence;)V

    .line 368
    :goto_16f
    invoke-virtual {v6}, Lkotlin/sequences/FilteringSequence$iterator$1;->hasNext()Z

    .line 371
    move-result v9

    .line 372
    if-eqz v9, :cond_22a

    .line 374
    invoke-virtual {v6}, Lkotlin/sequences/FilteringSequence$iterator$1;->next()Ljava/lang/Object;

    .line 377
    move-result-object v9

    .line 378
    move-object v13, v9

    .line 379
    check-cast v13, Ljava/lang/Number;

    .line 381
    invoke-virtual {v13}, Ljava/lang/Number;->floatValue()F

    .line 384
    move-result v13

    .line 385
    move-object v15, v12

    .line 386
    sget-object v12, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 388
    move-wide/from16 v20, v3

    .line 390
    invoke-static/range {v20 .. v21}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 393
    move-result v3

    .line 394
    const/16 v4, 0xd

    .line 396
    move-object/from16 v22, v6

    .line 398
    const/4 v6, 0x0

    .line 399
    invoke-static {v3, v6, v4}, Landroidx/compose/ui/unit/ConstraintsKt;->Constraints$default(III)J

    .line 402
    move-result-wide v23

    .line 403
    const/16 v16, 0x3cc

    .line 405
    move v3, v13

    .line 406
    const/4 v13, 0x3

    .line 407
    move v6, v3

    .line 408
    move-object/from16 v28, v14

    .line 410
    move-object v3, v15

    .line 411
    move-wide/from16 v14, v23

    .line 413
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 416
    move-result-object v12

    .line 417
    move-object/from16 v23, v11

    .line 419
    iget-wide v11, v12, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 421
    const-wide v24, 0xffffffffL

    .line 426
    and-long v11, v11, v24

    .line 428
    long-to-int v11, v11

    .line 429
    const/high16 v12, 0x40c00000    # 6.0f

    .line 431
    invoke-interface {v1, v12}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 434
    move-result v12

    .line 435
    add-int v29, v12, v11

    .line 437
    invoke-static {v3, v7, v6}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type$lambda$235$lambda$234$lambda$220$titleStyle(Landroidx/compose/ui/text/TextStyle;FF)Landroidx/compose/ui/text/TextStyle;

    .line 440
    move-result-object v12

    .line 441
    invoke-static/range {v20 .. v21}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 444
    move-result v11

    .line 445
    const/4 v13, 0x0

    .line 446
    invoke-static {v11, v13, v4}, Landroidx/compose/ui/unit/ConstraintsKt;->Constraints$default(III)J

    .line 449
    move-result-wide v14

    .line 450
    const/4 v13, 0x3

    .line 451
    move-object/from16 v11, v19

    .line 453
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 456
    move-result-object v12

    .line 457
    iget-wide v11, v12, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 459
    and-long v11, v11, v24

    .line 461
    long-to-int v11, v11

    .line 462
    add-int v29, v29, v11

    .line 464
    const/high16 v11, 0x41d00000    # 26.0f

    .line 466
    invoke-interface {v1, v11}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 469
    move-result v11

    .line 470
    add-int v29, v11, v29

    .line 472
    invoke-interface/range {v28 .. v28}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 475
    move-result-object v30

    .line 476
    const/16 v31, 0x0

    .line 478
    :goto_1dd
    invoke-interface/range {v30 .. v30}, Ljava/util/Iterator;->hasNext()Z

    .line 481
    move-result v11

    .line 482
    if-eqz v11, :cond_201

    .line 484
    invoke-interface/range {v30 .. v30}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 487
    move-result-object v11

    .line 488
    check-cast v11, Ljava/lang/String;

    .line 490
    invoke-static {v6}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type$lambda$235$lambda$234$lambda$220$factStyle(F)Landroidx/compose/ui/text/TextStyle;

    .line 493
    move-result-object v12

    .line 494
    const/4 v13, 0x0

    .line 495
    invoke-static {v2, v13, v4}, Landroidx/compose/ui/unit/ConstraintsKt;->Constraints$default(III)J

    .line 498
    move-result-wide v14

    .line 499
    const/16 v16, 0x3dc

    .line 501
    const/4 v13, 0x0

    .line 502
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 505
    move-result-object v11

    .line 506
    iget-wide v11, v11, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 508
    and-long v11, v11, v24

    .line 510
    long-to-int v11, v11

    .line 511
    add-int v31, v31, v11

    .line 513
    goto :goto_1dd

    .line 514
    :cond_201
    move-object/from16 v32, v19

    .line 516
    add-int v29, v29, v31

    .line 518
    const/high16 v4, 0x41400000    # 12.0f

    .line 520
    invoke-interface {v1, v4}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 523
    move-result v6

    .line 524
    shl-int/lit8 v6, v6, 0x1

    .line 526
    add-int v29, v29, v6

    .line 528
    sget v6, Lcom/spotifry/music/ui/spotifried/CardsKt;->RISE:F

    .line 530
    invoke-interface {v1, v6}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 533
    move-result v6

    .line 534
    add-int v6, v6, v29

    .line 536
    invoke-static/range {v20 .. v21}, Landroidx/compose/ui/unit/Constraints;->getMaxHeight-impl(J)I

    .line 539
    move-result v11

    .line 540
    if-le v6, v11, :cond_233

    .line 542
    move-object v12, v3

    .line 543
    move-wide/from16 v3, v20

    .line 545
    move-object/from16 v6, v22

    .line 547
    move-object/from16 v11, v23

    .line 549
    move-object/from16 v14, v28

    .line 551
    move-object/from16 v19, v32

    .line 553
    goto/16 :goto_16f

    .line 555
    :cond_22a
    move-object/from16 v23, v11

    .line 557
    move-object v3, v12

    .line 558
    move-object/from16 v28, v14

    .line 560
    move-object/from16 v32, v19

    .line 562
    move-object/from16 v9, v26

    .line 564
    :cond_233
    check-cast v9, Ljava/lang/Float;

    .line 566
    if-eqz v9, :cond_23c

    .line 568
    invoke-virtual {v9}, Ljava/lang/Float;->floatValue()F

    .line 571
    move-result v1

    .line 572
    goto :goto_23e

    .line 573
    :cond_23c
    const/high16 v1, 0x3f000000    # 0.5f

    .line 575
    :goto_23e
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 578
    move-result-object v15

    .line 579
    invoke-virtual {v5, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 582
    :goto_245
    check-cast v15, Ljava/lang/Number;

    .line 584
    invoke-virtual {v15}, Ljava/lang/Number;->floatValue()F

    .line 587
    move-result v1

    .line 588
    invoke-static {v5}, Landroidx/compose/foundation/ImageKt;->rememberScrollState(Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/foundation/ScrollState;

    .line 591
    move-result-object v2

    .line 592
    sget-object v6, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 594
    move/from16 v9, v17

    .line 596
    invoke-static {v6, v2, v9}, Landroidx/compose/foundation/ImageKt;->scroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;Z)Landroidx/compose/ui/Modifier;

    .line 599
    move-result-object v10

    .line 600
    sget v14, Lcom/spotifry/music/ui/spotifried/CardsKt;->RISE:F

    .line 602
    const/4 v15, 0x7

    .line 603
    const/4 v11, 0x0

    .line 604
    const/4 v12, 0x0

    .line 605
    const/4 v13, 0x0

    .line 606
    invoke-static/range {v10 .. v15}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 609
    move-result-object v2

    .line 610
    sget-object v10, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 612
    sget-object v11, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 614
    const/4 v13, 0x0

    .line 615
    invoke-static {v10, v11, v5, v13}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 618
    move-result-object v10

    .line 619
    iget-wide v12, v5, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 621
    invoke-static {v12, v13}, Ljava/lang/Long;->hashCode(J)I

    .line 624
    move-result v12

    .line 625
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 628
    move-result-object v13

    .line 629
    invoke-static {v5, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 632
    move-result-object v2

    .line 633
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 635
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 638
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 640
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 643
    iget-boolean v15, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 645
    if-eqz v15, :cond_28a

    .line 647
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 650
    goto :goto_28d

    .line 651
    :cond_28a
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 654
    :goto_28d
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 656
    invoke-static {v5, v10, v15}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 659
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 661
    invoke-static {v5, v13, v10}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 664
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 666
    iget-boolean v4, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 668
    if-nez v4, :cond_2ab

    .line 670
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 673
    move-result-object v4

    .line 674
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 677
    move-result-object v9

    .line 678
    invoke-static {v4, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 681
    move-result v4

    .line 682
    if-nez v4, :cond_2ae

    .line 684
    :cond_2ab
    invoke-static {v12, v5, v12, v13}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 687
    :cond_2ae
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 689
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 692
    iget-boolean v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$3:Z

    .line 694
    const/16 v9, 0x36

    .line 696
    move-object/from16 v16, v3

    .line 698
    const/4 v12, 0x0

    .line 699
    invoke-static {v6, v12, v2, v5, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 702
    move-result-object v3

    .line 703
    move-object/from16 v19, v4

    .line 705
    move-object/from16 v20, v5

    .line 707
    invoke-static/range {v20 .. v20}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 710
    move-result-wide v4

    .line 711
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 713
    const v24, 0xc06180

    .line 716
    const v25, 0x1aff8

    .line 719
    move-object/from16 v29, v6

    .line 721
    move/from16 v22, v7

    .line 723
    const-wide/16 v6, 0x0

    .line 725
    move-object/from16 v30, v8

    .line 727
    const/4 v8, 0x0

    .line 728
    const/4 v9, 0x0

    .line 729
    move-object/from16 v33, v10

    .line 731
    const/4 v10, 0x0

    .line 732
    move-object/from16 v34, v11

    .line 734
    move/from16 v35, v12

    .line 736
    const-wide/16 v11, 0x0

    .line 738
    move-object/from16 v36, v13

    .line 740
    const/4 v13, 0x0

    .line 741
    move-object/from16 v37, v14

    .line 743
    move-object/from16 v38, v15

    .line 745
    const-wide/16 v14, 0x0

    .line 747
    move-object/from16 v39, v16

    .line 749
    const/16 v16, 0x2

    .line 751
    const/16 v17, 0x0

    .line 753
    const/16 v18, 0x3

    .line 755
    move-object/from16 v42, v19

    .line 757
    const/16 v19, 0x0

    .line 759
    move/from16 v43, v22

    .line 761
    move-object/from16 v22, v20

    .line 763
    const/16 v20, 0x0

    .line 765
    move/from16 v44, v2

    .line 767
    move-object/from16 v2, v23

    .line 769
    const/16 v23, 0x0

    .line 771
    move/from16 v0, p3

    .line 773
    move/from16 p2, v1

    .line 775
    move-object/from16 v54, v30

    .line 777
    move-object/from16 v50, v33

    .line 779
    move-object/from16 v47, v34

    .line 781
    move/from16 v1, v35

    .line 783
    move-object/from16 v51, v36

    .line 785
    move-object/from16 v48, v37

    .line 787
    move-object/from16 v49, v38

    .line 789
    move-object/from16 v45, v39

    .line 791
    move-object/from16 v52, v42

    .line 793
    move/from16 v46, v43

    .line 795
    move/from16 v53, v44

    .line 797
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 800
    move-object/from16 v5, v22

    .line 802
    const/4 v2, 0x6

    .line 803
    move-object/from16 v6, v32

    .line 805
    invoke-static {v6, v0, v1, v2}, Lkotlin/text/StringsKt;->lastIndexOf$default(Ljava/lang/CharSequence;CII)I

    .line 808
    move-result v0

    .line 809
    const/16 v17, 0x1

    .line 811
    add-int/lit8 v0, v0, 0x1

    .line 813
    new-instance v3, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 815
    invoke-direct {v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 818
    invoke-static {v0, v6}, Lkotlin/text/StringsKt;->take(ILjava/lang/String;)Ljava/lang/String;

    .line 821
    move-result-object v4

    .line 822
    invoke-virtual {v3, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 825
    new-instance v55, Landroidx/compose/ui/text/SpanStyle;

    .line 827
    const/16 v73, 0x0

    .line 829
    const v74, 0xfffe

    .line 832
    move-object/from16 v4, p0

    .line 834
    iget-wide v7, v4, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$4:J

    .line 836
    const-wide/16 v58, 0x0

    .line 838
    const/16 v60, 0x0

    .line 840
    const/16 v61, 0x0

    .line 842
    const/16 v62, 0x0

    .line 844
    const/16 v63, 0x0

    .line 846
    const/16 v64, 0x0

    .line 848
    const-wide/16 v65, 0x0

    .line 850
    const/16 v67, 0x0

    .line 852
    const/16 v68, 0x0

    .line 854
    const/16 v69, 0x0

    .line 856
    const-wide/16 v70, 0x0

    .line 858
    const/16 v72, 0x0

    .line 860
    move-wide/from16 v56, v7

    .line 862
    invoke-direct/range {v55 .. v74}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 865
    move-object/from16 v7, v55

    .line 867
    move-wide/from16 v76, v56

    .line 869
    invoke-virtual {v3, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 872
    move-result v7

    .line 873
    :try_start_368
    invoke-static {v0, v6}, Lkotlin/text/StringsKt;->drop(ILjava/lang/String;)Ljava/lang/String;

    .line 876
    move-result-object v0

    .line 877
    invoke-virtual {v3, v0}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_36f
    .catchall {:try_start_368 .. :try_end_36f} :catchall_544

    .line 880
    invoke-virtual {v3, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 883
    invoke-virtual {v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 886
    move-result-object v2

    .line 887
    const/4 v13, 0x0

    .line 888
    const/16 v14, 0xd

    .line 890
    const/4 v10, 0x0

    .line 891
    const/high16 v11, 0x40c00000    # 6.0f

    .line 893
    const/4 v12, 0x0

    .line 894
    move-object/from16 v9, v29

    .line 896
    invoke-static/range {v9 .. v14}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 899
    move-result-object v3

    .line 900
    move/from16 v6, v53

    .line 902
    const/16 v7, 0x36

    .line 904
    invoke-static {v3, v1, v6, v5, v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 907
    move-result-object v3

    .line 908
    move/from16 v8, p2

    .line 910
    move-object/from16 v12, v45

    .line 912
    move/from16 v7, v46

    .line 914
    invoke-static {v12, v7, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type$lambda$235$lambda$234$lambda$220$titleStyle(Landroidx/compose/ui/text/TextStyle;FF)Landroidx/compose/ui/text/TextStyle;

    .line 917
    move-result-object v19

    .line 918
    const/16 v22, 0x6000

    .line 920
    const v23, 0x3bffc

    .line 923
    move-object/from16 v20, v5

    .line 925
    const-wide/16 v4, 0x0

    .line 927
    move/from16 v44, v6

    .line 929
    const-wide/16 v6, 0x0

    .line 931
    move v9, v8

    .line 932
    const/4 v8, 0x0

    .line 933
    move v11, v9

    .line 934
    const-wide/16 v9, 0x0

    .line 936
    move v13, v11

    .line 937
    const-wide/16 v11, 0x0

    .line 939
    move v14, v13

    .line 940
    const/4 v13, 0x0

    .line 941
    move v15, v14

    .line 942
    const/4 v14, 0x0

    .line 943
    move/from16 v16, v15

    .line 945
    const/4 v15, 0x3

    .line 946
    move/from16 v18, v16

    .line 948
    const/16 v16, 0x0

    .line 950
    move/from16 v40, v17

    .line 952
    const/16 v17, 0x0

    .line 954
    move/from16 v21, v18

    .line 956
    const/16 v18, 0x0

    .line 958
    move/from16 v24, v21

    .line 960
    const/16 v21, 0x0

    .line 962
    move-object/from16 v0, p0

    .line 964
    move/from16 v1, v40

    .line 966
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 969
    move-object/from16 v5, v20

    .line 971
    const/4 v13, 0x0

    .line 972
    const/16 v14, 0xd

    .line 974
    const/4 v10, 0x0

    .line 975
    const/high16 v11, 0x41d00000    # 26.0f

    .line 977
    const/4 v12, 0x0

    .line 978
    move-object/from16 v9, v29

    .line 980
    invoke-static/range {v9 .. v14}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 983
    move-result-object v2

    .line 984
    const/high16 v3, 0x438c0000    # 280.0f

    .line 986
    invoke-static {v2, v3, v1}, Landroidx/compose/foundation/layout/SizeKt;->widthIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FI)Landroidx/compose/ui/Modifier;

    .line 989
    move-result-object v2

    .line 990
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 993
    move-result-object v3

    .line 994
    move-object/from16 v4, v54

    .line 996
    if-ne v3, v4, :cond_3f0

    .line 998
    new-instance v3, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda12;

    .line 1000
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 1002
    const/4 v6, 0x2

    .line 1003
    invoke-direct {v3, v4, v6}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda12;-><init>(Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;B)V

    .line 1006
    invoke-virtual {v5, v3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1009
    :cond_3f0
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 1011
    invoke-static {v2, v3}, Landroidx/compose/ui/layout/RulerKt;->onGloballyPositioned(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 1014
    move-result-object v2

    .line 1015
    new-instance v3, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 1017
    new-instance v4, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 1019
    const/4 v6, 0x3

    .line 1020
    invoke-direct {v4, v6}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 1023
    const/high16 v6, 0x41400000    # 12.0f

    .line 1025
    invoke-direct {v3, v6, v4}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 1028
    move-object/from16 v4, v47

    .line 1030
    const/4 v6, 0x6

    .line 1031
    invoke-static {v3, v4, v5, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 1034
    move-result-object v3

    .line 1035
    iget-wide v6, v5, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 1037
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 1040
    move-result v4

    .line 1041
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 1044
    move-result-object v6

    .line 1045
    invoke-static {v5, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 1048
    move-result-object v2

    .line 1049
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 1052
    iget-boolean v7, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 1054
    if-eqz v7, :cond_427

    .line 1056
    move-object/from16 v7, v48

    .line 1058
    invoke-virtual {v5, v7}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 1061
    :goto_424
    move-object/from16 v7, v49

    .line 1063
    goto :goto_42b

    .line 1064
    :cond_427
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 1067
    goto :goto_424

    .line 1068
    :goto_42b
    invoke-static {v5, v3, v7}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1071
    move-object/from16 v3, v50

    .line 1073
    invoke-static {v5, v6, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1076
    iget-boolean v3, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 1078
    if-nez v3, :cond_448

    .line 1080
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 1083
    move-result-object v3

    .line 1084
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1087
    move-result-object v6

    .line 1088
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1091
    move-result v3

    .line 1092
    if-eqz v3, :cond_448

    .line 1094
    :goto_445
    move-object/from16 v3, v52

    .line 1096
    goto :goto_44e

    .line 1097
    :cond_448
    move-object/from16 v3, v51

    .line 1099
    invoke-static {v4, v5, v4, v3}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 1102
    goto :goto_445

    .line 1103
    :goto_44e
    invoke-static {v5, v2, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1106
    const v2, -0x65b9258e

    .line 1109
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 1112
    invoke-interface/range {v28 .. v28}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1115
    move-result-object v25

    .line 1116
    const/4 v8, 0x0

    .line 1117
    :goto_45c
    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->hasNext()Z

    .line 1120
    move-result v2

    .line 1121
    if-eqz v2, :cond_539

    .line 1123
    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1126
    move-result-object v2

    .line 1127
    add-int/lit8 v27, v8, 0x1

    .line 1129
    if-ltz v8, :cond_535

    .line 1131
    check-cast v2, Ljava/lang/String;

    .line 1133
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1136
    const-string v3, "\\d+(?:[.,]\\d+)*%"

    .line 1138
    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 1141
    move-result-object v3

    .line 1142
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1145
    invoke-virtual {v3, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1148
    move-result-object v3

    .line 1149
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1152
    const/4 v13, 0x0

    .line 1153
    invoke-static {v3, v13, v2}, Lkotlin/text/RegexKt;->findNext(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Lkotlin/text/MatcherMatchResult;

    .line 1156
    move-result-object v3

    .line 1157
    if-nez v3, :cond_49a

    .line 1159
    const-string v3, "\\d+(?:[.,]\\d+)*(?: [ap]\\.m\\.)?"

    .line 1161
    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 1164
    move-result-object v3

    .line 1165
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1168
    invoke-virtual {v3, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1171
    move-result-object v3

    .line 1172
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1175
    invoke-static {v3, v13, v2}, Lkotlin/text/RegexKt;->findNext(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Lkotlin/text/MatcherMatchResult;

    .line 1178
    move-result-object v3

    .line 1179
    :cond_49a
    if-eqz v3, :cond_4a1

    .line 1181
    invoke-virtual {v3}, Lkotlin/text/MatcherMatchResult;->getRange()Lkotlin/ranges/IntRange;

    .line 1184
    move-result-object v3

    .line 1185
    goto :goto_4a3

    .line 1186
    :cond_4a1
    move-object/from16 v3, v26

    .line 1188
    :goto_4a3
    new-instance v4, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 1190
    invoke-direct {v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 1193
    if-nez v3, :cond_4ae

    .line 1195
    invoke-virtual {v4, v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 1198
    goto :goto_4f4

    .line 1199
    :cond_4ae
    iget v6, v3, Lkotlin/ranges/IntProgression;->last:I

    .line 1201
    iget v3, v3, Lkotlin/ranges/IntProgression;->first:I

    .line 1203
    const/4 v13, 0x0

    .line 1204
    invoke-virtual {v2, v13, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1207
    move-result-object v7

    .line 1208
    invoke-virtual {v4, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 1211
    new-instance v75, Landroidx/compose/ui/text/SpanStyle;

    .line 1213
    sget-object v80, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 1215
    const/16 v93, 0x0

    .line 1217
    const v94, 0xfffa

    .line 1220
    const-wide/16 v78, 0x0

    .line 1222
    const/16 v81, 0x0

    .line 1224
    const/16 v82, 0x0

    .line 1226
    const/16 v83, 0x0

    .line 1228
    const/16 v84, 0x0

    .line 1230
    const-wide/16 v85, 0x0

    .line 1232
    const/16 v87, 0x0

    .line 1234
    const/16 v88, 0x0

    .line 1236
    const/16 v89, 0x0

    .line 1238
    const-wide/16 v90, 0x0

    .line 1240
    const/16 v92, 0x0

    .line 1242
    invoke-direct/range {v75 .. v94}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 1245
    move-object/from16 v7, v75

    .line 1247
    invoke-virtual {v4, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 1250
    move-result v7

    .line 1251
    add-int/2addr v6, v1

    .line 1252
    :try_start_4e3
    invoke-virtual {v2, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1255
    move-result-object v3

    .line 1256
    invoke-virtual {v4, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_4ea
    .catchall {:try_start_4e3 .. :try_end_4ea} :catchall_530

    .line 1259
    invoke-virtual {v4, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 1262
    invoke-virtual {v2, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1265
    move-result-object v2

    .line 1266
    invoke-virtual {v4, v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 1269
    :goto_4f4
    invoke-virtual {v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 1272
    move-result-object v9

    .line 1273
    mul-int/lit16 v8, v8, 0xfa

    .line 1275
    add-int/lit16 v3, v8, 0x3e8

    .line 1277
    const/16 v6, 0xc06

    .line 1279
    const/4 v7, 0x0

    .line 1280
    move-object/from16 v2, v29

    .line 1282
    move/from16 v4, v44

    .line 1284
    invoke-static/range {v2 .. v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->riseAt(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/Modifier;

    .line 1287
    move-result-object v3

    .line 1288
    move-object/from16 v20, v5

    .line 1290
    invoke-static/range {v24 .. v24}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type$lambda$235$lambda$234$lambda$220$factStyle(F)Landroidx/compose/ui/text/TextStyle;

    .line 1293
    move-result-object v19

    .line 1294
    const/16 v22, 0x0

    .line 1296
    const v23, 0x3fff8

    .line 1299
    iget-wide v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$6:J

    .line 1301
    const-wide/16 v6, 0x0

    .line 1303
    const/4 v8, 0x0

    .line 1304
    move-object v2, v9

    .line 1305
    const-wide/16 v9, 0x0

    .line 1307
    const-wide/16 v11, 0x0

    .line 1309
    const/4 v13, 0x0

    .line 1310
    const/4 v14, 0x0

    .line 1311
    const/4 v15, 0x0

    .line 1312
    const/16 v16, 0x0

    .line 1314
    const/16 v17, 0x0

    .line 1316
    const/16 v18, 0x0

    .line 1318
    const/16 v21, 0x0

    .line 1320
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1323
    move-object/from16 v5, v20

    .line 1325
    move/from16 v8, v27

    .line 1327
    goto/16 :goto_45c

    .line 1329
    :catchall_530
    move-exception v0

    .line 1330
    invoke-virtual {v4, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 1333
    throw v0

    .line 1334
    :cond_535
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 1337
    throw v26

    .line 1338
    :cond_539
    const/4 v13, 0x0

    .line 1339
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1342
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1345
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1348
    goto :goto_550

    .line 1349
    :catchall_544
    move-exception v0

    .line 1350
    invoke-virtual {v3, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 1353
    throw v0

    .line 1354
    :cond_549
    invoke-static {}, Landroidx/media3/session/MediaSessionStub$$ExternalSyntheticLambda8;->m$1()V

    .line 1357
    return-object v26

    .line 1358
    :cond_54d
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 1361
    :goto_550
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1363
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda15 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda15)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$1:J

.field public final synthetic f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$3:F

.field public final synthetic f$4:Lcom/spotifry/music/ui/listening/SunMotion;

.field public final synthetic f$5:Landroidx/compose/ui/text/TextStyle;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;JLcom/spotifry/music/data/spotifried/SpotifriedStats;FLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/text/TextStyle;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 10
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$3:F

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$4:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$5:Landroidx/compose/ui/text/TextStyle;

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 39

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v12, p2

    .line 9
    check-cast v12, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    const/4 v4, 0x4

    .line 25
    if-nez v3, :cond_24

    .line 27
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_22

    .line 33
    move v3, v4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    const/4 v3, 0x2

    .line 36
    :goto_23
    or-int/2addr v2, v3

    .line 37
    :cond_24
    and-int/lit8 v3, v2, 0x13

    .line 39
    const/16 v5, 0x12

    .line 41
    const/4 v6, 0x1

    .line 42
    const/4 v7, 0x0

    .line 43
    if-eq v3, v5, :cond_2e

    .line 45
    move v3, v6

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v3, v7

    .line 48
    :goto_2f
    and-int/2addr v2, v6

    .line 49
    invoke-virtual {v12, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_2e6

    .line 55
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 58
    move-result v2

    .line 59
    const v3, 0x3f8a3d71    # 1.08f

    .line 62
    mul-float/2addr v2, v3

    .line 63
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 65
    invoke-direct {v3, v2}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 68
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 71
    move-result v2

    .line 72
    new-instance v8, Landroidx/compose/ui/unit/Dp;

    .line 74
    invoke-direct {v8, v2}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 77
    invoke-virtual {v3, v8}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 80
    move-result v2

    .line 81
    if-lez v2, :cond_53

    .line 83
    move-object v3, v8

    .line 84
    :cond_53
    sget-object v2, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 86
    iget v3, v3, Landroidx/compose/ui/unit/Dp;->value:F

    .line 88
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->requiredSize-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 91
    move-result-object v8

    .line 92
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 94
    invoke-virtual {v12, v9}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 97
    move-result v10

    .line 98
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 101
    move-result-object v11

    .line 102
    sget-object v13, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 104
    if-nez v10, :cond_6b

    .line 106
    if-ne v11, v13, :cond_74

    .line 108
    :cond_6b
    new-instance v11, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;

    .line 110
    const/4 v10, 0x3

    .line 111
    invoke-direct {v11, v9, v10}, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 114
    invoke-virtual {v12, v11}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 117
    :cond_74
    check-cast v11, Lkotlin/jvm/functions/Function1;

    .line 119
    invoke-static {v8, v11}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 122
    move-result-object v8

    .line 123
    iget-wide v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$1:J

    .line 125
    invoke-virtual {v12, v10, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 128
    move-result v14

    .line 129
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 132
    move-result-object v5

    .line 133
    if-nez v14, :cond_88

    .line 135
    if-ne v5, v13, :cond_92

    .line 137
    :cond_88
    new-instance v5, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 139
    const/16 v14, 0xb

    .line 141
    invoke-direct {v5, v10, v11, v14}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 144
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 147
    :cond_92
    check-cast v5, Lkotlin/jvm/functions/Function1;

    .line 149
    invoke-static {v8, v5, v12, v7}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 152
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->requiredSize-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 155
    move-result-object v5

    .line 156
    const-string v8, "sun"

    .line 158
    invoke-static {v5, v8}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 161
    move-result-object v5

    .line 162
    invoke-virtual {v12, v9}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 165
    move-result v8

    .line 166
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 169
    move-result-object v10

    .line 170
    if-nez v8, :cond_ad

    .line 172
    if-ne v10, v13, :cond_b5

    .line 174
    :cond_ad
    new-instance v10, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;

    .line 176
    invoke-direct {v10, v9, v4}, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 179
    invoke-virtual {v12, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 182
    :cond_b5
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 184
    invoke-static {v5, v10}, Landroidx/compose/ui/draw/ClipKt;->drawWithContent(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 187
    move-result-object v4

    .line 188
    sget-object v5, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 190
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 193
    move-result-object v5

    .line 194
    iget-wide v10, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 196
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 199
    move-result v8

    .line 200
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 203
    move-result-object v10

    .line 204
    invoke-static {v12, v4}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 207
    move-result-object v4

    .line 208
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 210
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 213
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 215
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 218
    iget-boolean v14, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 220
    if-eqz v14, :cond_e1

    .line 222
    invoke-virtual {v12, v11}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 225
    goto :goto_e4

    .line 226
    :cond_e1
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 229
    :goto_e4
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 231
    invoke-static {v12, v5, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 234
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 236
    invoke-static {v12, v10, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 239
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 241
    iget-boolean v10, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 243
    if-nez v10, :cond_102

    .line 245
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 248
    move-result-object v10

    .line 249
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 252
    move-result-object v11

    .line 253
    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 256
    move-result v10

    .line 257
    if-nez v10, :cond_105

    .line 259
    :cond_102
    invoke-static {v8, v12, v8, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 262
    :cond_105
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 264
    invoke-static {v12, v4, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 267
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 269
    iget-object v4, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 271
    const/high16 v5, 0x3f800000    # 1.0f

    .line 273
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 276
    move-result-object v5

    .line 277
    move-object v8, v13

    .line 278
    const v13, 0x30006180

    .line 281
    const/16 v14, 0x1e0

    .line 283
    move v10, v3

    .line 284
    iget v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$3:F

    .line 286
    move-object v11, v2

    .line 287
    move-object v2, v4

    .line 288
    const/4 v4, 0x0

    .line 289
    move/from16 v16, v6

    .line 291
    move-object v6, v5

    .line 292
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$4:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 294
    move/from16 v17, v7

    .line 296
    const/4 v7, 0x0

    .line 297
    move-object/from16 v18, v8

    .line 299
    const/4 v8, 0x0

    .line 300
    move-object/from16 v19, v9

    .line 302
    const/4 v9, 0x0

    .line 303
    move/from16 v20, v10

    .line 305
    const/4 v10, 0x0

    .line 306
    move-object/from16 v21, v11

    .line 308
    const/4 v11, 0x0

    .line 309
    move-object/from16 p1, v1

    .line 311
    move/from16 v1, v16

    .line 313
    move/from16 v15, v17

    .line 315
    move-object/from16 v26, v18

    .line 317
    move-object/from16 p3, v19

    .line 319
    const/16 v16, 0x12

    .line 321
    invoke-static/range {v2 .. v14}, Lcom/spotifry/music/ui/listening/SunKt;->Sun(Ljava/util/List;FZLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/Modifier;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function1;Ljava/lang/String;ZLandroidx/compose/runtime/ComposerImpl;II)V

    .line 324
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 327
    const v4, 0x3ee147ae    # 0.44f

    .line 330
    mul-float v4, v4, v20

    .line 332
    sget-object v5, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 334
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 337
    move-result-object v5

    .line 338
    check-cast v5, Landroidx/compose/ui/unit/Density;

    .line 340
    iget-object v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$5:Landroidx/compose/ui/text/TextStyle;

    .line 342
    iget-object v6, v0, Landroidx/compose/ui/text/TextStyle;->paragraphStyle:Landroidx/compose/ui/text/ParagraphStyle;

    .line 344
    iget-wide v6, v6, Landroidx/compose/ui/text/ParagraphStyle;->lineHeight:J

    .line 346
    invoke-interface {v5, v6, v7}, Landroidx/compose/ui/unit/Density;->toDp-GaN1DYA(J)F

    .line 349
    move-result v5

    .line 350
    const/high16 v27, 0x40000000    # 2.0f

    .line 352
    div-float v5, v5, v27

    .line 354
    invoke-virtual/range {p1 .. p1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 357
    move-result v6

    .line 358
    div-float v6, v6, v27

    .line 360
    sub-float/2addr v6, v5

    .line 361
    new-instance v7, Landroidx/compose/ui/unit/Dp;

    .line 363
    invoke-direct {v7, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 366
    invoke-static {v2, v3, v1}, Lcom/spotifry/music/ui/listening/SunKt;->sunReach(Ljava/util/List;FZ)F

    .line 369
    move-result v8

    .line 370
    mul-float v8, v8, v20

    .line 372
    const/high16 v9, 0x41000000    # 8.0f

    .line 374
    add-float/2addr v8, v9

    .line 375
    add-float/2addr v8, v5

    .line 376
    new-instance v10, Landroidx/compose/ui/unit/Dp;

    .line 378
    invoke-direct {v10, v8}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 381
    invoke-virtual {v7, v10}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 384
    move-result v8

    .line 385
    if-gez v8, :cond_183

    .line 387
    move-object v7, v10

    .line 388
    :cond_183
    new-instance v8, Landroidx/compose/ui/unit/Dp;

    .line 390
    invoke-direct {v8, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 393
    invoke-virtual {v7, v8}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 396
    move-result v10

    .line 397
    if-lez v10, :cond_18f

    .line 399
    move-object v7, v8

    .line 400
    :cond_18f
    new-instance v8, Landroidx/compose/ui/unit/Dp;

    .line 402
    invoke-direct {v8, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 405
    invoke-static {v2, v3, v15}, Lcom/spotifry/music/ui/listening/SunKt;->sunReach(Ljava/util/List;FZ)F

    .line 408
    move-result v2

    .line 409
    mul-float v2, v2, v20

    .line 411
    add-float/2addr v2, v9

    .line 412
    add-float/2addr v2, v5

    .line 413
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 415
    invoke-direct {v3, v2}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 418
    invoke-virtual {v8, v3}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 421
    move-result v2

    .line 422
    if-gez v2, :cond_1a8

    .line 424
    move-object v8, v3

    .line 425
    :cond_1a8
    new-instance v2, Landroidx/compose/ui/unit/Dp;

    .line 427
    invoke-direct {v2, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 430
    invoke-virtual {v8, v2}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 433
    move-result v3

    .line 434
    if-lez v3, :cond_1b4

    .line 436
    move-object v8, v2

    .line 437
    :cond_1b4
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 440
    move-result-object v2

    .line 441
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 443
    const/4 v5, 0x0

    .line 444
    invoke-direct {v3, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 447
    iget v6, v7, Landroidx/compose/ui/unit/Dp;->value:F

    .line 449
    neg-float v6, v6

    .line 450
    new-instance v7, Landroidx/compose/ui/unit/Dp;

    .line 452
    invoke-direct {v7, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 455
    new-instance v6, Lkotlin/Pair;

    .line 457
    invoke-direct {v6, v3, v7}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 460
    new-instance v3, Lkotlin/Pair;

    .line 462
    invoke-direct {v3, v2, v6}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 465
    const/4 v2, 0x6

    .line 466
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 469
    move-result-object v2

    .line 470
    new-instance v6, Landroidx/compose/ui/unit/Dp;

    .line 472
    invoke-direct {v6, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 475
    new-instance v7, Landroidx/compose/ui/unit/Dp;

    .line 477
    invoke-direct {v7, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 480
    new-instance v10, Lkotlin/Pair;

    .line 482
    invoke-direct {v10, v6, v7}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 485
    new-instance v6, Lkotlin/Pair;

    .line 487
    invoke-direct {v6, v2, v10}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 490
    const/16 v2, 0xc

    .line 492
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 495
    move-result-object v2

    .line 496
    new-instance v7, Landroidx/compose/ui/unit/Dp;

    .line 498
    invoke-direct {v7, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 501
    new-instance v10, Lkotlin/Pair;

    .line 503
    invoke-direct {v10, v7, v8}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 506
    new-instance v7, Lkotlin/Pair;

    .line 508
    invoke-direct {v7, v2, v10}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 511
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 514
    move-result-object v2

    .line 515
    neg-float v4, v4

    .line 516
    new-instance v8, Landroidx/compose/ui/unit/Dp;

    .line 518
    invoke-direct {v8, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 521
    new-instance v4, Landroidx/compose/ui/unit/Dp;

    .line 523
    invoke-direct {v4, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 526
    new-instance v10, Lkotlin/Pair;

    .line 528
    invoke-direct {v10, v8, v4}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 531
    new-instance v4, Lkotlin/Pair;

    .line 533
    invoke-direct {v4, v2, v10}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 536
    filled-new-array {v3, v6, v7, v4}, [Lkotlin/Pair;

    .line 539
    move-result-object v2

    .line 540
    invoke-static {v2}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 543
    move-result-object v2

    .line 544
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 547
    move-result-object v28

    .line 548
    :goto_223
    invoke-interface/range {v28 .. v28}, Ljava/util/Iterator;->hasNext()Z

    .line 551
    move-result v2

    .line 552
    if-eqz v2, :cond_2e9

    .line 554
    invoke-interface/range {v28 .. v28}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 557
    move-result-object v2

    .line 558
    check-cast v2, Lkotlin/Pair;

    .line 560
    iget-object v3, v2, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 562
    check-cast v3, Ljava/lang/Number;

    .line 564
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 567
    move-result v3

    .line 568
    iget-object v2, v2, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 570
    check-cast v2, Lkotlin/Pair;

    .line 572
    invoke-static {v3}, Lcom/spotifry/music/data/Log;->hourName(I)Ljava/lang/String;

    .line 575
    move-result-object v4

    .line 576
    iget-object v6, v2, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 578
    check-cast v6, Landroidx/compose/ui/unit/Dp;

    .line 580
    iget v6, v6, Landroidx/compose/ui/unit/Dp;->value:F

    .line 582
    move-object/from16 v11, v21

    .line 584
    invoke-static {v11, v5, v6, v1}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 587
    move-result-object v6

    .line 588
    const/4 v7, 0x2

    .line 589
    invoke-static {v6, v9, v5, v7}, Landroidx/compose/foundation/layout/OffsetKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 592
    move-result-object v6

    .line 593
    invoke-virtual/range {p1 .. p1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 596
    move-result v8

    .line 597
    div-float v8, v8, v27

    .line 599
    sub-float/2addr v8, v9

    .line 600
    iget-object v2, v2, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 602
    check-cast v2, Landroidx/compose/ui/unit/Dp;

    .line 604
    iget v2, v2, Landroidx/compose/ui/unit/Dp;->value:F

    .line 606
    add-float/2addr v8, v2

    .line 607
    new-instance v2, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;

    .line 609
    const/high16 v10, 0x3f000000    # 0.5f

    .line 611
    invoke-direct {v2, v8, v10}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;-><init>(FF)V

    .line 614
    invoke-static {v6, v2}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 617
    move-result-object v2

    .line 618
    move-object/from16 v6, p3

    .line 620
    invoke-virtual {v12, v6}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 623
    move-result v8

    .line 624
    invoke-virtual {v12, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 627
    move-result v10

    .line 628
    or-int/2addr v8, v10

    .line 629
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 632
    move-result-object v10

    .line 633
    if-nez v8, :cond_27f

    .line 635
    move-object/from16 v8, v26

    .line 637
    if-ne v10, v8, :cond_289

    .line 639
    goto :goto_281

    .line 640
    :cond_27f
    move-object/from16 v8, v26

    .line 642
    :goto_281
    new-instance v10, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;

    .line 644
    invoke-direct {v10, v6, v3, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;-><init>(Ljava/lang/Object;IB)V

    .line 647
    invoke-virtual {v12, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 650
    :cond_289
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 652
    invoke-static {v2, v10}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 655
    move-result-object v3

    .line 656
    move-object v2, v4

    .line 657
    move v10, v5

    .line 658
    invoke-static {v12}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 661
    move-result-wide v4

    .line 662
    const/16 v24, 0x6000

    .line 664
    const v25, 0x1bff8

    .line 667
    move-object/from16 v19, v6

    .line 669
    const-wide/16 v6, 0x0

    .line 671
    move-object/from16 v18, v8

    .line 673
    const/4 v8, 0x0

    .line 674
    move v14, v9

    .line 675
    const/4 v9, 0x0

    .line 676
    move/from16 v16, v10

    .line 678
    const/4 v10, 0x0

    .line 679
    move-object/from16 v21, v11

    .line 681
    move-object/from16 v22, v12

    .line 683
    const-wide/16 v11, 0x0

    .line 685
    const/4 v13, 0x0

    .line 686
    move/from16 v23, v14

    .line 688
    move/from16 v20, v15

    .line 690
    const-wide/16 v14, 0x0

    .line 692
    move/from16 v26, v16

    .line 694
    const/16 v16, 0x0

    .line 696
    const/16 v17, 0x0

    .line 698
    move-object/from16 v30, v18

    .line 700
    const/16 v18, 0x1

    .line 702
    move-object/from16 v31, v19

    .line 704
    const/16 v19, 0x0

    .line 706
    move/from16 v32, v20

    .line 708
    const/16 v20, 0x0

    .line 710
    move/from16 v33, v23

    .line 712
    const/16 v23, 0x0

    .line 714
    move-object/from16 v34, v21

    .line 716
    move-object/from16 v21, v0

    .line 718
    move-object/from16 v0, v34

    .line 720
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 723
    move-object/from16 p3, v21

    .line 725
    move-object/from16 v21, v0

    .line 727
    move-object/from16 v0, p3

    .line 729
    move-object/from16 v12, v22

    .line 731
    move/from16 v5, v26

    .line 733
    move-object/from16 v26, v30

    .line 735
    move-object/from16 p3, v31

    .line 737
    move/from16 v15, v32

    .line 739
    move/from16 v9, v33

    .line 741
    goto/16 :goto_223

    .line 743
    :cond_2e6
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 746
    :cond_2e9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 748
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda17 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda17)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$2:Ljava/lang/Integer;

.field public final synthetic f$3:J

.field public final synthetic f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

.field public final synthetic f$5:Ljava/lang/String;

.field public final synthetic f$6:I

.field public final synthetic f$7:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$8:J


# direct methods
.method public synthetic constructor <init>(ZLcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/lang/Integer;JLcom/spotifry/music/ui/spotifried/CountUp;Ljava/lang/String;ILandroidx/compose/animation/core/Animatable;J)V
    .registers 12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$0:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$2:Ljava/lang/Integer;

    .line 10
    iput-wide p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$3:J

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$5:Ljava/lang/String;

    .line 16
    iput p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$6:I

    .line 18
    iput-object p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$7:Landroidx/compose/animation/core/Animatable;

    .line 20
    iput-wide p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$8:J

    .line 22
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 43

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 5
    iget-object v9, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 7
    move-object/from16 v1, p1

    .line 9
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 11
    move-object/from16 v6, p2

    .line 13
    check-cast v6, Landroidx/compose/runtime/ComposerImpl;

    .line 15
    move-object/from16 v3, p3

    .line 17
    check-cast v3, Ljava/lang/Integer;

    .line 19
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 22
    move-result v3

    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    and-int/lit8 v4, v3, 0x6

    .line 28
    const/4 v5, 0x4

    .line 29
    if-nez v4, :cond_28

    .line 31
    invoke-virtual {v6, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 34
    move-result v4

    .line 35
    if-eqz v4, :cond_26

    .line 37
    move v4, v5

    .line 38
    goto :goto_27

    .line 39
    :cond_26
    const/4 v4, 0x2

    .line 40
    :goto_27
    or-int/2addr v3, v4

    .line 41
    :cond_28
    and-int/lit8 v4, v3, 0x13

    .line 43
    const/16 v7, 0x12

    .line 45
    const/4 v8, 0x1

    .line 46
    if-eq v4, v7, :cond_31

    .line 48
    move v4, v8

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    const/4 v4, 0x0

    .line 51
    :goto_32
    and-int/2addr v3, v8

    .line 52
    invoke-virtual {v6, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v3

    .line 56
    if-eqz v3, :cond_295

    .line 58
    new-instance v3, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 60
    invoke-direct {v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 63
    iget-object v4, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->start:Ljava/time/LocalDate;

    .line 65
    iget-wide v11, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 67
    iget-object v7, v9, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->label:Ljava/lang/String;

    .line 69
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 72
    move-result v13

    .line 73
    const-string v14, ", "

    .line 75
    const-string v15, " "

    .line 77
    if-ne v13, v5, :cond_69

    .line 79
    const/4 v5, 0x0

    .line 80
    :goto_4f
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 83
    move-result v13

    .line 84
    if-ge v5, v13, :cond_62

    .line 86
    invoke-virtual {v7, v5}, Ljava/lang/String;->charAt(I)C

    .line 89
    move-result v13

    .line 90
    invoke-static {v13}, Ljava/lang/Character;->isDigit(C)Z

    .line 93
    move-result v13

    .line 94
    if-eqz v13, :cond_69

    .line 96
    add-int/lit8 v5, v5, 0x1

    .line 98
    goto :goto_4f

    .line 99
    :cond_62
    const-string v5, "You gave "

    .line 101
    invoke-static {v5, v7, v15}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 104
    move-result-object v5

    .line 105
    goto :goto_83

    .line 106
    :cond_69
    const-string v5, "Last 12 months"

    .line 108
    invoke-virtual {v7, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 111
    move-result v5

    .line 112
    if-eqz v5, :cond_74

    .line 114
    const-string v5, "Twelve months, "

    .line 116
    goto :goto_83

    .line 117
    :cond_74
    const-string v5, "All time"

    .line 119
    invoke-virtual {v7, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 122
    move-result v5

    .line 123
    if-eqz v5, :cond_7f

    .line 125
    const-string v5, "All told, "

    .line 127
    goto :goto_83

    .line 128
    :cond_7f
    invoke-virtual {v7, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 131
    move-result-object v5

    .line 132
    :goto_83
    invoke-virtual {v3, v5}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 135
    new-instance v16, Landroidx/compose/ui/text/SpanStyle;

    .line 137
    const/16 v34, 0x0

    .line 139
    const v35, 0xffbe

    .line 142
    move-object/from16 v36, v9

    .line 144
    iget-wide v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$3:J

    .line 146
    const-wide/16 v19, 0x0

    .line 148
    const/16 v21, 0x0

    .line 150
    const/16 v22, 0x0

    .line 152
    const/16 v23, 0x0

    .line 154
    const/16 v24, 0x0

    .line 156
    const-string v25, "tnum"

    .line 158
    const-wide/16 v26, 0x0

    .line 160
    const/16 v28, 0x0

    .line 162
    const/16 v29, 0x0

    .line 164
    const/16 v30, 0x0

    .line 166
    const-wide/16 v31, 0x0

    .line 168
    const/16 v33, 0x0

    .line 170
    move-wide/from16 v17, v8

    .line 172
    invoke-direct/range {v16 .. v35}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 175
    move-object/from16 v5, v16

    .line 177
    move-wide/from16 v7, v17

    .line 179
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 181
    iget-object v13, v9, Lcom/spotifry/music/ui/spotifried/CountUp;->text:Ljava/lang/String;

    .line 183
    iget-object v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$5:Ljava/lang/String;

    .line 185
    invoke-static {v13, v15, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 188
    move-result-object v10

    .line 189
    invoke-static {v3, v9, v5, v10}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countSpan(Landroidx/compose/ui/text/AnnotatedString$Builder;Lcom/spotifry/music/ui/spotifried/CountUp;Landroidx/compose/ui/text/SpanStyle;Ljava/lang/String;)V

    .line 192
    invoke-virtual {v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 195
    move-result-object v10

    .line 196
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 198
    iget-boolean v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$0:Z

    .line 200
    const/16 v5, 0x36

    .line 202
    move-wide v15, v11

    .line 203
    const/4 v13, 0x0

    .line 204
    invoke-static {v3, v13, v9, v6, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 207
    move-result-object v11

    .line 208
    sget-object v27, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 210
    const/high16 v30, 0x6000000

    .line 212
    const v31, 0x3fffc

    .line 215
    const-wide/16 v12, 0x0

    .line 217
    move-wide/from16 v18, v15

    .line 219
    move-object/from16 v16, v14

    .line 221
    const-wide/16 v14, 0x0

    .line 223
    move-object/from16 v20, v16

    .line 225
    const/16 v16, 0x0

    .line 227
    move-wide/from16 v21, v18

    .line 229
    const-wide/16 v17, 0x0

    .line 231
    move-object/from16 v23, v20

    .line 233
    const-wide/16 v19, 0x0

    .line 235
    move-wide/from16 v25, v21

    .line 237
    const/16 v21, 0x0

    .line 239
    const/16 v22, 0x0

    .line 241
    move-object/from16 v28, v23

    .line 243
    const/16 v23, 0x0

    .line 245
    const/16 v24, 0x0

    .line 247
    move-wide/from16 v32, v25

    .line 249
    const/16 v25, 0x0

    .line 251
    const/16 v26, 0x0

    .line 253
    const/16 v29, 0x0

    .line 255
    move-object/from16 v37, v28

    .line 257
    move-object/from16 v28, v6

    .line 259
    move-object/from16 v6, v37

    .line 261
    invoke-static/range {v10 .. v31}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 264
    move-object/from16 v10, v28

    .line 266
    const-wide/32 v11, 0x15180

    .line 269
    cmp-long v11, v32, v11

    .line 271
    const v12, 0x1d46319c

    .line 274
    if-ltz v11, :cond_184

    .line 276
    const v11, 0x1e7124bd

    .line 279
    invoke-virtual {v10, v11}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 282
    invoke-static/range {v32 .. v33}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 285
    move-result v11

    .line 286
    invoke-static {v11}, Lcom/spotifry/music/data/Log;->longDuration(I)Ljava/lang/String;

    .line 289
    move-result-object v11

    .line 290
    const-string v13, "That is "

    .line 292
    const-string v14, ", with no break."

    .line 294
    invoke-static {v13, v11, v14}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 297
    move-result-object v11

    .line 298
    const/16 v19, 0x0

    .line 300
    const/16 v20, 0xd

    .line 302
    const/16 v16, 0x0

    .line 304
    const/high16 v17, 0x41600000    # 14.0f

    .line 306
    const/16 v18, 0x0

    .line 308
    move-object v15, v3

    .line 309
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 312
    move-result-object v3

    .line 313
    move-object/from16 v34, v15

    .line 315
    const/4 v13, 0x1

    .line 316
    invoke-static {v3, v13, v9, v10, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 319
    move-result-object v3

    .line 320
    move v15, v13

    .line 321
    invoke-static {v10}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 324
    move-result-wide v12

    .line 325
    sget-object v29, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 327
    const/high16 v32, 0xc00000

    .line 329
    const v33, 0x1fff8

    .line 332
    move/from16 v17, v15

    .line 334
    const-wide/16 v14, 0x0

    .line 336
    const/16 v16, 0x0

    .line 338
    move/from16 v19, v17

    .line 340
    const/16 v17, 0x0

    .line 342
    const/16 v18, 0x0

    .line 344
    move/from16 v22, v19

    .line 346
    const-wide/16 v19, 0x0

    .line 348
    const/16 v21, 0x0

    .line 350
    move/from16 v25, v22

    .line 352
    const-wide/16 v22, 0x0

    .line 354
    const/16 v24, 0x0

    .line 356
    move/from16 v27, v25

    .line 358
    const/16 v25, 0x0

    .line 360
    const/16 v26, 0x0

    .line 362
    move/from16 v30, v27

    .line 364
    const/16 v27, 0x0

    .line 366
    const/16 v28, 0x0

    .line 368
    const/16 v31, 0x0

    .line 370
    move-object/from16 v37, v11

    .line 372
    move-object v11, v3

    .line 373
    move/from16 v35, v30

    .line 375
    move-object/from16 v30, v10

    .line 377
    move-object/from16 v10, v37

    .line 379
    invoke-static/range {v10 .. v33}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 382
    move-object/from16 v10, v30

    .line 384
    const/4 v11, 0x0

    .line 385
    :goto_180
    invoke-virtual {v10, v11}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 388
    goto :goto_18e

    .line 389
    :cond_184
    move-object/from16 v34, v3

    .line 391
    move v3, v12

    .line 392
    const/4 v11, 0x0

    .line 393
    const/16 v35, 0x1

    .line 395
    invoke-virtual {v10, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 398
    goto :goto_180

    .line 399
    :goto_18e
    const/high16 v12, 0x3f800000    # 1.0f

    .line 401
    invoke-static {v1, v12}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 404
    move-result-object v1

    .line 405
    invoke-static {v1, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 408
    move-result-object v12

    .line 409
    sget-object v13, Landroidx/compose/ui/Alignment$Companion;->BottomStart:Landroidx/compose/ui/BiasAlignment;

    .line 411
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;

    .line 413
    move-object v14, v1

    .line 414
    iget v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$6:I

    .line 416
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$2:Ljava/lang/Integer;

    .line 418
    move-object v15, v4

    .line 419
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$7:Landroidx/compose/animation/core/Animatable;

    .line 421
    move-object/from16 v16, v6

    .line 423
    iget-wide v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$8:J

    .line 425
    move-wide/from16 v37, v7

    .line 427
    move-wide v7, v5

    .line 428
    move-wide/from16 v5, v37

    .line 430
    move-object v0, v14

    .line 431
    move-object/from16 v11, v16

    .line 433
    move/from16 v14, v35

    .line 435
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;-><init>(ILcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/lang/Integer;Landroidx/compose/animation/core/Animatable;JJ)V

    .line 438
    move-object v1, v3

    .line 439
    move-object v3, v12

    .line 440
    move-object v4, v13

    .line 441
    move-wide v12, v5

    .line 442
    const v5, -0x1d8a8ca4

    .line 445
    invoke-static {v5, v0, v10}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 448
    move-result-object v5

    .line 449
    const/16 v7, 0xc30

    .line 451
    const/4 v8, 0x4

    .line 452
    move-object v6, v10

    .line 453
    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 456
    if-eqz v1, :cond_28d

    .line 458
    const v0, 0x1e8c731e

    .line 461
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 464
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 467
    move-result v0

    .line 468
    int-to-long v3, v0

    .line 469
    invoke-virtual {v15, v3, v4}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 472
    move-result-object v0

    .line 473
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->daySeconds:Ljava/util/List;

    .line 475
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 478
    move-result v1

    .line 479
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 482
    move-result-object v1

    .line 483
    check-cast v1, Ljava/lang/Number;

    .line 485
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 488
    move-result-wide v1

    .line 489
    long-to-double v3, v1

    .line 490
    const-wide v5, 0x40ac200000000000L    # 3600.0

    .line 495
    div-double/2addr v3, v5

    .line 496
    invoke-static {v3, v4}, Lkotlin/math/MathKt;->roundToInt(D)I

    .line 499
    move-result v3

    .line 500
    if-lt v3, v14, :cond_1fc

    .line 502
    const-string v1, "hour"

    .line 504
    invoke-static {v3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->plural(ILjava/lang/String;)Ljava/lang/String;

    .line 507
    move-result-object v1

    .line 508
    goto :goto_206

    .line 509
    :cond_1fc
    invoke-static {v1, v2}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 512
    move-result v1

    .line 513
    const-string v2, "minute"

    .line 515
    invoke-static {v1, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->plural(ILjava/lang/String;)Ljava/lang/String;

    .line 518
    move-result-object v1

    .line 519
    :goto_206
    invoke-virtual {v15}, Ljava/time/LocalDate;->getYear()I

    .line 522
    move-result v2

    .line 523
    move-object/from16 v3, v36

    .line 525
    iget-object v3, v3, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->to:Ljava/time/LocalDate;

    .line 527
    invoke-virtual {v3}, Ljava/time/LocalDate;->getYear()I

    .line 530
    move-result v3

    .line 531
    if-eq v2, v3, :cond_217

    .line 533
    const-string v2, "d MMMM yyyy"

    .line 535
    goto :goto_219

    .line 536
    :cond_217
    const-string v2, "d MMMM"

    .line 538
    :goto_219
    sget-object v3, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 540
    invoke-static {v2, v3}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    .line 543
    move-result-object v2

    .line 544
    invoke-virtual {v0, v2}, Ljava/time/LocalDate;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 547
    move-result-object v0

    .line 548
    const-string v2, "Longest day: "

    .line 550
    invoke-static {v2, v1, v11, v0}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 553
    move-result-object v0

    .line 554
    const/16 v19, 0x0

    .line 556
    const/16 v20, 0xd

    .line 558
    const/16 v16, 0x0

    .line 560
    const/high16 v17, 0x41200000    # 10.0f

    .line 562
    const/16 v18, 0x0

    .line 564
    move-object/from16 v15, v34

    .line 566
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 569
    move-result-object v1

    .line 570
    const/4 v2, 0x3

    .line 571
    const/16 v3, 0x36

    .line 573
    invoke-static {v1, v2, v9, v10, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 576
    move-result-object v11

    .line 577
    sget-object v14, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 579
    const/16 v1, 0xe

    .line 581
    invoke-static {v1}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 584
    move-result-wide v17

    .line 585
    const/16 v1, 0x13

    .line 587
    invoke-static {v1}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 590
    move-result-wide v25

    .line 591
    sget-object v19, Landroidx/compose/ui/text/font/FontWeight;->SemiBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 593
    const/16 v28, 0x0

    .line 595
    const v29, 0xfdfff9

    .line 598
    const-wide/16 v15, 0x0

    .line 600
    const/16 v20, 0x0

    .line 602
    const/16 v21, 0x0

    .line 604
    const-wide/16 v22, 0x0

    .line 606
    const/16 v24, 0x0

    .line 608
    const/16 v27, 0x0

    .line 610
    invoke-static/range {v14 .. v29}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 613
    move-result-object v29

    .line 614
    const/16 v32, 0x0

    .line 616
    const v33, 0x1fff8

    .line 619
    const-wide/16 v14, 0x0

    .line 621
    const/16 v16, 0x0

    .line 623
    const/16 v17, 0x0

    .line 625
    const/16 v18, 0x0

    .line 627
    const-wide/16 v19, 0x0

    .line 629
    const/16 v24, 0x0

    .line 631
    const/16 v25, 0x0

    .line 633
    const/16 v26, 0x0

    .line 635
    const/16 v27, 0x0

    .line 637
    const/16 v28, 0x0

    .line 639
    const/16 v31, 0x0

    .line 641
    move-object/from16 v30, v10

    .line 643
    move-object v10, v0

    .line 644
    const/4 v0, 0x0

    .line 645
    invoke-static/range {v10 .. v33}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 648
    move-object/from16 v10, v30

    .line 650
    :goto_289
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 653
    goto :goto_299

    .line 654
    :cond_28d
    const/4 v0, 0x0

    .line 655
    const v14, 0x1d46319c

    .line 658
    invoke-virtual {v10, v14}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 661
    goto :goto_289

    .line 662
    :cond_295
    move-object v10, v6

    .line 663
    invoke-virtual {v10}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 666
    :goto_299
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 668
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda45 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda45)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$2:Ljava/lang/Integer;

.field public final synthetic f$3:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$4:J

.field public final synthetic f$5:J


# direct methods
.method public synthetic constructor <init>(ILcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/lang/Integer;Landroidx/compose/animation/core/Animatable;JJ)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$0:I

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$2:Ljava/lang/Integer;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 12
    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$4:J

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$5:J

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 32

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 5
    iget-object v2, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->daySeconds:Ljava/util/List;

    .line 7
    move-object/from16 v3, p1

    .line 9
    check-cast v3, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 11
    move-object/from16 v4, p2

    .line 13
    check-cast v4, Landroidx/compose/runtime/ComposerImpl;

    .line 15
    move-object/from16 v5, p3

    .line 17
    check-cast v5, Ljava/lang/Integer;

    .line 19
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 22
    move-result v5

    .line 23
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    and-int/lit8 v6, v5, 0x6

    .line 28
    if-nez v6, :cond_27

    .line 30
    invoke-virtual {v4, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 33
    move-result v6

    .line 34
    if-eqz v6, :cond_25

    .line 36
    const/4 v6, 0x4

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    const/4 v6, 0x2

    .line 39
    :goto_26
    or-int/2addr v5, v6

    .line 40
    :cond_27
    and-int/lit8 v6, v5, 0x13

    .line 42
    const/16 v7, 0x12

    .line 44
    const/4 v8, 0x0

    .line 45
    const/4 v9, 0x1

    .line 46
    if-eq v6, v7, :cond_31

    .line 48
    move v6, v9

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v6, v8

    .line 51
    :goto_32
    and-int/2addr v5, v9

    .line 52
    invoke-virtual {v4, v5, v6}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_379

    .line 58
    invoke-virtual {v3}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 61
    move-result v5

    .line 62
    const/high16 v6, 0x40200000    # 2.5f

    .line 64
    div-float v6, v5, v6

    .line 66
    float-to-int v6, v6

    .line 67
    iget v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$0:I

    .line 69
    invoke-static {v7, v6}, Ljava/lang/Math;->min(II)I

    .line 72
    move-result v6

    .line 73
    if-ge v6, v9, :cond_4b

    .line 75
    move v6, v9

    .line 76
    :cond_4b
    int-to-float v10, v6

    .line 77
    div-float/2addr v5, v10

    .line 78
    new-instance v10, Landroidx/compose/ui/unit/Dp;

    .line 80
    const/high16 v11, 0x3f800000    # 1.0f

    .line 82
    invoke-direct {v10, v11}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 85
    const v12, 0x3ecccccd    # 0.4f

    .line 88
    mul-float/2addr v12, v5

    .line 89
    new-instance v13, Landroidx/compose/ui/unit/Dp;

    .line 91
    invoke-direct {v13, v12}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 94
    invoke-virtual {v10, v13}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 97
    move-result v12

    .line 98
    if-lez v12, :cond_64

    .line 100
    move-object v10, v13

    .line 101
    :cond_64
    iget v10, v10, Landroidx/compose/ui/unit/Dp;->value:F

    .line 103
    sub-float/2addr v5, v10

    .line 104
    new-instance v10, Landroidx/compose/ui/unit/Dp;

    .line 106
    invoke-direct {v10, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 109
    sget v5, Lcom/spotifry/music/ui/spotifried/CardsKt;->WIDE_BAR:F

    .line 111
    new-instance v12, Landroidx/compose/ui/unit/Dp;

    .line 113
    invoke-direct {v12, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 116
    invoke-virtual {v10, v12}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 119
    move-result v5

    .line 120
    if-lez v5, :cond_7a

    .line 122
    move-object v10, v12

    .line 123
    :cond_7a
    invoke-virtual {v4, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 126
    move-result v5

    .line 127
    invoke-virtual {v4, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 130
    move-result v12

    .line 131
    or-int/2addr v5, v12

    .line 132
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 135
    move-result-object v12

    .line 136
    sget-object v13, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 138
    if-nez v5, :cond_92

    .line 140
    if-eq v12, v13, :cond_92

    .line 142
    move-object v15, v10

    .line 143
    const/16 p1, 0x0

    .line 145
    goto/16 :goto_13e

    .line 147
    :cond_92
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 150
    move-result v5

    .line 151
    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    .line 154
    move-result v5

    .line 155
    new-array v6, v5, [J

    .line 157
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 160
    move-result-object v12

    .line 161
    move v15, v8

    .line 162
    :goto_a1
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 165
    move-result v16

    .line 166
    if-eqz v16, :cond_d4

    .line 168
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 171
    move-result-object v16

    .line 172
    add-int/lit8 v17, v15, 0x1

    .line 174
    if-ltz v15, :cond_ce

    .line 176
    check-cast v16, Ljava/lang/Number;

    .line 178
    move/from16 p2, v15

    .line 180
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->longValue()J

    .line 183
    move-result-wide v14

    .line 184
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 187
    move-result v16

    .line 188
    mul-int v18, p2, v5

    .line 190
    div-int v18, v18, v16

    .line 192
    move-object/from16 p3, v12

    .line 194
    aget-wide v11, v6, v18

    .line 196
    invoke-static {v11, v12, v14, v15}, Ljava/lang/Math;->max(JJ)J

    .line 199
    move-result-wide v11

    .line 200
    aput-wide v11, v6, v18

    .line 202
    move-object/from16 v12, p3

    .line 204
    move/from16 v15, v17

    .line 206
    goto :goto_a1

    .line 207
    :cond_ce
    const/16 p1, 0x0

    .line 209
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 212
    throw p1

    .line 213
    :cond_d4
    const/16 p1, 0x0

    .line 215
    if-nez v5, :cond_db

    .line 217
    move-object/from16 v2, p1

    .line 219
    goto :goto_f2

    .line 220
    :cond_db
    aget-wide v11, v6, v8

    .line 222
    add-int/lit8 v2, v5, -0x1

    .line 224
    if-gt v9, v2, :cond_ee

    .line 226
    move v14, v9

    .line 227
    :goto_e2
    aget-wide v15, v6, v14

    .line 229
    cmp-long v17, v11, v15

    .line 231
    if-gez v17, :cond_e9

    .line 233
    move-wide v11, v15

    .line 234
    :cond_e9
    if-eq v14, v2, :cond_ee

    .line 236
    add-int/lit8 v14, v14, 0x1

    .line 238
    goto :goto_e2

    .line 239
    :cond_ee
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 242
    move-result-object v2

    .line 243
    :goto_f2
    if-eqz v2, :cond_127

    .line 245
    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    .line 248
    move-result-wide v11

    .line 249
    const-wide/16 v14, 0x0

    .line 251
    cmp-long v11, v11, v14

    .line 253
    if-gtz v11, :cond_100

    .line 255
    move-object/from16 v2, p1

    .line 257
    :cond_100
    if-eqz v2, :cond_127

    .line 259
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 262
    move-result-wide v11

    .line 263
    new-instance v2, Ljava/util/ArrayList;

    .line 265
    invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 268
    move v14, v8

    .line 269
    :goto_10c
    move-object v15, v10

    .line 270
    if-ge v14, v5, :cond_125

    .line 272
    aget-wide v9, v6, v14

    .line 274
    long-to-float v9, v9

    .line 275
    long-to-float v10, v11

    .line 276
    div-float/2addr v9, v10

    .line 277
    float-to-double v9, v9

    .line 278
    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    .line 281
    move-result-wide v9

    .line 282
    double-to-float v9, v9

    .line 283
    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 286
    move-result-object v9

    .line 287
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 290
    add-int/lit8 v14, v14, 0x1

    .line 292
    move-object v10, v15

    .line 293
    goto :goto_10c

    .line 294
    :cond_125
    move-object v12, v2

    .line 295
    goto :goto_13b

    .line 296
    :cond_127
    move-object v15, v10

    .line 297
    new-instance v2, Ljava/util/ArrayList;

    .line 299
    invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 302
    move v6, v8

    .line 303
    :goto_12e
    if-ge v6, v5, :cond_125

    .line 305
    const/4 v9, 0x0

    .line 306
    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 309
    move-result-object v9

    .line 310
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 313
    add-int/lit8 v6, v6, 0x1

    .line 315
    goto :goto_12e

    .line 316
    :goto_13b
    invoke-virtual {v4, v12}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 319
    :goto_13e
    check-cast v12, Ljava/util/List;

    .line 321
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$2:Ljava/lang/Integer;

    .line 323
    if-eqz v2, :cond_153

    .line 325
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 328
    move-result v2

    .line 329
    invoke-interface {v12}, Ljava/util/List;->size()I

    .line 332
    move-result v5

    .line 333
    mul-int/2addr v5, v2

    .line 334
    div-int/2addr v5, v7

    .line 335
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 338
    move-result-object v14

    .line 339
    goto :goto_155

    .line 340
    :cond_153
    move-object/from16 v14, p1

    .line 342
    :goto_155
    invoke-virtual {v3}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 345
    move-result v2

    .line 346
    const/high16 v3, 0x41f00000    # 30.0f

    .line 348
    sub-float/2addr v2, v3

    .line 349
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 351
    invoke-direct {v3, v2}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 354
    new-instance v2, Landroidx/compose/ui/unit/Dp;

    .line 356
    const/high16 v5, 0x43870000    # 270.0f

    .line 358
    invoke-direct {v2, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 361
    invoke-virtual {v3, v2}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 364
    move-result v5

    .line 365
    if-lez v5, :cond_16f

    .line 367
    move-object v3, v2

    .line 368
    :cond_16f
    new-instance v2, Landroidx/compose/ui/unit/Dp;

    .line 370
    const/high16 v5, 0x42200000    # 40.0f

    .line 372
    invoke-direct {v2, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 375
    invoke-virtual {v3, v2}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 378
    move-result v5

    .line 379
    if-gez v5, :cond_17d

    .line 381
    move-object v3, v2

    .line 382
    :cond_17d
    if-lez v7, :cond_370

    .line 384
    const v2, 0x1ae637cb

    .line 387
    invoke-virtual {v4, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 390
    sget-object v2, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 392
    sget-object v5, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 394
    invoke-static {v2, v5, v4, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 397
    move-result-object v2

    .line 398
    iget-wide v5, v4, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 400
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 403
    move-result v5

    .line 404
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 407
    move-result-object v6

    .line 408
    sget-object v9, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 410
    invoke-static {v4, v9}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 413
    move-result-object v10

    .line 414
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 416
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 419
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 421
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 424
    iget-boolean v8, v4, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 426
    if-eqz v8, :cond_1af

    .line 428
    invoke-virtual {v4, v11}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 431
    goto :goto_1b2

    .line 432
    :cond_1af
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 435
    :goto_1b2
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 437
    invoke-static {v4, v2, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 440
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 442
    invoke-static {v4, v6, v2}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 445
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 447
    move-object/from16 v16, v15

    .line 449
    iget-boolean v15, v4, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 451
    if-nez v15, :cond_1d5

    .line 453
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 456
    move-result-object v15

    .line 457
    move/from16 v25, v7

    .line 459
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 462
    move-result-object v7

    .line 463
    invoke-static {v15, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 466
    move-result v7

    .line 467
    if-nez v7, :cond_1da

    .line 469
    goto :goto_1d7

    .line 470
    :cond_1d5
    move/from16 v25, v7

    .line 472
    :goto_1d7
    invoke-static {v5, v4, v5, v6}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 475
    :cond_1da
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 477
    invoke-static {v4, v10, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 480
    const/high16 v7, 0x3f800000    # 1.0f

    .line 482
    invoke-static {v9, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 485
    move-result-object v10

    .line 486
    iget v3, v3, Landroidx/compose/ui/unit/Dp;->value:F

    .line 488
    invoke-static {v10, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 491
    move-result-object v3

    .line 492
    const-string v7, "day_bars"

    .line 494
    invoke-static {v3, v7}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 497
    move-result-object v3

    .line 498
    move-object/from16 v15, v16

    .line 500
    iget v7, v15, Landroidx/compose/ui/unit/Dp;->value:F

    .line 502
    invoke-virtual {v4, v7}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 505
    move-result v10

    .line 506
    invoke-virtual {v4, v12}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 509
    move-result v15

    .line 510
    or-int/2addr v10, v15

    .line 511
    iget-object v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 513
    invoke-virtual {v4, v15}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 516
    move-result v16

    .line 517
    or-int v10, v10, v16

    .line 519
    invoke-virtual {v4, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 522
    move-result v16

    .line 523
    or-int v10, v10, v16

    .line 525
    move-object/from16 v20, v14

    .line 527
    move-object/from16 v19, v15

    .line 529
    iget-wide v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$4:J

    .line 531
    invoke-virtual {v4, v14, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 534
    move-result v16

    .line 535
    or-int v10, v10, v16

    .line 537
    move-wide/from16 v21, v14

    .line 539
    iget-wide v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$5:J

    .line 541
    invoke-virtual {v4, v14, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 544
    move-result v0

    .line 545
    or-int/2addr v10, v0

    .line 546
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 549
    move-result-object v0

    .line 550
    if-nez v10, :cond_229

    .line 552
    if-ne v0, v13, :cond_239

    .line 554
    :cond_229
    new-instance v16, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;

    .line 556
    move/from16 v17, v7

    .line 558
    move-object/from16 v18, v12

    .line 560
    move-wide/from16 v23, v14

    .line 562
    invoke-direct/range {v16 .. v24}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;-><init>(FLjava/util/List;Landroidx/compose/animation/core/Animatable;Ljava/lang/Integer;JJ)V

    .line 565
    move-object/from16 v0, v16

    .line 567
    invoke-virtual {v4, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 570
    :cond_239
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 572
    const/4 v7, 0x0

    .line 573
    invoke-static {v3, v0, v4, v7}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 576
    const/high16 v0, 0x3f800000    # 1.0f

    .line 578
    invoke-static {v9, v0}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 581
    move-result-object v12

    .line 582
    const/16 v16, 0x0

    .line 584
    const/16 v17, 0xd

    .line 586
    const/4 v13, 0x0

    .line 587
    const/high16 v14, 0x41000000    # 8.0f

    .line 589
    const/4 v15, 0x0

    .line 590
    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 593
    move-result-object v0

    .line 594
    sget-object v3, Landroidx/compose/foundation/layout/OffsetKt;->SpaceBetween:Landroidx/compose/foundation/layout/Arrangement$Center$1;

    .line 596
    sget-object v9, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 598
    const/4 v10, 0x6

    .line 599
    invoke-static {v3, v9, v4, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 602
    move-result-object v3

    .line 603
    iget-wide v9, v4, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 605
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 608
    move-result v9

    .line 609
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 612
    move-result-object v10

    .line 613
    invoke-static {v4, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 616
    move-result-object v0

    .line 617
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 620
    iget-boolean v12, v4, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 622
    if-eqz v12, :cond_273

    .line 624
    invoke-virtual {v4, v11}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 627
    goto :goto_276

    .line 628
    :cond_273
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 631
    :goto_276
    invoke-static {v4, v3, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 634
    invoke-static {v4, v10, v2}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 637
    iget-boolean v2, v4, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 639
    if-nez v2, :cond_28e

    .line 641
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 644
    move-result-object v2

    .line 645
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 648
    move-result-object v3

    .line 649
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 652
    move-result v2

    .line 653
    if-nez v2, :cond_291

    .line 655
    :cond_28e
    invoke-static {v9, v4, v9, v6}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 658
    :cond_291
    invoke-static {v4, v0, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 661
    const v0, -0x4182f2d3

    .line 664
    invoke-virtual {v4, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 667
    iget-object v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->start:Ljava/time/LocalDate;

    .line 669
    move/from16 v1, v25

    .line 671
    int-to-long v2, v1

    .line 672
    const-wide/16 v5, 0x1

    .line 674
    sub-long v5, v2, v5

    .line 676
    invoke-virtual {v0, v5, v6}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 679
    move-result-object v5

    .line 680
    invoke-virtual {v0}, Ljava/time/LocalDate;->getYear()I

    .line 683
    move-result v6

    .line 684
    invoke-virtual {v5}, Ljava/time/LocalDate;->getYear()I

    .line 687
    move-result v8

    .line 688
    if-eq v6, v8, :cond_2b4

    .line 690
    const-string v6, "MMM yyyy"

    .line 692
    goto :goto_2bd

    .line 693
    :cond_2b4
    const/16 v6, 0x3e

    .line 695
    if-le v1, v6, :cond_2bb

    .line 697
    const-string v6, "MMM"

    .line 699
    goto :goto_2bd

    .line 700
    :cond_2bb
    const-string v6, "d MMM"

    .line 702
    :goto_2bd
    sget-object v8, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 704
    invoke-static {v6, v8}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    .line 707
    move-result-object v6

    .line 708
    const/16 v8, 0x1e

    .line 710
    if-ge v1, v8, :cond_2d0

    .line 712
    filled-new-array {v0, v5}, [Ljava/time/LocalDate;

    .line 715
    move-result-object v0

    .line 716
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 719
    move-result-object v0

    .line 720
    goto :goto_2df

    .line 721
    :cond_2d0
    const-wide/16 v8, 0x2

    .line 723
    div-long/2addr v2, v8

    .line 724
    invoke-virtual {v0, v2, v3}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 727
    move-result-object v1

    .line 728
    filled-new-array {v0, v1, v5}, [Ljava/time/LocalDate;

    .line 731
    move-result-object v0

    .line 732
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 735
    move-result-object v0

    .line 736
    :goto_2df
    new-instance v1, Ljava/util/ArrayList;

    .line 738
    const/16 v2, 0xa

    .line 740
    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 743
    move-result v2

    .line 744
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 747
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 750
    move-result-object v0

    .line 751
    :goto_2ee
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 754
    move-result v2

    .line 755
    if-eqz v2, :cond_302

    .line 757
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 760
    move-result-object v2

    .line 761
    check-cast v2, Ljava/time/LocalDate;

    .line 763
    invoke-virtual {v2, v6}, Ljava/time/LocalDate;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 766
    move-result-object v2

    .line 767
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 770
    goto :goto_2ee

    .line 771
    :cond_302
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/util/ArrayList;)Ljava/util/List;

    .line 774
    move-result-object v0

    .line 775
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 778
    move-result-object v0

    .line 779
    :goto_30a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 782
    move-result v1

    .line 783
    if-eqz v1, :cond_360

    .line 785
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 788
    move-result-object v1

    .line 789
    check-cast v1, Ljava/lang/String;

    .line 791
    move v2, v7

    .line 792
    invoke-static {v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 795
    move-result-wide v6

    .line 796
    sget-object v8, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 798
    const/16 v3, 0xb

    .line 800
    invoke-static {v3}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 803
    move-result-wide v11

    .line 804
    const/16 v3, 0xe

    .line 806
    invoke-static {v3}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 809
    move-result-wide v19

    .line 810
    const/16 v22, 0x0

    .line 812
    const v23, 0xfdfffd

    .line 815
    const-wide/16 v9, 0x0

    .line 817
    const/4 v13, 0x0

    .line 818
    const/4 v14, 0x0

    .line 819
    const/4 v15, 0x0

    .line 820
    const-wide/16 v16, 0x0

    .line 822
    const/16 v18, 0x0

    .line 824
    const/16 v21, 0x0

    .line 826
    invoke-static/range {v8 .. v23}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 829
    move-result-object v23

    .line 830
    const/16 v26, 0x0

    .line 832
    const v27, 0x1fffa

    .line 835
    const/4 v5, 0x0

    .line 836
    const-wide/16 v8, 0x0

    .line 838
    const/4 v10, 0x0

    .line 839
    const/4 v11, 0x0

    .line 840
    const/4 v12, 0x0

    .line 841
    const-wide/16 v13, 0x0

    .line 843
    const/16 v18, 0x0

    .line 845
    const/16 v19, 0x0

    .line 847
    const/16 v20, 0x0

    .line 849
    const/16 v21, 0x0

    .line 851
    const/16 v22, 0x0

    .line 853
    const/16 v25, 0x0

    .line 855
    move-object/from16 v24, v4

    .line 857
    move-object v4, v1

    .line 858
    invoke-static/range {v4 .. v27}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 861
    move v7, v2

    .line 862
    move-object/from16 v4, v24

    .line 864
    goto :goto_30a

    .line 865
    :cond_360
    move-object v3, v4

    .line 866
    move v2, v7

    .line 867
    const/4 v1, 0x1

    .line 868
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 871
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 874
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 877
    :goto_36c
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 880
    goto :goto_37d

    .line 881
    :cond_370
    move-object v3, v4

    .line 882
    move v2, v8

    .line 883
    const v0, 0x40ace606

    .line 886
    invoke-virtual {v3, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 889
    goto :goto_36c

    .line 890
    :cond_379
    move-object v3, v4

    .line 891
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 894
    :goto_37d
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 896
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda68 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda68)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:F

.field public final synthetic f$1:Ljava/util/List;

.field public final synthetic f$2:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$5:Ljava/lang/Integer;

.field public final synthetic f$6:J

.field public final synthetic f$7:J


# direct methods
.method public synthetic constructor <init>(FLjava/util/List;Landroidx/compose/animation/core/Animatable;Ljava/lang/Integer;JJ)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$0:F

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$1:Ljava/util/List;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$5:Ljava/lang/Integer;

    .line 12
    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$6:J

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$7:J

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 26

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$0:F

    .line 12
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 15
    move-result v13

    .line 16
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$1:Ljava/util/List;

    .line 18
    invoke-interface {v14}, Ljava/util/List;->size()I

    .line 21
    move-result v2

    .line 22
    const/4 v15, 0x0

    .line 23
    const/16 v16, 0x20

    .line 25
    const/4 v3, 0x1

    .line 26
    if-le v2, v3, :cond_31

    .line 28
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 31
    move-result-wide v4

    .line 32
    shr-long v4, v4, v16

    .line 34
    long-to-int v2, v4

    .line 35
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 38
    move-result v2

    .line 39
    sub-float/2addr v2, v13

    .line 40
    invoke-interface {v14}, Ljava/util/List;->size()I

    .line 43
    move-result v4

    .line 44
    sub-int/2addr v4, v3

    .line 45
    int-to-float v3, v4

    .line 46
    div-float/2addr v2, v3

    .line 47
    move/from16 v17, v2

    .line 49
    goto :goto_33

    .line 50
    :cond_31
    move/from16 v17, v15

    .line 52
    :goto_33
    const/high16 v2, 0x3fc00000    # 1.5f

    .line 54
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 57
    move-result v2

    .line 58
    sget v3, Lcom/spotifry/music/ui/spotifried/CardsKt;->WIDE_BAR:F

    .line 60
    invoke-interface {v1, v3}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 63
    move-result v3

    .line 64
    cmpl-float v3, v13, v3

    .line 66
    const/high16 v18, 0x40000000    # 2.0f

    .line 68
    const/high16 v4, 0x3f800000    # 1.0f

    .line 70
    if-ltz v3, :cond_4e

    .line 72
    const/high16 v3, 0x40400000    # 3.0f

    .line 74
    invoke-interface {v1, v3}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 77
    move-result v3

    .line 78
    goto :goto_58

    .line 79
    :cond_4e
    invoke-interface {v1, v4}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 82
    move-result v3

    .line 83
    div-float v5, v13, v18

    .line 85
    invoke-static {v3, v5}, Ljava/lang/Math;->min(FF)F

    .line 88
    move-result v3

    .line 89
    :goto_58
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 92
    move-result-object v19

    .line 93
    const/4 v5, 0x0

    .line 94
    :goto_5d
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    .line 97
    move-result v6

    .line 98
    if-eqz v6, :cond_123

    .line 100
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 103
    move-result-object v6

    .line 104
    add-int/lit8 v20, v5, 0x1

    .line 106
    if-ltz v5, :cond_11e

    .line 108
    check-cast v6, Ljava/lang/Number;

    .line 110
    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    .line 113
    move-result v6

    .line 114
    sget-object v7, Lcom/spotifry/music/ui/spotifried/CardsKt;->Ease:Landroidx/compose/animation/core/CubicBezierEasing;

    .line 116
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 118
    invoke-virtual {v8}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 121
    move-result-object v8

    .line 122
    check-cast v8, Ljava/lang/Number;

    .line 124
    invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F

    .line 127
    move-result v8

    .line 128
    const/high16 v9, 0x43c80000    # 400.0f

    .line 130
    sub-float/2addr v8, v9

    .line 131
    mul-int/lit16 v9, v5, 0x578

    .line 133
    invoke-interface {v14}, Ljava/util/List;->size()I

    .line 136
    move-result v10

    .line 137
    div-int/2addr v9, v10

    .line 138
    int-to-float v9, v9

    .line 139
    sub-float/2addr v8, v9

    .line 140
    const/high16 v9, 0x442f0000    # 700.0f

    .line 142
    div-float/2addr v8, v9

    .line 143
    invoke-static {v8, v15, v4}, Lkotlin/ResultKt;->coerceIn(FFF)F

    .line 146
    move-result v8

    .line 147
    invoke-virtual {v7, v8}, Landroidx/compose/animation/core/CubicBezierEasing;->transform(F)F

    .line 150
    move-result v7

    .line 151
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 154
    move-result-wide v8

    .line 155
    const-wide v10, 0xffffffffL

    .line 160
    and-long/2addr v8, v10

    .line 161
    long-to-int v8, v8

    .line 162
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 165
    move-result v8

    .line 166
    mul-float/2addr v8, v6

    .line 167
    invoke-static {v8, v2}, Ljava/lang/Math;->max(FF)F

    .line 170
    move-result v6

    .line 171
    mul-float/2addr v6, v7

    .line 172
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$5:Ljava/lang/Integer;

    .line 174
    if-eqz v7, :cond_b8

    .line 176
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 179
    move-result v7

    .line 180
    if-ne v5, v7, :cond_b8

    .line 182
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$6:J

    .line 184
    goto :goto_ba

    .line 185
    :cond_b8
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$7:J

    .line 187
    :goto_ba
    int-to-float v5, v5

    .line 188
    mul-float v5, v5, v17

    .line 190
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 193
    move-result-wide v21

    .line 194
    move v9, v5

    .line 195
    and-long v4, v21, v10

    .line 197
    long-to-int v4, v4

    .line 198
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 201
    move-result v4

    .line 202
    sub-float/2addr v4, v6

    .line 203
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 206
    move-result v5

    .line 207
    move-wide/from16 v21, v10

    .line 209
    int-to-long v10, v5

    .line 210
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 213
    move-result v4

    .line 214
    int-to-long v4, v4

    .line 215
    shl-long v10, v10, v16

    .line 217
    and-long v4, v4, v21

    .line 219
    or-long/2addr v4, v10

    .line 220
    invoke-static {v13}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 223
    move-result v9

    .line 224
    int-to-long v9, v9

    .line 225
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 228
    move-result v11

    .line 229
    int-to-long v11, v11

    .line 230
    shl-long v9, v9, v16

    .line 232
    and-long v11, v11, v21

    .line 234
    or-long/2addr v9, v11

    .line 235
    div-float v6, v6, v18

    .line 237
    invoke-static {v3, v6}, Ljava/lang/Math;->min(FF)F

    .line 240
    move-result v6

    .line 241
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 244
    move-result v11

    .line 245
    int-to-long v11, v11

    .line 246
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 249
    move-result v6

    .line 250
    move-object/from16 v23, v1

    .line 252
    int-to-long v0, v6

    .line 253
    shl-long v11, v11, v16

    .line 255
    and-long v0, v0, v21

    .line 257
    or-long/2addr v11, v0

    .line 258
    move v0, v2

    .line 259
    move v1, v3

    .line 260
    move-wide v2, v7

    .line 261
    move-wide v6, v9

    .line 262
    move-wide v8, v11

    .line 263
    const/4 v11, 0x0

    .line 264
    const/16 v12, 0xf0

    .line 266
    const/4 v10, 0x0

    .line 267
    move/from16 v21, v1

    .line 269
    move-object/from16 v1, v23

    .line 271
    const/high16 v22, 0x3f800000    # 1.0f

    .line 273
    invoke-static/range {v1 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 276
    move v2, v0

    .line 277
    move/from16 v5, v20

    .line 279
    move/from16 v3, v21

    .line 281
    move/from16 v4, v22

    .line 283
    move-object/from16 v0, p0

    .line 285
    goto/16 :goto_5d

    .line 287
    :cond_11e
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 290
    const/4 v0, 0x0

    .line 291
    throw v0

    .line 292
    :cond_123
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 294
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda19 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda19)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/ObsessionDay;

.field public final synthetic f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$3:J

.field public final synthetic f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

.field public final synthetic f$5:J

.field public final synthetic f$6:J

.field public final synthetic f$7:Ljava/util/List;

.field public final synthetic f$8:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$9:F


# direct methods
.method public synthetic constructor <init>(ZLcom/spotifry/music/data/spotifried/ObsessionDay;Lcom/spotifry/music/data/spotifried/SpotifriedStats;JLcom/spotifry/music/ui/spotifried/CountUp;JJLjava/util/List;Landroidx/compose/animation/core/Animatable;F)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$0:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$1:Lcom/spotifry/music/data/spotifried/ObsessionDay;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 10
    iput-wide p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$3:J

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$5:J

    .line 16
    iput-wide p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$6:J

    .line 18
    iput-object p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$7:Ljava/util/List;

    .line 20
    iput-object p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$8:Landroidx/compose/animation/core/Animatable;

    .line 22
    iput p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$9:F

    .line 24
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 55

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    if-nez v3, :cond_23

    .line 26
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_21

    .line 32
    const/4 v3, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v3, 0x2

    .line 35
    :goto_22
    or-int/2addr v2, v3

    .line 36
    :cond_23
    and-int/lit8 v3, v2, 0x13

    .line 38
    const/16 v4, 0x12

    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v7, 0x1

    .line 42
    if-eq v3, v4, :cond_2d

    .line 44
    move v3, v7

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move v3, v6

    .line 47
    :goto_2e
    and-int/2addr v2, v7

    .line 48
    invoke-virtual {v5, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 51
    move-result v2

    .line 52
    if-eqz v2, :cond_1f6

    .line 54
    new-instance v2, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 56
    invoke-direct {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 59
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$1:Lcom/spotifry/music/data/spotifried/ObsessionDay;

    .line 61
    iget-object v4, v3, Lcom/spotifry/music/data/spotifried/ObsessionDay;->date:Ljava/time/LocalDate;

    .line 63
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 65
    iget-object v9, v8, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->start:Ljava/time/LocalDate;

    .line 67
    invoke-virtual {v9}, Ljava/time/LocalDate;->getYear()I

    .line 70
    move-result v9

    .line 71
    iget-object v8, v8, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 73
    iget-object v8, v8, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->to:Ljava/time/LocalDate;

    .line 75
    invoke-virtual {v8}, Ljava/time/LocalDate;->getYear()I

    .line 78
    move-result v8

    .line 79
    if-eq v9, v8, :cond_53

    .line 81
    const-string v8, "d MMMM yyyy"

    .line 83
    goto :goto_55

    .line 84
    :cond_53
    const-string v8, "d MMMM"

    .line 86
    :goto_55
    sget-object v9, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 88
    invoke-static {v8, v9}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    .line 91
    move-result-object v8

    .line 92
    invoke-virtual {v4, v8}, Ljava/time/LocalDate;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 95
    move-result-object v4

    .line 96
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 99
    new-instance v8, Ljava/lang/StringBuilder;

    .line 101
    const-string v9, "On "

    .line 103
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 106
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    const-string v4, ", "

    .line 111
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 117
    move-result-object v4

    .line 118
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 121
    new-instance v8, Landroidx/compose/ui/text/SpanStyle;

    .line 123
    const/16 v26, 0x0

    .line 125
    const v27, 0xfffe

    .line 128
    iget-wide v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$3:J

    .line 130
    const-wide/16 v11, 0x0

    .line 132
    const/4 v13, 0x0

    .line 133
    const/4 v14, 0x0

    .line 134
    const/4 v15, 0x0

    .line 135
    const/16 v16, 0x0

    .line 137
    const/16 v17, 0x0

    .line 139
    const-wide/16 v18, 0x0

    .line 141
    const/16 v20, 0x0

    .line 143
    const/16 v21, 0x0

    .line 145
    const/16 v22, 0x0

    .line 147
    const-wide/16 v23, 0x0

    .line 149
    const/16 v25, 0x0

    .line 151
    invoke-direct/range {v8 .. v27}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 154
    move-wide/from16 v24, v9

    .line 156
    invoke-virtual {v2, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 159
    move-result v4

    .line 160
    :try_start_9f
    const-string v8, "something happened."

    .line 162
    invoke-virtual {v2, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_a4
    .catchall {:try_start_9f .. :try_end_a4} :catchall_1f1

    .line 165
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 168
    invoke-virtual {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 171
    move-result-object v2

    .line 172
    sget-object v4, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 174
    iget-boolean v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$0:Z

    .line 176
    const/16 v9, 0x36

    .line 178
    invoke-static {v4, v6, v8, v5, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 181
    move-result-object v6

    .line 182
    sget-object v19, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 184
    const/high16 v22, 0x6000000

    .line 186
    const v23, 0x3fffc

    .line 189
    move-object v10, v4

    .line 190
    move-object/from16 v20, v5

    .line 192
    const-wide/16 v4, 0x0

    .line 194
    move-object v11, v3

    .line 195
    move-object v3, v6

    .line 196
    const-wide/16 v6, 0x0

    .line 198
    move v13, v8

    .line 199
    const/4 v8, 0x0

    .line 200
    move-object v15, v10

    .line 201
    const-wide/16 v9, 0x0

    .line 203
    move-object/from16 v16, v11

    .line 205
    const-wide/16 v11, 0x0

    .line 207
    move/from16 v18, v13

    .line 209
    const/4 v13, 0x0

    .line 210
    const/4 v14, 0x0

    .line 211
    move-object/from16 v26, v15

    .line 213
    const/4 v15, 0x0

    .line 214
    move-object/from16 v27, v16

    .line 216
    const/16 v16, 0x0

    .line 218
    const/16 v17, 0x0

    .line 220
    move/from16 v29, v18

    .line 222
    const/16 v18, 0x0

    .line 224
    const/16 v21, 0x0

    .line 226
    move-object/from16 p1, v1

    .line 228
    move-object/from16 v1, v27

    .line 230
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 233
    move-object/from16 v5, v20

    .line 235
    new-instance v2, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 237
    invoke-direct {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 240
    iget-object v3, v1, Lcom/spotifry/music/data/spotifried/ObsessionDay;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 242
    iget-object v3, v3, Lcom/spotifry/music/data/db/SongEntity;->title:Ljava/lang/String;

    .line 244
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 247
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 250
    move-result v4

    .line 251
    const/16 v6, 0x3c

    .line 253
    if-le v4, v6, :cond_12c

    .line 255
    invoke-static {v6, v3}, Lkotlin/text/StringsKt;->take(ILjava/lang/String;)Ljava/lang/String;

    .line 258
    move-result-object v4

    .line 259
    const/16 v7, 0x20

    .line 261
    invoke-static {v4, v7}, Lkotlin/text/StringsKt;->substringBeforeLast$default(Ljava/lang/String;C)Ljava/lang/String;

    .line 264
    move-result-object v4

    .line 265
    const/4 v7, 0x3

    .line 266
    new-array v7, v7, [C

    .line 268
    fill-array-data v7, :array_1fe

    .line 271
    invoke-static {v4, v7}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    .line 274
    move-result-object v4

    .line 275
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 278
    move-result v7

    .line 279
    const/16 v8, 0x28

    .line 281
    if-ge v7, v8, :cond_126

    .line 283
    invoke-static {v6, v3}, Lkotlin/text/StringsKt;->take(ILjava/lang/String;)Ljava/lang/String;

    .line 286
    move-result-object v3

    .line 287
    invoke-static {v3}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 290
    move-result-object v3

    .line 291
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 294
    move-result-object v4

    .line 295
    :cond_126
    const-string v3, "\u2026"

    .line 297
    invoke-static {v4, v3}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 300
    move-result-object v3

    .line 301
    :cond_12c
    new-instance v4, Ljava/lang/StringBuilder;

    .line 303
    const-string v6, "You played \u201c"

    .line 305
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 308
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 311
    const-string v3, "\u201d "

    .line 313
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 316
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 319
    move-result-object v3

    .line 320
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 323
    new-instance v31, Landroidx/compose/ui/text/SpanStyle;

    .line 325
    sget-object v36, Landroidx/compose/ui/text/font/FontWeight;->Bold:Landroidx/compose/ui/text/font/FontWeight;

    .line 327
    const/16 v49, 0x0

    .line 329
    const v50, 0xffba

    .line 332
    iget-wide v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$5:J

    .line 334
    const-wide/16 v34, 0x0

    .line 336
    const/16 v37, 0x0

    .line 338
    const/16 v38, 0x0

    .line 340
    const/16 v39, 0x0

    .line 342
    const-string v40, "tnum"

    .line 344
    const-wide/16 v41, 0x0

    .line 346
    const/16 v43, 0x0

    .line 348
    const/16 v44, 0x0

    .line 350
    const/16 v45, 0x0

    .line 352
    const-wide/16 v46, 0x0

    .line 354
    const/16 v48, 0x0

    .line 356
    move-wide/from16 v32, v3

    .line 358
    invoke-direct/range {v31 .. v50}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 361
    move-object/from16 v3, v31

    .line 363
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 365
    iget-object v6, v4, Lcom/spotifry/music/ui/spotifried/CountUp;->text:Ljava/lang/String;

    .line 367
    iget v1, v1, Lcom/spotifry/music/data/spotifried/ObsessionDay;->plays:I

    .line 369
    const/4 v7, 0x1

    .line 370
    if-ne v1, v7, :cond_176

    .line 372
    const-string v1, "time"

    .line 374
    goto :goto_178

    .line 375
    :cond_176
    const-string v1, "times"

    .line 377
    :goto_178
    const-string v8, " "

    .line 379
    invoke-static {v6, v8, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 382
    move-result-object v1

    .line 383
    invoke-static {v2, v4, v3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countSpan(Landroidx/compose/ui/text/AnnotatedString$Builder;Lcom/spotifry/music/ui/spotifried/CountUp;Landroidx/compose/ui/text/SpanStyle;Ljava/lang/String;)V

    .line 386
    const-string v1, " in one day. We won\'t ask."

    .line 388
    invoke-virtual {v2, v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 391
    invoke-virtual {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 394
    move-result-object v2

    .line 395
    const/4 v12, 0x0

    .line 396
    const/16 v13, 0xd

    .line 398
    const/4 v9, 0x0

    .line 399
    const/high16 v10, 0x41600000    # 14.0f

    .line 401
    const/4 v11, 0x0

    .line 402
    move-object/from16 v8, v26

    .line 404
    invoke-static/range {v8 .. v13}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 407
    move-result-object v1

    .line 408
    move/from16 v3, v29

    .line 410
    const/16 v14, 0x36

    .line 412
    invoke-static {v1, v7, v3, v5, v14}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 415
    move-result-object v1

    .line 416
    move-object/from16 v20, v5

    .line 418
    invoke-static/range {v20 .. v20}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 421
    move-result-wide v4

    .line 422
    sget-object v19, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 424
    const/high16 v22, 0x6000000

    .line 426
    const v23, 0x3fff8

    .line 429
    const-wide/16 v6, 0x0

    .line 431
    const/4 v8, 0x0

    .line 432
    const-wide/16 v9, 0x0

    .line 434
    const-wide/16 v11, 0x0

    .line 436
    const/4 v13, 0x0

    .line 437
    const/4 v14, 0x0

    .line 438
    const/4 v15, 0x0

    .line 439
    const/16 v16, 0x0

    .line 441
    const/16 v17, 0x0

    .line 443
    const/16 v18, 0x0

    .line 445
    const/16 v21, 0x0

    .line 447
    move-object v3, v1

    .line 448
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 451
    move-object/from16 v5, v20

    .line 453
    const/high16 v1, 0x3f800000    # 1.0f

    .line 455
    move-object/from16 v2, p1

    .line 457
    invoke-static {v2, v1}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 460
    move-result-object v2

    .line 461
    invoke-static {v2, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 464
    move-result-object v2

    .line 465
    sget-object v3, Landroidx/compose/ui/Alignment$Companion;->BottomStart:Landroidx/compose/ui/BiasAlignment;

    .line 467
    new-instance v9, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;

    .line 469
    iget-wide v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$6:J

    .line 471
    iget-object v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$7:Ljava/util/List;

    .line 473
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$8:Landroidx/compose/animation/core/Animatable;

    .line 475
    iget v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$9:F

    .line 477
    move-wide/from16 v16, v24

    .line 479
    move/from16 v10, v29

    .line 481
    invoke-direct/range {v9 .. v17}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;-><init>(ZJLjava/util/List;Landroidx/compose/animation/core/Animatable;FJ)V

    .line 484
    const v0, -0x1c3f66c4

    .line 487
    invoke-static {v0, v9, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 490
    move-result-object v4

    .line 491
    const/16 v6, 0xc30

    .line 493
    const/4 v7, 0x4

    .line 494
    invoke-static/range {v2 .. v7}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 497
    goto :goto_1fb

    .line 498
    :catchall_1f1
    move-exception v0

    .line 499
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 502
    throw v0

    .line 503
    :cond_1f6
    move-object/from16 v20, v5

    .line 505
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 508
    :goto_1fb
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 510
    return-object v0

    .line 511
    :array_1fe
    .array-data 2
        0x2cs
        0x20s
        0x2ds
    .end array-data
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda44 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda44)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:J

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$4:F

.field public final synthetic f$5:J


# direct methods
.method public synthetic constructor <init>(ZJLjava/util/List;Landroidx/compose/animation/core/Animatable;FJ)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$0:Z

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$2:Ljava/util/List;

    .line 10
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 12
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$4:F

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$5:J

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 30

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 24
    const/4 v5, 0x2

    .line 25
    if-nez v4, :cond_24

    .line 27
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v4

    .line 31
    if-eqz v4, :cond_22

    .line 33
    const/4 v4, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v4, v5

    .line 36
    :goto_23
    or-int/2addr v3, v4

    .line 37
    :cond_24
    and-int/lit8 v4, v3, 0x13

    .line 39
    const/16 v6, 0x12

    .line 41
    const/4 v7, 0x0

    .line 42
    const/4 v8, 0x1

    .line 43
    if-eq v4, v6, :cond_2e

    .line 45
    move v4, v8

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v4, v7

    .line 48
    :goto_2f
    and-int/2addr v3, v8

    .line 49
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v3

    .line 53
    if-eqz v3, :cond_1d9

    .line 55
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 58
    move-result v1

    .line 59
    const/high16 v3, 0x41d00000    # 26.0f

    .line 61
    sub-float/2addr v1, v3

    .line 62
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 64
    invoke-direct {v3, v1}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 67
    new-instance v1, Landroidx/compose/ui/unit/Dp;

    .line 69
    const/high16 v4, 0x433e0000    # 190.0f

    .line 71
    invoke-direct {v1, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 74
    invoke-virtual {v3, v1}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 77
    move-result v4

    .line 78
    if-lez v4, :cond_50

    .line 80
    move-object v3, v1

    .line 81
    :cond_50
    new-instance v1, Landroidx/compose/ui/unit/Dp;

    .line 83
    const/high16 v4, 0x42200000    # 40.0f

    .line 85
    invoke-direct {v1, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 88
    invoke-virtual {v3, v1}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 91
    move-result v4

    .line 92
    if-gez v4, :cond_5e

    .line 94
    move-object v3, v1

    .line 95
    :cond_5e
    const/16 v1, 0x36

    .line 97
    sget-object v4, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 99
    iget-boolean v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$0:Z

    .line 101
    invoke-static {v4, v5, v6, v2, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 104
    move-result-object v1

    .line 105
    sget-object v5, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 107
    sget-object v6, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 109
    invoke-static {v5, v6, v2, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 112
    move-result-object v5

    .line 113
    iget-wide v9, v2, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 115
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 118
    move-result v6

    .line 119
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 122
    move-result-object v9

    .line 123
    invoke-static {v2, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 126
    move-result-object v1

    .line 127
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 129
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 134
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 137
    iget-boolean v11, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 139
    if-eqz v11, :cond_90

    .line 141
    invoke-virtual {v2, v10}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 144
    goto :goto_93

    .line 145
    :cond_90
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 148
    :goto_93
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 150
    invoke-static {v2, v5, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 153
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 155
    invoke-static {v2, v9, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 158
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 160
    iget-boolean v12, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 162
    if-nez v12, :cond_b1

    .line 164
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 167
    move-result-object v12

    .line 168
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 171
    move-result-object v13

    .line 172
    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 175
    move-result v12

    .line 176
    if-nez v12, :cond_b4

    .line 178
    :cond_b1
    invoke-static {v6, v2, v6, v9}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 181
    :cond_b4
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 183
    invoke-static {v2, v1, v6}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 186
    const/high16 v1, 0x3f800000    # 1.0f

    .line 188
    invoke-static {v4, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 191
    move-result-object v12

    .line 192
    iget v3, v3, Landroidx/compose/ui/unit/Dp;->value:F

    .line 194
    invoke-static {v12, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 197
    move-result-object v3

    .line 198
    iget-wide v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$1:J

    .line 200
    invoke-virtual {v2, v13, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 203
    move-result v12

    .line 204
    iget-object v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$2:Ljava/util/List;

    .line 206
    invoke-virtual {v2, v15}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 209
    move-result v16

    .line 210
    or-int v12, v12, v16

    .line 212
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 214
    invoke-virtual {v2, v8}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 217
    move-result v16

    .line 218
    or-int v12, v12, v16

    .line 220
    iget v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$4:F

    .line 222
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 225
    move-result v16

    .line 226
    or-int v12, v12, v16

    .line 228
    move-object/from16 v16, v8

    .line 230
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$5:J

    .line 232
    invoke-virtual {v2, v7, v8}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 235
    move-result v0

    .line 236
    or-int/2addr v12, v0

    .line 237
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 240
    move-result-object v0

    .line 241
    if-nez v12, :cond_f6

    .line 243
    sget-object v12, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 245
    if-ne v0, v12, :cond_103

    .line 247
    :cond_f6
    new-instance v12, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;

    .line 249
    move/from16 v17, v1

    .line 251
    move-wide/from16 v18, v7

    .line 253
    invoke-direct/range {v12 .. v19}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;-><init>(JLjava/util/List;Landroidx/compose/animation/core/Animatable;FJ)V

    .line 256
    invoke-virtual {v2, v12}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 259
    move-object v0, v12

    .line 260
    :cond_103
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 262
    const/4 v1, 0x0

    .line 263
    invoke-static {v3, v0, v2, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 266
    const/high16 v0, 0x3f800000    # 1.0f

    .line 268
    invoke-static {v4, v0}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 271
    move-result-object v12

    .line 272
    const/16 v16, 0x0

    .line 274
    const/16 v17, 0xd

    .line 276
    const/4 v13, 0x0

    .line 277
    const/high16 v14, 0x41000000    # 8.0f

    .line 279
    const/4 v15, 0x0

    .line 280
    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 283
    move-result-object v0

    .line 284
    sget-object v3, Landroidx/compose/foundation/layout/OffsetKt;->SpaceBetween:Landroidx/compose/foundation/layout/Arrangement$Center$1;

    .line 286
    sget-object v4, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 288
    const/4 v7, 0x6

    .line 289
    invoke-static {v3, v4, v2, v7}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 292
    move-result-object v3

    .line 293
    iget-wide v7, v2, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 295
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 298
    move-result v4

    .line 299
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 302
    move-result-object v7

    .line 303
    invoke-static {v2, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 306
    move-result-object v0

    .line 307
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 310
    iget-boolean v8, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 312
    if-eqz v8, :cond_13d

    .line 314
    invoke-virtual {v2, v10}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 317
    goto :goto_140

    .line 318
    :cond_13d
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 321
    :goto_140
    invoke-static {v2, v3, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 324
    invoke-static {v2, v7, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 327
    iget-boolean v3, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 329
    if-nez v3, :cond_158

    .line 331
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 334
    move-result-object v3

    .line 335
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 338
    move-result-object v5

    .line 339
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 342
    move-result v3

    .line 343
    if-nez v3, :cond_15b

    .line 345
    :cond_158
    invoke-static {v4, v2, v4, v9}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 348
    :cond_15b
    invoke-static {v2, v0, v6}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 351
    const v0, -0x49d896a2

    .line 354
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 357
    const-string v0, "18"

    .line 359
    const-string v3, "24"

    .line 361
    const-string v4, "00"

    .line 363
    const-string v5, "06"

    .line 365
    const-string v6, "12"

    .line 367
    filled-new-array {v4, v5, v6, v0, v3}, [Ljava/lang/String;

    .line 370
    move-result-object v0

    .line 371
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 374
    move-result-object v0

    .line 375
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 378
    move-result-object v0

    .line 379
    :goto_17a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 382
    move-result v3

    .line 383
    if-eqz v3, :cond_1ce

    .line 385
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 388
    move-result-object v3

    .line 389
    check-cast v3, Ljava/lang/String;

    .line 391
    invoke-static {v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 394
    move-result-wide v4

    .line 395
    sget-object v6, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 397
    const/16 v7, 0xb

    .line 399
    invoke-static {v7}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 402
    move-result-wide v9

    .line 403
    const/16 v7, 0xe

    .line 405
    invoke-static {v7}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 408
    move-result-wide v17

    .line 409
    const/16 v20, 0x0

    .line 411
    const v21, 0xfdfffd

    .line 414
    const-wide/16 v7, 0x0

    .line 416
    const/4 v11, 0x0

    .line 417
    const/4 v12, 0x0

    .line 418
    const/4 v13, 0x0

    .line 419
    const-wide/16 v14, 0x0

    .line 421
    const/16 v16, 0x0

    .line 423
    const/16 v19, 0x0

    .line 425
    invoke-static/range {v6 .. v21}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 428
    move-result-object v21

    .line 429
    const/16 v24, 0x0

    .line 431
    const v25, 0x1fffa

    .line 434
    move-object/from16 v22, v2

    .line 436
    move-object v2, v3

    .line 437
    const/4 v3, 0x0

    .line 438
    const-wide/16 v6, 0x0

    .line 440
    const/4 v8, 0x0

    .line 441
    const/4 v9, 0x0

    .line 442
    const/4 v10, 0x0

    .line 443
    const-wide/16 v11, 0x0

    .line 445
    const/16 v16, 0x0

    .line 447
    const/16 v17, 0x0

    .line 449
    const/16 v18, 0x0

    .line 451
    const/16 v19, 0x0

    .line 453
    const/16 v20, 0x0

    .line 455
    const/16 v23, 0x0

    .line 457
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 460
    move-object/from16 v2, v22

    .line 462
    goto :goto_17a

    .line 463
    :cond_1ce
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 466
    const/4 v0, 0x1

    .line 467
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 470
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 473
    goto :goto_1dc

    .line 474
    :cond_1d9
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 477
    :goto_1dc
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 479
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda21 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda21)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/lang/Integer;

.field public final synthetic f$1:F

.field public final synthetic f$10:I

.field public final synthetic f$11:J

.field public final synthetic f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

.field public final synthetic f$3:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$4:I

.field public final synthetic f$5:I

.field public final synthetic f$6:J

.field public final synthetic f$7:J

.field public final synthetic f$8:Ljava/util/List;

.field public final synthetic f$9:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Integer;FLcom/spotifry/music/data/spotifried/AgeStats;Landroidx/compose/animation/core/Animatable;IIJJLjava/util/List;IIJ)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$0:Ljava/lang/Integer;

    .line 6
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$1:F

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 12
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$4:I

    .line 14
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$5:I

    .line 16
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$6:J

    .line 18
    iput-wide p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$7:J

    .line 20
    iput-object p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$8:Ljava/util/List;

    .line 22
    iput p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$9:I

    .line 24
    iput p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$10:I

    .line 26
    iput-wide p14, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$11:J

    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 28

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 24
    if-nez v4, :cond_23

    .line 26
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v4

    .line 30
    if-eqz v4, :cond_21

    .line 32
    const/4 v4, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v4, 0x2

    .line 35
    :goto_22
    or-int/2addr v3, v4

    .line 36
    :cond_23
    and-int/lit8 v4, v3, 0x13

    .line 38
    const/16 v5, 0x12

    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v7, 0x1

    .line 42
    if-eq v4, v5, :cond_2d

    .line 44
    move v4, v7

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move v4, v6

    .line 47
    :goto_2e
    and-int/2addr v3, v7

    .line 48
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 51
    move-result v3

    .line 52
    if-eqz v3, :cond_80

    .line 54
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$0:Ljava/lang/Integer;

    .line 56
    if-nez v9, :cond_4f

    .line 58
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 61
    move-result v1

    .line 62
    const/high16 v3, 0x44020000    # 520.0f

    .line 64
    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    .line 67
    move-result v1

    .line 68
    if-ltz v1, :cond_4f

    .line 70
    const/high16 v1, 0x3fc00000    # 1.5f

    .line 72
    iget v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$1:F

    .line 74
    cmpg-float v1, v3, v1

    .line 76
    if-gez v1, :cond_4f

    .line 78
    move v10, v7

    .line 79
    goto :goto_50

    .line 80
    :cond_4f
    move v10, v6

    .line 81
    :goto_50
    new-instance v8, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;

    .line 83
    iget-object v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 85
    iget-object v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 87
    iget v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$4:I

    .line 89
    iget v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$5:I

    .line 91
    iget-wide v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$6:J

    .line 93
    iget-wide v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$7:J

    .line 95
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$8:Ljava/util/List;

    .line 97
    iget v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$9:I

    .line 99
    iget v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$10:I

    .line 101
    move-object/from16 v19, v1

    .line 103
    iget-wide v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$11:J

    .line 105
    move-wide/from16 v22, v0

    .line 107
    move-wide/from16 v17, v5

    .line 109
    move/from16 v20, v7

    .line 111
    move/from16 v21, v15

    .line 113
    move-wide v15, v3

    .line 114
    invoke-direct/range {v8 .. v23}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;-><init>(Ljava/lang/Integer;ZLcom/spotifry/music/data/spotifried/AgeStats;Landroidx/compose/animation/core/Animatable;IIJJLjava/util/List;IIJ)V

    .line 117
    const v0, 0x3222bc52

    .line 120
    invoke-static {v0, v8, v2}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 123
    move-result-object v0

    .line 124
    const/4 v1, 0x6

    .line 125
    invoke-static {v0, v2, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 128
    goto :goto_83

    .line 129
    :cond_80
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 132
    :goto_83
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 134
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda39 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda39)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/lang/Integer;

.field public final synthetic f$1:Z

.field public final synthetic f$10:I

.field public final synthetic f$11:J

.field public final synthetic f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

.field public final synthetic f$3:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$4:I

.field public final synthetic f$5:I

.field public final synthetic f$6:J

.field public final synthetic f$7:J

.field public final synthetic f$8:Ljava/util/List;

.field public final synthetic f$9:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Integer;ZLcom/spotifry/music/data/spotifried/AgeStats;Landroidx/compose/animation/core/Animatable;IIJJLjava/util/List;IIJ)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$0:Ljava/lang/Integer;

    .line 6
    iput-boolean p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$1:Z

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 12
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$4:I

    .line 14
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$5:I

    .line 16
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$6:J

    .line 18
    iput-wide p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$7:J

    .line 20
    iput-object p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$8:Ljava/util/List;

    .line 22
    iput p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$9:I

    .line 24
    iput p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$10:I

    .line 26
    iput-wide p14, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$11:J

    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 55

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    const-string v3, "14 in "

    .line 21
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    and-int/lit8 v4, v2, 0x6

    .line 26
    if-nez v4, :cond_25

    .line 28
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 31
    move-result v4

    .line 32
    if-eqz v4, :cond_23

    .line 34
    const/4 v4, 0x4

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    const/4 v4, 0x2

    .line 37
    :goto_24
    or-int/2addr v2, v4

    .line 38
    :cond_25
    and-int/lit8 v4, v2, 0x13

    .line 40
    const/16 v6, 0x12

    .line 42
    const/4 v7, 0x1

    .line 43
    const/4 v8, 0x0

    .line 44
    if-eq v4, v6, :cond_2f

    .line 46
    move v4, v7

    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move v4, v8

    .line 49
    :goto_30
    and-int/2addr v2, v7

    .line 50
    invoke-virtual {v5, v2, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 53
    move-result v2

    .line 54
    if-eqz v2, :cond_5cf

    .line 56
    sget-object v9, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 58
    const/16 v2, 0x28

    .line 60
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 63
    move-result-wide v12

    .line 64
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 67
    move-result-wide v20

    .line 68
    const-wide v10, -0x400999999999999aL    # -1.4

    .line 73
    invoke-static {v10, v11}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 76
    move-result-wide v17

    .line 77
    const/16 v23, 0x0

    .line 79
    const v24, 0xfdff7d

    .line 82
    const-wide/16 v10, 0x0

    .line 84
    const/4 v14, 0x0

    .line 85
    const/4 v15, 0x0

    .line 86
    const/16 v16, 0x0

    .line 88
    const/16 v19, 0x0

    .line 90
    const/16 v22, 0x0

    .line 92
    invoke-static/range {v9 .. v24}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 95
    move-result-object v19

    .line 96
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$0:Ljava/lang/Integer;

    .line 98
    iget-wide v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$7:J

    .line 100
    const-string v4, "."

    .line 102
    if-eqz v2, :cond_ff

    .line 104
    const v6, 0x583b13fd

    .line 107
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 110
    new-instance v6, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 112
    invoke-direct {v6}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 115
    const-string v9, "You listen like someone who was "

    .line 117
    invoke-virtual {v6, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 120
    new-instance v20, Landroidx/compose/ui/text/SpanStyle;

    .line 122
    const/16 v38, 0x0

    .line 124
    const v39, 0xfffe

    .line 127
    const-wide/16 v23, 0x0

    .line 129
    const/16 v25, 0x0

    .line 131
    const/16 v26, 0x0

    .line 133
    const/16 v27, 0x0

    .line 135
    const/16 v28, 0x0

    .line 137
    const/16 v29, 0x0

    .line 139
    const-wide/16 v30, 0x0

    .line 141
    const/16 v32, 0x0

    .line 143
    const/16 v33, 0x0

    .line 145
    const/16 v34, 0x0

    .line 147
    const-wide/16 v35, 0x0

    .line 149
    const/16 v37, 0x0

    .line 151
    move-wide/from16 v21, v12

    .line 153
    invoke-direct/range {v20 .. v39}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 156
    move-object/from16 v9, v20

    .line 158
    move-wide/from16 v30, v21

    .line 160
    invoke-virtual {v6, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 163
    move-result v9

    .line 164
    :try_start_a3
    new-instance v10, Ljava/lang/StringBuilder;

    .line 166
    invoke-direct {v10, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 169
    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 172
    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 175
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    move-result-object v3

    .line 179
    invoke-virtual {v6, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_b5
    .catchall {:try_start_a3 .. :try_end_b5} :catchall_fa

    .line 182
    invoke-virtual {v6, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 185
    move-object/from16 v29, v2

    .line 187
    invoke-virtual {v6}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 190
    move-result-object v2

    .line 191
    const/16 v22, 0x0

    .line 193
    const v23, 0x3fffe

    .line 196
    const/4 v3, 0x0

    .line 197
    move-object v6, v4

    .line 198
    move-object/from16 v20, v5

    .line 200
    const-wide/16 v4, 0x0

    .line 202
    move-object v9, v6

    .line 203
    const-wide/16 v6, 0x0

    .line 205
    move v11, v8

    .line 206
    const/4 v8, 0x0

    .line 207
    move-object v12, v9

    .line 208
    const-wide/16 v9, 0x0

    .line 210
    move v15, v11

    .line 211
    move-object v14, v12

    .line 212
    const-wide/16 v11, 0x0

    .line 214
    const/4 v13, 0x0

    .line 215
    move-object/from16 v17, v14

    .line 217
    const/4 v14, 0x0

    .line 218
    move/from16 v18, v15

    .line 220
    const/4 v15, 0x0

    .line 221
    const/16 v16, 0x0

    .line 223
    move-object/from16 v24, v17

    .line 225
    const/16 v17, 0x0

    .line 227
    move/from16 v25, v18

    .line 229
    const/16 v18, 0x0

    .line 231
    const/16 v21, 0x0

    .line 233
    move-object/from16 p1, v1

    .line 235
    move-object/from16 v42, v24

    .line 237
    move/from16 v1, v25

    .line 239
    move-object/from16 v41, v29

    .line 241
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 244
    move-object/from16 v5, v20

    .line 246
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 249
    goto/16 :goto_174

    .line 251
    :catchall_fa
    move-exception v0

    .line 252
    invoke-virtual {v6, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 255
    throw v0

    .line 256
    :cond_ff
    move-object/from16 p1, v1

    .line 258
    move-object/from16 v41, v2

    .line 260
    move-object/from16 v42, v4

    .line 262
    move v1, v8

    .line 263
    move-wide/from16 v30, v12

    .line 265
    const v2, 0x583dddd6

    .line 268
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 271
    new-instance v2, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 273
    invoke-direct {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 276
    const-string v3, "How old is "

    .line 278
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 281
    new-instance v20, Landroidx/compose/ui/text/SpanStyle;

    .line 283
    const/16 v38, 0x0

    .line 285
    const v39, 0xfffe

    .line 288
    const-wide/16 v23, 0x0

    .line 290
    const/16 v25, 0x0

    .line 292
    const/16 v26, 0x0

    .line 294
    const/16 v27, 0x0

    .line 296
    const/16 v28, 0x0

    .line 298
    const/16 v29, 0x0

    .line 300
    move-wide/from16 v21, v30

    .line 302
    const-wide/16 v30, 0x0

    .line 304
    const/16 v32, 0x0

    .line 306
    const/16 v33, 0x0

    .line 308
    const/16 v34, 0x0

    .line 310
    const-wide/16 v35, 0x0

    .line 312
    const/16 v37, 0x0

    .line 314
    invoke-direct/range {v20 .. v39}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 317
    move-object/from16 v3, v20

    .line 319
    move-wide/from16 v30, v21

    .line 321
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 324
    move-result v3

    .line 325
    :try_start_144
    const-string v4, "your music?"

    .line 327
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_149
    .catchall {:try_start_144 .. :try_end_149} :catchall_5ca

    .line 330
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 333
    invoke-virtual {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 336
    move-result-object v2

    .line 337
    const/16 v22, 0x0

    .line 339
    const v23, 0x3fffe

    .line 342
    const/4 v3, 0x0

    .line 343
    move-object/from16 v20, v5

    .line 345
    const-wide/16 v4, 0x0

    .line 347
    const-wide/16 v6, 0x0

    .line 349
    const/4 v8, 0x0

    .line 350
    const-wide/16 v9, 0x0

    .line 352
    const-wide/16 v11, 0x0

    .line 354
    const/4 v13, 0x0

    .line 355
    const/4 v14, 0x0

    .line 356
    const/4 v15, 0x0

    .line 357
    const/16 v16, 0x0

    .line 359
    const/16 v17, 0x0

    .line 361
    const/16 v18, 0x0

    .line 363
    const/16 v21, 0x0

    .line 365
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 368
    move-object/from16 v5, v20

    .line 370
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 373
    :goto_174
    iget-boolean v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$1:Z

    .line 375
    const v9, 0x56b97230

    .line 378
    if-eqz v8, :cond_191

    .line 380
    const v2, 0x34652d2e

    .line 383
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 386
    const v2, 0x3f19999a    # 0.6f

    .line 389
    move-object/from16 v10, p1

    .line 391
    invoke-static {v10, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 394
    move-result-object v2

    .line 395
    invoke-static {v5, v2}, Landroidx/compose/foundation/layout/OffsetKt;->Spacer(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)V

    .line 398
    :goto_18d
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 401
    goto :goto_197

    .line 402
    :cond_191
    move-object/from16 v10, p1

    .line 404
    invoke-virtual {v5, v9}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 407
    goto :goto_18d

    .line 408
    :goto_197
    const/high16 v11, 0x3f800000    # 1.0f

    .line 410
    if-eqz v8, :cond_19f

    .line 412
    const v2, 0x3f333333    # 0.7f

    .line 415
    goto :goto_1a0

    .line 416
    :cond_19f
    move v2, v11

    .line 417
    :goto_1a0
    invoke-static {v10, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 420
    move-result-object v2

    .line 421
    invoke-static {v2, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 424
    move-result-object v2

    .line 425
    invoke-static {v2}, Landroidx/compose/ui/draw/ClipKt;->clipToBounds(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 428
    move-result-object v2

    .line 429
    new-instance v20, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;

    .line 431
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$8:Ljava/util/List;

    .line 433
    iget-wide v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$6:J

    .line 435
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 437
    iget v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$9:I

    .line 439
    iget v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$10:I

    .line 441
    iget-wide v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$11:J

    .line 443
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 445
    move-object/from16 v21, v3

    .line 447
    move-object/from16 v24, v4

    .line 449
    move-wide/from16 v22, v6

    .line 451
    move-object/from16 v32, v9

    .line 453
    move/from16 v25, v12

    .line 455
    move/from16 v26, v13

    .line 457
    move-wide/from16 v27, v14

    .line 459
    move-object/from16 v29, v41

    .line 461
    invoke-direct/range {v20 .. v32}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;-><init>(Ljava/util/List;JLandroidx/compose/animation/core/Animatable;IIJLjava/lang/Integer;JLcom/spotifry/music/data/spotifried/AgeStats;)V

    .line 464
    move-object/from16 v3, v20

    .line 466
    move-object/from16 v12, v24

    .line 468
    const v4, 0x5be6f828

    .line 471
    invoke-static {v4, v3, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 474
    move-result-object v4

    .line 475
    const/16 v6, 0xc00

    .line 477
    const/4 v7, 0x6

    .line 478
    const/4 v3, 0x0

    .line 479
    invoke-static/range {v2 .. v7}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 482
    const/16 v2, 0xb

    .line 484
    sget-object v13, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 486
    sget-object v3, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 488
    if-eqz v29, :cond_41d

    .line 490
    const v0, 0x58778822

    .line 493
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 496
    iget-object v0, v9, Lcom/spotifry/music/data/spotifried/AgeStats;->age:Ljava/lang/Integer;

    .line 498
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 501
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 504
    move-result v0

    .line 505
    int-to-float v0, v0

    .line 506
    invoke-virtual {v12}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 509
    move-result-object v4

    .line 510
    check-cast v4, Ljava/lang/Number;

    .line 512
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 515
    move-result v4

    .line 516
    const v6, 0x453b8000    # 3000.0f

    .line 519
    const/high16 v7, 0x44610000    # 900.0f

    .line 521
    invoke-static {v4, v6, v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 524
    move-result v4

    .line 525
    mul-float/2addr v4, v0

    .line 526
    invoke-static {v4}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 529
    move-result v0

    .line 530
    invoke-static {v0}, Lcom/spotifry/music/ui/listening/ListeningScreenKt;->count(I)Ljava/lang/String;

    .line 533
    move-result-object v0

    .line 534
    invoke-virtual {v5, v12}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 537
    move-result v4

    .line 538
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 541
    move-result-object v6

    .line 542
    if-nez v4, :cond_221

    .line 544
    if-ne v6, v3, :cond_22a

    .line 546
    :cond_221
    new-instance v6, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda11;

    .line 548
    const/4 v4, 0x1

    .line 549
    invoke-direct {v6, v12, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda11;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 552
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 555
    :cond_22a
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 557
    iget-object v7, v9, Lcom/spotifry/music/data/spotifried/AgeStats;->years:Ljava/util/List;

    .line 559
    new-instance v8, Lokhttp3/ConnectionPool;

    .line 561
    invoke-direct {v8, v7}, Lokhttp3/ConnectionPool;-><init>(Ljava/lang/Object;)V

    .line 564
    invoke-static {v8}, Lkotlin/math/MathKt;->eachCount(Lkotlin/collections/Grouping;)Ljava/util/Map;

    .line 567
    move-result-object v7

    .line 568
    invoke-interface {v7}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 571
    move-result-object v7

    .line 572
    check-cast v7, Ljava/lang/Iterable;

    .line 574
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 577
    move-result-object v7

    .line 578
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 581
    move-result v8

    .line 582
    const/4 v9, 0x0

    .line 583
    if-nez v8, :cond_24a

    .line 585
    move-object v8, v9

    .line 586
    goto :goto_27c

    .line 587
    :cond_24a
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 590
    move-result-object v8

    .line 591
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 594
    move-result v10

    .line 595
    if-eqz v10, :cond_27c

    .line 597
    move-object v10, v8

    .line 598
    check-cast v10, Ljava/util/Map$Entry;

    .line 600
    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 603
    move-result-object v10

    .line 604
    check-cast v10, Ljava/lang/Number;

    .line 606
    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    .line 609
    move-result v10

    .line 610
    :cond_261
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 613
    move-result-object v11

    .line 614
    move-object v12, v11

    .line 615
    check-cast v12, Ljava/util/Map$Entry;

    .line 617
    invoke-interface {v12}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 620
    move-result-object v12

    .line 621
    check-cast v12, Ljava/lang/Number;

    .line 623
    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    .line 626
    move-result v12

    .line 627
    if-ge v10, v12, :cond_276

    .line 629
    move-object v8, v11

    .line 630
    move v10, v12

    .line 631
    :cond_276
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 634
    move-result v11

    .line 635
    if-nez v11, :cond_261

    .line 637
    :cond_27c
    :goto_27c
    check-cast v8, Ljava/util/Map$Entry;

    .line 639
    if-eqz v8, :cond_287

    .line 641
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 644
    move-result-object v7

    .line 645
    move-object v9, v7

    .line 646
    check-cast v9, Ljava/lang/Integer;

    .line 648
    :cond_287
    if-eqz v9, :cond_2a6

    .line 650
    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    .line 653
    move-result v7

    .line 654
    const/16 v8, 0x776

    .line 656
    const-string v9, "s"

    .line 658
    if-gt v8, v7, :cond_299

    .line 660
    const/16 v8, 0x7c7

    .line 662
    if-ge v7, v8, :cond_299

    .line 664
    rem-int/lit8 v7, v7, 0x64

    .line 666
    :cond_299
    invoke-static {v7, v9}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 669
    move-result-object v7

    .line 670
    const-string v8, " Most of your songs are from the "

    .line 672
    move-object/from16 v12, v42

    .line 674
    invoke-static {v8, v7, v12}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 677
    move-result-object v7

    .line 678
    goto :goto_2a8

    .line 679
    :cond_2a6
    const-string v7, ""

    .line 681
    :goto_2a8
    const-string v8, "Your listening age."

    .line 683
    invoke-virtual {v8, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 686
    move-result-object v26

    .line 687
    const/16 v17, 0x0

    .line 689
    const/16 v18, 0xd

    .line 691
    const/4 v14, 0x0

    .line 692
    const/high16 v15, 0x40c00000    # 6.0f

    .line 694
    const/16 v16, 0x0

    .line 696
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 699
    move-result-object v7

    .line 700
    move-object/from16 v27, v13

    .line 702
    new-instance v8, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 704
    new-instance v9, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 706
    const/4 v10, 0x3

    .line 707
    invoke-direct {v9, v10}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 710
    const/high16 v10, 0x41200000    # 10.0f

    .line 712
    invoke-direct {v8, v10, v9}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 715
    sget-object v9, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 717
    const/4 v10, 0x6

    .line 718
    invoke-static {v8, v9, v5, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 721
    move-result-object v8

    .line 722
    iget-wide v9, v5, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 724
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 727
    move-result v9

    .line 728
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 731
    move-result-object v10

    .line 732
    invoke-static {v5, v7}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 735
    move-result-object v7

    .line 736
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 738
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 741
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 743
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 746
    iget-boolean v12, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 748
    if-eqz v12, :cond_2f1

    .line 750
    invoke-virtual {v5, v11}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 753
    goto :goto_2f4

    .line 754
    :cond_2f1
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 757
    :goto_2f4
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 759
    invoke-static {v5, v8, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 762
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 764
    invoke-static {v5, v10, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 767
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 769
    iget-boolean v10, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 771
    if-nez v10, :cond_312

    .line 773
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 776
    move-result-object v10

    .line 777
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 780
    move-result-object v11

    .line 781
    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 784
    move-result v10

    .line 785
    if-nez v10, :cond_315

    .line 787
    :cond_312
    invoke-static {v9, v5, v9, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 790
    :cond_315
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 792
    invoke-static {v5, v7, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 795
    sget-object v7, Landroidx/compose/ui/layout/AlignmentLineKt;->FirstBaseline:Landroidx/compose/ui/layout/HorizontalAlignmentLine;

    .line 797
    new-instance v8, Landroidx/compose/foundation/layout/WithAlignmentLineElement;

    .line 799
    invoke-direct {v8, v7}, Landroidx/compose/foundation/layout/WithAlignmentLineElement;-><init>(Landroidx/compose/ui/layout/HorizontalAlignmentLine;)V

    .line 802
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 805
    move-result v9

    .line 806
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 809
    move-result-object v10

    .line 810
    if-nez v9, :cond_32d

    .line 812
    if-ne v10, v3, :cond_335

    .line 814
    :cond_32d
    new-instance v10, Landroidx/room/RoomDatabase$$ExternalSyntheticLambda3;

    .line 816
    invoke-direct {v10, v6, v2}, Landroidx/room/RoomDatabase$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/functions/Function0;B)V

    .line 819
    invoke-virtual {v5, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 822
    :cond_335
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 824
    invoke-static {v8, v10}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 827
    move-result-object v8

    .line 828
    sget-object v15, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 830
    sget-object v14, Landroidx/compose/ui/text/font/FontWeight;->Black:Landroidx/compose/ui/text/font/FontWeight;

    .line 832
    const/16 v9, 0x70

    .line 834
    invoke-static {v9}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 837
    move-result-wide v12

    .line 838
    const/16 v9, 0x60

    .line 840
    invoke-static {v9}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 843
    move-result-wide v19

    .line 844
    const-wide v9, -0x3fe999999999999aL    # -5.6

    .line 849
    invoke-static {v9, v10}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 852
    move-result-wide v16

    .line 853
    new-instance v21, Landroidx/compose/ui/text/TextStyle;

    .line 855
    move-object/from16 v9, v21

    .line 857
    const/16 v21, 0x0

    .line 859
    const v22, 0xfdff19

    .line 862
    const-wide/16 v10, 0x0

    .line 864
    const/16 v18, 0x0

    .line 866
    invoke-direct/range {v9 .. v22}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 869
    const/16 v24, 0x0

    .line 871
    const v25, 0x1fff8

    .line 874
    move-object v10, v6

    .line 875
    move-object v11, v7

    .line 876
    const-wide/16 v6, 0x0

    .line 878
    move-object v12, v3

    .line 879
    move-object v3, v8

    .line 880
    const/4 v8, 0x0

    .line 881
    move-object/from16 v21, v9

    .line 883
    const/4 v9, 0x0

    .line 884
    move-object v13, v10

    .line 885
    const/4 v10, 0x0

    .line 886
    move-object v14, v11

    .line 887
    move-object v15, v12

    .line 888
    const-wide/16 v11, 0x0

    .line 890
    move-object/from16 v16, v13

    .line 892
    const/4 v13, 0x0

    .line 893
    move-object/from16 v17, v14

    .line 895
    move-object/from16 v18, v15

    .line 897
    const-wide/16 v14, 0x0

    .line 899
    move-object/from16 v19, v16

    .line 901
    const/16 v16, 0x0

    .line 903
    move-object/from16 v20, v17

    .line 905
    const/16 v17, 0x0

    .line 907
    move-object/from16 v22, v18

    .line 909
    const/16 v18, 0x0

    .line 911
    move-object/from16 v23, v19

    .line 913
    const/16 v19, 0x0

    .line 915
    move-object/from16 v28, v20

    .line 917
    const/16 v20, 0x0

    .line 919
    move-object/from16 v29, v23

    .line 921
    const/16 v23, 0x0

    .line 923
    move v1, v2

    .line 924
    move-object v2, v0

    .line 925
    move-object/from16 v0, v29

    .line 927
    move/from16 v29, v1

    .line 929
    move-object/from16 v43, v22

    .line 931
    move-object/from16 v1, v28

    .line 933
    move-object/from16 v22, v5

    .line 935
    move-wide/from16 v4, v30

    .line 937
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 940
    move-object/from16 v5, v22

    .line 942
    new-instance v2, Landroidx/compose/foundation/layout/WithAlignmentLineElement;

    .line 944
    invoke-direct {v2, v1}, Landroidx/compose/foundation/layout/WithAlignmentLineElement;-><init>(Landroidx/compose/ui/layout/HorizontalAlignmentLine;)V

    .line 947
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 950
    move-result v1

    .line 951
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 954
    move-result-object v3

    .line 955
    if-nez v1, :cond_3c0

    .line 957
    move-object/from16 v1, v43

    .line 959
    if-ne v3, v1, :cond_3ca

    .line 961
    :cond_3c0
    new-instance v3, Landroidx/room/RoomDatabase$$ExternalSyntheticLambda3;

    .line 963
    const/16 v1, 0xc

    .line 965
    invoke-direct {v3, v0, v1}, Landroidx/room/RoomDatabase$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/functions/Function0;B)V

    .line 968
    invoke-virtual {v5, v3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 971
    :cond_3ca
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 973
    invoke-static {v2, v3}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 976
    move-result-object v3

    .line 977
    move-object/from16 v22, v5

    .line 979
    invoke-static/range {v22 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 982
    move-result-wide v4

    .line 983
    sget-object v6, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 985
    const v20, 0x10303

    .line 988
    const v21, 0xdfffff

    .line 991
    const-wide/16 v7, 0x0

    .line 993
    const-wide/16 v9, 0x0

    .line 995
    const/4 v11, 0x0

    .line 996
    const/4 v12, 0x0

    .line 997
    const/4 v13, 0x0

    .line 998
    const-wide/16 v14, 0x0

    .line 1000
    const/16 v16, 0x0

    .line 1002
    const-wide/16 v17, 0x0

    .line 1004
    const/16 v19, 0x0

    .line 1006
    invoke-static/range {v6 .. v21}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 1009
    move-result-object v21

    .line 1010
    move-object v0, v6

    .line 1011
    const/16 v24, 0x0

    .line 1013
    const v25, 0x1fff8

    .line 1016
    const-wide/16 v6, 0x0

    .line 1018
    const/4 v8, 0x0

    .line 1019
    const/4 v9, 0x0

    .line 1020
    const/4 v10, 0x0

    .line 1021
    const-wide/16 v11, 0x0

    .line 1023
    const/16 v16, 0x0

    .line 1025
    const/16 v17, 0x0

    .line 1027
    const/16 v18, 0x0

    .line 1029
    const/16 v19, 0x0

    .line 1031
    const/16 v20, 0x0

    .line 1033
    const/16 v23, 0x0

    .line 1035
    move-object/from16 v2, v26

    .line 1037
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1040
    move-object/from16 v5, v22

    .line 1042
    const/4 v13, 0x1

    .line 1043
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1046
    const/4 v15, 0x0

    .line 1047
    invoke-virtual {v5, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1050
    move-object/from16 v30, v0

    .line 1052
    goto/16 :goto_573

    .line 1054
    :cond_41d
    move/from16 v29, v2

    .line 1056
    move-object v1, v3

    .line 1057
    move-object/from16 v27, v13

    .line 1059
    const/4 v13, 0x1

    .line 1060
    const v2, 0x588c8057

    .line 1063
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 1066
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$4:I

    .line 1068
    int-to-float v3, v2

    .line 1069
    iget v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$5:I

    .line 1071
    add-int v7, v2, v0

    .line 1073
    if-lt v7, v13, :cond_433

    .line 1075
    move v13, v7

    .line 1076
    :cond_433
    int-to-float v0, v13

    .line 1077
    div-float v0, v3, v0

    .line 1079
    invoke-static {v2}, Lcom/spotifry/music/ui/listening/ListeningScreenKt;->count(I)Ljava/lang/String;

    .line 1082
    move-result-object v2

    .line 1083
    invoke-static {v7}, Lcom/spotifry/music/ui/listening/ListeningScreenKt;->count(I)Ljava/lang/String;

    .line 1086
    move-result-object v3

    .line 1087
    const-string v4, "Checking song years: "

    .line 1089
    const-string v6, " of "

    .line 1091
    invoke-static {v4, v2, v6, v3}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1094
    move-result-object v2

    .line 1095
    const/16 v17, 0x0

    .line 1097
    const/16 v18, 0xd

    .line 1099
    const/4 v14, 0x0

    .line 1100
    const/high16 v15, 0x41600000    # 14.0f

    .line 1102
    const/16 v16, 0x0

    .line 1104
    move-object/from16 v13, v27

    .line 1106
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 1109
    move-result-object v3

    .line 1110
    move/from16 v26, v15

    .line 1112
    sget-object v38, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 1114
    sget-object v37, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 1116
    const/16 v4, 0x18

    .line 1118
    invoke-static {v4}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 1121
    move-result-wide v35

    .line 1122
    const/16 v4, 0x1c

    .line 1124
    invoke-static {v4}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 1127
    move-result-wide v42

    .line 1128
    const-wide v6, -0x4026666666666666L    # -0.4

    .line 1133
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 1136
    move-result-wide v39

    .line 1137
    new-instance v32, Landroidx/compose/ui/text/TextStyle;

    .line 1139
    const/16 v44, 0x0

    .line 1141
    const v45, 0xfdff19

    .line 1144
    const-wide/16 v33, 0x0

    .line 1146
    const/16 v41, 0x0

    .line 1148
    invoke-direct/range {v32 .. v45}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 1151
    const/16 v24, 0x0

    .line 1153
    const v25, 0x1fffc

    .line 1156
    move-object/from16 v20, v5

    .line 1158
    const-wide/16 v4, 0x0

    .line 1160
    const-wide/16 v6, 0x0

    .line 1162
    move v9, v8

    .line 1163
    const/4 v8, 0x0

    .line 1164
    move v12, v9

    .line 1165
    const/4 v9, 0x0

    .line 1166
    move-object v13, v10

    .line 1167
    const/4 v10, 0x0

    .line 1168
    move v14, v11

    .line 1169
    move v15, v12

    .line 1170
    const-wide/16 v11, 0x0

    .line 1172
    move-object/from16 v16, v13

    .line 1174
    const/4 v13, 0x0

    .line 1175
    move/from16 v17, v14

    .line 1177
    move/from16 v18, v15

    .line 1179
    const-wide/16 v14, 0x0

    .line 1181
    move-object/from16 v19, v16

    .line 1183
    const/16 v16, 0x0

    .line 1185
    move/from16 v21, v17

    .line 1187
    const/16 v17, 0x0

    .line 1189
    move/from16 v33, v18

    .line 1191
    const/16 v18, 0x0

    .line 1193
    move-object/from16 v34, v19

    .line 1195
    const/16 v19, 0x0

    .line 1197
    move-wide/from16 v35, v22

    .line 1199
    move-object/from16 v22, v20

    .line 1201
    const/16 v20, 0x0

    .line 1203
    const/16 v23, 0x30

    .line 1205
    move-object/from16 v43, v1

    .line 1207
    move/from16 v1, v21

    .line 1209
    move-wide/from16 v49, v30

    .line 1211
    move-object/from16 v21, v32

    .line 1213
    move-object/from16 v46, v34

    .line 1215
    move-wide/from16 v47, v35

    .line 1217
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1220
    move-object/from16 v5, v22

    .line 1222
    const/16 v17, 0x0

    .line 1224
    const/16 v18, 0xd

    .line 1226
    const/4 v14, 0x0

    .line 1227
    const/16 v16, 0x0

    .line 1229
    move/from16 v15, v26

    .line 1231
    move-object/from16 v13, v27

    .line 1233
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 1236
    move-result-object v2

    .line 1237
    invoke-static {v2, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 1240
    move-result-object v1

    .line 1241
    const/high16 v2, 0x40800000    # 4.0f

    .line 1243
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 1246
    move-result-object v1

    .line 1247
    const-string v2, "years_progress"

    .line 1249
    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 1252
    move-result-object v1

    .line 1253
    move-wide/from16 v10, v47

    .line 1255
    invoke-virtual {v5, v10, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 1258
    move-result v2

    .line 1259
    move-wide/from16 v12, v49

    .line 1261
    invoke-virtual {v5, v12, v13}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 1264
    move-result v3

    .line 1265
    or-int/2addr v2, v3

    .line 1266
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 1269
    move-result v3

    .line 1270
    or-int/2addr v2, v3

    .line 1271
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 1274
    move-result-object v3

    .line 1275
    if-nez v2, :cond_500

    .line 1277
    move-object/from16 v15, v43

    .line 1279
    if-ne v3, v15, :cond_50a

    .line 1281
    :cond_500
    new-instance v9, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;

    .line 1283
    move v14, v0

    .line 1284
    invoke-direct/range {v9 .. v14}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;-><init>(JJF)V

    .line 1287
    invoke-virtual {v5, v9}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1290
    move-object v3, v9

    .line 1291
    :cond_50a
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 1293
    invoke-static {v1, v3}, Landroidx/compose/ui/draw/ClipKt;->drawBehind(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 1296
    move-result-object v0

    .line 1297
    const/4 v15, 0x0

    .line 1298
    invoke-static {v0, v5, v15}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 1301
    const/16 v17, 0x0

    .line 1303
    const/16 v18, 0xd

    .line 1305
    const/4 v14, 0x0

    .line 1306
    const/high16 v15, 0x41400000    # 12.0f

    .line 1308
    const/16 v16, 0x0

    .line 1310
    move-object/from16 v13, v27

    .line 1312
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 1315
    move-result-object v3

    .line 1316
    move-object/from16 v22, v5

    .line 1318
    invoke-static/range {v22 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 1321
    move-result-wide v4

    .line 1322
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 1324
    const/high16 v24, 0xc00000

    .line 1326
    const v25, 0x1fff8

    .line 1329
    const-string v2, "Needs 20 songs with a year."

    .line 1331
    const-wide/16 v6, 0x0

    .line 1333
    const/4 v8, 0x0

    .line 1334
    const/4 v9, 0x0

    .line 1335
    const/4 v10, 0x0

    .line 1336
    const-wide/16 v11, 0x0

    .line 1338
    const/4 v13, 0x0

    .line 1339
    const-wide/16 v14, 0x0

    .line 1341
    const/16 v16, 0x0

    .line 1343
    const/16 v17, 0x0

    .line 1345
    const/16 v18, 0x0

    .line 1347
    const/16 v19, 0x0

    .line 1349
    const/16 v20, 0x0

    .line 1351
    const/16 v23, 0x36

    .line 1353
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1356
    move-object/from16 v5, v22

    .line 1358
    if-eqz v33, :cond_566

    .line 1360
    const v0, 0x34681b6e

    .line 1363
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 1366
    const v0, 0x3f4ccccd    # 0.8f

    .line 1369
    move-object/from16 v13, v46

    .line 1371
    invoke-static {v13, v0}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 1374
    move-result-object v0

    .line 1375
    invoke-static {v5, v0}, Landroidx/compose/foundation/layout/OffsetKt;->Spacer(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)V

    .line 1378
    const/4 v15, 0x0

    .line 1379
    :goto_562
    invoke-virtual {v5, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1382
    goto :goto_56e

    .line 1383
    :cond_566
    const v0, 0x56b97230

    .line 1386
    const/4 v15, 0x0

    .line 1387
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 1390
    goto :goto_562

    .line 1391
    :goto_56e
    invoke-virtual {v5, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1394
    move-object/from16 v30, v21

    .line 1396
    :goto_573
    const/16 v17, 0x0

    .line 1398
    const/16 v18, 0xd

    .line 1400
    const/4 v14, 0x0

    .line 1401
    const/high16 v15, 0x41000000    # 8.0f

    .line 1403
    const/16 v16, 0x0

    .line 1405
    move-object/from16 v13, v27

    .line 1407
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 1410
    move-result-object v3

    .line 1411
    move-object/from16 v22, v5

    .line 1413
    invoke-static/range {v22 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 1416
    move-result-wide v4

    .line 1417
    invoke-static/range {v29 .. v29}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 1420
    move-result-wide v33

    .line 1421
    const/16 v0, 0xe

    .line 1423
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 1426
    move-result-wide v41

    .line 1427
    const/16 v44, 0x0

    .line 1429
    const v45, 0xfdfffd

    .line 1432
    const-wide/16 v31, 0x0

    .line 1434
    const/16 v35, 0x0

    .line 1436
    const/16 v36, 0x0

    .line 1438
    const/16 v37, 0x0

    .line 1440
    const-wide/16 v38, 0x0

    .line 1442
    const/16 v40, 0x0

    .line 1444
    const/16 v43, 0x0

    .line 1446
    invoke-static/range {v30 .. v45}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 1449
    move-result-object v21

    .line 1450
    const/16 v24, 0x0

    .line 1452
    const v25, 0x1fff8

    .line 1455
    const-string v2, "Song years from MusicBrainz"

    .line 1457
    const-wide/16 v6, 0x0

    .line 1459
    const/4 v8, 0x0

    .line 1460
    const/4 v9, 0x0

    .line 1461
    const/4 v10, 0x0

    .line 1462
    const-wide/16 v11, 0x0

    .line 1464
    const/4 v13, 0x0

    .line 1465
    const-wide/16 v14, 0x0

    .line 1467
    const/16 v16, 0x0

    .line 1469
    const/16 v17, 0x0

    .line 1471
    const/16 v18, 0x0

    .line 1473
    const/16 v19, 0x0

    .line 1475
    const/16 v20, 0x0

    .line 1477
    const/16 v23, 0x36

    .line 1479
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1482
    goto :goto_5d4

    .line 1483
    :catchall_5ca
    move-exception v0

    .line 1484
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 1487
    throw v0

    .line 1488
    :cond_5cf
    move-object/from16 v22, v5

    .line 1490
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 1493
    :goto_5d4
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1495
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda63 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda63)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:J

.field public final synthetic f$2:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$3:I

.field public final synthetic f$4:I

.field public final synthetic f$5:J

.field public final synthetic f$6:Ljava/lang/Integer;

.field public final synthetic f$7:J

.field public final synthetic f$8:Lcom/spotifry/music/data/spotifried/AgeStats;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;JLandroidx/compose/animation/core/Animatable;IIJLjava/lang/Integer;JLcom/spotifry/music/data/spotifried/AgeStats;)V
    .registers 13

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$0:Ljava/util/List;

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 10
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$3:I

    .line 12
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$4:I

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$5:J

    .line 16
    iput-object p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$6:Ljava/lang/Integer;

    .line 18
    iput-wide p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$7:J

    .line 20
    iput-object p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$8:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 22
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 68

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 24
    if-nez v4, :cond_23

    .line 26
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v4

    .line 30
    if-eqz v4, :cond_21

    .line 32
    const/4 v4, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v4, 0x2

    .line 35
    :goto_22
    or-int/2addr v3, v4

    .line 36
    :cond_23
    and-int/lit8 v4, v3, 0x13

    .line 38
    const/16 v6, 0x12

    .line 40
    const/4 v7, 0x1

    .line 41
    const/4 v8, 0x0

    .line 42
    if-eq v4, v6, :cond_2d

    .line 44
    move v4, v7

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move v4, v8

    .line 47
    :goto_2e
    and-int/lit8 v6, v3, 0x1

    .line 49
    invoke-virtual {v2, v6, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v4

    .line 53
    if-eqz v4, :cond_4c8

    .line 55
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 58
    move-result v4

    .line 59
    const/high16 v6, 0x41b00000    # 22.0f

    .line 61
    sub-float/2addr v4, v6

    .line 62
    sget-object v9, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 64
    const/16 v10, 0xb

    .line 66
    invoke-static {v10}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 69
    move-result-wide v12

    .line 70
    const/16 v25, 0xe

    .line 72
    invoke-static/range {v25 .. v25}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 75
    move-result-wide v20

    .line 76
    const/16 v23, 0x0

    .line 78
    const v24, 0xfdfffd

    .line 81
    const-wide/16 v10, 0x0

    .line 83
    const/4 v14, 0x0

    .line 84
    const/4 v15, 0x0

    .line 85
    const/16 v16, 0x0

    .line 87
    const-wide/16 v17, 0x0

    .line 89
    const/16 v19, 0x0

    .line 91
    const/16 v22, 0x0

    .line 93
    invoke-static/range {v9 .. v24}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 96
    move-result-object v9

    .line 97
    sget-object v10, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 99
    invoke-virtual {v2, v10}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 102
    move-result-object v10

    .line 103
    check-cast v10, Landroidx/compose/ui/unit/Density;

    .line 105
    iget-object v11, v9, Landroidx/compose/ui/text/TextStyle;->paragraphStyle:Landroidx/compose/ui/text/ParagraphStyle;

    .line 107
    iget-wide v11, v11, Landroidx/compose/ui/text/ParagraphStyle;->lineHeight:J

    .line 109
    invoke-interface {v10, v11, v12}, Landroidx/compose/ui/unit/Density;->toDp-GaN1DYA(J)F

    .line 112
    move-result v42

    .line 113
    iget-object v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$0:Ljava/util/List;

    .line 115
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 118
    move-result-object v12

    .line 119
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 122
    move-result v13

    .line 123
    const/16 v43, 0x0

    .line 125
    if-nez v13, :cond_81

    .line 127
    move-object/from16 v13, v43

    .line 129
    goto :goto_b3

    .line 130
    :cond_81
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 133
    move-result-object v13

    .line 134
    check-cast v13, Lkotlin/Pair;

    .line 136
    iget-object v13, v13, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 138
    check-cast v13, Ljava/lang/Number;

    .line 140
    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    .line 143
    move-result v13

    .line 144
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 147
    move-result-object v13

    .line 148
    :cond_93
    :goto_93
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 151
    move-result v14

    .line 152
    if-eqz v14, :cond_b3

    .line 154
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 157
    move-result-object v14

    .line 158
    check-cast v14, Lkotlin/Pair;

    .line 160
    iget-object v14, v14, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 162
    check-cast v14, Ljava/lang/Number;

    .line 164
    invoke-virtual {v14}, Ljava/lang/Number;->intValue()I

    .line 167
    move-result v14

    .line 168
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 171
    move-result-object v14

    .line 172
    invoke-virtual {v13, v14}, Ljava/lang/Integer;->compareTo(Ljava/lang/Object;)I

    .line 175
    move-result v15

    .line 176
    if-gez v15, :cond_93

    .line 178
    move-object v13, v14

    .line 179
    goto :goto_93

    .line 180
    :cond_b3
    :goto_b3
    if-eqz v13, :cond_ba

    .line 182
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 185
    move-result v12

    .line 186
    goto :goto_bb

    .line 187
    :cond_ba
    move v12, v8

    .line 188
    :goto_bb
    const/high16 v13, 0x41400000    # 12.0f

    .line 190
    sub-float v44, v4, v13

    .line 192
    add-float v13, v6, v42

    .line 194
    const/high16 v14, 0x41000000    # 8.0f

    .line 196
    add-float/2addr v13, v14

    .line 197
    const/high16 v26, 0x40800000    # 4.0f

    .line 199
    add-float v13, v13, v26

    .line 201
    sub-float v13, v44, v13

    .line 203
    const/4 v15, 0x0

    .line 204
    const/high16 v6, 0x41200000    # 10.0f

    .line 206
    if-nez v12, :cond_d1

    .line 208
    :goto_cf
    move v12, v6

    .line 209
    goto :goto_fa

    .line 210
    :cond_d1
    new-instance v5, Landroidx/compose/ui/unit/Dp;

    .line 212
    invoke-direct {v5, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 215
    new-instance v6, Landroidx/compose/ui/unit/Dp;

    .line 217
    invoke-direct {v6, v13}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 220
    new-instance v13, Landroidx/compose/ui/unit/Dp;

    .line 222
    invoke-direct {v13, v15}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 225
    invoke-virtual {v6, v13}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 228
    move-result v16

    .line 229
    if-gez v16, :cond_e7

    .line 231
    move-object v6, v13

    .line 232
    :cond_e7
    iget v6, v6, Landroidx/compose/ui/unit/Dp;->value:F

    .line 234
    int-to-float v12, v12

    .line 235
    div-float/2addr v6, v12

    .line 236
    new-instance v12, Landroidx/compose/ui/unit/Dp;

    .line 238
    invoke-direct {v12, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 241
    invoke-virtual {v5, v12}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 244
    move-result v6

    .line 245
    if-lez v6, :cond_f7

    .line 247
    move-object v5, v12

    .line 248
    :cond_f7
    iget v6, v5, Landroidx/compose/ui/unit/Dp;->value:F

    .line 250
    goto :goto_cf

    .line 251
    :goto_fa
    const v5, 0x3f4ccccd    # 0.8f

    .line 254
    mul-float/2addr v5, v12

    .line 255
    new-instance v6, Landroidx/compose/ui/unit/Dp;

    .line 257
    invoke-direct {v6, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 260
    new-instance v5, Landroidx/compose/ui/unit/Dp;

    .line 262
    const/high16 v13, 0x40400000    # 3.0f

    .line 264
    invoke-direct {v5, v13}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 267
    new-instance v13, Landroidx/compose/ui/unit/Dp;

    .line 269
    invoke-direct {v13, v14}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 272
    invoke-static {v6, v5, v13}, Lkotlin/ResultKt;->coerceIn(Landroidx/compose/ui/unit/Dp;Landroidx/compose/ui/unit/Dp;Landroidx/compose/ui/unit/Dp;)Ljava/lang/Comparable;

    .line 275
    move-result-object v5

    .line 276
    check-cast v5, Landroidx/compose/ui/unit/Dp;

    .line 278
    iget v5, v5, Landroidx/compose/ui/unit/Dp;->value:F

    .line 280
    const/high16 v6, 0x41900000    # 18.0f

    .line 282
    invoke-interface {v10, v6}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 285
    move-result v6

    .line 286
    invoke-static {v8, v2, v8, v7}, Landroidx/compose/ui/text/ParagraphKt;->rememberTextMeasurer(ILandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/text/TextMeasurer;

    .line 289
    move-result-object v45

    .line 290
    sget-object v13, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 292
    move-object/from16 v16, v1

    .line 294
    const/high16 v1, 0x3f800000    # 1.0f

    .line 296
    move/from16 p3, v3

    .line 298
    invoke-static {v13, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 301
    move-result-object v3

    .line 302
    invoke-virtual {v2, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 305
    move-result v17

    .line 306
    move-object/from16 v19, v3

    .line 308
    move/from16 v18, v4

    .line 310
    iget-wide v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$1:J

    .line 312
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 315
    move-result v20

    .line 316
    or-int v17, v17, v20

    .line 318
    invoke-virtual {v2, v11}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 321
    move-result v20

    .line 322
    or-int v17, v17, v20

    .line 324
    move/from16 v20, v7

    .line 326
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 328
    invoke-virtual {v2, v7}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 331
    move-result v21

    .line 332
    or-int v17, v17, v21

    .line 334
    move-object/from16 v21, v10

    .line 336
    iget v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$3:I

    .line 338
    invoke-virtual {v2, v10}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 341
    move-result v22

    .line 342
    or-int v17, v17, v22

    .line 344
    move-object/from16 v22, v11

    .line 346
    iget v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$4:I

    .line 348
    invoke-virtual {v2, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 351
    move-result v23

    .line 352
    or-int v17, v17, v23

    .line 354
    invoke-virtual {v2, v12}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 357
    move-result v23

    .line 358
    or-int v17, v17, v23

    .line 360
    move-object/from16 v23, v13

    .line 362
    move/from16 v24, v14

    .line 364
    iget-wide v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$5:J

    .line 366
    invoke-virtual {v2, v13, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 369
    move-result v27

    .line 370
    or-int v17, v17, v27

    .line 372
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 375
    move-result v27

    .line 376
    or-int v17, v17, v27

    .line 378
    and-int/lit8 v1, p3, 0xe

    .line 380
    const/4 v8, 0x4

    .line 381
    if-ne v1, v8, :cond_181

    .line 383
    move/from16 v1, v20

    .line 385
    goto :goto_182

    .line 386
    :cond_181
    const/4 v1, 0x0

    .line 387
    :goto_182
    or-int v17, v17, v1

    .line 389
    move v1, v6

    .line 390
    iget-object v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$6:Ljava/lang/Integer;

    .line 392
    invoke-virtual {v2, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 395
    move-result v25

    .line 396
    or-int v17, v17, v25

    .line 398
    move-object/from16 v28, v9

    .line 400
    iget-wide v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$7:J

    .line 402
    invoke-virtual {v2, v8, v9}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 405
    move-result v29

    .line 406
    or-int v17, v17, v29

    .line 408
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 411
    move-result-object v15

    .line 412
    sget-object v0, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 414
    if-nez v17, :cond_1bb

    .line 416
    if-eq v15, v0, :cond_1bb

    .line 418
    move-object/from16 v46, v0

    .line 420
    move/from16 v48, v1

    .line 422
    move-object v0, v2

    .line 423
    move-object/from16 v55, v6

    .line 425
    move-wide/from16 v56, v8

    .line 427
    move v3, v10

    .line 428
    move v4, v11

    .line 429
    move/from16 v53, v12

    .line 431
    move-object/from16 v2, v16

    .line 433
    move-object/from16 v49, v19

    .line 435
    move-object/from16 v47, v21

    .line 437
    move-object/from16 v54, v22

    .line 439
    move-object/from16 v50, v23

    .line 441
    move/from16 v52, v24

    .line 443
    goto :goto_1e3

    .line 444
    :cond_1bb
    move v15, v1

    .line 445
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;

    .line 447
    move-object/from16 v46, v0

    .line 449
    move-object v0, v2

    .line 450
    move/from16 v48, v15

    .line 452
    move/from16 v2, v18

    .line 454
    move-object/from16 v49, v19

    .line 456
    move-object/from16 v47, v21

    .line 458
    move-object/from16 v50, v23

    .line 460
    move/from16 v52, v24

    .line 462
    move v15, v5

    .line 463
    move-object/from16 v5, v22

    .line 465
    invoke-direct/range {v1 .. v16}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;-><init>(FJLjava/util/List;Ljava/lang/Integer;Landroidx/compose/animation/core/Animatable;JIIFJFLandroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;)V

    .line 468
    move-object/from16 v54, v5

    .line 470
    move-object/from16 v55, v6

    .line 472
    move-wide/from16 v56, v8

    .line 474
    move v3, v10

    .line 475
    move v4, v11

    .line 476
    move/from16 v53, v12

    .line 478
    move-object/from16 v2, v16

    .line 480
    invoke-virtual {v0, v1}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 483
    move-object v15, v1

    .line 484
    :goto_1e3
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 486
    const/4 v1, 0x6

    .line 487
    move-object/from16 v5, v49

    .line 489
    invoke-static {v5, v15, v0, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 492
    sub-int v11, v4, v3

    .line 494
    const/16 v1, 0x64

    .line 496
    if-le v11, v1, :cond_1f4

    .line 498
    const/16 v1, 0x28

    .line 500
    goto :goto_1f6

    .line 501
    :cond_1f4
    const/16 v1, 0x14

    .line 503
    :goto_1f6
    const v5, -0x1f59f95

    .line 506
    invoke-virtual {v0, v5}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 509
    new-instance v5, Lkotlin/ranges/IntRange;

    .line 511
    add-int v10, v3, v1

    .line 513
    const/4 v6, 0x1

    .line 514
    sub-int/2addr v10, v6

    .line 515
    div-int/2addr v10, v1

    .line 516
    mul-int/2addr v10, v1

    .line 517
    invoke-direct {v5, v10, v4, v6}, Lkotlin/ranges/IntProgression;-><init>(III)V

    .line 520
    invoke-static {v1, v5}, Lkotlin/ResultKt;->step(ILkotlin/ranges/IntRange;)Lkotlin/ranges/IntProgression;

    .line 523
    move-result-object v1

    .line 524
    invoke-virtual {v1}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 527
    move-result-object v1

    .line 528
    :goto_20f
    move-object v5, v1

    .line 529
    check-cast v5, Lkotlin/ranges/IntProgressionIterator;

    .line 531
    iget-boolean v5, v5, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 533
    const/high16 v8, 0x3f000000    # 0.5f

    .line 535
    if-eqz v5, :cond_28d

    .line 537
    move-object v5, v1

    .line 538
    check-cast v5, Lkotlin/collections/IntIterator;

    .line 540
    invoke-virtual {v5}, Lkotlin/collections/IntIterator;->nextInt()I

    .line 543
    move-result v5

    .line 544
    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 547
    move-result-object v9

    .line 548
    sget-object v10, Landroidx/compose/ui/Alignment$Companion;->BottomStart:Landroidx/compose/ui/BiasAlignment;

    .line 550
    move-object/from16 v11, v50

    .line 552
    invoke-virtual {v2, v11, v10}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;)Landroidx/compose/ui/Modifier;

    .line 555
    move-result-object v10

    .line 556
    invoke-static {v2, v3, v4, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 559
    move-result v5

    .line 560
    new-instance v12, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;

    .line 562
    invoke-direct {v12, v5, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;-><init>(FF)V

    .line 565
    invoke-static {v10, v12}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 568
    move-result-object v5

    .line 569
    move v10, v3

    .line 570
    move v8, v4

    .line 571
    move-object v3, v5

    .line 572
    invoke-static {v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 575
    move-result-wide v4

    .line 576
    const/16 v24, 0x0

    .line 578
    const v25, 0x1fff8

    .line 581
    move-object v12, v7

    .line 582
    const-wide/16 v6, 0x0

    .line 584
    move v13, v8

    .line 585
    const/4 v8, 0x0

    .line 586
    move-object/from16 v16, v2

    .line 588
    move-object v2, v9

    .line 589
    const/4 v9, 0x0

    .line 590
    move v14, v10

    .line 591
    const/4 v10, 0x0

    .line 592
    move-object v15, v12

    .line 593
    const-wide/16 v11, 0x0

    .line 595
    move/from16 v17, v13

    .line 597
    const/4 v13, 0x0

    .line 598
    move/from16 v19, v14

    .line 600
    move-object/from16 v18, v15

    .line 602
    const-wide/16 v14, 0x0

    .line 604
    move-object/from16 v21, v16

    .line 606
    const/16 v16, 0x0

    .line 608
    move/from16 v22, v17

    .line 610
    const/16 v17, 0x0

    .line 612
    move-object/from16 v23, v18

    .line 614
    const/16 v18, 0x0

    .line 616
    move/from16 v27, v19

    .line 618
    const/16 v19, 0x0

    .line 620
    const/16 v20, 0x0

    .line 622
    move-object/from16 v29, v23

    .line 624
    const/16 v23, 0x0

    .line 626
    move-object/from16 p1, v1

    .line 628
    move/from16 v59, v22

    .line 630
    move/from16 v1, v27

    .line 632
    move-object/from16 v58, v29

    .line 634
    move-object/from16 v22, v0

    .line 636
    move-object/from16 v0, v21

    .line 638
    move-object/from16 v21, v28

    .line 640
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 643
    move-object v2, v0

    .line 644
    move v3, v1

    .line 645
    move-object/from16 v0, v22

    .line 647
    move-object/from16 v7, v58

    .line 649
    move/from16 v4, v59

    .line 651
    move-object/from16 v1, p1

    .line 653
    goto :goto_20f

    .line 654
    :cond_28d
    move-object v1, v2

    .line 655
    move-object v2, v0

    .line 656
    move-object v0, v1

    .line 657
    move v1, v3

    .line 658
    move/from16 v59, v4

    .line 660
    move-object/from16 v58, v7

    .line 662
    const/4 v3, 0x0

    .line 663
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 666
    if-eqz v55, :cond_352

    .line 668
    const v3, -0x1f58a3d

    .line 671
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 674
    invoke-static/range {v55 .. v55}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 677
    move-result-object v3

    .line 678
    invoke-virtual/range {v55 .. v55}, Ljava/lang/Integer;->intValue()I

    .line 681
    move-result v4

    .line 682
    move/from16 v5, v59

    .line 684
    invoke-static {v0, v1, v5, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 687
    move-result v4

    .line 688
    new-instance v6, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;

    .line 690
    invoke-direct {v6, v4, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;-><init>(FF)V

    .line 693
    move-object/from16 v4, v50

    .line 695
    invoke-static {v4, v6}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 698
    move-result-object v15

    .line 699
    const/16 v19, 0x0

    .line 701
    const/16 v20, 0xd

    .line 703
    const/16 v16, 0x0

    .line 705
    const/16 v18, 0x0

    .line 707
    move/from16 v17, v26

    .line 709
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 712
    move-result-object v6

    .line 713
    move/from16 v49, v17

    .line 715
    move-object/from16 v7, v58

    .line 717
    invoke-virtual {v2, v7}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 720
    move-result v8

    .line 721
    move/from16 v15, v48

    .line 723
    invoke-virtual {v2, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 726
    move-result v9

    .line 727
    or-int/2addr v8, v9

    .line 728
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 731
    move-result-object v9

    .line 732
    if-nez v8, :cond_2e2

    .line 734
    move-object/from16 v8, v46

    .line 736
    if-ne v9, v8, :cond_2ed

    .line 738
    goto :goto_2e4

    .line 739
    :cond_2e2
    move-object/from16 v8, v46

    .line 741
    :goto_2e4
    new-instance v9, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 743
    const/4 v10, 0x4

    .line 744
    invoke-direct {v9, v7, v15, v10}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 747
    invoke-virtual {v2, v9}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 750
    :cond_2ed
    check-cast v9, Lkotlin/jvm/functions/Function1;

    .line 752
    invoke-static {v6, v9}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 755
    move-result-object v6

    .line 756
    const/16 v9, 0xc

    .line 758
    invoke-static {v9}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 761
    move-result-wide v29

    .line 762
    sget-object v31, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 764
    const/16 v40, 0x0

    .line 766
    const v41, 0xfffff9

    .line 769
    move-object/from16 v21, v28

    .line 771
    const-wide/16 v27, 0x0

    .line 773
    const/16 v32, 0x0

    .line 775
    const/16 v33, 0x0

    .line 777
    const-wide/16 v34, 0x0

    .line 779
    const/16 v36, 0x0

    .line 781
    const-wide/16 v37, 0x0

    .line 783
    const/16 v39, 0x0

    .line 785
    move-object/from16 v26, v21

    .line 787
    invoke-static/range {v26 .. v41}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 790
    move-result-object v21

    .line 791
    move-object/from16 v28, v26

    .line 793
    const/16 v24, 0x0

    .line 795
    const v25, 0x1fff8

    .line 798
    move-object/from16 v22, v2

    .line 800
    move-object v2, v3

    .line 801
    move-object v3, v6

    .line 802
    move-object v12, v7

    .line 803
    const-wide/16 v6, 0x0

    .line 805
    move-object/from16 v46, v8

    .line 807
    const/4 v8, 0x0

    .line 808
    const/4 v9, 0x0

    .line 809
    const/4 v10, 0x0

    .line 810
    move-object/from16 v29, v12

    .line 812
    const-wide/16 v11, 0x0

    .line 814
    const/4 v13, 0x0

    .line 815
    const-wide/16 v14, 0x0

    .line 817
    const/16 v16, 0x0

    .line 819
    const/16 v17, 0x0

    .line 821
    const/16 v18, 0x0

    .line 823
    const/16 v19, 0x0

    .line 825
    const/16 v20, 0x0

    .line 827
    const/16 v23, 0x0

    .line 829
    move-object/from16 v60, v4

    .line 831
    move/from16 v62, v5

    .line 833
    move-object/from16 v61, v29

    .line 835
    move-object/from16 v63, v46

    .line 837
    move-wide/from16 v4, v56

    .line 839
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 842
    move-object/from16 v2, v22

    .line 844
    const/4 v3, 0x0

    .line 845
    :goto_34c
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 848
    move-object/from16 v4, p0

    .line 850
    goto :goto_364

    .line 851
    :cond_352
    move/from16 v49, v26

    .line 853
    move-object/from16 v63, v46

    .line 855
    move-object/from16 v60, v50

    .line 857
    move-object/from16 v61, v58

    .line 859
    move/from16 v62, v59

    .line 861
    const/4 v3, 0x0

    .line 862
    const v4, -0x3e60c006

    .line 865
    invoke-virtual {v2, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 868
    goto :goto_34c

    .line 869
    :goto_364
    iget-object v4, v4, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$8:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 871
    iget-object v4, v4, Lcom/spotifry/music/data/spotifried/AgeStats;->oldestYear:Ljava/lang/Integer;

    .line 873
    if-nez v4, :cond_375

    .line 875
    const v0, -0x3cb62000    # -201.875f

    .line 878
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 881
    :goto_370
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 884
    goto/16 :goto_4cb

    .line 886
    :cond_375
    const v3, -0x3cb61fff

    .line 889
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 892
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 895
    move-result v3

    .line 896
    const-string v4, ", your oldest"

    .line 898
    invoke-static {v3, v4}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 901
    move-result-object v27

    .line 902
    const-wide/16 v30, 0x0

    .line 904
    const/16 v32, 0x3fc

    .line 906
    const/16 v29, 0x0

    .line 908
    move-object/from16 v26, v45

    .line 910
    invoke-static/range {v26 .. v32}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 913
    move-result-object v4

    .line 914
    iget-wide v4, v4, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 916
    const/16 v6, 0x20

    .line 918
    shr-long/2addr v4, v6

    .line 919
    long-to-int v4, v4

    .line 920
    move-object/from16 v10, v47

    .line 922
    invoke-interface {v10, v4}, Landroidx/compose/ui/unit/Density;->toDp-u2uoSUM(I)F

    .line 925
    move-result v4

    .line 926
    move/from16 v13, v62

    .line 928
    invoke-static {v0, v1, v13, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 931
    move-result v5

    .line 932
    add-float v5, v5, v49

    .line 934
    sub-float/2addr v5, v4

    .line 935
    new-instance v6, Landroidx/compose/ui/unit/Dp;

    .line 937
    invoke-direct {v6, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 940
    new-instance v5, Landroidx/compose/ui/unit/Dp;

    .line 942
    const/4 v7, 0x0

    .line 943
    invoke-direct {v5, v7}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 946
    invoke-virtual {v6, v5}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 949
    move-result v8

    .line 950
    if-gez v8, :cond_3b8

    .line 952
    move-object v6, v5

    .line 953
    :cond_3b8
    new-instance v5, Ljava/util/ArrayList;

    .line 955
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 958
    invoke-interface/range {v54 .. v54}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 961
    move-result-object v8

    .line 962
    :cond_3c1
    :goto_3c1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 965
    move-result v9

    .line 966
    if-eqz v9, :cond_3f1

    .line 968
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 971
    move-result-object v9

    .line 972
    move-object v10, v9

    .line 973
    check-cast v10, Lkotlin/Pair;

    .line 975
    iget v11, v6, Landroidx/compose/ui/unit/Dp;->value:F

    .line 977
    sub-float v12, v11, v49

    .line 979
    add-float/2addr v11, v4

    .line 980
    add-float v11, v11, v49

    .line 982
    iget-object v10, v10, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 984
    check-cast v10, Ljava/lang/Number;

    .line 986
    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    .line 989
    move-result v10

    .line 990
    invoke-static {v0, v1, v13, v10}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 993
    move-result v10

    .line 994
    invoke-static {v10, v12}, Ljava/lang/Float;->compare(FF)I

    .line 997
    move-result v12

    .line 998
    if-ltz v12, :cond_3c1

    .line 1000
    invoke-static {v10, v11}, Ljava/lang/Float;->compare(FF)I

    .line 1003
    move-result v10

    .line 1004
    if-gtz v10, :cond_3c1

    .line 1006
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1009
    goto :goto_3c1

    .line 1010
    :cond_3f1
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1013
    move-result-object v4

    .line 1014
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1017
    move-result v5

    .line 1018
    if-eqz v5, :cond_42f

    .line 1020
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1023
    move-result-object v5

    .line 1024
    check-cast v5, Lkotlin/Pair;

    .line 1026
    iget-object v5, v5, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 1028
    check-cast v5, Ljava/lang/Number;

    .line 1030
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 1033
    move-result v5

    .line 1034
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1037
    move-result-object v5

    .line 1038
    :cond_40d
    :goto_40d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1041
    move-result v6

    .line 1042
    if-eqz v6, :cond_42d

    .line 1044
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1047
    move-result-object v6

    .line 1048
    check-cast v6, Lkotlin/Pair;

    .line 1050
    iget-object v6, v6, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 1052
    check-cast v6, Ljava/lang/Number;

    .line 1054
    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    .line 1057
    move-result v6

    .line 1058
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1061
    move-result-object v6

    .line 1062
    invoke-virtual {v5, v6}, Ljava/lang/Integer;->compareTo(Ljava/lang/Object;)I

    .line 1065
    move-result v8

    .line 1066
    if-gez v8, :cond_40d

    .line 1068
    move-object v5, v6

    .line 1069
    goto :goto_40d

    .line 1070
    :cond_42d
    move-object/from16 v43, v5

    .line 1072
    :cond_42f
    if-eqz v43, :cond_436

    .line 1074
    invoke-virtual/range {v43 .. v43}, Ljava/lang/Integer;->intValue()I

    .line 1077
    move-result v8

    .line 1078
    goto :goto_437

    .line 1079
    :cond_436
    const/4 v8, 0x0

    .line 1080
    :goto_437
    int-to-float v4, v8

    .line 1081
    mul-float v12, v53, v4

    .line 1083
    sub-float v44, v44, v12

    .line 1085
    sub-float v44, v44, v49

    .line 1087
    sub-float v44, v44, v52

    .line 1089
    sub-float v4, v44, v42

    .line 1091
    if-nez v55, :cond_44d

    .line 1093
    invoke-static {v4, v7}, Ljava/lang/Float;->compare(FF)I

    .line 1096
    move-result v5

    .line 1097
    if-gez v5, :cond_44d

    .line 1099
    :goto_44a
    const/4 v3, 0x0

    .line 1100
    goto/16 :goto_370

    .line 1102
    :cond_44d
    if-nez v55, :cond_453

    .line 1104
    :goto_44f
    move-object/from16 v11, v60

    .line 1106
    const/4 v6, 0x1

    .line 1107
    goto :goto_469

    .line 1108
    :cond_453
    new-instance v5, Landroidx/compose/ui/unit/Dp;

    .line 1110
    invoke-direct {v5, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 1113
    new-instance v4, Landroidx/compose/ui/unit/Dp;

    .line 1115
    const/high16 v6, 0x41b00000    # 22.0f

    .line 1117
    invoke-direct {v4, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 1120
    invoke-virtual {v5, v4}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 1123
    move-result v6

    .line 1124
    if-gez v6, :cond_466

    .line 1126
    move-object v5, v4

    .line 1127
    :cond_466
    iget v4, v5, Landroidx/compose/ui/unit/Dp;->value:F

    .line 1129
    goto :goto_44f

    .line 1130
    :goto_469
    invoke-static {v11, v7, v4, v6}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 1133
    move-result-object v4

    .line 1134
    invoke-static {v0, v1, v13, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 1137
    move-result v0

    .line 1138
    add-float v0, v0, v49

    .line 1140
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;

    .line 1142
    const/high16 v3, 0x3f800000    # 1.0f

    .line 1144
    invoke-direct {v1, v0, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;-><init>(FF)V

    .line 1147
    invoke-static {v4, v1}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 1150
    move-result-object v0

    .line 1151
    move-object/from16 v7, v61

    .line 1153
    invoke-virtual {v2, v7}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 1156
    move-result v1

    .line 1157
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 1160
    move-result-object v3

    .line 1161
    if-nez v1, :cond_48e

    .line 1163
    move-object/from16 v8, v63

    .line 1165
    if-ne v3, v8, :cond_497

    .line 1167
    :cond_48e
    new-instance v3, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;

    .line 1169
    const/4 v1, 0x5

    .line 1170
    invoke-direct {v3, v7, v1}, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 1173
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1176
    :cond_497
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 1178
    invoke-static {v0, v3}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 1181
    move-result-object v3

    .line 1182
    invoke-static {v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 1185
    move-result-wide v4

    .line 1186
    const/16 v24, 0x6000

    .line 1188
    const v25, 0x1bff8

    .line 1191
    const-wide/16 v6, 0x0

    .line 1193
    const/4 v8, 0x0

    .line 1194
    const/4 v9, 0x0

    .line 1195
    const/4 v10, 0x0

    .line 1196
    const-wide/16 v11, 0x0

    .line 1198
    const/4 v13, 0x0

    .line 1199
    const-wide/16 v14, 0x0

    .line 1201
    const/16 v16, 0x0

    .line 1203
    const/16 v17, 0x0

    .line 1205
    const/16 v18, 0x1

    .line 1207
    const/16 v19, 0x0

    .line 1209
    const/16 v20, 0x0

    .line 1211
    const/16 v23, 0x0

    .line 1213
    move-object/from16 v22, v2

    .line 1215
    move-object/from16 v2, v27

    .line 1217
    move-object/from16 v21, v28

    .line 1219
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1222
    move-object/from16 v2, v22

    .line 1224
    goto :goto_44a

    .line 1225
    :cond_4c8
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 1228
    :goto_4cb
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1230
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda69 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda69)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:F

.field public final synthetic f$1:J

.field public final synthetic f$10:F

.field public final synthetic f$11:Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Ljava/lang/Integer;

.field public final synthetic f$4:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$5:J

.field public final synthetic f$6:I

.field public final synthetic f$7:I

.field public final synthetic f$8:F

.field public final synthetic f$9:J


# direct methods
.method public synthetic constructor <init>(FJLjava/util/List;Ljava/lang/Integer;Landroidx/compose/animation/core/Animatable;JIIFJFLandroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$0:F

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$2:Ljava/util/List;

    .line 10
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$3:Ljava/lang/Integer;

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$4:Landroidx/compose/animation/core/Animatable;

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$5:J

    .line 16
    iput p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$6:I

    .line 18
    iput p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$7:I

    .line 20
    iput p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$8:F

    .line 22
    iput-wide p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$9:J

    .line 24
    iput p14, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$10:F

    .line 26
    iput-object p15, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$11:Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$0:F

    .line 12
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 15
    move-result v11

    .line 16
    invoke-static {v11}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 19
    move-result v2

    .line 20
    int-to-long v2, v2

    .line 21
    const-wide v12, 0xffffffffL

    .line 26
    and-long v4, v2, v12

    .line 28
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 31
    move-result-wide v2

    .line 32
    const/16 v14, 0x20

    .line 34
    shr-long/2addr v2, v14

    .line 35
    long-to-int v2, v2

    .line 36
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 39
    move-result v2

    .line 40
    const/high16 v15, 0x3f800000    # 1.0f

    .line 42
    invoke-interface {v1, v15}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 45
    move-result v3

    .line 46
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 49
    move-result v2

    .line 50
    int-to-long v6, v2

    .line 51
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 54
    move-result v2

    .line 55
    int-to-long v2, v2

    .line 56
    shl-long/2addr v6, v14

    .line 57
    and-long/2addr v2, v12

    .line 58
    or-long/2addr v6, v2

    .line 59
    const/4 v9, 0x0

    .line 60
    const/16 v10, 0x78

    .line 62
    iget-wide v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$1:J

    .line 64
    const/4 v8, 0x0

    .line 65
    invoke-static/range {v1 .. v10}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFII)V

    .line 68
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$2:Ljava/util/List;

    .line 70
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 73
    move-result-object v10

    .line 74
    :goto_49
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 77
    move-result v2

    .line 78
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$4:Landroidx/compose/animation/core/Animatable;

    .line 80
    iget v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$6:I

    .line 82
    iget v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$7:I

    .line 84
    iget-object v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$11:Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 86
    const/high16 v7, 0x40000000    # 2.0f

    .line 88
    const/high16 v8, 0x44480000    # 800.0f

    .line 90
    if-eqz v2, :cond_de

    .line 92
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 95
    move-result-object v2

    .line 96
    check-cast v2, Lkotlin/Pair;

    .line 98
    iget-object v9, v2, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 100
    check-cast v9, Ljava/lang/Number;

    .line 102
    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    .line 105
    move-result v9

    .line 106
    iget-object v2, v2, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 108
    check-cast v2, Ljava/lang/Number;

    .line 110
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 113
    move-result v2

    .line 114
    invoke-virtual {v3}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 117
    move-result-object v3

    .line 118
    check-cast v3, Ljava/lang/Number;

    .line 120
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 123
    move-result v3

    .line 124
    move-wide/from16 v16, v12

    .line 126
    sub-int v12, v9, v4

    .line 128
    int-to-float v12, v12

    .line 129
    const v13, 0x44b54000    # 1450.0f

    .line 132
    mul-float/2addr v12, v13

    .line 133
    sub-int v13, v5, v4

    .line 135
    int-to-float v13, v13

    .line 136
    div-float/2addr v12, v13

    .line 137
    const/high16 v13, 0x43960000    # 300.0f

    .line 139
    add-float/2addr v12, v13

    .line 140
    int-to-float v2, v2

    .line 141
    const/high16 v13, 0x41c80000    # 25.0f

    .line 143
    mul-float/2addr v13, v2

    .line 144
    add-float/2addr v13, v12

    .line 145
    invoke-static {v3, v13, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 148
    move-result v3

    .line 149
    const/high16 v8, 0x41400000    # 12.0f

    .line 151
    invoke-interface {v1, v8}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 154
    move-result v8

    .line 155
    sub-float v8, v11, v8

    .line 157
    iget v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$8:F

    .line 159
    invoke-interface {v1, v12}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 162
    move-result v12

    .line 163
    mul-float/2addr v12, v2

    .line 164
    sub-float/2addr v8, v12

    .line 165
    sub-float v2, v15, v3

    .line 167
    const/high16 v12, 0x42f00000    # 120.0f

    .line 169
    invoke-interface {v1, v12}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 172
    move-result v12

    .line 173
    mul-float/2addr v12, v2

    .line 174
    sub-float/2addr v8, v12

    .line 175
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$10:F

    .line 177
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 180
    move-result v2

    .line 181
    div-float/2addr v2, v7

    .line 182
    invoke-static {v6, v4, v5, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 185
    move-result v4

    .line 186
    invoke-interface {v1, v4}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 189
    move-result v4

    .line 190
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 193
    move-result v4

    .line 194
    int-to-long v4, v4

    .line 195
    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 198
    move-result v6

    .line 199
    int-to-long v6, v6

    .line 200
    shl-long/2addr v4, v14

    .line 201
    and-long v6, v6, v16

    .line 203
    or-long v5, v4, v6

    .line 205
    const v4, 0x3f666666    # 0.9f

    .line 208
    mul-float v7, v3, v4

    .line 210
    const/4 v8, 0x0

    .line 211
    const/16 v9, 0x70

    .line 213
    move v4, v2

    .line 214
    iget-wide v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$9:J

    .line 216
    invoke-static/range {v1 .. v9}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 219
    move-wide/from16 v12, v16

    .line 221
    goto/16 :goto_49

    .line 223
    :cond_de
    move-wide/from16 v16, v12

    .line 225
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$3:Ljava/lang/Integer;

    .line 227
    if-eqz v2, :cond_14e

    .line 229
    invoke-virtual {v3}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 232
    move-result-object v3

    .line 233
    check-cast v3, Ljava/lang/Number;

    .line 235
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 238
    move-result v3

    .line 239
    const v9, 0x45098000    # 2200.0f

    .line 242
    invoke-static {v3, v9, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 245
    move-result v3

    .line 246
    const/high16 v8, 0x41d00000    # 26.0f

    .line 248
    invoke-interface {v1, v8}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 251
    move-result v8

    .line 252
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 255
    move-result v2

    .line 256
    invoke-static {v6, v4, v5, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 259
    move-result v2

    .line 260
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 263
    move-result v2

    .line 264
    invoke-interface {v1, v15}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 267
    move-result v4

    .line 268
    sub-float/2addr v2, v4

    .line 269
    sub-float v4, v11, v8

    .line 271
    mul-float/2addr v4, v3

    .line 272
    sub-float/2addr v11, v4

    .line 273
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 276
    move-result v2

    .line 277
    int-to-long v2, v2

    .line 278
    invoke-static {v11}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 281
    move-result v5

    .line 282
    int-to-long v5, v5

    .line 283
    shl-long/2addr v2, v14

    .line 284
    and-long v5, v5, v16

    .line 286
    or-long/2addr v2, v5

    .line 287
    invoke-interface {v1, v7}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 290
    move-result v5

    .line 291
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 294
    move-result v5

    .line 295
    int-to-long v5, v5

    .line 296
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 299
    move-result v4

    .line 300
    int-to-long v7, v4

    .line 301
    shl-long/2addr v5, v14

    .line 302
    and-long v7, v7, v16

    .line 304
    or-long/2addr v5, v7

    .line 305
    invoke-interface {v1, v15}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 308
    move-result v4

    .line 309
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 312
    move-result v7

    .line 313
    int-to-long v7, v7

    .line 314
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 317
    move-result v4

    .line 318
    int-to-long v9, v4

    .line 319
    shl-long/2addr v7, v14

    .line 320
    and-long v9, v9, v16

    .line 322
    or-long/2addr v7, v9

    .line 323
    const/4 v10, 0x0

    .line 324
    const/16 v11, 0xf0

    .line 326
    iget-wide v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$5:J

    .line 328
    const/4 v9, 0x0

    .line 329
    move-object v0, v1

    .line 330
    move-wide v3, v2

    .line 331
    move-wide v1, v12

    .line 332
    invoke-static/range {v0 .. v11}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 335
    :cond_14e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 337
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda67 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda67)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:J

.field public final synthetic f$2:F


# direct methods
.method public synthetic constructor <init>(JJF)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-wide p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$0:J

    .line 6
    iput-wide p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$1:J

    .line 8
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$2:F

    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 16

    .line 1
    move-object v0, p1

    .line 2
    check-cast v0, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 4
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 10
    move-result-wide v1

    .line 11
    const-wide v12, 0xffffffffL

    .line 16
    and-long/2addr v1, v12

    .line 17
    long-to-int p1, v1

    .line 18
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 21
    move-result p1

    .line 22
    const/high16 v1, 0x40000000    # 2.0f

    .line 24
    div-float/2addr p1, v1

    .line 25
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 28
    move-result v1

    .line 29
    int-to-long v1, v1

    .line 30
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 33
    move-result p1

    .line 34
    int-to-long v3, p1

    .line 35
    const/16 p1, 0x20

    .line 37
    shl-long/2addr v1, p1

    .line 38
    and-long/2addr v3, v12

    .line 39
    or-long v7, v1, v3

    .line 41
    const/4 v10, 0x0

    .line 42
    const/16 v11, 0xf6

    .line 44
    iget-wide v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$0:J

    .line 46
    const-wide/16 v3, 0x0

    .line 48
    const-wide/16 v5, 0x0

    .line 50
    const/4 v9, 0x0

    .line 51
    invoke-static/range {v0 .. v11}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 54
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 57
    move-result-wide v1

    .line 58
    shr-long/2addr v1, p1

    .line 59
    long-to-int v1, v1

    .line 60
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 63
    move-result v1

    .line 64
    iget v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$2:F

    .line 66
    mul-float/2addr v1, v2

    .line 67
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 70
    move-result-wide v2

    .line 71
    and-long/2addr v2, v12

    .line 72
    long-to-int v2, v2

    .line 73
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 76
    move-result v2

    .line 77
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 80
    move-result v1

    .line 81
    int-to-long v3, v1

    .line 82
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 85
    move-result v1

    .line 86
    int-to-long v1, v1

    .line 87
    shl-long/2addr v3, p1

    .line 88
    and-long/2addr v1, v12

    .line 89
    or-long v5, v3, v1

    .line 91
    const/16 v11, 0xf2

    .line 93
    iget-wide v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$1:J

    .line 95
    const-wide/16 v3, 0x0

    .line 97
    invoke-static/range {v0 .. v11}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 100
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 102
    return-object p0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda23 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda23)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$1:J

.field public final synthetic f$2:F

.field public final synthetic f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$4:F

.field public final synthetic f$5:Lcom/spotifry/music/ui/listening/SunMotion;

.field public final synthetic f$6:Z


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;JFLcom/spotifry/music/data/spotifried/SpotifriedStats;FLcom/spotifry/music/ui/listening/SunMotion;Z)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$1:J

    .line 8
    iput p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$2:F

    .line 10
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 12
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$4:F

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$5:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 16
    iput-boolean p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$6:Z

    .line 18
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v12, p2

    .line 9
    check-cast v12, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    if-nez v3, :cond_23

    .line 26
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_21

    .line 32
    const/4 v3, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v3, 0x2

    .line 35
    :goto_22
    or-int/2addr v2, v3

    .line 36
    :cond_23
    and-int/lit8 v3, v2, 0x13

    .line 38
    const/16 v5, 0x12

    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v15, 0x1

    .line 42
    if-eq v3, v5, :cond_2d

    .line 44
    move v3, v15

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move v3, v6

    .line 47
    :goto_2e
    and-int/2addr v2, v15

    .line 48
    invoke-virtual {v12, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 51
    move-result v2

    .line 52
    if-eqz v2, :cond_1fa

    .line 54
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 57
    move-result v1

    .line 58
    const v2, 0x3faa3d71    # 1.33f

    .line 61
    mul-float/2addr v1, v2

    .line 62
    sget-object v2, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 64
    invoke-virtual {v12, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 67
    move-result-object v2

    .line 68
    check-cast v2, Landroidx/compose/ui/unit/Density;

    .line 70
    const/high16 v3, 0x430c0000    # 140.0f

    .line 72
    invoke-interface {v2, v3}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 75
    move-result v2

    .line 76
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 78
    const/high16 v5, 0x3f800000    # 1.0f

    .line 80
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 83
    move-result-object v7

    .line 84
    new-instance v8, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 86
    const/16 v9, 0xd

    .line 88
    invoke-direct {v8, v9}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 91
    invoke-static {v7, v8}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 94
    move-result-object v7

    .line 95
    new-instance v8, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 97
    const/16 v9, 0xe

    .line 99
    invoke-direct {v8, v9}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 102
    invoke-static {v7, v8}, Landroidx/compose/ui/draw/ClipKt;->drawWithContent(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 105
    move-result-object v7

    .line 106
    sget-object v8, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 108
    invoke-static {v8, v6}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 111
    move-result-object v9

    .line 112
    iget-wide v10, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 114
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 117
    move-result v10

    .line 118
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 121
    move-result-object v11

    .line 122
    invoke-static {v12, v7}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 125
    move-result-object v7

    .line 126
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 128
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 131
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 133
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 136
    iget-boolean v14, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 138
    if-eqz v14, :cond_8f

    .line 140
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 143
    goto :goto_92

    .line 144
    :cond_8f
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 147
    :goto_92
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 149
    invoke-static {v12, v9, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 152
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 154
    invoke-static {v12, v11, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 157
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 159
    iget-boolean v4, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 161
    if-nez v4, :cond_b0

    .line 163
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 166
    move-result-object v4

    .line 167
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 170
    move-result-object v5

    .line 171
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 174
    move-result v4

    .line 175
    if-nez v4, :cond_b3

    .line 177
    :cond_b0
    invoke-static {v10, v12, v10, v11}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 180
    :cond_b3
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 182
    invoke-static {v12, v7, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 185
    sget-object v5, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    .line 187
    sget-object v7, Landroidx/compose/ui/Alignment$Companion;->BottomCenter:Landroidx/compose/ui/BiasAlignment;

    .line 189
    invoke-virtual {v5, v3, v7}, Landroidx/compose/foundation/layout/BoxScopeInstance;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;)Landroidx/compose/ui/Modifier;

    .line 192
    move-result-object v5

    .line 193
    const/high16 v7, 0x40000000    # 2.0f

    .line 195
    div-float v7, v1, v7

    .line 197
    const/high16 v10, 0x42480000    # 50.0f

    .line 199
    sub-float/2addr v7, v10

    .line 200
    const/4 v10, 0x0

    .line 201
    invoke-static {v5, v10, v7, v15}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 204
    move-result-object v5

    .line 205
    invoke-static {v5, v1}, Landroidx/compose/foundation/layout/SizeKt;->requiredSize-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 208
    move-result-object v1

    .line 209
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 211
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 214
    move-result v7

    .line 215
    invoke-virtual {v12, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 218
    move-result v10

    .line 219
    or-int/2addr v7, v10

    .line 220
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 223
    move-result-object v10

    .line 224
    sget-object v6, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 226
    if-nez v7, :cond_e5

    .line 228
    if-ne v10, v6, :cond_ed

    .line 230
    :cond_e5
    new-instance v10, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 232
    invoke-direct {v10, v5, v2, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 235
    invoke-virtual {v12, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 238
    :cond_ed
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 240
    invoke-static {v1, v10}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 243
    move-result-object v1

    .line 244
    const/4 v2, 0x0

    .line 245
    invoke-static {v8, v2}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 248
    move-result-object v5

    .line 249
    move-object v2, v8

    .line 250
    iget-wide v7, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 252
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 255
    move-result v7

    .line 256
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 259
    move-result-object v8

    .line 260
    invoke-static {v12, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 263
    move-result-object v1

    .line 264
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 267
    iget-boolean v10, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 269
    if-eqz v10, :cond_112

    .line 271
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 274
    goto :goto_115

    .line 275
    :cond_112
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 278
    :goto_115
    invoke-static {v12, v5, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 281
    invoke-static {v12, v8, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 284
    iget-boolean v5, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 286
    if-nez v5, :cond_12d

    .line 288
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 291
    move-result-object v5

    .line 292
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 295
    move-result-object v8

    .line 296
    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 299
    move-result v5

    .line 300
    if-nez v5, :cond_130

    .line 302
    :cond_12d
    invoke-static {v7, v12, v7, v11}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 305
    :cond_130
    invoke-static {v12, v1, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 308
    const/high16 v1, 0x3f800000    # 1.0f

    .line 310
    invoke-static {v3, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 313
    move-result-object v5

    .line 314
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$1:J

    .line 316
    invoke-virtual {v12, v7, v8}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 319
    move-result v1

    .line 320
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 323
    move-result-object v10

    .line 324
    if-nez v1, :cond_147

    .line 326
    if-ne v10, v6, :cond_151

    .line 328
    :cond_147
    new-instance v10, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 330
    const/16 v1, 0xc

    .line 332
    invoke-direct {v10, v7, v8, v1}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 335
    invoke-virtual {v12, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 338
    :cond_151
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 340
    const/4 v1, 0x6

    .line 341
    invoke-static {v5, v10, v12, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 344
    const/high16 v5, 0x3f800000    # 1.0f

    .line 346
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 349
    move-result-object v10

    .line 350
    iget v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$2:F

    .line 352
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 355
    move-result v16

    .line 356
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 359
    move-result-object v1

    .line 360
    if-nez v16, :cond_16b

    .line 362
    if-ne v1, v6, :cond_174

    .line 364
    :cond_16b
    new-instance v1, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda2;

    .line 366
    const/4 v6, 0x2

    .line 367
    invoke-direct {v1, v5, v6}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda2;-><init>(FB)V

    .line 370
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 373
    :cond_174
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 375
    invoke-static {v10, v1}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 378
    move-result-object v1

    .line 379
    const/4 v5, 0x0

    .line 380
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 383
    move-result-object v2

    .line 384
    iget-wide v5, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 386
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 389
    move-result v5

    .line 390
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 393
    move-result-object v6

    .line 394
    invoke-static {v12, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 397
    move-result-object v1

    .line 398
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 401
    iget-boolean v10, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 403
    if-eqz v10, :cond_198

    .line 405
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 408
    goto :goto_19b

    .line 409
    :cond_198
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 412
    :goto_19b
    invoke-static {v12, v2, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 415
    invoke-static {v12, v6, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 418
    iget-boolean v2, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 420
    if-nez v2, :cond_1b3

    .line 422
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 425
    move-result-object v2

    .line 426
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 429
    move-result-object v6

    .line 430
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 433
    move-result v2

    .line 434
    if-nez v2, :cond_1b6

    .line 436
    :cond_1b3
    invoke-static {v5, v12, v5, v11}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 439
    :cond_1b6
    invoke-static {v12, v1, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 442
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 444
    iget-object v2, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 446
    const/high16 v5, 0x3f800000    # 1.0f

    .line 448
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 451
    move-result-object v6

    .line 452
    const v13, 0x30006180

    .line 455
    const/16 v14, 0x1e0

    .line 457
    iget v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$4:F

    .line 459
    const/4 v4, 0x0

    .line 460
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$5:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 462
    move-wide v8, v7

    .line 463
    const/4 v7, 0x0

    .line 464
    move-wide v9, v8

    .line 465
    const/4 v8, 0x0

    .line 466
    move-wide v10, v9

    .line 467
    const/4 v9, 0x0

    .line 468
    move-wide/from16 v17, v10

    .line 470
    const/4 v10, 0x0

    .line 471
    const/4 v11, 0x0

    .line 472
    move-wide/from16 v19, v17

    .line 474
    invoke-static/range {v2 .. v14}, Lcom/spotifry/music/ui/listening/SunKt;->Sun(Ljava/util/List;FZLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/Modifier;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function1;Ljava/lang/String;ZLandroidx/compose/runtime/ComposerImpl;II)V

    .line 477
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 480
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 483
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 486
    new-instance v2, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;

    .line 488
    iget-boolean v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$6:Z

    .line 490
    move-wide/from16 v8, v19

    .line 492
    invoke-direct {v2, v0, v1, v8, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;-><init>(ZLcom/spotifry/music/data/spotifried/SpotifriedStats;J)V

    .line 495
    const v0, -0x452c89c7

    .line 498
    invoke-static {v0, v2, v12}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 501
    move-result-object v0

    .line 502
    const/4 v1, 0x6

    .line 503
    invoke-static {v0, v12, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 506
    goto :goto_1fd

    .line 507
    :cond_1fa
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 510
    :goto_1fd
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 512
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda43 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda43)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$2:J


# direct methods
.method public synthetic constructor <init>(ZLcom/spotifry/music/data/spotifried/SpotifriedStats;J)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$0:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 8
    iput-wide p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$2:J

    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 31

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v1, v3, 0x11

    .line 24
    const/16 v4, 0x10

    .line 26
    const/4 v5, 0x0

    .line 27
    const/4 v6, 0x1

    .line 28
    if-eq v1, v4, :cond_1f

    .line 30
    move v1, v6

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v1, v5

    .line 33
    :goto_20
    and-int/2addr v3, v6

    .line 34
    invoke-virtual {v2, v3, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_149

    .line 40
    new-instance v1, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 42
    invoke-direct {v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 45
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 47
    iget-object v3, v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 49
    iget-object v3, v3, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->label:Ljava/lang/String;

    .line 51
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 54
    move-result v4

    .line 55
    const/4 v7, 0x4

    .line 56
    const-string v8, ","

    .line 58
    if-ne v4, v7, :cond_54

    .line 60
    move v4, v5

    .line 61
    :goto_3c
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 64
    move-result v7

    .line 65
    if-ge v4, v7, :cond_4f

    .line 67
    invoke-virtual {v3, v4}, Ljava/lang/String;->charAt(I)C

    .line 70
    move-result v7

    .line 71
    invoke-static {v7}, Ljava/lang/Character;->isDigit(C)Z

    .line 74
    move-result v7

    .line 75
    if-eqz v7, :cond_54

    .line 77
    add-int/lit8 v4, v4, 0x1

    .line 79
    goto :goto_3c

    .line 80
    :cond_4f
    invoke-virtual {v3, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 83
    move-result-object v3

    .line 84
    goto :goto_92

    .line 85
    :cond_54
    const-string v4, "All time"

    .line 87
    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 90
    move-result v4

    .line 91
    if-eqz v4, :cond_5f

    .line 93
    const-string v3, "Everything,"

    .line 95
    goto :goto_92

    .line 96
    :cond_5f
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 99
    move-result v4

    .line 100
    if-lez v4, :cond_8c

    .line 102
    new-instance v4, Ljava/lang/StringBuilder;

    .line 104
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 107
    invoke-virtual {v3, v5}, Ljava/lang/String;->charAt(I)C

    .line 110
    move-result v7

    .line 111
    invoke-static {v7}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 114
    move-result-object v7

    .line 115
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 118
    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 120
    invoke-virtual {v7, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 123
    move-result-object v7

    .line 124
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 127
    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 130
    invoke-virtual {v3, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 133
    move-result-object v3

    .line 134
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 140
    move-result-object v3

    .line 141
    :cond_8c
    const-string v4, "Your "

    .line 143
    invoke-static {v4, v3, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 146
    move-result-object v3

    .line 147
    :goto_92
    invoke-virtual {v1, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 150
    const-string v3, "\nplayed\n"

    .line 152
    invoke-virtual {v1, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 155
    new-instance v7, Landroidx/compose/ui/text/SpanStyle;

    .line 157
    const/16 v25, 0x0

    .line 159
    const v26, 0xfffe

    .line 162
    iget-wide v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$2:J

    .line 164
    const-wide/16 v10, 0x0

    .line 166
    const/4 v12, 0x0

    .line 167
    const/4 v13, 0x0

    .line 168
    const/4 v14, 0x0

    .line 169
    const/4 v15, 0x0

    .line 170
    const/16 v16, 0x0

    .line 172
    const-wide/16 v17, 0x0

    .line 174
    const/16 v19, 0x0

    .line 176
    const/16 v20, 0x0

    .line 178
    const/16 v21, 0x0

    .line 180
    const-wide/16 v22, 0x0

    .line 182
    const/16 v24, 0x0

    .line 184
    invoke-direct/range {v7 .. v26}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 187
    invoke-virtual {v1, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 190
    move-result v3

    .line 191
    :try_start_be
    const-string v4, "back."

    .line 193
    invoke-virtual {v1, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_c3
    .catchall {:try_start_be .. :try_end_c3} :catchall_144

    .line 196
    invoke-virtual {v1, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 199
    invoke-virtual {v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 202
    move-result-object v1

    .line 203
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 205
    iget-boolean v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$0:Z

    .line 207
    const/16 v4, 0x36

    .line 209
    invoke-static {v3, v5, v0, v2, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 212
    move-result-object v5

    .line 213
    sget-object v19, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 215
    const/high16 v22, 0x6000000

    .line 217
    const v23, 0x3fffc

    .line 220
    move-object v8, v3

    .line 221
    move v7, v4

    .line 222
    move-object v3, v5

    .line 223
    const-wide/16 v4, 0x0

    .line 225
    move v9, v7

    .line 226
    const-wide/16 v6, 0x0

    .line 228
    move-object v11, v8

    .line 229
    const/4 v8, 0x0

    .line 230
    move v12, v9

    .line 231
    const-wide/16 v9, 0x0

    .line 233
    move-object v15, v11

    .line 234
    move v14, v12

    .line 235
    const-wide/16 v11, 0x0

    .line 237
    const/4 v13, 0x0

    .line 238
    move/from16 v17, v14

    .line 240
    const/4 v14, 0x0

    .line 241
    move-object/from16 v18, v15

    .line 243
    const/4 v15, 0x0

    .line 244
    const/16 v16, 0x0

    .line 246
    move/from16 v21, v17

    .line 248
    const/16 v17, 0x0

    .line 250
    move-object/from16 v24, v18

    .line 252
    const/16 v18, 0x0

    .line 254
    move/from16 v25, v21

    .line 256
    const/16 v21, 0x0

    .line 258
    move-object/from16 v20, v2

    .line 260
    move-object v2, v1

    .line 261
    move/from16 v1, v25

    .line 263
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 266
    move-object/from16 v2, v20

    .line 268
    const/4 v11, 0x0

    .line 269
    const/16 v12, 0xd

    .line 271
    const/4 v8, 0x0

    .line 272
    const/high16 v9, 0x41600000    # 14.0f

    .line 274
    const/4 v10, 0x0

    .line 275
    move-object/from16 v7, v24

    .line 277
    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 280
    move-result-object v3

    .line 281
    const/4 v13, 0x1

    .line 282
    invoke-static {v3, v13, v0, v2, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 285
    move-result-object v3

    .line 286
    invoke-static {v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 289
    move-result-wide v4

    .line 290
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 292
    const/high16 v24, 0xc00000

    .line 294
    const v25, 0x1fff8

    .line 297
    const-string v2, "Tap to start. This one is about you."

    .line 299
    const-wide/16 v6, 0x0

    .line 301
    const/4 v8, 0x0

    .line 302
    const/4 v9, 0x0

    .line 303
    const/4 v10, 0x0

    .line 304
    const-wide/16 v11, 0x0

    .line 306
    const/4 v13, 0x0

    .line 307
    const-wide/16 v14, 0x0

    .line 309
    const/16 v17, 0x0

    .line 311
    const/16 v18, 0x0

    .line 313
    const/16 v19, 0x0

    .line 315
    move-object/from16 v22, v20

    .line 317
    const/16 v20, 0x0

    .line 319
    const/16 v23, 0x6

    .line 321
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 324
    goto :goto_14e

    .line 325
    :catchall_144
    move-exception v0

    .line 326
    invoke-virtual {v1, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 329
    throw v0

    .line 330
    :cond_149
    move-object/from16 v20, v2

    .line 332
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 335
    :goto_14e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 337
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda27 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda27)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/spotifry/music/data/TopSong;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$3:J

.field public final synthetic f$4:Landroidx/compose/foundation/shape/RoundedCornerShape;

.field public final synthetic f$5:Lcom/spotifry/music/ui/spotifried/CountUp;


# direct methods
.method public synthetic constructor <init>(ZLcom/spotifry/music/data/TopSong;Landroidx/compose/runtime/MutableState;JLandroidx/compose/foundation/shape/RoundedCornerShape;Lcom/spotifry/music/ui/spotifried/CountUp;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$0:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$1:Lcom/spotifry/music/data/TopSong;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$2:Landroidx/compose/runtime/MutableState;

    .line 10
    iput-wide p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$3:J

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$4:Landroidx/compose/foundation/shape/RoundedCornerShape;

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$5:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 72

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v9, p2

    .line 9
    check-cast v9, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    const/4 v4, 0x2

    .line 25
    if-nez v3, :cond_24

    .line 27
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_22

    .line 33
    const/4 v3, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v3, v4

    .line 36
    :goto_23
    or-int/2addr v2, v3

    .line 37
    :cond_24
    and-int/lit8 v3, v2, 0x13

    .line 39
    const/16 v5, 0x12

    .line 41
    const/4 v6, 0x0

    .line 42
    const/4 v7, 0x1

    .line 43
    if-eq v3, v5, :cond_2e

    .line 45
    move v3, v7

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v3, v6

    .line 48
    :goto_2f
    and-int/2addr v2, v7

    .line 49
    invoke-virtual {v9, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_42d

    .line 55
    const/high16 v2, 0x3f800000    # 1.0f

    .line 57
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 60
    move-result-object v1

    .line 61
    sget-object v3, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 63
    sget-object v5, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 65
    invoke-static {v3, v5, v9, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 68
    move-result-object v3

    .line 69
    iget-wide v10, v9, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 71
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 74
    move-result v5

    .line 75
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 78
    move-result-object v8

    .line 79
    invoke-static {v9, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 82
    move-result-object v1

    .line 83
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 85
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 88
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 90
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 93
    iget-boolean v11, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 95
    if-eqz v11, :cond_64

    .line 97
    invoke-virtual {v9, v10}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 100
    goto :goto_67

    .line 101
    :cond_64
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 104
    :goto_67
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 106
    invoke-static {v9, v3, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 109
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 111
    invoke-static {v9, v8, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 114
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 116
    iget-boolean v12, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 118
    if-nez v12, :cond_85

    .line 120
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 123
    move-result-object v12

    .line 124
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 127
    move-result-object v13

    .line 128
    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 131
    move-result v12

    .line 132
    if-nez v12, :cond_88

    .line 134
    :cond_85
    invoke-static {v5, v9, v5, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 137
    :cond_88
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 139
    invoke-static {v9, v1, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 142
    sget-object v1, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 144
    iget-boolean v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$0:Z

    .line 146
    const/16 v13, 0x36

    .line 148
    move-object v14, v3

    .line 149
    invoke-static {v1, v6, v12, v9, v13}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 152
    move-result-object v3

    .line 153
    sget-object v15, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 155
    const/16 v16, 0x26

    .line 157
    invoke-static/range {v16 .. v16}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 160
    move-result-wide v18

    .line 161
    const/16 v16, 0x25

    .line 163
    invoke-static/range {v16 .. v16}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 166
    move-result-wide v26

    .line 167
    const-wide v16, -0x400b333333333333L    # -1.3

    .line 172
    invoke-static/range {v16 .. v17}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 175
    move-result-wide v23

    .line 176
    const/16 v29, 0x0

    .line 178
    const v30, 0xfdff7d

    .line 181
    const-wide/16 v16, 0x0

    .line 183
    const/16 v20, 0x0

    .line 185
    const/16 v21, 0x0

    .line 187
    const/16 v22, 0x0

    .line 189
    const/16 v25, 0x0

    .line 191
    const/16 v28, 0x0

    .line 193
    invoke-static/range {v15 .. v30}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 196
    move-result-object v21

    .line 197
    const/16 v24, 0x6180

    .line 199
    const v25, 0x1affc

    .line 202
    move v15, v2

    .line 203
    const-string v2, "You couldn\'t leave this one alone."

    .line 205
    move-object/from16 v16, v5

    .line 207
    const-wide/16 v4, 0x0

    .line 209
    move/from16 v18, v6

    .line 211
    const-wide/16 v6, 0x0

    .line 213
    move-object/from16 v20, v8

    .line 215
    const/4 v8, 0x0

    .line 216
    move-object/from16 v22, v9

    .line 218
    const/4 v9, 0x0

    .line 219
    move-object/from16 v23, v10

    .line 221
    const/4 v10, 0x0

    .line 222
    move-object/from16 v26, v11

    .line 224
    move/from16 v27, v12

    .line 226
    const-wide/16 v11, 0x0

    .line 228
    const/4 v13, 0x0

    .line 229
    move-object/from16 v29, v14

    .line 231
    move/from16 v30, v15

    .line 233
    const-wide/16 v14, 0x0

    .line 235
    move-object/from16 v31, v16

    .line 237
    const/16 v16, 0x2

    .line 239
    const/16 v17, 0x0

    .line 241
    move/from16 v33, v18

    .line 243
    const/16 v18, 0x3

    .line 245
    const/16 v19, 0x0

    .line 247
    move-object/from16 v35, v20

    .line 249
    const/16 v20, 0x0

    .line 251
    move-object/from16 v36, v23

    .line 253
    const/16 v23, 0x6

    .line 255
    move-object/from16 p1, v1

    .line 257
    move-object/from16 v37, v26

    .line 259
    move-object/from16 v38, v29

    .line 261
    move/from16 v1, v30

    .line 263
    move-object/from16 v40, v31

    .line 265
    move/from16 v0, v33

    .line 267
    move-object/from16 v39, v35

    .line 269
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 272
    move-object/from16 v9, v22

    .line 274
    sget-object v2, Landroidx/compose/ui/Alignment$Companion;->CenterHorizontally:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 276
    new-instance v3, Landroidx/compose/foundation/layout/HorizontalAlignElement;

    .line 278
    invoke-direct {v3, v2}, Landroidx/compose/foundation/layout/HorizontalAlignElement;-><init>(Landroidx/compose/ui/BiasAlignment$Horizontal;)V

    .line 281
    const/4 v7, 0x0

    .line 282
    const/16 v8, 0xd

    .line 284
    const/4 v4, 0x0

    .line 285
    const/high16 v14, 0x41a00000    # 20.0f

    .line 287
    const/4 v6, 0x0

    .line 288
    move v5, v14

    .line 289
    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 292
    move-result-object v2

    .line 293
    new-instance v3, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 295
    invoke-direct {v3, v1, v0}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 298
    invoke-interface {v2, v3}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 301
    move-result-object v2

    .line 302
    const/high16 v3, 0x43960000    # 300.0f

    .line 304
    const/4 v12, 0x1

    .line 305
    invoke-static {v2, v3, v12}, Landroidx/compose/foundation/layout/SizeKt;->widthIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FI)Landroidx/compose/ui/Modifier;

    .line 308
    move-result-object v2

    .line 309
    invoke-static {v2, v1, v12}, Landroidx/compose/foundation/layout/OffsetKt;->aspectRatio(Landroidx/compose/ui/Modifier;FZ)Landroidx/compose/ui/Modifier;

    .line 312
    move-result-object v2

    .line 313
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 316
    move-result-object v3

    .line 317
    sget-object v13, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 319
    if-ne v3, v13, :cond_14f

    .line 321
    new-instance v3, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda30;

    .line 323
    const/16 v4, 0x1c

    .line 325
    move-object/from16 v15, p0

    .line 327
    iget-object v5, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$2:Landroidx/compose/runtime/MutableState;

    .line 329
    invoke-direct {v3, v5, v4}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda30;-><init>(Landroidx/compose/runtime/MutableState;B)V

    .line 332
    invoke-virtual {v9, v3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 335
    goto :goto_151

    .line 336
    :cond_14f
    move-object/from16 v15, p0

    .line 338
    :goto_151
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 340
    invoke-static {v2, v3}, Landroidx/compose/ui/layout/RulerKt;->onPlaced(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 343
    move-result-object v2

    .line 344
    const-string v3, "top_cover"

    .line 346
    invoke-static {v2, v3}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 349
    move-result-object v2

    .line 350
    const/16 v3, 0x30

    .line 352
    move/from16 v4, v27

    .line 354
    invoke-static {v2, v12, v4, v9, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 357
    move-result-object v2

    .line 358
    sget-object v3, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 360
    invoke-static {v3, v0}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 363
    move-result-object v3

    .line 364
    iget-wide v5, v9, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 366
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 369
    move-result v5

    .line 370
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 373
    move-result-object v6

    .line 374
    invoke-static {v9, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 377
    move-result-object v2

    .line 378
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 381
    iget-boolean v7, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 383
    if-eqz v7, :cond_188

    .line 385
    move-object/from16 v7, v36

    .line 387
    invoke-virtual {v9, v7}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 390
    :goto_185
    move-object/from16 v8, v37

    .line 392
    goto :goto_18e

    .line 393
    :cond_188
    move-object/from16 v7, v36

    .line 395
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 398
    goto :goto_185

    .line 399
    :goto_18e
    invoke-static {v9, v3, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 402
    move-object/from16 v3, v38

    .line 404
    invoke-static {v9, v6, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 407
    iget-boolean v6, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 409
    if-nez v6, :cond_1ad

    .line 411
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 414
    move-result-object v6

    .line 415
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 418
    move-result-object v10

    .line 419
    invoke-static {v6, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 422
    move-result v6

    .line 423
    if-eqz v6, :cond_1ad

    .line 425
    move-object/from16 v6, v39

    .line 427
    :goto_1aa
    move-object/from16 v5, v40

    .line 429
    goto :goto_1b3

    .line 430
    :cond_1ad
    move-object/from16 v6, v39

    .line 432
    invoke-static {v5, v9, v5, v6}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 435
    goto :goto_1aa

    .line 436
    :goto_1b3
    invoke-static {v9, v2, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 439
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 441
    const/16 v10, 0x1f

    .line 443
    const/4 v11, 0x3

    .line 444
    move-object/from16 p3, v13

    .line 446
    iget-wide v13, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$3:J

    .line 448
    move-object/from16 v35, v6

    .line 450
    iget-object v6, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$4:Landroidx/compose/foundation/shape/RoundedCornerShape;

    .line 452
    if-lt v2, v10, :cond_1f9

    .line 454
    const v2, 0x4572055b

    .line 457
    invoke-virtual {v9, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 460
    sget-object v2, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    .line 462
    invoke-virtual {v2}, Landroidx/compose/foundation/layout/BoxScopeInstance;->matchParentSize()Landroidx/compose/ui/Modifier;

    .line 465
    move-result-object v2

    .line 466
    const/high16 v10, 0x41c00000    # 24.0f

    .line 468
    const/4 v1, 0x0

    .line 469
    invoke-static {v2, v1, v10, v12}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 472
    move-result-object v1

    .line 473
    const/high16 v2, 0x41900000    # 18.0f

    .line 475
    invoke-static {v1, v2, v2}, Landroidx/compose/foundation/layout/OffsetKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    .line 478
    move-result-object v1

    .line 479
    new-instance v2, Landroidx/compose/ui/draw/BlurKt$blur$1;

    .line 481
    invoke-direct {v2, v11, v0}, Landroidx/compose/ui/draw/BlurKt$blur$1;-><init>(IZ)V

    .line 484
    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 487
    move-result-object v1

    .line 488
    const v2, 0x3ee66666    # 0.45f

    .line 491
    invoke-static {v2, v13, v14}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 494
    move-result-wide v11

    .line 495
    invoke-static {v1, v11, v12, v6}, Landroidx/compose/foundation/ImageKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    .line 498
    move-result-object v1

    .line 499
    invoke-static {v1, v9, v0}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 502
    :goto_1f5
    invoke-virtual {v9, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 505
    goto :goto_200

    .line 506
    :cond_1f9
    const v1, 0x67d0bbdf

    .line 509
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 512
    goto :goto_1f5

    .line 513
    :goto_200
    iget-object v0, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$1:Lcom/spotifry/music/data/TopSong;

    .line 515
    iget-object v1, v0, Lcom/spotifry/music/data/TopSong;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 517
    iget-object v2, v1, Lcom/spotifry/music/data/db/SongEntity;->id:Ljava/lang/String;

    .line 519
    move-object/from16 v29, v3

    .line 521
    iget-object v3, v1, Lcom/spotifry/music/data/db/SongEntity;->thumbnailUrl:Ljava/lang/String;

    .line 523
    move/from16 v27, v4

    .line 525
    iget-object v4, v1, Lcom/spotifry/music/data/db/SongEntity;->thumbPath:Ljava/lang/String;

    .line 527
    move-object/from16 v12, p1

    .line 529
    const/high16 v11, 0x3f800000    # 1.0f

    .line 531
    invoke-static {v12, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 534
    move-result-object v11

    .line 535
    const/16 v10, 0xc00

    .line 537
    move-object/from16 v31, v5

    .line 539
    move-object v5, v11

    .line 540
    const/16 v11, 0x60

    .line 542
    move-object/from16 v36, v7

    .line 544
    const/4 v7, 0x0

    .line 545
    move-object/from16 v37, v8

    .line 547
    const/4 v8, 0x0

    .line 548
    move/from16 v49, v27

    .line 550
    move-object/from16 v46, v29

    .line 552
    move-object/from16 v48, v31

    .line 554
    move-object/from16 v47, v35

    .line 556
    move-object/from16 v44, v36

    .line 558
    move-object/from16 v45, v37

    .line 560
    invoke-static/range {v2 .. v11}, Lcom/spotifry/music/ui/components/CoverKt;->CoverArt(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;ZZLandroidx/compose/runtime/ComposerImpl;II)V

    .line 563
    const/4 v2, 0x1

    .line 564
    invoke-virtual {v9, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 567
    iget-object v2, v1, Lcom/spotifry/music/data/db/SongEntity;->title:Ljava/lang/String;

    .line 569
    const/16 v16, 0x0

    .line 571
    const/16 v17, 0xd

    .line 573
    move-wide v4, v13

    .line 574
    const/4 v13, 0x0

    .line 575
    const/4 v15, 0x0

    .line 576
    move-object/from16 v3, p3

    .line 578
    move-wide/from16 v26, v4

    .line 580
    const/high16 v14, 0x41a00000    # 20.0f

    .line 582
    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 585
    move-result-object v4

    .line 586
    move-object/from16 v28, v12

    .line 588
    move/from16 v5, v49

    .line 590
    const/4 v6, 0x2

    .line 591
    const/16 v7, 0x36

    .line 593
    invoke-static {v4, v6, v5, v9, v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 596
    move-result-object v4

    .line 597
    sget-object v35, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 599
    sget-object v34, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 601
    const/16 v8, 0x1a

    .line 603
    invoke-static {v8}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 606
    move-result-wide v32

    .line 607
    const/16 v8, 0x1b

    .line 609
    invoke-static {v8}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 612
    move-result-wide v39

    .line 613
    const-wide v10, -0x401b333333333333L    # -0.65

    .line 618
    invoke-static {v10, v11}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 621
    move-result-wide v36

    .line 622
    new-instance v29, Landroidx/compose/ui/text/TextStyle;

    .line 624
    const/16 v41, 0x0

    .line 626
    const v42, 0xfdff59

    .line 629
    const-wide/16 v30, 0x0

    .line 631
    const/16 v38, 0x0

    .line 633
    invoke-direct/range {v29 .. v42}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 636
    const/16 v24, 0x6180

    .line 638
    const v25, 0x1affc

    .line 641
    move-object v8, v3

    .line 642
    move-object v3, v4

    .line 643
    const-wide/16 v4, 0x0

    .line 645
    const-wide/16 v6, 0x0

    .line 647
    move-object v10, v8

    .line 648
    const/4 v8, 0x0

    .line 649
    move-object/from16 v22, v9

    .line 651
    const/4 v9, 0x0

    .line 652
    move-object v11, v10

    .line 653
    const/4 v10, 0x0

    .line 654
    move-object v13, v11

    .line 655
    const-wide/16 v11, 0x0

    .line 657
    move-object v14, v13

    .line 658
    const/4 v13, 0x0

    .line 659
    move-object/from16 v16, v14

    .line 661
    const-wide/16 v14, 0x0

    .line 663
    move-object/from16 v17, v16

    .line 665
    const/16 v16, 0x2

    .line 667
    move-object/from16 v18, v17

    .line 669
    const/16 v17, 0x0

    .line 671
    move-object/from16 v20, v18

    .line 673
    const/16 v18, 0x2

    .line 675
    const/16 v19, 0x0

    .line 677
    move-object/from16 v21, v20

    .line 679
    const/16 v20, 0x0

    .line 681
    const/16 v23, 0x0

    .line 683
    move-object/from16 v43, v0

    .line 685
    move-object/from16 v50, v21

    .line 687
    move-object/from16 v21, v29

    .line 689
    move/from16 v0, v49

    .line 691
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 694
    move-object/from16 v9, v22

    .line 696
    iget-object v1, v1, Lcom/spotifry/music/data/db/SongEntity;->artist:Ljava/lang/String;

    .line 698
    invoke-static {v1}, Lcom/spotifry/music/data/Log;->cleanArtist(Ljava/lang/String;)Ljava/lang/String;

    .line 701
    move-result-object v2

    .line 702
    const/16 v16, 0x0

    .line 704
    const/16 v17, 0xd

    .line 706
    const/4 v13, 0x0

    .line 707
    const/high16 v14, 0x40800000    # 4.0f

    .line 709
    const/4 v15, 0x0

    .line 710
    move-object/from16 v12, v28

    .line 712
    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 715
    move-result-object v1

    .line 716
    const/16 v3, 0x36

    .line 718
    const/4 v6, 0x2

    .line 719
    invoke-static {v1, v6, v0, v9, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 722
    move-result-object v1

    .line 723
    invoke-static {v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 726
    move-result-wide v4

    .line 727
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 729
    const/16 v6, 0xe

    .line 731
    invoke-static {v6}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 734
    move-result-wide v54

    .line 735
    const/16 v65, 0x0

    .line 737
    const v66, 0xfffffd

    .line 740
    const-wide/16 v52, 0x0

    .line 742
    const/16 v56, 0x0

    .line 744
    const/16 v57, 0x0

    .line 746
    const/16 v58, 0x0

    .line 748
    const-wide/16 v59, 0x0

    .line 750
    const/16 v61, 0x0

    .line 752
    const-wide/16 v62, 0x0

    .line 754
    const/16 v64, 0x0

    .line 756
    move-object/from16 v51, v21

    .line 758
    invoke-static/range {v51 .. v66}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 761
    move-result-object v21

    .line 762
    const v25, 0x1aff8

    .line 765
    const-wide/16 v6, 0x0

    .line 767
    const/4 v9, 0x0

    .line 768
    const-wide/16 v11, 0x0

    .line 770
    const/4 v13, 0x0

    .line 771
    const-wide/16 v14, 0x0

    .line 773
    const/16 v16, 0x2

    .line 775
    const/16 v17, 0x0

    .line 777
    const/16 v18, 0x1

    .line 779
    move/from16 v67, v3

    .line 781
    move-object v3, v1

    .line 782
    move/from16 v1, v67

    .line 784
    move-object/from16 v67, v28

    .line 786
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 789
    move-object/from16 v9, v22

    .line 791
    const/4 v2, 0x1

    .line 792
    invoke-virtual {v9, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 795
    move-object/from16 v12, v67

    .line 797
    const/4 v10, 0x3

    .line 798
    invoke-static {v12, v10, v0, v9, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 801
    move-result-object v0

    .line 802
    new-instance v1, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 804
    new-instance v3, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 806
    invoke-direct {v3, v10}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 809
    const/high16 v4, 0x41000000    # 8.0f

    .line 811
    invoke-direct {v1, v4, v3}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 814
    sget-object v3, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 816
    const/4 v4, 0x6

    .line 817
    invoke-static {v1, v3, v9, v4}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 820
    move-result-object v1

    .line 821
    iget-wide v3, v9, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 823
    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    .line 826
    move-result v3

    .line 827
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 830
    move-result-object v4

    .line 831
    invoke-static {v9, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 834
    move-result-object v0

    .line 835
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 838
    iget-boolean v5, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 840
    if-eqz v5, :cond_351

    .line 842
    move-object/from16 v7, v44

    .line 844
    invoke-virtual {v9, v7}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 847
    :goto_34e
    move-object/from16 v8, v45

    .line 849
    goto :goto_355

    .line 850
    :cond_351
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 853
    goto :goto_34e

    .line 854
    :goto_355
    invoke-static {v9, v1, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 857
    move-object/from16 v14, v46

    .line 859
    invoke-static {v9, v4, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 862
    iget-boolean v1, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 864
    if-nez v1, :cond_372

    .line 866
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 869
    move-result-object v1

    .line 870
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 873
    move-result-object v4

    .line 874
    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 877
    move-result v1

    .line 878
    if-eqz v1, :cond_372

    .line 880
    :goto_36f
    move-object/from16 v5, v48

    .line 882
    goto :goto_378

    .line 883
    :cond_372
    move-object/from16 v6, v47

    .line 885
    invoke-static {v3, v9, v3, v6}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 888
    goto :goto_36f

    .line 889
    :goto_378
    invoke-static {v9, v0, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 892
    move-object/from16 v15, p0

    .line 894
    iget-object v0, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$5:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 896
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CountUp;->text:Ljava/lang/String;

    .line 898
    sget-object v3, Landroidx/compose/ui/layout/AlignmentLineKt;->FirstBaseline:Landroidx/compose/ui/layout/HorizontalAlignmentLine;

    .line 900
    new-instance v4, Landroidx/compose/foundation/layout/WithAlignmentLineElement;

    .line 902
    invoke-direct {v4, v3}, Landroidx/compose/foundation/layout/WithAlignmentLineElement;-><init>(Landroidx/compose/ui/layout/HorizontalAlignmentLine;)V

    .line 905
    invoke-virtual {v9, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 908
    move-result v5

    .line 909
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 912
    move-result-object v6

    .line 913
    if-nez v5, :cond_396

    .line 915
    move-object/from16 v8, v50

    .line 917
    if-ne v6, v8, :cond_39e

    .line 919
    :cond_396
    new-instance v6, Lkotlin/collections/AbstractMap$$ExternalSyntheticLambda0;

    .line 921
    invoke-direct {v6, v0, v2}, Lkotlin/collections/AbstractMap$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;B)V

    .line 924
    invoke-virtual {v9, v6}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 927
    :cond_39e
    check-cast v6, Lkotlin/jvm/functions/Function1;

    .line 929
    invoke-static {v4, v6}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 932
    move-result-object v0

    .line 933
    sget-object v34, Landroidx/compose/ui/text/font/FontWeight;->Black:Landroidx/compose/ui/text/font/FontWeight;

    .line 935
    const/16 v4, 0x40

    .line 937
    invoke-static {v4}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 940
    move-result-wide v32

    .line 941
    const/16 v4, 0x3a

    .line 943
    invoke-static {v4}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 946
    move-result-wide v39

    .line 947
    const-wide v4, -0x3ff6666666666666L    # -3.2

    .line 952
    invoke-static {v4, v5}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 955
    move-result-wide v36

    .line 956
    new-instance v29, Landroidx/compose/ui/text/TextStyle;

    .line 958
    const/16 v41, 0x0

    .line 960
    const v42, 0xfdff19

    .line 963
    const-wide/16 v30, 0x0

    .line 965
    const/16 v38, 0x0

    .line 967
    invoke-direct/range {v29 .. v42}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 970
    const/16 v24, 0x0

    .line 972
    const v25, 0x1fff8

    .line 975
    const-wide/16 v6, 0x0

    .line 977
    const/4 v8, 0x0

    .line 978
    move-object/from16 v22, v9

    .line 980
    const/4 v9, 0x0

    .line 981
    const/4 v10, 0x0

    .line 982
    const-wide/16 v11, 0x0

    .line 984
    const/4 v13, 0x0

    .line 985
    const-wide/16 v14, 0x0

    .line 987
    const/16 v16, 0x0

    .line 989
    const/16 v17, 0x0

    .line 991
    const/16 v18, 0x0

    .line 993
    const/16 v19, 0x0

    .line 995
    const/16 v20, 0x0

    .line 997
    const/16 v23, 0x0

    .line 999
    move-object v4, v3

    .line 1000
    move-object v3, v0

    .line 1001
    move-object v0, v4

    .line 1002
    move v4, v2

    .line 1003
    move-object v2, v1

    .line 1004
    move v1, v4

    .line 1005
    move-wide/from16 v4, v26

    .line 1007
    move-object/from16 v21, v29

    .line 1009
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1012
    move-object/from16 v2, v43

    .line 1014
    iget v2, v2, Lcom/spotifry/music/data/TopSong;->plays:I

    .line 1016
    if-ne v2, v1, :cond_3fc

    .line 1018
    const-string v2, "play"

    .line 1020
    goto :goto_3fe

    .line 1021
    :cond_3fc
    const-string v2, "plays"

    .line 1023
    :goto_3fe
    new-instance v3, Landroidx/compose/foundation/layout/WithAlignmentLineElement;

    .line 1025
    invoke-direct {v3, v0}, Landroidx/compose/foundation/layout/WithAlignmentLineElement;-><init>(Landroidx/compose/ui/layout/HorizontalAlignmentLine;)V

    .line 1028
    invoke-static/range {v22 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 1031
    move-result-wide v4

    .line 1032
    const/high16 v24, 0xc00000

    .line 1034
    const v25, 0x1fff8

    .line 1037
    const-wide/16 v6, 0x0

    .line 1039
    const/4 v8, 0x0

    .line 1040
    const/4 v9, 0x0

    .line 1041
    const/4 v10, 0x0

    .line 1042
    const-wide/16 v11, 0x0

    .line 1044
    const/4 v13, 0x0

    .line 1045
    const-wide/16 v14, 0x0

    .line 1047
    const/16 v16, 0x0

    .line 1049
    const/16 v17, 0x0

    .line 1051
    const/16 v18, 0x0

    .line 1053
    const/16 v19, 0x0

    .line 1055
    const/16 v20, 0x0

    .line 1057
    const/16 v23, 0x0

    .line 1059
    move-object/from16 v21, v51

    .line 1061
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1064
    move-object/from16 v9, v22

    .line 1066
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1069
    goto :goto_430

    .line 1070
    :cond_42d
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 1073
    :goto_430
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1075
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda29 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda29)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:J

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$4:Z

.field public final synthetic f$5:F

.field public final synthetic f$6:J

.field public final synthetic f$7:Ljava/time/format/DateTimeFormatter;

.field public final synthetic f$8:Z


# direct methods
.method public synthetic constructor <init>(ZJLjava/util/List;Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZFJLjava/time/format/DateTimeFormatter;Z)V
    .registers 12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$0:Z

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$2:Ljava/util/List;

    .line 10
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 12
    iput-boolean p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$4:Z

    .line 14
    iput p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$5:F

    .line 16
    iput-wide p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$6:J

    .line 18
    iput-object p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$7:Ljava/time/format/DateTimeFormatter;

    .line 20
    iput-boolean p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$8:Z

    .line 22
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 30

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    if-nez v3, :cond_23

    .line 26
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_21

    .line 32
    const/4 v3, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v3, 0x2

    .line 35
    :goto_22
    or-int/2addr v2, v3

    .line 36
    :cond_23
    and-int/lit8 v3, v2, 0x13

    .line 38
    const/16 v4, 0x12

    .line 40
    const/4 v6, 0x1

    .line 41
    if-eq v3, v4, :cond_2c

    .line 43
    move v3, v6

    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    const/4 v3, 0x0

    .line 46
    :goto_2d
    and-int/2addr v2, v6

    .line 47
    invoke-virtual {v5, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 50
    move-result v2

    .line 51
    if-eqz v2, :cond_d6

    .line 53
    new-instance v2, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 55
    invoke-direct {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 58
    iget-boolean v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$0:Z

    .line 60
    if-eqz v3, :cond_40

    .line 62
    const-string v3, "Your year,\n"

    .line 64
    goto :goto_42

    .line 65
    :cond_40
    const-string v3, "Your months,\n"

    .line 67
    :goto_42
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 70
    new-instance v6, Landroidx/compose/ui/text/SpanStyle;

    .line 72
    const/16 v24, 0x0

    .line 74
    const v25, 0xfffe

    .line 77
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$1:J

    .line 79
    const-wide/16 v9, 0x0

    .line 81
    const/4 v11, 0x0

    .line 82
    const/4 v12, 0x0

    .line 83
    const/4 v13, 0x0

    .line 84
    const/4 v14, 0x0

    .line 85
    const/4 v15, 0x0

    .line 86
    const-wide/16 v16, 0x0

    .line 88
    const/16 v18, 0x0

    .line 90
    const/16 v19, 0x0

    .line 92
    const/16 v20, 0x0

    .line 94
    const-wide/16 v21, 0x0

    .line 96
    const/16 v23, 0x0

    .line 98
    invoke-direct/range {v6 .. v25}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 101
    move-wide/from16 v24, v7

    .line 103
    invoke-virtual {v2, v6}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 106
    move-result v3

    .line 107
    :try_start_6a
    const-string v4, "in order."

    .line 109
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_6f
    .catchall {:try_start_6a .. :try_end_6f} :catchall_d1

    .line 112
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 115
    invoke-virtual {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 118
    move-result-object v2

    .line 119
    sget-object v19, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 121
    const/high16 v22, 0x6000000

    .line 123
    const v23, 0x3fffe

    .line 126
    const/4 v3, 0x0

    .line 127
    move-object/from16 v20, v5

    .line 129
    const-wide/16 v4, 0x0

    .line 131
    const-wide/16 v6, 0x0

    .line 133
    const/4 v8, 0x0

    .line 134
    const-wide/16 v9, 0x0

    .line 136
    const-wide/16 v11, 0x0

    .line 138
    const/4 v13, 0x0

    .line 139
    const/4 v14, 0x0

    .line 140
    const/4 v15, 0x0

    .line 141
    const/16 v16, 0x0

    .line 143
    const/16 v17, 0x0

    .line 145
    const/16 v18, 0x0

    .line 147
    const/16 v21, 0x0

    .line 149
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 152
    move-object/from16 v5, v20

    .line 154
    const/high16 v2, 0x3f800000    # 1.0f

    .line 156
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 159
    move-result-object v1

    .line 160
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 163
    move-result-object v6

    .line 164
    const/4 v10, 0x0

    .line 165
    const/16 v11, 0xd

    .line 167
    const/4 v7, 0x0

    .line 168
    const/high16 v8, 0x41b00000    # 22.0f

    .line 170
    const/4 v9, 0x0

    .line 171
    invoke-static/range {v6 .. v11}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 174
    move-result-object v2

    .line 175
    new-instance v7, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;

    .line 177
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$2:Ljava/util/List;

    .line 179
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 181
    iget-boolean v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$4:Z

    .line 183
    iget v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$5:F

    .line 185
    iget-wide v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$6:J

    .line 187
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$7:Ljava/time/format/DateTimeFormatter;

    .line 189
    iget-boolean v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$8:Z

    .line 191
    move-wide/from16 v16, v24

    .line 193
    invoke-direct/range {v7 .. v17}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;-><init>(Ljava/util/List;Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZFJLjava/time/format/DateTimeFormatter;ZJ)V

    .line 196
    const v0, -0x774a7cf6

    .line 199
    invoke-static {v0, v7, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 202
    move-result-object v4

    .line 203
    const/16 v6, 0xc00

    .line 205
    const/4 v7, 0x6

    .line 206
    invoke-static/range {v2 .. v7}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 209
    goto :goto_db

    .line 210
    :catchall_d1
    move-exception v0

    .line 211
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 214
    throw v0

    .line 215
    :cond_d6
    move-object/from16 v20, v5

    .line 217
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 220
    :goto_db
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 222
    return-object v0
.end method

###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda46 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda46)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$2:Z

.field public final synthetic f$3:F

.field public final synthetic f$4:J

.field public final synthetic f$5:Ljava/time/format/DateTimeFormatter;

.field public final synthetic f$6:Z

.field public final synthetic f$7:J


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZFJLjava/time/format/DateTimeFormatter;ZJ)V
    .registers 11

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$0:Ljava/util/List;

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 8
    iput-boolean p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$2:Z

    .line 10
    iput p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$3:F

    .line 12
    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$4:J

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$5:Ljava/time/format/DateTimeFormatter;

    .line 16
    iput-boolean p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$6:Z

    .line 18
    iput-wide p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$7:J

    .line 20
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 55

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 24
    const/4 v5, 0x2

    .line 25
    if-nez v4, :cond_24

    .line 27
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v4

    .line 31
    if-eqz v4, :cond_22

    .line 33
    const/4 v4, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v4, v5

    .line 36
    :goto_23
    or-int/2addr v3, v4

    .line 37
    :cond_24
    and-int/lit8 v4, v3, 0x13

    .line 39
    const/16 v6, 0x12

    .line 41
    const/4 v7, 0x0

    .line 42
    const/4 v8, 0x1

    .line 43
    if-eq v4, v6, :cond_2e

    .line 45
    move v4, v8

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v4, v7

    .line 48
    :goto_2f
    and-int/2addr v3, v8

    .line 49
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v3

    .line 53
    if-eqz v3, :cond_318

    .line 55
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 58
    move-result v1

    .line 59
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$0:Ljava/util/List;

    .line 61
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 64
    move-result v4

    .line 65
    int-to-float v4, v4

    .line 66
    div-float/2addr v1, v4

    .line 67
    new-instance v4, Landroidx/compose/ui/unit/Dp;

    .line 69
    invoke-direct {v4, v1}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 72
    new-instance v1, Landroidx/compose/ui/unit/Dp;

    .line 74
    const/high16 v6, 0x42900000    # 72.0f

    .line 76
    invoke-direct {v1, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 79
    invoke-virtual {v4, v1}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 82
    move-result v6

    .line 83
    if-lez v6, :cond_55

    .line 85
    move-object v4, v1

    .line 86
    :cond_55
    sget-object v15, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 88
    sget-object v14, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 90
    const v1, 0x3ee66666    # 0.45f

    .line 93
    iget v4, v4, Landroidx/compose/ui/unit/Dp;->value:F

    .line 95
    mul-float/2addr v1, v4

    .line 96
    const/high16 v6, 0x41b00000    # 22.0f

    .line 98
    const/high16 v9, 0x41400000    # 12.0f

    .line 100
    invoke-static {v1, v9, v6}, Lkotlin/ResultKt;->coerceIn(FFF)F

    .line 103
    move-result v1

    .line 104
    const-wide v10, 0x100000000L

    .line 109
    invoke-static {v1, v10, v11}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 112
    move-result-wide v12

    .line 113
    const-wide v10, -0x402ccccccccccccdL    # -0.3

    .line 118
    invoke-static {v10, v11}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 121
    move-result-wide v16

    .line 122
    new-instance v21, Landroidx/compose/ui/text/TextStyle;

    .line 124
    move v1, v9

    .line 125
    move-object/from16 v9, v21

    .line 127
    const/16 v21, 0x0

    .line 129
    const v22, 0xffff59

    .line 132
    const-wide/16 v10, 0x0

    .line 134
    const/16 v18, 0x0

    .line 136
    const-wide/16 v19, 0x0

    .line 138
    invoke-direct/range {v9 .. v22}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 141
    move-object/from16 v26, v9

    .line 143
    sget-object v9, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 145
    const/16 v6, 0xc

    .line 147
    invoke-static {v6}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 150
    move-result-wide v12

    .line 151
    const/16 v6, 0xe

    .line 153
    invoke-static {v6}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 156
    move-result-wide v20

    .line 157
    sget-object v14, Landroidx/compose/ui/text/font/FontWeight;->SemiBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 159
    const/16 v23, 0x0

    .line 161
    const v24, 0xfdfff9

    .line 164
    const/4 v15, 0x0

    .line 165
    const/16 v16, 0x0

    .line 167
    const-wide/16 v17, 0x0

    .line 169
    const/16 v19, 0x0

    .line 171
    const/16 v22, 0x0

    .line 173
    invoke-static/range {v9 .. v24}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 176
    move-result-object v21

    .line 177
    sget-object v9, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 179
    sget-object v10, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 181
    invoke-static {v9, v10, v2, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 184
    move-result-object v9

    .line 185
    iget-wide v10, v2, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 187
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 190
    move-result v10

    .line 191
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 194
    move-result-object v11

    .line 195
    sget-object v12, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 197
    invoke-static {v2, v12}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 200
    move-result-object v13

    .line 201
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 203
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 206
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 208
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 211
    iget-boolean v15, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 213
    if-eqz v15, :cond_da

    .line 215
    invoke-virtual {v2, v14}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 218
    goto :goto_dd

    .line 219
    :cond_da
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 222
    :goto_dd
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 224
    invoke-static {v2, v9, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 227
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 229
    invoke-static {v2, v11, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 232
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 234
    iget-boolean v11, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 236
    if-nez v11, :cond_fb

    .line 238
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 241
    move-result-object v11

    .line 242
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 245
    move-result-object v14

    .line 246
    invoke-static {v11, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 249
    move-result v11

    .line 250
    if-nez v11, :cond_fe

    .line 252
    :cond_fb
    invoke-static {v10, v2, v10, v9}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 255
    :cond_fe
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 257
    invoke-static {v2, v13, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 260
    const v9, 0x77fb555b

    .line 263
    invoke-virtual {v2, v9}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 266
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 269
    move-result-object v43

    .line 270
    move v3, v7

    .line 271
    :goto_10e
    invoke-interface/range {v43 .. v43}, Ljava/util/Iterator;->hasNext()Z

    .line 274
    move-result v9

    .line 275
    if-eqz v9, :cond_30f

    .line 277
    invoke-interface/range {v43 .. v43}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 280
    move-result-object v9

    .line 281
    add-int/lit8 v44, v3, 0x1

    .line 283
    if-ltz v3, :cond_30a

    .line 285
    check-cast v9, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 287
    iget-object v10, v9, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 289
    iget-object v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 291
    iget-object v11, v11, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->changeMonth:Ljava/time/YearMonth;

    .line 293
    invoke-virtual {v10, v11}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 296
    move-result v27

    .line 297
    mul-int/lit8 v3, v3, 0x5a

    .line 299
    add-int/lit16 v3, v3, 0xc8

    .line 301
    const/16 v10, 0x2bc

    .line 303
    const/16 v11, 0x180

    .line 305
    iget-boolean v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$2:Z

    .line 307
    invoke-static {v3, v10, v11, v2, v13}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 310
    move-result-object v3

    .line 311
    const/high16 v10, 0x3f800000    # 1.0f

    .line 313
    invoke-static {v12, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 316
    move-result-object v11

    .line 317
    invoke-static {v11, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 320
    move-result-object v11

    .line 321
    if-eqz v27, :cond_145

    .line 323
    const-string v13, "change_month"

    .line 325
    goto :goto_147

    .line 326
    :cond_145
    const-string v13, "month"

    .line 328
    :goto_147
    invoke-static {v11, v13}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 331
    move-result-object v11

    .line 332
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 335
    move-result v13

    .line 336
    iget v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$3:F

    .line 338
    invoke-virtual {v2, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 341
    move-result v15

    .line 342
    or-int/2addr v13, v15

    .line 343
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 346
    move-result-object v15

    .line 347
    sget-object v7, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 349
    if-nez v13, :cond_160

    .line 351
    if-ne v15, v7, :cond_168

    .line 353
    :cond_160
    new-instance v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 355
    invoke-direct {v15, v3, v14, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 358
    invoke-virtual {v2, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 361
    :cond_168
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 363
    invoke-static {v11, v15}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 366
    move-result-object v3

    .line 367
    iget-wide v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$4:J

    .line 369
    invoke-virtual {v2, v13, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 372
    move-result v11

    .line 373
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 376
    move-result-object v15

    .line 377
    if-nez v11, :cond_17c

    .line 379
    if-ne v15, v7, :cond_184

    .line 381
    :cond_17c
    new-instance v15, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 383
    invoke-direct {v15, v13, v14, v6}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 386
    invoke-virtual {v2, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 389
    :cond_184
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 391
    invoke-static {v3, v15}, Landroidx/compose/ui/draw/ClipKt;->drawBehind(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 394
    move-result-object v3

    .line 395
    new-instance v7, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 397
    new-instance v11, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 399
    const/4 v13, 0x3

    .line 400
    invoke-direct {v11, v13}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 403
    invoke-direct {v7, v1, v11}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 406
    sget-object v11, Landroidx/compose/ui/Alignment$Companion;->CenterVertically:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 408
    const/16 v13, 0x36

    .line 410
    invoke-static {v7, v11, v2, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 413
    move-result-object v7

    .line 414
    iget-wide v13, v2, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 416
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 419
    move-result v11

    .line 420
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 423
    move-result-object v13

    .line 424
    invoke-static {v2, v3}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 427
    move-result-object v3

    .line 428
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 430
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 433
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 435
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 438
    iget-boolean v15, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 440
    if-eqz v15, :cond_1bd

    .line 442
    invoke-virtual {v2, v14}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 445
    goto :goto_1c0

    .line 446
    :cond_1bd
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 449
    :goto_1c0
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 451
    invoke-static {v2, v7, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 454
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 456
    invoke-static {v2, v13, v7}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 459
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 461
    iget-boolean v13, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 463
    if-nez v13, :cond_1de

    .line 465
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 468
    move-result-object v13

    .line 469
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 472
    move-result-object v14

    .line 473
    invoke-static {v13, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 476
    move-result v13

    .line 477
    if-nez v13, :cond_1e1

    .line 479
    :cond_1de
    invoke-static {v11, v2, v11, v7}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 482
    :cond_1e1
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 484
    invoke-static {v2, v3, v7}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 487
    iget-object v3, v9, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 489
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$5:Ljava/time/format/DateTimeFormatter;

    .line 491
    invoke-virtual {v3, v7}, Ljava/time/YearMonth;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 494
    move-result-object v3

    .line 495
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 498
    iget-boolean v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$6:Z

    .line 500
    if-eqz v7, :cond_1f8

    .line 502
    const/high16 v7, 0x42500000    # 52.0f

    .line 504
    goto :goto_1fa

    .line 505
    :cond_1f8
    const/high16 v7, 0x42000000    # 32.0f

    .line 507
    :goto_1fa
    invoke-static {v12, v7}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 510
    move-result-object v7

    .line 511
    move v13, v4

    .line 512
    move v11, v5

    .line 513
    invoke-static {v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 516
    move-result-wide v4

    .line 517
    const/16 v24, 0x6000

    .line 519
    const v25, 0x1bff8

    .line 522
    move-object/from16 v22, v2

    .line 524
    move-object v2, v3

    .line 525
    move v14, v6

    .line 526
    move-object v3, v7

    .line 527
    const-wide/16 v6, 0x0

    .line 529
    const/4 v8, 0x0

    .line 530
    move-object/from16 v16, v9

    .line 532
    const/4 v9, 0x0

    .line 533
    move/from16 v17, v10

    .line 535
    const/4 v10, 0x0

    .line 536
    move/from16 v19, v11

    .line 538
    move-object/from16 v18, v12

    .line 540
    const-wide/16 v11, 0x0

    .line 542
    move/from16 v20, v13

    .line 544
    const/4 v13, 0x0

    .line 545
    move/from16 v23, v14

    .line 547
    const-wide/16 v14, 0x0

    .line 549
    move-object/from16 v29, v16

    .line 551
    const/16 v16, 0x0

    .line 553
    move/from16 v30, v17

    .line 555
    const/16 v17, 0x0

    .line 557
    move-object/from16 v31, v18

    .line 559
    const/16 v18, 0x1

    .line 561
    move/from16 v32, v19

    .line 563
    const/16 v19, 0x0

    .line 565
    move/from16 v33, v20

    .line 567
    const/16 v20, 0x0

    .line 569
    move/from16 v34, v23

    .line 571
    const/16 v23, 0x0

    .line 573
    move-object/from16 v1, v29

    .line 575
    move/from16 v0, v30

    .line 577
    move-object/from16 v46, v31

    .line 579
    move/from16 v47, v32

    .line 581
    move/from16 v48, v33

    .line 583
    move/from16 v45, v34

    .line 585
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 588
    move/from16 v28, v27

    .line 590
    move-object/from16 v27, v21

    .line 592
    iget-object v1, v1, Lcom/spotifry/music/data/spotifried/MonthTop;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 594
    iget-object v2, v1, Lcom/spotifry/music/data/db/SongEntity;->title:Ljava/lang/String;

    .line 596
    new-instance v3, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 598
    const/4 v1, 0x1

    .line 599
    invoke-direct {v3, v0, v1}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 602
    move-object/from16 v0, p0

    .line 604
    iget-wide v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$7:J

    .line 606
    if-eqz v28, :cond_261

    .line 608
    move-wide v6, v4

    .line 609
    goto :goto_263

    .line 610
    :cond_261
    sget-wide v6, Landroidx/compose/ui/graphics/Color;->Unspecified:J

    .line 612
    :goto_263
    const/16 v24, 0x6180

    .line 614
    const v25, 0x1aff8

    .line 617
    move-wide v8, v4

    .line 618
    move-wide v4, v6

    .line 619
    const-wide/16 v6, 0x0

    .line 621
    move-wide v9, v8

    .line 622
    const/4 v8, 0x0

    .line 623
    move-wide v10, v9

    .line 624
    const/4 v9, 0x0

    .line 625
    move-wide v11, v10

    .line 626
    const/4 v10, 0x0

    .line 627
    move-wide v13, v11

    .line 628
    const-wide/16 v11, 0x0

    .line 630
    move-wide v14, v13

    .line 631
    const/4 v13, 0x0

    .line 632
    move-wide/from16 v16, v14

    .line 634
    const-wide/16 v14, 0x0

    .line 636
    move-wide/from16 v17, v16

    .line 638
    const/16 v16, 0x2

    .line 640
    move-wide/from16 v18, v17

    .line 642
    const/16 v17, 0x0

    .line 644
    move-wide/from16 v19, v18

    .line 646
    const/16 v18, 0x1

    .line 648
    move-wide/from16 v20, v19

    .line 650
    const/16 v19, 0x0

    .line 652
    move-wide/from16 v29, v20

    .line 654
    const/16 v20, 0x0

    .line 656
    const/16 v23, 0x0

    .line 658
    move-object/from16 v21, v26

    .line 660
    move-wide/from16 v49, v29

    .line 662
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 665
    move-object/from16 v2, v22

    .line 667
    if-eqz v28, :cond_2ed

    .line 669
    const v3, -0x489302c7

    .line 672
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 675
    const/16 v3, 0xb

    .line 677
    invoke-static {v3}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 680
    move-result-wide v30

    .line 681
    const/16 v41, 0x0

    .line 683
    const v42, 0xfffffd

    .line 686
    const-wide/16 v28, 0x0

    .line 688
    const/16 v32, 0x0

    .line 690
    const/16 v33, 0x0

    .line 692
    const/16 v34, 0x0

    .line 694
    const-wide/16 v35, 0x0

    .line 696
    const/16 v37, 0x0

    .line 698
    const-wide/16 v38, 0x0

    .line 700
    const/16 v40, 0x0

    .line 702
    invoke-static/range {v27 .. v42}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 705
    move-result-object v21

    .line 706
    const/16 v24, 0x0

    .line 708
    const v25, 0x1fffa

    .line 711
    move-object/from16 v22, v2

    .line 713
    const-string v2, "taste changed"

    .line 715
    const/4 v3, 0x0

    .line 716
    const-wide/16 v6, 0x0

    .line 718
    const/4 v8, 0x0

    .line 719
    const/4 v9, 0x0

    .line 720
    const/4 v10, 0x0

    .line 721
    const-wide/16 v11, 0x0

    .line 723
    const/4 v13, 0x0

    .line 724
    const-wide/16 v14, 0x0

    .line 726
    const/16 v16, 0x0

    .line 728
    const/16 v17, 0x0

    .line 730
    const/16 v18, 0x0

    .line 732
    const/16 v19, 0x0

    .line 734
    const/16 v20, 0x0

    .line 736
    const/16 v23, 0x6

    .line 738
    move-wide/from16 v4, v49

    .line 740
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 743
    move-object/from16 v2, v22

    .line 745
    const/4 v3, 0x0

    .line 746
    :goto_2e9
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 749
    goto :goto_2f5

    .line 750
    :cond_2ed
    const/4 v3, 0x0

    .line 751
    const v4, 0x33f01a54

    .line 754
    invoke-virtual {v2, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 757
    goto :goto_2e9

    .line 758
    :goto_2f5
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 761
    move v8, v1

    .line 762
    move v7, v3

    .line 763
    move-object/from16 v21, v27

    .line 765
    move/from16 v3, v44

    .line 767
    move/from16 v6, v45

    .line 769
    move-object/from16 v12, v46

    .line 771
    move/from16 v5, v47

    .line 773
    move/from16 v4, v48

    .line 775
    const/high16 v1, 0x41400000    # 12.0f

    .line 777
    goto/16 :goto_10e

    .line 779
    :cond_30a
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 782
    const/4 v0, 0x0

    .line 783
    throw v0

    .line 784
    :cond_30f
    move v3, v7

    .line 785
    move v1, v8

    .line 786
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 789
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 792
    goto :goto_31b

    .line 793
    :cond_318
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 796
    :goto_31b
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 798
    return-object v0
.end method
