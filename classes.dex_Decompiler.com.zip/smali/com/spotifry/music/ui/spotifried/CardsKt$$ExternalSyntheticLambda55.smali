###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda55 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda55)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:J

.field public final synthetic f$1:Ljava/lang/Object;

.field public final synthetic f$2:Ljava/lang/Object;

.field public final synthetic f$3:F

.field public final synthetic f$4:J


# direct methods
.method public synthetic constructor <init>(JLjava/util/List;Landroidx/compose/animation/core/Animatable;FJ)V
    .registers 9

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->$r8$classId:B

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-wide p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$0:J

    .line 9
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$1:Ljava/lang/Object;

    .line 11
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$2:Ljava/lang/Object;

    .line 13
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$3:F

    .line 15
    iput-wide p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$4:J

    .line 17
    return-void
.end method

.method public synthetic constructor <init>(Landroidx/compose/ui/graphics/RadialGradient;FJJLandroidx/compose/ui/graphics/LinearGradient;)V
    .registers 9

    .line 18
    const/4 v0, 0x1

    iput-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->$r8$classId:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$1:Ljava/lang/Object;

    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$3:F

    iput-wide p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$0:J

    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$4:J

    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$2:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 39

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-byte v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->$r8$classId:B

    .line 5
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    const/high16 v3, 0x40800000    # 4.0f

    .line 9
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$2:Ljava/lang/Object;

    .line 11
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$1:Ljava/lang/Object;

    .line 13
    packed-switch v1, :pswitch_data_240

    .line 16
    move-object v11, v9

    .line 17
    check-cast v11, Landroidx/compose/ui/graphics/RadialGradient;

    .line 19
    check-cast v8, Landroidx/compose/ui/graphics/LinearGradient;

    .line 21
    move-object/from16 v12, p1

    .line 23
    check-cast v12, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 25
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    const/high16 v1, 0x428c0000    # 70.0f

    .line 30
    iget v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$3:F

    .line 32
    mul-float/2addr v1, v9

    .line 33
    const/16 v16, 0x0

    .line 35
    const/16 v17, 0x78

    .line 37
    iget-wide v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$0:J

    .line 39
    const/4 v15, 0x0

    .line 40
    move-object v10, v12

    .line 41
    move v12, v1

    .line 42
    invoke-static/range {v10 .. v17}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-V9BoPsw$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Brush;FJFLandroidx/compose/ui/graphics/drawscope/Stroke;I)V

    .line 45
    move-object v12, v10

    .line 46
    move-wide v10, v13

    .line 47
    const v1, 0x3f4ccccd    # 0.8f

    .line 50
    iget-wide v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$4:J

    .line 52
    invoke-static {v1, v13, v14}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 55
    move-result-wide v0

    .line 56
    const/high16 v15, 0x42240000    # 41.0f

    .line 58
    mul-float v19, v15, v9

    .line 60
    move-wide v14, v13

    .line 61
    new-instance v13, Landroidx/compose/ui/graphics/drawscope/Stroke;

    .line 63
    const/16 v17, 0x0

    .line 65
    const/16 v18, 0x1e

    .line 67
    move-wide/from16 v20, v14

    .line 69
    const/4 v15, 0x0

    .line 70
    const/16 v16, 0x0

    .line 72
    move v14, v9

    .line 73
    move-wide/from16 v4, v20

    .line 75
    const/high16 v22, 0x40000000    # 2.0f

    .line 77
    const-wide v23, 0xffffffffL

    .line 82
    invoke-direct/range {v13 .. v18}, Landroidx/compose/ui/graphics/drawscope/Stroke;-><init>(FFIII)V

    .line 85
    move v6, v14

    .line 86
    const/16 v20, 0x68

    .line 88
    const/16 v18, 0x0

    .line 90
    move-wide/from16 v16, v10

    .line 92
    move/from16 v15, v19

    .line 94
    move-object/from16 v19, v13

    .line 96
    move-wide v13, v0

    .line 97
    invoke-static/range {v12 .. v20}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 100
    sget-wide v0, Landroidx/compose/ui/graphics/Color;->Black:J

    .line 102
    const v9, 0x3e3851ec    # 0.18f

    .line 105
    invoke-static {v9, v0, v1}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 108
    move-result-wide v19

    .line 109
    const/high16 v9, 0x427c0000    # 63.0f

    .line 111
    mul-float/2addr v9, v6

    .line 112
    new-instance v13, Landroidx/compose/ui/graphics/drawscope/Stroke;

    .line 114
    const/16 v17, 0x0

    .line 116
    const/16 v18, 0x1e

    .line 118
    const/4 v15, 0x0

    .line 119
    const/16 v16, 0x0

    .line 121
    move v14, v6

    .line 122
    invoke-direct/range {v13 .. v18}, Landroidx/compose/ui/graphics/drawscope/Stroke;-><init>(FFIII)V

    .line 125
    move-wide/from16 v14, v19

    .line 127
    const/16 v20, 0x68

    .line 129
    const/16 v18, 0x0

    .line 131
    move-wide/from16 v16, v10

    .line 133
    move-object/from16 v19, v13

    .line 135
    move-wide v13, v14

    .line 136
    move v15, v9

    .line 137
    invoke-static/range {v12 .. v20}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 140
    const/high16 v9, 0x425b0000    # 54.75f

    .line 142
    mul-float/2addr v9, v6

    .line 143
    const v13, 0x3f59999a    # 0.85f

    .line 146
    invoke-static {v13, v4, v5}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 149
    move-result-wide v13

    .line 150
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 153
    move-result v4

    .line 154
    int-to-long v4, v4

    .line 155
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 158
    move-result v15

    .line 159
    move-object/from16 v25, v8

    .line 161
    const/16 v16, 0x20

    .line 163
    int-to-long v7, v15

    .line 164
    shl-long v4, v4, v16

    .line 166
    and-long v7, v7, v23

    .line 168
    or-long/2addr v4, v7

    .line 169
    invoke-static {v10, v11, v4, v5}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 172
    move-result-wide v17

    .line 173
    mul-float v4, v22, v9

    .line 175
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 178
    move-result v5

    .line 179
    int-to-long v7, v5

    .line 180
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 183
    move-result v4

    .line 184
    int-to-long v4, v4

    .line 185
    shl-long v7, v7, v16

    .line 187
    and-long v4, v4, v23

    .line 189
    or-long v19, v7, v4

    .line 191
    new-instance v21, Landroidx/compose/ui/graphics/drawscope/Stroke;

    .line 193
    const/high16 v4, 0x40200000    # 2.5f

    .line 195
    mul-float v27, v6, v4

    .line 197
    const/16 v30, 0x0

    .line 199
    const/16 v31, 0x1e

    .line 201
    const/16 v28, 0x0

    .line 203
    const/16 v29, 0x0

    .line 205
    move-object/from16 v26, v21

    .line 207
    invoke-direct/range {v26 .. v31}, Landroidx/compose/ui/graphics/drawscope/Stroke;-><init>(FFIII)V

    .line 210
    const/high16 v15, 0x43430000    # 195.0f

    .line 212
    const/high16 v16, 0x42b40000    # 90.0f

    .line 214
    invoke-interface/range {v12 .. v21}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawArc-yD3GUKo(JFFJJLandroidx/compose/ui/graphics/drawscope/DrawStyle;)V

    .line 217
    const/high16 v4, 0x42870000    # 67.5f

    .line 219
    mul-float v14, v6, v4

    .line 221
    new-instance v15, Landroidx/compose/ui/graphics/drawscope/Stroke;

    .line 223
    mul-float v16, v3, v6

    .line 225
    const/16 v19, 0x0

    .line 227
    const/16 v20, 0x1e

    .line 229
    const/16 v17, 0x0

    .line 231
    const/16 v18, 0x0

    .line 233
    invoke-direct/range {v15 .. v20}, Landroidx/compose/ui/graphics/drawscope/Stroke;-><init>(FFIII)V

    .line 236
    const/16 v19, 0x68

    .line 238
    move-object/from16 v18, v15

    .line 240
    move-object/from16 v13, v25

    .line 242
    move-wide v15, v10

    .line 243
    invoke-static/range {v12 .. v19}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-V9BoPsw$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;Landroidx/compose/ui/graphics/Brush;FJFLandroidx/compose/ui/graphics/drawscope/Stroke;I)V

    .line 246
    const/high16 v3, 0x3e800000    # 0.25f

    .line 248
    invoke-static {v3, v0, v1}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 251
    move-result-wide v0

    .line 252
    const/high16 v3, 0x428b0000    # 69.5f

    .line 254
    mul-float v9, v6, v3

    .line 256
    new-instance v19, Landroidx/compose/ui/graphics/drawscope/Stroke;

    .line 258
    const/16 v17, 0x0

    .line 260
    const/16 v18, 0x1e

    .line 262
    const/4 v15, 0x0

    .line 263
    const/16 v16, 0x0

    .line 265
    move v14, v6

    .line 266
    move-object/from16 v13, v19

    .line 268
    invoke-direct/range {v13 .. v18}, Landroidx/compose/ui/graphics/drawscope/Stroke;-><init>(FFIII)V

    .line 271
    const/16 v20, 0x68

    .line 273
    const/16 v18, 0x0

    .line 275
    move-wide v13, v0

    .line 276
    move v15, v9

    .line 277
    move-wide/from16 v16, v10

    .line 279
    invoke-static/range {v12 .. v20}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 282
    const-wide v0, 0xff050505L

    .line 287
    invoke-static {v0, v1}, Landroidx/compose/ui/graphics/ColorKt;->Color(J)J

    .line 290
    move-result-wide v13

    .line 291
    const v0, 0x40733333    # 3.8f

    .line 294
    mul-float v15, v6, v0

    .line 296
    const/16 v19, 0x0

    .line 298
    const/16 v20, 0x78

    .line 300
    invoke-static/range {v12 .. v20}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 303
    return-object v2

    .line 304
    :pswitch_12f
    const/16 v16, 0x20

    .line 306
    const/high16 v22, 0x40000000    # 2.0f

    .line 308
    const-wide v23, 0xffffffffL

    .line 313
    check-cast v9, Ljava/util/List;

    .line 315
    check-cast v8, Landroidx/compose/animation/core/Animatable;

    .line 317
    move-object/from16 v1, p1

    .line 319
    check-cast v1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 321
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 324
    invoke-interface {v1, v3}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 327
    move-result v3

    .line 328
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 331
    move-result-wide v4

    .line 332
    and-long v4, v4, v23

    .line 334
    long-to-int v4, v4

    .line 335
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 338
    move-result v4

    .line 339
    const/high16 v5, 0x3f800000    # 1.0f

    .line 341
    invoke-interface {v1, v5}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 344
    move-result v6

    .line 345
    sub-float/2addr v4, v6

    .line 346
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 349
    move-result v4

    .line 350
    int-to-long v6, v4

    .line 351
    and-long v28, v6, v23

    .line 353
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 356
    move-result-wide v6

    .line 357
    shr-long v6, v6, v16

    .line 359
    long-to-int v4, v6

    .line 360
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 363
    move-result v4

    .line 364
    invoke-interface {v1, v5}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 367
    move-result v5

    .line 368
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 371
    move-result v4

    .line 372
    int-to-long v6, v4

    .line 373
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 376
    move-result v4

    .line 377
    int-to-long v4, v4

    .line 378
    shl-long v6, v6, v16

    .line 380
    and-long v4, v4, v23

    .line 382
    or-long v30, v6, v4

    .line 384
    const/16 v33, 0x0

    .line 386
    const/16 v34, 0x78

    .line 388
    iget-wide v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$0:J

    .line 390
    const/16 v32, 0x0

    .line 392
    move-object/from16 v25, v1

    .line 394
    move-wide/from16 v26, v4

    .line 396
    invoke-static/range {v25 .. v34}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFII)V

    .line 399
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 402
    move-result-object v1

    .line 403
    const/4 v4, 0x0

    .line 404
    :goto_193
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 407
    move-result v5

    .line 408
    if-eqz v5, :cond_23e

    .line 410
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 413
    move-result-object v5

    .line 414
    add-int/lit8 v6, v4, 0x1

    .line 416
    if-ltz v4, :cond_239

    .line 418
    check-cast v5, Ljava/lang/Number;

    .line 420
    invoke-virtual {v5}, Ljava/lang/Number;->floatValue()F

    .line 423
    move-result v5

    .line 424
    const v7, 0x3f266666    # 0.65f

    .line 427
    int-to-float v10, v6

    .line 428
    mul-float/2addr v10, v7

    .line 429
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 432
    move-result v7

    .line 433
    int-to-float v7, v7

    .line 434
    div-float/2addr v10, v7

    .line 435
    const v7, 0x3eb33333    # 0.35f

    .line 438
    add-float/2addr v10, v7

    .line 439
    invoke-interface/range {v25 .. v25}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 442
    move-result-wide v11

    .line 443
    and-long v11, v11, v23

    .line 445
    long-to-int v7, v11

    .line 446
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 449
    move-result v7

    .line 450
    mul-float/2addr v7, v10

    .line 451
    invoke-virtual {v8}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 454
    move-result-object v10

    .line 455
    check-cast v10, Ljava/lang/Number;

    .line 457
    invoke-virtual {v10}, Ljava/lang/Number;->floatValue()F

    .line 460
    move-result v10

    .line 461
    int-to-float v4, v4

    .line 462
    iget v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$3:F

    .line 464
    mul-float/2addr v4, v11

    .line 465
    const/high16 v11, 0x43fa0000    # 500.0f

    .line 467
    add-float/2addr v4, v11

    .line 468
    const v11, 0x44098000    # 550.0f

    .line 471
    invoke-static {v10, v4, v11}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 474
    move-result v4

    .line 475
    mul-float/2addr v4, v7

    .line 476
    const/high16 v7, 0x41c00000    # 24.0f

    .line 478
    div-float/2addr v5, v7

    .line 479
    invoke-interface/range {v25 .. v25}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 482
    move-result-wide v10

    .line 483
    shr-long v10, v10, v16

    .line 485
    long-to-int v7, v10

    .line 486
    invoke-static {v7}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 489
    move-result v7

    .line 490
    sub-float/2addr v7, v3

    .line 491
    mul-float/2addr v7, v5

    .line 492
    invoke-interface/range {v25 .. v25}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 495
    move-result-wide v10

    .line 496
    and-long v10, v10, v23

    .line 498
    long-to-int v5, v10

    .line 499
    invoke-static {v5}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 502
    move-result v5

    .line 503
    sub-float/2addr v5, v4

    .line 504
    invoke-static {v7}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 507
    move-result v7

    .line 508
    int-to-long v10, v7

    .line 509
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 512
    move-result v5

    .line 513
    int-to-long v12, v5

    .line 514
    shl-long v10, v10, v16

    .line 516
    and-long v12, v12, v23

    .line 518
    or-long v28, v10, v12

    .line 520
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 523
    move-result v5

    .line 524
    int-to-long v10, v5

    .line 525
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 528
    move-result v4

    .line 529
    int-to-long v4, v4

    .line 530
    shl-long v10, v10, v16

    .line 532
    and-long v4, v4, v23

    .line 534
    or-long v30, v10, v4

    .line 536
    div-float v4, v3, v22

    .line 538
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 541
    move-result v5

    .line 542
    int-to-long v10, v5

    .line 543
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 546
    move-result v4

    .line 547
    int-to-long v4, v4

    .line 548
    shl-long v10, v10, v16

    .line 550
    and-long v4, v4, v23

    .line 552
    or-long v32, v10, v4

    .line 554
    const/16 v35, 0x0

    .line 556
    const/16 v36, 0xf0

    .line 558
    iget-wide v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;->f$4:J

    .line 560
    const/16 v34, 0x0

    .line 562
    move-wide/from16 v26, v4

    .line 564
    invoke-static/range {v25 .. v36}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 567
    move v4, v6

    .line 568
    goto/16 :goto_193

    .line 570
    :cond_239
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 573
    const/4 v0, 0x0

    .line 574
    throw v0

    .line 575
    :cond_23e
    return-object v2

    nop

    .line 577
    :pswitch_data_240
    .packed-switch 0x0
        :pswitch_12f
    .end packed-switch
.end method
