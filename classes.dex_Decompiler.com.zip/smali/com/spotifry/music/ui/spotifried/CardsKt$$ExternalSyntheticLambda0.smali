###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda0 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda0)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:Z

.field public final synthetic f$2:I


# direct methods
.method public synthetic constructor <init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V
    .registers 5

    .line 15
    iput-byte p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->$r8$classId:B

    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    iput-boolean p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$1:Z

    iput p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$2:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ZLkotlin/jvm/functions/Function2;I)V
    .registers 5

    .line 1
    const/16 v0, 0xd

    .line 3
    iput-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->$r8$classId:B

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$1:Z

    .line 10
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 12
    iput p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$2:I

    .line 14
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->$r8$classId:B

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    iget v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$2:I

    .line 7
    iget-object v3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 9
    iget-boolean p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;->f$1:Z

    .line 11
    packed-switch v0, :pswitch_data_118

    .line 14
    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 16
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 18
    check-cast p2, Ljava/lang/Integer;

    .line 20
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    or-int/lit8 v2, v2, 0x1

    .line 25
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 28
    move-result p2

    .line 29
    invoke-static {p0, v3, p1, p2}, Lkotlin/text/RegexKt;->PredictiveBackHandler(ZLkotlin/jvm/functions/Function2;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 32
    return-object v1

    .line 33
    :pswitch_20
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 35
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 37
    check-cast p2, Ljava/lang/Integer;

    .line 39
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 42
    or-int/lit8 v2, v2, 0x1

    .line 44
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 47
    move-result p2

    .line 48
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->MonthsCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 51
    return-object v1

    .line 52
    :pswitch_33
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 54
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 56
    check-cast p2, Ljava/lang/Integer;

    .line 58
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 61
    or-int/lit8 v2, v2, 0x1

    .line 63
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 66
    move-result p2

    .line 67
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->HoursCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 70
    return-object v1

    .line 71
    :pswitch_46
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 73
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 75
    check-cast p2, Ljava/lang/Integer;

    .line 77
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    or-int/lit8 v2, v2, 0x1

    .line 82
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 85
    move-result p2

    .line 86
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->DayCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 89
    return-object v1

    .line 90
    :pswitch_59
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 92
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 94
    check-cast p2, Ljava/lang/Integer;

    .line 96
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 99
    or-int/lit8 v2, v2, 0x1

    .line 101
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 104
    move-result p2

    .line 105
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->DayCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 108
    return-object v1

    .line 109
    :pswitch_6c
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 111
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 113
    check-cast p2, Ljava/lang/Integer;

    .line 115
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 118
    or-int/lit8 v2, v2, 0x1

    .line 120
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 123
    move-result p2

    .line 124
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->SunCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 127
    return-object v1

    .line 128
    :pswitch_7f
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 130
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 132
    check-cast p2, Ljava/lang/Integer;

    .line 134
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 137
    or-int/lit8 v2, v2, 0x1

    .line 139
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 142
    move-result p2

    .line 143
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->IntroCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 146
    return-object v1

    .line 147
    :pswitch_92
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 149
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 151
    check-cast p2, Ljava/lang/Integer;

    .line 153
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 156
    or-int/lit8 v2, v2, 0x1

    .line 158
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 161
    move-result p2

    .line 162
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Months(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 165
    return-object v1

    .line 166
    :pswitch_a5
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 168
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 170
    check-cast p2, Ljava/lang/Integer;

    .line 172
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 175
    or-int/lit8 v2, v2, 0x1

    .line 177
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 180
    move-result p2

    .line 181
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Intro(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 184
    return-object v1

    .line 185
    :pswitch_b8
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 187
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 189
    check-cast p2, Ljava/lang/Integer;

    .line 191
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 194
    or-int/lit8 v2, v2, 0x1

    .line 196
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 199
    move-result p2

    .line 200
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->TopSongCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 203
    return-object v1

    .line 204
    :pswitch_cb
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 206
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 208
    check-cast p2, Ljava/lang/Integer;

    .line 210
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 213
    or-int/lit8 v2, v2, 0x1

    .line 215
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 218
    move-result p2

    .line 219
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Hours(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 222
    return-object v1

    .line 223
    :pswitch_de
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 225
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 227
    check-cast p2, Ljava/lang/Integer;

    .line 229
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 232
    or-int/lit8 v2, v2, 0x1

    .line 234
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 237
    move-result p2

    .line 238
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->SunPortrait(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 241
    return-object v1

    .line 242
    :pswitch_f1
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 244
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 246
    check-cast p2, Ljava/lang/Integer;

    .line 248
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 251
    or-int/lit8 v2, v2, 0x1

    .line 253
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 256
    move-result p2

    .line 257
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->MonthsCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 260
    return-object v1

    .line 261
    :pswitch_104
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 263
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 265
    check-cast p2, Ljava/lang/Integer;

    .line 267
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 270
    or-int/lit8 v2, v2, 0x1

    .line 272
    invoke-static {v2}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 275
    move-result p2

    .line 276
    invoke-static {v3, p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->TopSongCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 279
    return-object v1

    nop

    .line 281
    :pswitch_data_118
    .packed-switch 0x0
        :pswitch_104
        :pswitch_f1
        :pswitch_de
        :pswitch_cb
        :pswitch_b8
        :pswitch_a5
        :pswitch_92
        :pswitch_7f
        :pswitch_6c
        :pswitch_59
        :pswitch_46
        :pswitch_33
        :pswitch_20
    .end packed-switch
.end method
