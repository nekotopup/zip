###### Class com.spotifry.music.ui.spotifried.SpotifriedViewModel (com.spotifry.music.ui.spotifried.SpotifriedViewModel)
.class public final Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;
.super Landroidx/lifecycle/ViewModel;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"


# instance fields
.field public final picked:Lkotlinx/coroutines/flow/StateFlowImpl;

.field public final state:Lkotlinx/coroutines/flow/ReadonlyStateFlow;

.field public final today:Lkotlin/jvm/functions/Function0;

.field public final zone:Ljava/time/ZoneId;


# direct methods
.method public constructor <init>(Landroidx/room/coroutines/FlowUtil$createFlow$$inlined$map$1;Landroidx/room/coroutines/FlowUtil$createFlow$$inlined$map$1;Lkotlinx/coroutines/flow/StateFlowImpl;)V
    .registers 14

    .line 1
    sget-object v0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;->INSTANCE:Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;

    .line 3
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    invoke-direct {p0}, Landroidx/lifecycle/ViewModel;-><init>()V

    .line 9
    iput-object v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->today:Lkotlin/jvm/functions/Function0;

    .line 11
    const/4 v0, 0x0

    .line 12
    invoke-static {v0}, Lkotlinx/coroutines/flow/StateFlowKt;->MutableStateFlow(Ljava/lang/Object;)Lkotlinx/coroutines/flow/StateFlowImpl;

    .line 15
    move-result-object v1

    .line 16
    iput-object v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->picked:Lkotlinx/coroutines/flow/StateFlowImpl;

    .line 18
    invoke-static {}, Ljava/time/ZoneId;->systemDefault()Ljava/time/ZoneId;

    .line 21
    move-result-object v2

    .line 22
    iput-object v2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->zone:Ljava/time/ZoneId;

    .line 24
    new-instance v3, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$state$1;

    .line 26
    const-string v8, "build(Ljava/util/List;Ljava/util/List;Lcom/spotifry/music/data/spotifried/WrappedPeriod;Ljava/lang/String;)Lcom/spotifry/music/ui/spotifried/SpotifriedState;"

    .line 28
    const/4 v9, 0x4

    .line 29
    const/4 v4, 0x5

    .line 30
    const-class v6, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;

    .line 32
    const-string v7, "build"

    .line 34
    move-object v5, p0

    .line 35
    invoke-direct/range {v3 .. v9}, Lkotlin/jvm/internal/AdaptedFunctionReference;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 38
    const/4 p0, 0x4

    .line 39
    new-array p0, p0, [Lkotlinx/coroutines/flow/Flow;

    .line 41
    const/4 v2, 0x0

    .line 42
    aput-object p1, p0, v2

    .line 44
    const/4 p1, 0x1

    .line 45
    aput-object p2, p0, p1

    .line 47
    const/4 p1, 0x2

    .line 48
    aput-object v1, p0, p1

    .line 50
    const/4 p1, 0x3

    .line 51
    aput-object p3, p0, p1

    .line 53
    new-instance p1, Lkotlinx/coroutines/flow/FlowKt__LimitKt$dropWhile$$inlined$unsafeFlow$1;

    .line 55
    const/16 p2, 0x8

    .line 57
    invoke-direct {p1, p0, v3, p2}, Lkotlinx/coroutines/flow/FlowKt__LimitKt$dropWhile$$inlined$unsafeFlow$1;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 60
    sget-object p0, Lkotlinx/coroutines/Dispatchers;->Default:Lkotlinx/coroutines/scheduling/DefaultScheduler;

    .line 62
    invoke-static {p1, p0}, Lkotlinx/coroutines/flow/StateFlowKt;->flowOn(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/scheduling/DefaultScheduler;)Lkotlinx/coroutines/flow/Flow;

    .line 65
    move-result-object p0

    .line 66
    invoke-static {v5}, Landroidx/lifecycle/ViewModelKt;->getViewModelScope(Landroidx/lifecycle/ViewModel;)Landroidx/lifecycle/viewmodel/internal/CloseableCoroutineScope;

    .line 69
    move-result-object p1

    .line 70
    new-instance p2, Lkotlinx/coroutines/flow/StartedWhileSubscribed;

    .line 72
    const-wide/16 v1, 0x1388

    .line 74
    invoke-direct {p2, v1, v2}, Lkotlinx/coroutines/flow/StartedWhileSubscribed;-><init>(J)V

    .line 77
    invoke-static {p0, p1, p2, v0}, Lkotlinx/coroutines/flow/StateFlowKt;->stateIn(Lkotlinx/coroutines/flow/Flow;Lkotlinx/coroutines/CoroutineScope;Lkotlinx/coroutines/flow/SharingStarted;Ljava/lang/Object;)Lkotlinx/coroutines/flow/ReadonlyStateFlow;

    .line 80
    move-result-object p0

    .line 81
    iput-object p0, v5, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->state:Lkotlinx/coroutines/flow/ReadonlyStateFlow;

    .line 83
    return-void
.end method

.method public static final build$statsOf(Ljava/util/List;Ljava/util/Map;Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Ljava/util/Set;Lcom/spotifry/music/data/spotifried/WrappedPeriod;)Lcom/spotifry/music/data/spotifried/SpotifriedStats;
    .registers 46

    .line 1
    move-object/from16 v0, p1

    .line 3
    move-object/from16 v1, p2

    .line 5
    move-object/from16 v2, p4

    .line 7
    iget-object v1, v1, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->zone:Ljava/time/ZoneId;

    .line 9
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    iget-object v3, v2, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->to:Ljava/time/LocalDate;

    .line 14
    iget-object v4, v2, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->from:Ljava/time/LocalDate;

    .line 16
    new-instance v5, Ljava/util/ArrayList;

    .line 18
    const/16 v6, 0xa

    .line 20
    move-object/from16 v7, p0

    .line 22
    invoke-static {v7, v6}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 25
    move-result v8

    .line 26
    invoke-direct {v5, v8}, Ljava/util/ArrayList;-><init>(I)V

    .line 29
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 32
    move-result-object v7

    .line 33
    :goto_20
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 36
    move-result v8

    .line 37
    if-eqz v8, :cond_61

    .line 39
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 42
    move-result-object v8

    .line 43
    check-cast v8, Lcom/spotifry/music/data/db/ListenRow;

    .line 45
    iget-wide v9, v8, Lcom/spotifry/music/data/db/ListenRow;->startedAt:J

    .line 47
    invoke-static {v9, v10}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    .line 50
    move-result-object v9

    .line 51
    invoke-virtual {v9, v1}, Ljava/time/Instant;->atZone(Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;

    .line 54
    move-result-object v9

    .line 55
    new-instance v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 57
    invoke-virtual {v9}, Ljava/time/ZonedDateTime;->toLocalDate()Ljava/time/LocalDate;

    .line 60
    move-result-object v11

    .line 61
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    invoke-virtual {v9}, Ljava/time/ZonedDateTime;->getHour()I

    .line 67
    move-result v12

    .line 68
    invoke-virtual {v9}, Ljava/time/ZonedDateTime;->getHour()I

    .line 71
    move-result v13

    .line 72
    int-to-float v13, v13

    .line 73
    invoke-virtual {v9}, Ljava/time/ZonedDateTime;->getMinute()I

    .line 76
    move-result v14

    .line 77
    int-to-float v14, v14

    .line 78
    const/high16 v15, 0x42700000    # 60.0f

    .line 80
    div-float/2addr v14, v15

    .line 81
    add-float/2addr v14, v13

    .line 82
    invoke-virtual {v9}, Ljava/time/ZonedDateTime;->getSecond()I

    .line 85
    move-result v9

    .line 86
    int-to-float v9, v9

    .line 87
    const/high16 v13, 0x45610000    # 3600.0f

    .line 89
    div-float/2addr v9, v13

    .line 90
    add-float/2addr v9, v14

    .line 91
    invoke-direct {v10, v8, v11, v12, v9}, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;-><init>(Lcom/spotifry/music/data/db/ListenRow;Ljava/time/LocalDate;IF)V

    .line 94
    invoke-virtual {v5, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 97
    goto :goto_20

    .line 98
    :cond_61
    new-instance v1, Ljava/util/ArrayList;

    .line 100
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 103
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 106
    move-result-object v7

    .line 107
    :cond_6a
    :goto_6a
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 110
    move-result v8

    .line 111
    if-eqz v8, :cond_8b

    .line 113
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 116
    move-result-object v8

    .line 117
    move-object v9, v8

    .line 118
    check-cast v9, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 120
    iget-object v10, v9, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 122
    invoke-virtual {v10, v4}, Ljava/time/LocalDate;->compareTo(Ljava/time/chrono/ChronoLocalDate;)I

    .line 125
    move-result v10

    .line 126
    if-ltz v10, :cond_6a

    .line 128
    iget-object v9, v9, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 130
    invoke-virtual {v9, v3}, Ljava/time/LocalDate;->compareTo(Ljava/time/chrono/ChronoLocalDate;)I

    .line 133
    move-result v9

    .line 134
    if-gtz v9, :cond_6a

    .line 136
    invoke-virtual {v1, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 139
    goto :goto_6a

    .line 140
    :cond_8b
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 143
    move-result-object v7

    .line 144
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 147
    move-result v8

    .line 148
    if-nez v8, :cond_97

    .line 150
    const/4 v8, 0x0

    .line 151
    goto :goto_b5

    .line 152
    :cond_97
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 155
    move-result-object v8

    .line 156
    check-cast v8, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 158
    iget-object v8, v8, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 160
    :cond_9f
    :goto_9f
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 163
    move-result v10

    .line 164
    if-eqz v10, :cond_b5

    .line 166
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 169
    move-result-object v10

    .line 170
    check-cast v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 172
    iget-object v10, v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 174
    invoke-virtual {v8, v10}, Ljava/time/LocalDate;->compareTo(Ljava/lang/Object;)I

    .line 177
    move-result v11

    .line 178
    if-lez v11, :cond_9f

    .line 180
    move-object v8, v10

    .line 181
    goto :goto_9f

    .line 182
    :cond_b5
    :goto_b5
    if-eqz v8, :cond_bd

    .line 184
    invoke-virtual {v4, v8}, Ljava/time/LocalDate;->compareTo(Ljava/lang/Object;)I

    .line 187
    move-result v7

    .line 188
    if-ltz v7, :cond_be

    .line 190
    :cond_bd
    move-object v8, v4

    .line 191
    :cond_be
    new-instance v7, Ljava/util/ArrayList;

    .line 193
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 196
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 199
    move-result-object v10

    .line 200
    :cond_c7
    :goto_c7
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 203
    move-result v11

    .line 204
    const/16 v12, 0x1e

    .line 206
    if-eqz v11, :cond_e0

    .line 208
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 211
    move-result-object v11

    .line 212
    move-object v13, v11

    .line 213
    check-cast v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 215
    iget-object v13, v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 217
    iget v13, v13, Lcom/spotifry/music/data/db/ListenRow;->secondsHeard:I

    .line 219
    if-lt v13, v12, :cond_c7

    .line 221
    invoke-virtual {v7, v11}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 224
    goto :goto_c7

    .line 225
    :cond_e0
    new-instance v10, Ljava/util/ArrayList;

    .line 227
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 230
    invoke-virtual {v7}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 233
    move-result-object v11

    .line 234
    :cond_e9
    :goto_e9
    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    .line 237
    move-result v13

    .line 238
    if-eqz v13, :cond_100

    .line 240
    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 243
    move-result-object v13

    .line 244
    move-object v14, v13

    .line 245
    check-cast v14, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 247
    iget-object v14, v14, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 249
    iget-object v14, v14, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 251
    if-eqz v14, :cond_e9

    .line 253
    invoke-virtual {v10, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 256
    goto :goto_e9

    .line 257
    :cond_100
    new-instance v11, Ljava/util/LinkedHashMap;

    .line 259
    invoke-direct {v11}, Ljava/util/LinkedHashMap;-><init>()V

    .line 262
    invoke-virtual {v10}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 265
    move-result-object v10

    .line 266
    :goto_109
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 269
    move-result v13

    .line 270
    if-eqz v13, :cond_12e

    .line 272
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 275
    move-result-object v13

    .line 276
    move-object v14, v13

    .line 277
    check-cast v14, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 279
    iget-object v14, v14, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 281
    iget-object v14, v14, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 283
    invoke-virtual {v11, v14}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 286
    move-result-object v15

    .line 287
    if-nez v15, :cond_128

    .line 289
    new-instance v15, Ljava/util/ArrayList;

    .line 291
    invoke-direct {v15}, Ljava/util/ArrayList;-><init>()V

    .line 294
    invoke-interface {v11, v14, v15}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 297
    :cond_128
    check-cast v15, Ljava/util/List;

    .line 299
    invoke-interface {v15, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 302
    goto :goto_109

    .line 303
    :cond_12e
    invoke-virtual {v11}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 306
    move-result-object v10

    .line 307
    check-cast v10, Ljava/lang/Iterable;

    .line 309
    new-instance v11, Ljava/util/ArrayList;

    .line 311
    invoke-static {v10, v6}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 314
    move-result v13

    .line 315
    invoke-direct {v11, v13}, Ljava/util/ArrayList;-><init>(I)V

    .line 318
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 321
    move-result-object v10

    .line 322
    :goto_141
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 325
    move-result v13

    .line 326
    if-eqz v13, :cond_18c

    .line 328
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 331
    move-result-object v13

    .line 332
    check-cast v13, Ljava/util/List;

    .line 334
    invoke-static {v13}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 337
    move-result-object v16

    .line 338
    move-object/from16 v9, v16

    .line 340
    check-cast v9, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 342
    iget-object v9, v9, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 344
    iget-object v9, v9, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 346
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 349
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 352
    move-result-object v16

    .line 353
    const-wide/16 v14, 0x0

    .line 355
    :goto_162
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->hasNext()Z

    .line 358
    move-result v17

    .line 359
    if-eqz v17, :cond_17b

    .line 361
    invoke-interface/range {v16 .. v16}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 364
    move-result-object v17

    .line 365
    move-object/from16 v12, v17

    .line 367
    check-cast v12, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 369
    iget-object v12, v12, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 371
    iget v12, v12, Lcom/spotifry/music/data/db/ListenRow;->secondsHeard:I

    .line 373
    move-object/from16 v18, v7

    .line 375
    int-to-long v6, v12

    .line 376
    add-long/2addr v14, v6

    .line 377
    move-object/from16 v7, v18

    .line 379
    goto :goto_162

    .line 380
    :cond_17b
    move-object/from16 v18, v7

    .line 382
    invoke-interface {v13}, Ljava/util/List;->size()I

    .line 385
    move-result v6

    .line 386
    new-instance v7, Lcom/spotifry/music/data/TopSong;

    .line 388
    invoke-direct {v7, v9, v14, v15, v6}, Lcom/spotifry/music/data/TopSong;-><init>(Lcom/spotifry/music/data/db/SongEntity;JI)V

    .line 391
    invoke-virtual {v11, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 394
    move-object/from16 v7, v18

    .line 396
    goto :goto_141

    .line 397
    :cond_18c
    move-object/from16 v18, v7

    .line 399
    const/16 p0, 0x0

    .line 401
    new-instance v6, Lcom/spotifry/music/data/Backups$applyTheRest$$inlined$sortedBy$1;

    .line 403
    const/16 v7, 0x13

    .line 405
    invoke-direct {v6, v7}, Lcom/spotifry/music/data/Backups$applyTheRest$$inlined$sortedBy$1;-><init>(B)V

    .line 408
    new-instance v7, Lcom/spotifry/music/data/PlaylistOrder$arrange$$inlined$thenBy$1;

    .line 410
    const/4 v9, 0x4

    .line 411
    invoke-direct {v7, v6, v9}, Lcom/spotifry/music/data/PlaylistOrder$arrange$$inlined$thenBy$1;-><init>(Ljava/lang/Object;B)V

    .line 414
    invoke-static {v11, v7}, Lkotlin/collections/CollectionsKt;->maxWithOrNull(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 417
    move-result-object v6

    .line 418
    move-object v7, v6

    .line 419
    check-cast v7, Lcom/spotifry/music/data/TopSong;

    .line 421
    sget-object v6, Ljava/time/temporal/ChronoUnit;->DAYS:Ljava/time/temporal/ChronoUnit;

    .line 423
    invoke-virtual {v6, v8, v3}, Ljava/time/temporal/ChronoUnit;->between(Ljava/time/temporal/Temporal;Ljava/time/temporal/Temporal;)J

    .line 426
    move-result-wide v9

    .line 427
    long-to-int v6, v9

    .line 428
    const/4 v9, 0x1

    .line 429
    add-int/2addr v6, v9

    .line 430
    const/4 v10, 0x0

    .line 431
    invoke-static {v10, v6}, Ljava/lang/Math;->max(II)I

    .line 434
    move-result v6

    .line 435
    new-array v11, v6, [J

    .line 437
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 440
    move-result-object v12

    .line 441
    :goto_1b8
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 444
    move-result v13

    .line 445
    if-eqz v13, :cond_1e3

    .line 447
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 450
    move-result-object v13

    .line 451
    check-cast v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 453
    sget-object v14, Ljava/time/temporal/ChronoUnit;->DAYS:Ljava/time/temporal/ChronoUnit;

    .line 455
    iget-object v15, v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 457
    invoke-virtual {v14, v8, v15}, Ljava/time/temporal/ChronoUnit;->between(Ljava/time/temporal/Temporal;Ljava/time/temporal/Temporal;)J

    .line 460
    move-result-wide v14

    .line 461
    long-to-int v14, v14

    .line 462
    add-int/lit8 v15, v6, -0x1

    .line 464
    invoke-static {v14, v10, v15}, Lkotlin/ResultKt;->coerceIn(III)I

    .line 467
    move-result v14

    .line 468
    aget-wide v15, v11, v14

    .line 470
    iget-object v13, v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 472
    iget v13, v13, Lcom/spotifry/music/data/db/ListenRow;->secondsHeard:I

    .line 474
    move/from16 v21, v9

    .line 476
    int-to-long v9, v13

    .line 477
    add-long/2addr v15, v9

    .line 478
    aput-wide v15, v11, v14

    .line 480
    move/from16 v9, v21

    .line 482
    const/4 v10, 0x0

    .line 483
    goto :goto_1b8

    .line 484
    :cond_1e3
    move/from16 v21, v9

    .line 486
    const-wide/16 v19, 0x0

    .line 488
    const/16 v9, 0x18

    .line 490
    new-array v9, v9, [J

    .line 492
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 495
    move-result-object v10

    .line 496
    :goto_1ef
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 499
    move-result v12

    .line 500
    if-eqz v12, :cond_20c

    .line 502
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 505
    move-result-object v12

    .line 506
    check-cast v12, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 508
    iget v13, v12, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->hour:I

    .line 510
    aget-wide v14, v9, v13

    .line 512
    iget-object v12, v12, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 514
    iget v12, v12, Lcom/spotifry/music/data/db/ListenRow;->secondsHeard:I

    .line 516
    move-object/from16 v16, v3

    .line 518
    int-to-long v2, v12

    .line 519
    add-long/2addr v14, v2

    .line 520
    aput-wide v14, v9, v13

    .line 522
    move-object/from16 v3, v16

    .line 524
    goto :goto_1ef

    .line 525
    :cond_20c
    move-object/from16 v16, v3

    .line 527
    new-instance v2, Ljava/util/ArrayList;

    .line 529
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 532
    invoke-virtual/range {v18 .. v18}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 535
    move-result-object v3

    .line 536
    :cond_217
    :goto_217
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 539
    move-result v10

    .line 540
    if-eqz v10, :cond_22e

    .line 542
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 545
    move-result-object v10

    .line 546
    move-object v12, v10

    .line 547
    check-cast v12, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 549
    iget-object v12, v12, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 551
    iget-object v12, v12, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 553
    if-eqz v12, :cond_217

    .line 555
    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 558
    goto :goto_217

    .line 559
    :cond_22e
    new-instance v3, Ljava/util/LinkedHashMap;

    .line 561
    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 564
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 567
    move-result-object v10

    .line 568
    :goto_237
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 571
    move-result v12

    .line 572
    if-eqz v12, :cond_263

    .line 574
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 577
    move-result-object v12

    .line 578
    move-object v13, v12

    .line 579
    check-cast v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 581
    iget-object v14, v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 583
    iget-object v14, v14, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 585
    iget-object v13, v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 587
    new-instance v15, Lkotlin/Pair;

    .line 589
    invoke-direct {v15, v14, v13}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 592
    invoke-virtual {v3, v15}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 595
    move-result-object v13

    .line 596
    if-nez v13, :cond_25d

    .line 598
    new-instance v13, Ljava/util/ArrayList;

    .line 600
    invoke-direct {v13}, Ljava/util/ArrayList;-><init>()V

    .line 603
    invoke-interface {v3, v15, v13}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 606
    :cond_25d
    check-cast v13, Ljava/util/List;

    .line 608
    invoke-interface {v13, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 611
    goto :goto_237

    .line 612
    :cond_263
    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 615
    move-result-object v3

    .line 616
    check-cast v3, Ljava/lang/Iterable;

    .line 618
    new-instance v10, Lcom/spotifry/music/data/Backups$applyTheRest$$inlined$sortedBy$1;

    .line 620
    const/16 v12, 0x14

    .line 622
    invoke-direct {v10, v12}, Lcom/spotifry/music/data/Backups$applyTheRest$$inlined$sortedBy$1;-><init>(B)V

    .line 625
    new-instance v13, Lcom/spotifry/music/data/PlaylistOrder$arrange$$inlined$thenBy$1;

    .line 627
    const/4 v14, 0x5

    .line 628
    invoke-direct {v13, v10, v14}, Lcom/spotifry/music/data/PlaylistOrder$arrange$$inlined$thenBy$1;-><init>(Ljava/lang/Object;B)V

    .line 631
    invoke-static {v3, v13}, Lkotlin/collections/CollectionsKt;->maxWithOrNull(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/lang/Object;

    .line 634
    move-result-object v3

    .line 635
    check-cast v3, Ljava/util/List;

    .line 637
    if-eqz v3, :cond_2c4

    .line 639
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 642
    move-result-object v10

    .line 643
    check-cast v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 645
    iget-object v10, v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 647
    iget-object v10, v10, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 649
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 652
    invoke-static {v3}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 655
    move-result-object v13

    .line 656
    check-cast v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 658
    iget-object v13, v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 660
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 663
    move-result v15

    .line 664
    new-instance v12, Ljava/util/ArrayList;

    .line 666
    move-object/from16 v25, v2

    .line 668
    const/16 v14, 0xa

    .line 670
    invoke-static {v3, v14}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 673
    move-result v2

    .line 674
    invoke-direct {v12, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 677
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 680
    move-result-object v2

    .line 681
    :goto_2a8
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 684
    move-result v3

    .line 685
    if-eqz v3, :cond_2be

    .line 687
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 690
    move-result-object v3

    .line 691
    check-cast v3, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 693
    iget v3, v3, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->hourF:F

    .line 695
    invoke-static {v3}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 698
    move-result-object v3

    .line 699
    invoke-virtual {v12, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 702
    goto :goto_2a8

    .line 703
    :cond_2be
    new-instance v2, Lcom/spotifry/music/data/spotifried/ObsessionDay;

    .line 705
    invoke-direct {v2, v10, v13, v15, v12}, Lcom/spotifry/music/data/spotifried/ObsessionDay;-><init>(Lcom/spotifry/music/data/db/SongEntity;Ljava/time/LocalDate;ILjava/util/ArrayList;)V

    .line 708
    goto :goto_2c8

    .line 709
    :cond_2c4
    move-object/from16 v25, v2

    .line 711
    move-object/from16 v2, p0

    .line 713
    :goto_2c8
    new-instance v3, Ljava/util/LinkedHashMap;

    .line 715
    invoke-direct {v3}, Ljava/util/LinkedHashMap;-><init>()V

    .line 718
    invoke-virtual/range {v25 .. v25}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 721
    move-result-object v10

    .line 722
    :goto_2d1
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 725
    move-result v12

    .line 726
    if-eqz v12, :cond_2f8

    .line 728
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 731
    move-result-object v12

    .line 732
    move-object v13, v12

    .line 733
    check-cast v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 735
    iget-object v13, v13, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 737
    invoke-static {v13}, Ljava/time/YearMonth;->from(Ljava/time/temporal/TemporalAccessor;)Ljava/time/YearMonth;

    .line 740
    move-result-object v13

    .line 741
    invoke-virtual {v3, v13}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 744
    move-result-object v14

    .line 745
    if-nez v14, :cond_2f2

    .line 747
    new-instance v14, Ljava/util/ArrayList;

    .line 749
    invoke-direct {v14}, Ljava/util/ArrayList;-><init>()V

    .line 752
    invoke-interface {v3, v13, v14}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 755
    :cond_2f2
    check-cast v14, Ljava/util/List;

    .line 757
    invoke-interface {v14, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 760
    goto :goto_2d1

    .line 761
    :cond_2f8
    new-instance v10, Ljava/util/TreeMap;

    .line 763
    invoke-direct {v10, v3}, Ljava/util/TreeMap;-><init>(Ljava/util/Map;)V

    .line 766
    new-instance v3, Ljava/util/LinkedHashMap;

    .line 768
    invoke-virtual {v10}, Ljava/util/TreeMap;->size()I

    .line 771
    move-result v12

    .line 772
    invoke-static {v12}, Lkotlin/collections/MapsKt__MapsKt;->mapCapacity(I)I

    .line 775
    move-result v12

    .line 776
    invoke-direct {v3, v12}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 779
    invoke-virtual {v10}, Ljava/util/TreeMap;->entrySet()Ljava/util/Set;

    .line 782
    move-result-object v10

    .line 783
    check-cast v10, Ljava/lang/Iterable;

    .line 785
    invoke-interface {v10}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 788
    move-result-object v10

    .line 789
    :goto_314
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 792
    move-result v12

    .line 793
    if-eqz v12, :cond_38a

    .line 795
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 798
    move-result-object v12

    .line 799
    check-cast v12, Ljava/util/Map$Entry;

    .line 801
    invoke-interface {v12}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 804
    move-result-object v13

    .line 805
    invoke-interface {v12}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 808
    move-result-object v12

    .line 809
    check-cast v12, Ljava/util/List;

    .line 811
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 814
    new-instance v14, Ljava/util/LinkedHashMap;

    .line 816
    invoke-direct {v14}, Ljava/util/LinkedHashMap;-><init>()V

    .line 819
    invoke-interface {v12}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 822
    move-result-object v12

    .line 823
    :goto_336
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 826
    move-result v15

    .line 827
    if-eqz v15, :cond_367

    .line 829
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 832
    move-result-object v15

    .line 833
    move-object/from16 v25, v2

    .line 835
    move-object v2, v15

    .line 836
    check-cast v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 838
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 840
    iget-object v2, v2, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 842
    invoke-virtual {v14, v2}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 845
    move-result-object v26

    .line 846
    move-object/from16 v27, v5

    .line 848
    if-nez v26, :cond_35b

    .line 850
    new-instance v5, Ljava/util/ArrayList;

    .line 852
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 855
    invoke-interface {v14, v2, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 858
    move-object/from16 v26, v5

    .line 860
    :cond_35b
    move-object/from16 v2, v26

    .line 862
    check-cast v2, Ljava/util/List;

    .line 864
    invoke-interface {v2, v15}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 867
    move-object/from16 v2, v25

    .line 869
    move-object/from16 v5, v27

    .line 871
    goto :goto_336

    .line 872
    :cond_367
    move-object/from16 v25, v2

    .line 874
    move-object/from16 v27, v5

    .line 876
    invoke-virtual {v14}, Ljava/util/LinkedHashMap;->values()Ljava/util/Collection;

    .line 879
    move-result-object v2

    .line 880
    check-cast v2, Ljava/lang/Iterable;

    .line 882
    new-instance v5, Lcom/spotifry/music/data/Backups$applyTheRest$$inlined$sortedBy$1;

    .line 884
    const/16 v12, 0x15

    .line 886
    invoke-direct {v5, v12}, Lcom/spotifry/music/data/Backups$applyTheRest$$inlined$sortedBy$1;-><init>(B)V

    .line 889
    new-instance v12, Lcom/spotifry/music/data/PlaylistOrder$arrange$$inlined$thenBy$1;

    .line 891
    const/4 v14, 0x6

    .line 892
    invoke-direct {v12, v5, v14}, Lcom/spotifry/music/data/PlaylistOrder$arrange$$inlined$thenBy$1;-><init>(Ljava/lang/Object;B)V

    .line 895
    invoke-static {v2, v12}, Lkotlin/collections/CollectionsKt;->sortedWith(Ljava/lang/Iterable;Ljava/util/Comparator;)Ljava/util/List;

    .line 898
    move-result-object v2

    .line 899
    invoke-interface {v3, v13, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 902
    move-object/from16 v2, v25

    .line 904
    move-object/from16 v5, v27

    .line 906
    goto :goto_314

    .line 907
    :cond_38a
    move-object/from16 v25, v2

    .line 909
    move-object/from16 v27, v5

    .line 911
    new-instance v12, Ljava/util/ArrayList;

    .line 913
    invoke-interface {v3}, Ljava/util/Map;->size()I

    .line 916
    move-result v2

    .line 917
    invoke-direct {v12, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 920
    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 923
    move-result-object v2

    .line 924
    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 927
    move-result-object v2

    .line 928
    :goto_39f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 931
    move-result v5

    .line 932
    if-eqz v5, :cond_3e0

    .line 934
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 937
    move-result-object v5

    .line 938
    check-cast v5, Ljava/util/Map$Entry;

    .line 940
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 943
    move-result-object v10

    .line 944
    check-cast v10, Ljava/time/YearMonth;

    .line 946
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 949
    move-result-object v5

    .line 950
    check-cast v5, Ljava/util/List;

    .line 952
    new-instance v13, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 954
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 957
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 960
    move-result-object v14

    .line 961
    check-cast v14, Ljava/util/List;

    .line 963
    invoke-static {v14}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 966
    move-result-object v14

    .line 967
    check-cast v14, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 969
    iget-object v14, v14, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 971
    iget-object v14, v14, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 973
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 976
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 979
    move-result-object v5

    .line 980
    check-cast v5, Ljava/util/List;

    .line 982
    invoke-interface {v5}, Ljava/util/List;->size()I

    .line 985
    move-result v5

    .line 986
    invoke-direct {v13, v10, v14, v5}, Lcom/spotifry/music/data/spotifried/MonthTop;-><init>(Ljava/time/YearMonth;Lcom/spotifry/music/data/db/SongEntity;I)V

    .line 989
    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 992
    goto :goto_39f

    .line 993
    :cond_3e0
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 995
    invoke-interface {v3}, Ljava/util/Map;->size()I

    .line 998
    move-result v5

    .line 999
    invoke-static {v5}, Lkotlin/collections/MapsKt__MapsKt;->mapCapacity(I)I

    .line 1002
    move-result v5

    .line 1003
    invoke-direct {v2, v5}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 1006
    invoke-virtual {v3}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 1009
    move-result-object v3

    .line 1010
    check-cast v3, Ljava/lang/Iterable;

    .line 1012
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1015
    move-result-object v3

    .line 1016
    :goto_3f7
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1019
    move-result v5

    .line 1020
    if-eqz v5, :cond_443

    .line 1022
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1025
    move-result-object v5

    .line 1026
    check-cast v5, Ljava/util/Map$Entry;

    .line 1028
    invoke-interface {v5}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1031
    move-result-object v10

    .line 1032
    invoke-interface {v5}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1035
    move-result-object v5

    .line 1036
    check-cast v5, Ljava/util/List;

    .line 1038
    const/4 v13, 0x5

    .line 1039
    invoke-static {v5, v13}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 1042
    move-result-object v5

    .line 1043
    new-instance v13, Ljava/util/ArrayList;

    .line 1045
    const/16 v14, 0xa

    .line 1047
    invoke-static {v5, v14}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 1050
    move-result v15

    .line 1051
    invoke-direct {v13, v15}, Ljava/util/ArrayList;-><init>(I)V

    .line 1054
    invoke-interface {v5}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1057
    move-result-object v5

    .line 1058
    :goto_421
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 1061
    move-result v14

    .line 1062
    if-eqz v14, :cond_43b

    .line 1064
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1067
    move-result-object v14

    .line 1068
    check-cast v14, Ljava/util/List;

    .line 1070
    invoke-static {v14}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 1073
    move-result-object v14

    .line 1074
    check-cast v14, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1076
    iget-object v14, v14, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1078
    iget-object v14, v14, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 1080
    invoke-virtual {v13, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1083
    goto :goto_421

    .line 1084
    :cond_43b
    invoke-static {v13}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 1087
    move-result-object v5

    .line 1088
    invoke-interface {v2, v10, v5}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1091
    goto :goto_3f7

    .line 1092
    :cond_443
    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->keySet()Ljava/util/Set;

    .line 1095
    move-result-object v3

    .line 1096
    check-cast v3, Ljava/lang/Iterable;

    .line 1098
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1101
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1104
    move-result-object v3

    .line 1105
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1108
    move-result v5

    .line 1109
    if-nez v5, :cond_459

    .line 1111
    sget-object v3, Lkotlin/collections/EmptyList;->INSTANCE:Lkotlin/collections/EmptyList;

    .line 1113
    goto :goto_477

    .line 1114
    :cond_459
    new-instance v5, Ljava/util/ArrayList;

    .line 1116
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 1119
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1122
    move-result-object v10

    .line 1123
    :goto_462
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1126
    move-result v13

    .line 1127
    if-eqz v13, :cond_476

    .line 1129
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1132
    move-result-object v13

    .line 1133
    new-instance v14, Lkotlin/Pair;

    .line 1135
    invoke-direct {v14, v10, v13}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 1138
    invoke-virtual {v5, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1141
    move-object v10, v13

    .line 1142
    goto :goto_462

    .line 1143
    :cond_476
    move-object v3, v5

    .line 1144
    :goto_477
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1147
    move-result-object v3

    .line 1148
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1151
    move-result v5

    .line 1152
    if-nez v5, :cond_484

    .line 1154
    move-object/from16 v5, p0

    .line 1156
    goto :goto_4da

    .line 1157
    :cond_484
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1160
    move-result-object v5

    .line 1161
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1164
    move-result v10

    .line 1165
    if-eqz v10, :cond_4da

    .line 1167
    move-object v10, v5

    .line 1168
    check-cast v10, Lkotlin/Pair;

    .line 1170
    iget-object v13, v10, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 1172
    check-cast v13, Ljava/time/YearMonth;

    .line 1174
    iget-object v10, v10, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 1176
    check-cast v10, Ljava/time/YearMonth;

    .line 1178
    invoke-static {v13, v2}, Lkotlin/collections/MapsKt__MapsKt;->getValue(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 1181
    move-result-object v13

    .line 1182
    check-cast v13, Ljava/lang/Iterable;

    .line 1184
    invoke-static {v10, v2}, Lkotlin/collections/MapsKt__MapsKt;->getValue(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 1187
    move-result-object v10

    .line 1188
    check-cast v10, Ljava/lang/Iterable;

    .line 1190
    invoke-static {v13, v10}, Lkotlin/collections/CollectionsKt;->intersect(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/Set;

    .line 1193
    move-result-object v10

    .line 1194
    invoke-interface {v10}, Ljava/util/Set;->size()I

    .line 1197
    move-result v10

    .line 1198
    :goto_4ad
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1201
    move-result-object v13

    .line 1202
    move-object v14, v13

    .line 1203
    check-cast v14, Lkotlin/Pair;

    .line 1205
    iget-object v15, v14, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 1207
    check-cast v15, Ljava/time/YearMonth;

    .line 1209
    iget-object v14, v14, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 1211
    check-cast v14, Ljava/time/YearMonth;

    .line 1213
    invoke-static {v15, v2}, Lkotlin/collections/MapsKt__MapsKt;->getValue(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 1216
    move-result-object v15

    .line 1217
    check-cast v15, Ljava/lang/Iterable;

    .line 1219
    invoke-static {v14, v2}, Lkotlin/collections/MapsKt__MapsKt;->getValue(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 1222
    move-result-object v14

    .line 1223
    check-cast v14, Ljava/lang/Iterable;

    .line 1225
    invoke-static {v15, v14}, Lkotlin/collections/CollectionsKt;->intersect(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/Set;

    .line 1228
    move-result-object v14

    .line 1229
    invoke-interface {v14}, Ljava/util/Set;->size()I

    .line 1232
    move-result v14

    .line 1233
    if-le v10, v14, :cond_4d4

    .line 1235
    move-object v5, v13

    .line 1236
    move v10, v14

    .line 1237
    :cond_4d4
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1240
    move-result v13

    .line 1241
    if-nez v13, :cond_b67

    .line 1243
    :cond_4da
    :goto_4da
    check-cast v5, Lkotlin/Pair;

    .line 1245
    if-eqz v5, :cond_4e4

    .line 1247
    iget-object v2, v5, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 1249
    check-cast v2, Ljava/time/YearMonth;

    .line 1251
    move-object v13, v2

    .line 1252
    goto :goto_4e6

    .line 1253
    :cond_4e4
    move-object/from16 v13, p0

    .line 1255
    :goto_4e6
    new-instance v2, Ljava/util/ArrayList;

    .line 1257
    const/16 v14, 0xa

    .line 1259
    invoke-static {v1, v14}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 1262
    move-result v3

    .line 1263
    invoke-direct {v2, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 1266
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1269
    move-result-object v3

    .line 1270
    :goto_4f5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1273
    move-result v5

    .line 1274
    if-eqz v5, :cond_507

    .line 1276
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1279
    move-result-object v5

    .line 1280
    check-cast v5, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1282
    iget-object v5, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 1284
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1287
    goto :goto_4f5

    .line 1288
    :cond_507
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/util/ArrayList;)Ljava/util/List;

    .line 1291
    move-result-object v2

    .line 1292
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    .line 1295
    move-result-object v2

    .line 1296
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1299
    move-result-object v2

    .line 1300
    const/4 v5, 0x0

    .line 1301
    const/4 v14, 0x0

    .line 1302
    move-object/from16 v3, p0

    .line 1304
    :goto_517
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1307
    move-result v10

    .line 1308
    if-eqz v10, :cond_545

    .line 1310
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1313
    move-result-object v10

    .line 1314
    check-cast v10, Ljava/time/LocalDate;

    .line 1316
    move-object v15, v1

    .line 1317
    move-object/from16 v26, v2

    .line 1319
    if-eqz v3, :cond_52f

    .line 1321
    const-wide/16 v1, 0x1

    .line 1323
    invoke-virtual {v3, v1, v2}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 1326
    move-result-object v1

    .line 1327
    goto :goto_531

    .line 1328
    :cond_52f
    move-object/from16 v1, p0

    .line 1330
    :goto_531
    invoke-static {v1, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1333
    move-result v1

    .line 1334
    if-eqz v1, :cond_53a

    .line 1336
    add-int/lit8 v5, v5, 0x1

    .line 1338
    goto :goto_53c

    .line 1339
    :cond_53a
    move/from16 v5, v21

    .line 1341
    :goto_53c
    invoke-static {v14, v5}, Ljava/lang/Math;->max(II)I

    .line 1344
    move-result v14

    .line 1345
    move-object v3, v10

    .line 1346
    move-object v1, v15

    .line 1347
    move-object/from16 v2, v26

    .line 1349
    goto :goto_517

    .line 1350
    :cond_545
    move-object v15, v1

    .line 1351
    new-instance v1, Ljava/util/ArrayList;

    .line 1353
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 1356
    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1359
    move-result-object v2

    .line 1360
    :cond_54f
    :goto_54f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1363
    move-result v3

    .line 1364
    if-eqz v3, :cond_568

    .line 1366
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1369
    move-result-object v3

    .line 1370
    move-object v5, v3

    .line 1371
    check-cast v5, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1373
    iget-object v5, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1375
    iget v5, v5, Lcom/spotifry/music/data/db/ListenRow;->secondsHeard:I

    .line 1377
    const/16 v10, 0x1e

    .line 1379
    if-lt v5, v10, :cond_54f

    .line 1381
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1384
    goto :goto_54f

    .line 1385
    :cond_568
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 1387
    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 1390
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1393
    move-result-object v1

    .line 1394
    :goto_571
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 1397
    move-result v3

    .line 1398
    if-eqz v3, :cond_596

    .line 1400
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1403
    move-result-object v3

    .line 1404
    move-object v5, v3

    .line 1405
    check-cast v5, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1407
    iget-object v5, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1409
    iget-object v5, v5, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 1411
    invoke-virtual {v2, v5}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1414
    move-result-object v10

    .line 1415
    if-nez v10, :cond_590

    .line 1417
    new-instance v10, Ljava/util/ArrayList;

    .line 1419
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 1422
    invoke-interface {v2, v5, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1425
    :cond_590
    check-cast v10, Ljava/util/List;

    .line 1427
    invoke-interface {v10, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1430
    goto :goto_571

    .line 1431
    :cond_596
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 1433
    invoke-interface {v2}, Ljava/util/Map;->size()I

    .line 1436
    move-result v3

    .line 1437
    invoke-static {v3}, Lkotlin/collections/MapsKt__MapsKt;->mapCapacity(I)I

    .line 1440
    move-result v3

    .line 1441
    invoke-direct {v1, v3}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 1444
    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 1447
    move-result-object v2

    .line 1448
    check-cast v2, Ljava/lang/Iterable;

    .line 1450
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1453
    move-result-object v2

    .line 1454
    :goto_5ad
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1457
    move-result v3

    .line 1458
    if-eqz v3, :cond_5f9

    .line 1460
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1463
    move-result-object v3

    .line 1464
    check-cast v3, Ljava/util/Map$Entry;

    .line 1466
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1469
    move-result-object v5

    .line 1470
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1473
    move-result-object v3

    .line 1474
    check-cast v3, Ljava/util/List;

    .line 1476
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1479
    move-result-object v3

    .line 1480
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1483
    move-result v10

    .line 1484
    if-eqz v10, :cond_5f5

    .line 1486
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1489
    move-result-object v10

    .line 1490
    check-cast v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1492
    iget-object v10, v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 1494
    :goto_5d5
    invoke-interface {v3}, Ljava/util/Iterator;->hasNext()Z

    .line 1497
    move-result v26

    .line 1498
    if-eqz v26, :cond_5f1

    .line 1500
    invoke-interface {v3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1503
    move-result-object v26

    .line 1504
    move-object/from16 p2, v2

    .line 1506
    move-object/from16 v2, v26

    .line 1508
    check-cast v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1510
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 1512
    invoke-virtual {v10, v2}, Ljava/time/LocalDate;->compareTo(Ljava/lang/Object;)I

    .line 1515
    move-result v26

    .line 1516
    if-lez v26, :cond_5ee

    .line 1518
    move-object v10, v2

    .line 1519
    :cond_5ee
    move-object/from16 v2, p2

    .line 1521
    goto :goto_5d5

    .line 1522
    :cond_5f1
    invoke-interface {v1, v5, v10}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1525
    goto :goto_5ad

    .line 1526
    :cond_5f5
    invoke-static {}, Landroidx/media3/session/MediaSessionStub$$ExternalSyntheticLambda8;->m$1()V

    .line 1529
    return-object p0

    .line 1530
    :cond_5f9
    new-instance v2, Ljava/util/ArrayList;

    .line 1532
    move-object/from16 v3, v18

    .line 1534
    const/16 v5, 0xa

    .line 1536
    invoke-static {v3, v5}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 1539
    move-result v10

    .line 1540
    invoke-direct {v2, v10}, Ljava/util/ArrayList;-><init>(I)V

    .line 1543
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1546
    move-result-object v5

    .line 1547
    :goto_60a
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 1550
    move-result v10

    .line 1551
    if-eqz v10, :cond_61e

    .line 1553
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1556
    move-result-object v10

    .line 1557
    check-cast v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1559
    iget-object v10, v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1561
    iget-object v10, v10, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 1563
    invoke-virtual {v2, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1566
    goto :goto_60a

    .line 1567
    :cond_61e
    invoke-static {v2}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/util/ArrayList;)Ljava/util/List;

    .line 1570
    move-result-object v2

    .line 1571
    invoke-interface {v2}, Ljava/util/Collection;->isEmpty()Z

    .line 1574
    move-result v5

    .line 1575
    if-eqz v5, :cond_62a

    .line 1577
    const/4 v5, 0x0

    .line 1578
    goto :goto_652

    .line 1579
    :cond_62a
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1582
    move-result-object v2

    .line 1583
    const/4 v5, 0x0

    .line 1584
    :cond_62f
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1587
    move-result v10

    .line 1588
    if-eqz v10, :cond_652

    .line 1590
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1593
    move-result-object v10

    .line 1594
    check-cast v10, Ljava/lang/String;

    .line 1596
    invoke-virtual {v1, v10}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1599
    move-result-object v10

    .line 1600
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1603
    check-cast v10, Ljava/time/LocalDate;

    .line 1605
    invoke-virtual {v10, v4}, Ljava/time/LocalDate;->compareTo(Ljava/time/chrono/ChronoLocalDate;)I

    .line 1608
    move-result v10

    .line 1609
    if-ltz v10, :cond_62f

    .line 1611
    add-int/lit8 v5, v5, 0x1

    .line 1613
    if-gez v5, :cond_62f

    .line 1615
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwCountOverflow()V

    .line 1618
    throw p0

    .line 1619
    :cond_652
    :goto_652
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 1621
    invoke-direct {v1}, Ljava/util/LinkedHashMap;-><init>()V

    .line 1624
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1627
    move-result-object v2

    .line 1628
    :goto_65b
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1631
    move-result v4

    .line 1632
    if-eqz v4, :cond_688

    .line 1634
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1637
    move-result-object v4

    .line 1638
    move-object v10, v4

    .line 1639
    check-cast v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1641
    iget-object v10, v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1643
    iget-object v10, v10, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 1645
    invoke-virtual {v1, v10}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1648
    move-result-object v18

    .line 1649
    move-object/from16 p2, v2

    .line 1651
    if-nez v18, :cond_67e

    .line 1653
    new-instance v2, Ljava/util/ArrayList;

    .line 1655
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 1658
    invoke-interface {v1, v10, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1661
    move-object/from16 v18, v2

    .line 1663
    :cond_67e
    move-object/from16 v2, v18

    .line 1665
    check-cast v2, Ljava/util/List;

    .line 1667
    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1670
    move-object/from16 v2, p2

    .line 1672
    goto :goto_65b

    .line 1673
    :cond_688
    invoke-interface {v1}, Ljava/util/Map;->isEmpty()Z

    .line 1676
    move-result v2

    .line 1677
    const/4 v4, 0x2

    .line 1678
    if-eqz v2, :cond_691

    .line 1680
    const/4 v2, 0x0

    .line 1681
    goto :goto_6b5

    .line 1682
    :cond_691
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 1685
    move-result-object v1

    .line 1686
    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 1689
    move-result-object v1

    .line 1690
    const/4 v2, 0x0

    .line 1691
    :cond_69a
    :goto_69a
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 1694
    move-result v10

    .line 1695
    if-eqz v10, :cond_6b5

    .line 1697
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1700
    move-result-object v10

    .line 1701
    check-cast v10, Ljava/util/Map$Entry;

    .line 1703
    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1706
    move-result-object v10

    .line 1707
    check-cast v10, Ljava/util/List;

    .line 1709
    invoke-interface {v10}, Ljava/util/List;->size()I

    .line 1712
    move-result v10

    .line 1713
    if-lt v10, v4, :cond_69a

    .line 1715
    add-int/lit8 v2, v2, 0x1

    .line 1717
    goto :goto_69a

    .line 1718
    :cond_6b5
    :goto_6b5
    invoke-virtual {v15}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1721
    move-result-object v1

    .line 1722
    move v10, v4

    .line 1723
    move/from16 p2, v5

    .line 1725
    move-wide/from16 v4, v19

    .line 1727
    :goto_6be
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 1730
    move-result v18

    .line 1731
    if-eqz v18, :cond_6df

    .line 1733
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1736
    move-result-object v18

    .line 1737
    move/from16 v26, v10

    .line 1739
    move-object/from16 v10, v18

    .line 1741
    check-cast v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1743
    iget-object v10, v10, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1745
    iget v10, v10, Lcom/spotifry/music/data/db/ListenRow;->secondsHeard:I

    .line 1747
    move-object/from16 v28, v1

    .line 1749
    move/from16 v18, v2

    .line 1751
    int-to-long v1, v10

    .line 1752
    add-long/2addr v4, v1

    .line 1753
    move/from16 v2, v18

    .line 1755
    move/from16 v10, v26

    .line 1757
    move-object/from16 v1, v28

    .line 1759
    goto :goto_6be

    .line 1760
    :cond_6df
    move/from16 v18, v2

    .line 1762
    move/from16 v26, v10

    .line 1764
    new-instance v1, Ljava/util/ArrayList;

    .line 1766
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 1769
    invoke-virtual {v15}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1772
    move-result-object v2

    .line 1773
    :goto_6ec
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1776
    move-result v10

    .line 1777
    if-eqz v10, :cond_707

    .line 1779
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1782
    move-result-object v10

    .line 1783
    move-object/from16 v28, v2

    .line 1785
    move-object v2, v10

    .line 1786
    check-cast v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1788
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1790
    iget-object v2, v2, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 1792
    if-eqz v2, :cond_704

    .line 1794
    invoke-virtual {v1, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1797
    :cond_704
    move-object/from16 v2, v28

    .line 1799
    goto :goto_6ec

    .line 1800
    :cond_707
    new-instance v2, Ljava/util/LinkedHashMap;

    .line 1802
    invoke-direct {v2}, Ljava/util/LinkedHashMap;-><init>()V

    .line 1805
    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1808
    move-result-object v1

    .line 1809
    :goto_710
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 1812
    move-result v10

    .line 1813
    if-eqz v10, :cond_74a

    .line 1815
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1818
    move-result-object v10

    .line 1819
    move-object/from16 v28, v1

    .line 1821
    move-object v1, v10

    .line 1822
    check-cast v1, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1824
    iget-object v1, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1826
    iget-object v1, v1, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 1828
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1831
    iget-object v1, v1, Lcom/spotifry/music/data/db/SongEntity;->artist:Ljava/lang/String;

    .line 1833
    invoke-static {v1}, Lcom/spotifry/music/data/Log;->cleanArtist(Ljava/lang/String;)Ljava/lang/String;

    .line 1836
    move-result-object v1

    .line 1837
    invoke-virtual {v2, v1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 1840
    move-result-object v29

    .line 1841
    move/from16 v30, v6

    .line 1843
    if-nez v29, :cond_73e

    .line 1845
    new-instance v6, Ljava/util/ArrayList;

    .line 1847
    invoke-direct {v6}, Ljava/util/ArrayList;-><init>()V

    .line 1850
    invoke-interface {v2, v1, v6}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1853
    move-object/from16 v29, v6

    .line 1855
    :cond_73e
    move-object/from16 v1, v29

    .line 1857
    check-cast v1, Ljava/util/List;

    .line 1859
    invoke-interface {v1, v10}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1862
    move-object/from16 v1, v28

    .line 1864
    move/from16 v6, v30

    .line 1866
    goto :goto_710

    .line 1867
    :cond_74a
    move/from16 v30, v6

    .line 1869
    new-instance v1, Ljava/util/LinkedHashMap;

    .line 1871
    invoke-interface {v2}, Ljava/util/Map;->size()I

    .line 1874
    move-result v6

    .line 1875
    invoke-static {v6}, Lkotlin/collections/MapsKt__MapsKt;->mapCapacity(I)I

    .line 1878
    move-result v6

    .line 1879
    invoke-direct {v1, v6}, Ljava/util/LinkedHashMap;-><init>(I)V

    .line 1882
    invoke-virtual {v2}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 1885
    move-result-object v2

    .line 1886
    check-cast v2, Ljava/lang/Iterable;

    .line 1888
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1891
    move-result-object v2

    .line 1892
    :goto_763
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 1895
    move-result v6

    .line 1896
    if-eqz v6, :cond_7ad

    .line 1898
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1901
    move-result-object v6

    .line 1902
    check-cast v6, Ljava/util/Map$Entry;

    .line 1904
    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 1907
    move-result-object v10

    .line 1908
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 1911
    move-result-object v6

    .line 1912
    check-cast v6, Ljava/util/List;

    .line 1914
    invoke-interface {v6}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1917
    move-result-object v6

    .line 1918
    move-wide/from16 v28, v19

    .line 1920
    :goto_77f
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 1923
    move-result v31

    .line 1924
    if-eqz v31, :cond_7a1

    .line 1926
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1929
    move-result-object v31

    .line 1930
    move-object/from16 v32, v2

    .line 1932
    move-object/from16 v2, v31

    .line 1934
    check-cast v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 1936
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 1938
    iget v2, v2, Lcom/spotifry/music/data/db/ListenRow;->secondsHeard:I

    .line 1940
    move-object/from16 v33, v6

    .line 1942
    move-object/from16 v31, v7

    .line 1944
    int-to-long v6, v2

    .line 1945
    add-long v28, v28, v6

    .line 1947
    move-object/from16 v7, v31

    .line 1949
    move-object/from16 v2, v32

    .line 1951
    move-object/from16 v6, v33

    .line 1953
    goto :goto_77f

    .line 1954
    :cond_7a1
    move-object/from16 v32, v2

    .line 1956
    invoke-static/range {v28 .. v29}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 1959
    move-result-object v2

    .line 1960
    invoke-interface {v1, v10, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1963
    move-object/from16 v2, v32

    .line 1965
    goto :goto_763

    .line 1966
    :cond_7ad
    move-object/from16 v31, v7

    .line 1968
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 1971
    move-result-object v1

    .line 1972
    check-cast v1, Ljava/lang/Iterable;

    .line 1974
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1977
    move-result-object v1

    .line 1978
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 1981
    move-result v2

    .line 1982
    if-nez v2, :cond_7c2

    .line 1984
    move-object/from16 v2, p0

    .line 1986
    goto :goto_7f8

    .line 1987
    :cond_7c2
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1990
    move-result-object v2

    .line 1991
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 1994
    move-result v6

    .line 1995
    if-eqz v6, :cond_7f8

    .line 1997
    move-object v6, v2

    .line 1998
    check-cast v6, Ljava/util/Map$Entry;

    .line 2000
    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 2003
    move-result-object v6

    .line 2004
    check-cast v6, Ljava/lang/Number;

    .line 2006
    invoke-virtual {v6}, Ljava/lang/Number;->longValue()J

    .line 2009
    move-result-wide v6

    .line 2010
    :goto_7d9
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2013
    move-result-object v10

    .line 2014
    move-object/from16 v28, v10

    .line 2016
    check-cast v28, Ljava/util/Map$Entry;

    .line 2018
    invoke-interface/range {v28 .. v28}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 2021
    move-result-object v28

    .line 2022
    check-cast v28, Ljava/lang/Number;

    .line 2024
    invoke-virtual/range {v28 .. v28}, Ljava/lang/Number;->longValue()J

    .line 2027
    move-result-wide v28

    .line 2028
    cmp-long v32, v6, v28

    .line 2030
    if-gez v32, :cond_7f2

    .line 2032
    move-object v2, v10

    .line 2033
    move-wide/from16 v6, v28

    .line 2035
    :cond_7f2
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 2038
    move-result v10

    .line 2039
    if-nez v10, :cond_b5b

    .line 2041
    :cond_7f8
    :goto_7f8
    check-cast v2, Ljava/util/Map$Entry;

    .line 2043
    if-eqz v2, :cond_81f

    .line 2045
    cmp-long v1, v4, v19

    .line 2047
    if-gtz v1, :cond_802

    .line 2049
    move-object/from16 v2, p0

    .line 2051
    :cond_802
    if-eqz v2, :cond_81f

    .line 2053
    new-instance v1, Lcom/spotifry/music/data/spotifried/ArtistShare;

    .line 2055
    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 2058
    move-result-object v6

    .line 2059
    check-cast v6, Ljava/lang/String;

    .line 2061
    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 2064
    move-result-object v2

    .line 2065
    check-cast v2, Ljava/lang/Number;

    .line 2067
    move-object/from16 v28, v9

    .line 2069
    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    .line 2072
    move-result-wide v9

    .line 2073
    long-to-float v2, v9

    .line 2074
    long-to-float v4, v4

    .line 2075
    div-float/2addr v2, v4

    .line 2076
    invoke-direct {v1, v6, v2}, Lcom/spotifry/music/data/spotifried/ArtistShare;-><init>(Ljava/lang/String;F)V

    .line 2079
    goto :goto_823

    .line 2080
    :cond_81f
    move-object/from16 v28, v9

    .line 2082
    move-object/from16 v1, p0

    .line 2084
    :goto_823
    new-instance v2, Ljava/util/ArrayList;

    .line 2086
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 2089
    invoke-virtual {v3}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2092
    move-result-object v4

    .line 2093
    :cond_82c
    :goto_82c
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 2096
    move-result v5

    .line 2097
    if-eqz v5, :cond_843

    .line 2099
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2102
    move-result-object v5

    .line 2103
    move-object v6, v5

    .line 2104
    check-cast v6, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2106
    iget-object v6, v6, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 2108
    iget-object v6, v6, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 2110
    if-eqz v6, :cond_82c

    .line 2112
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2115
    goto :goto_82c

    .line 2116
    :cond_843
    new-instance v4, Ljava/util/ArrayList;

    .line 2118
    const/16 v5, 0xa

    .line 2120
    invoke-static {v2, v5}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 2123
    move-result v6

    .line 2124
    invoke-direct {v4, v6}, Ljava/util/ArrayList;-><init>(I)V

    .line 2127
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2130
    move-result-object v2

    .line 2131
    :goto_852
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 2134
    move-result v5

    .line 2135
    if-eqz v5, :cond_866

    .line 2137
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2140
    move-result-object v5

    .line 2141
    check-cast v5, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2143
    iget-object v5, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 2145
    iget-object v5, v5, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 2147
    invoke-virtual {v4, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2150
    goto :goto_852

    .line 2151
    :cond_866
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/util/ArrayList;)Ljava/util/List;

    .line 2154
    move-result-object v9

    .line 2155
    new-instance v2, Ljava/util/ArrayList;

    .line 2157
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 2160
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 2163
    move-result-object v4

    .line 2164
    :cond_873
    :goto_873
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 2167
    move-result v5

    .line 2168
    if-eqz v5, :cond_88a

    .line 2170
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2173
    move-result-object v5

    .line 2174
    move-object v6, v5

    .line 2175
    check-cast v6, Ljava/lang/String;

    .line 2177
    invoke-interface {v0, v6}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    .line 2180
    move-result v6

    .line 2181
    if-eqz v6, :cond_873

    .line 2183
    invoke-virtual {v2, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2186
    goto :goto_873

    .line 2187
    :cond_88a
    new-instance v10, Ljava/util/ArrayList;

    .line 2189
    const/16 v4, 0xa

    .line 2191
    invoke-static {v2, v4}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 2194
    move-result v4

    .line 2195
    invoke-direct {v10, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 2198
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2201
    move-result-object v4

    .line 2202
    :goto_899
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 2205
    move-result v5

    .line 2206
    if-eqz v5, :cond_8b7

    .line 2208
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2211
    move-result-object v5

    .line 2212
    check-cast v5, Ljava/lang/String;

    .line 2214
    invoke-static {v5, v0}, Lkotlin/collections/MapsKt__MapsKt;->getValue(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 2217
    move-result-object v5

    .line 2218
    check-cast v5, Ljava/lang/Number;

    .line 2220
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 2223
    move-result v5

    .line 2224
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2227
    move-result-object v5

    .line 2228
    invoke-virtual {v10, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2231
    goto :goto_899

    .line 2232
    :cond_8b7
    invoke-virtual {v2}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2235
    move-result-object v17

    .line 2236
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    .line 2239
    move-result v2

    .line 2240
    if-nez v2, :cond_8c4

    .line 2242
    move-object/from16 v2, p0

    .line 2244
    goto :goto_8f6

    .line 2245
    :cond_8c4
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2248
    move-result-object v2

    .line 2249
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    .line 2252
    move-result v4

    .line 2253
    if-eqz v4, :cond_8f6

    .line 2255
    move-object v4, v2

    .line 2256
    check-cast v4, Ljava/lang/String;

    .line 2258
    invoke-static {v4, v0}, Lkotlin/collections/MapsKt__MapsKt;->getValue(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 2261
    move-result-object v4

    .line 2262
    check-cast v4, Ljava/lang/Number;

    .line 2264
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 2267
    move-result v4

    .line 2268
    :goto_8db
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2271
    move-result-object v5

    .line 2272
    move-object v6, v5

    .line 2273
    check-cast v6, Ljava/lang/String;

    .line 2275
    invoke-static {v6, v0}, Lkotlin/collections/MapsKt__MapsKt;->getValue(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 2278
    move-result-object v6

    .line 2279
    check-cast v6, Ljava/lang/Number;

    .line 2281
    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    .line 2284
    move-result v6

    .line 2285
    if-le v4, v6, :cond_8f0

    .line 2287
    move-object v2, v5

    .line 2288
    move v4, v6

    .line 2289
    :cond_8f0
    invoke-interface/range {v17 .. v17}, Ljava/util/Iterator;->hasNext()Z

    .line 2292
    move-result v5

    .line 2293
    if-nez v5, :cond_b4f

    .line 2295
    :cond_8f6
    :goto_8f6
    check-cast v2, Ljava/lang/String;

    .line 2297
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2300
    move-result v4

    .line 2301
    const/16 v5, 0x14

    .line 2303
    if-lt v4, v5, :cond_903

    .line 2305
    move/from16 v4, v21

    .line 2307
    goto :goto_904

    .line 2308
    :cond_903
    const/4 v4, 0x0

    .line 2309
    :goto_904
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2312
    move-result v33

    .line 2313
    invoke-interface {v9}, Ljava/util/List;->size()I

    .line 2316
    move-result v34

    .line 2317
    invoke-interface {v9}, Ljava/util/Collection;->isEmpty()Z

    .line 2320
    move-result v5

    .line 2321
    if-eqz v5, :cond_915

    .line 2323
    const/16 v35, 0x0

    .line 2325
    goto :goto_938

    .line 2326
    :cond_915
    invoke-interface {v9}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 2329
    move-result-object v5

    .line 2330
    const/4 v6, 0x0

    .line 2331
    :cond_91a
    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    .line 2334
    move-result v7

    .line 2335
    if-eqz v7, :cond_936

    .line 2337
    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2340
    move-result-object v7

    .line 2341
    check-cast v7, Ljava/lang/String;

    .line 2343
    move-object/from16 v9, p3

    .line 2345
    invoke-interface {v9, v7}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 2348
    move-result v7

    .line 2349
    if-nez v7, :cond_91a

    .line 2351
    add-int/lit8 v6, v6, 0x1

    .line 2353
    if-gez v6, :cond_91a

    .line 2355
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwCountOverflow()V

    .line 2358
    throw p0

    .line 2359
    :cond_936
    move/from16 v35, v6

    .line 2361
    :goto_938
    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    .line 2364
    move-result-object v36

    .line 2365
    if-eqz v4, :cond_97e

    .line 2367
    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    .line 2370
    move-result-object v4

    .line 2371
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2374
    move-result v5

    .line 2375
    add-int/lit8 v5, v5, -0x1

    .line 2377
    div-int/lit8 v5, v5, 0x2

    .line 2379
    invoke-interface {v4, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2382
    move-result-object v4

    .line 2383
    check-cast v4, Ljava/lang/Number;

    .line 2385
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 2388
    move-result v4

    .line 2389
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2392
    move-result-object v4

    .line 2393
    invoke-static {v10}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    .line 2396
    move-result-object v5

    .line 2397
    invoke-virtual {v10}, Ljava/util/ArrayList;->size()I

    .line 2400
    move-result v6

    .line 2401
    add-int/lit8 v6, v6, -0x1

    .line 2403
    div-int/lit8 v6, v6, 0x2

    .line 2405
    invoke-interface {v5, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2408
    move-result-object v5

    .line 2409
    check-cast v5, Ljava/lang/Number;

    .line 2411
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 2414
    move-result v5

    .line 2415
    invoke-virtual/range {v16 .. v16}, Ljava/time/LocalDate;->getYear()I

    .line 2418
    move-result v6

    .line 2419
    sub-int/2addr v6, v5

    .line 2420
    add-int/lit8 v6, v6, 0xe

    .line 2422
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2425
    move-result-object v5

    .line 2426
    move-object/from16 v37, v4

    .line 2428
    move-object/from16 v38, v5

    .line 2430
    goto :goto_982

    .line 2431
    :cond_97e
    move-object/from16 v37, p0

    .line 2433
    move-object/from16 v38, v37

    .line 2435
    :goto_982
    if-eqz v2, :cond_995

    .line 2437
    invoke-static {v2, v0}, Lkotlin/collections/MapsKt__MapsKt;->getValue(Ljava/lang/Object;Ljava/util/Map;)Ljava/lang/Object;

    .line 2440
    move-result-object v0

    .line 2441
    check-cast v0, Ljava/lang/Number;

    .line 2443
    invoke-virtual {v0}, Ljava/lang/Number;->intValue()I

    .line 2446
    move-result v0

    .line 2447
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2450
    move-result-object v0

    .line 2451
    move-object/from16 v39, v0

    .line 2453
    goto :goto_997

    .line 2454
    :cond_995
    move-object/from16 v39, p0

    .line 2456
    :goto_997
    if-eqz v2, :cond_9c4

    .line 2458
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 2461
    move-result v0

    .line 2462
    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->listIterator(I)Ljava/util/ListIterator;

    .line 2465
    move-result-object v0

    .line 2466
    :cond_9a1
    invoke-interface {v0}, Ljava/util/ListIterator;->hasPrevious()Z

    .line 2469
    move-result v4

    .line 2470
    if-eqz v4, :cond_9be

    .line 2472
    invoke-interface {v0}, Ljava/util/ListIterator;->previous()Ljava/lang/Object;

    .line 2475
    move-result-object v4

    .line 2476
    check-cast v4, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2478
    iget-object v5, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 2480
    iget-object v5, v5, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 2482
    invoke-static {v5, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2485
    move-result v5

    .line 2486
    if-eqz v5, :cond_9a1

    .line 2488
    iget-object v0, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 2490
    iget-object v0, v0, Lcom/spotifry/music/data/db/ListenRow;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 2492
    move-object/from16 v40, v0

    .line 2494
    goto :goto_9c6

    .line 2495
    :cond_9be
    const-string v0, "List contains no element matching the predicate."

    .line 2497
    invoke-static {v0}, Landroidx/media3/session/MediaSessionStub$$ExternalSyntheticLambda8;->m(Ljava/lang/String;)V

    .line 2500
    return-object p0

    .line 2501
    :cond_9c4
    move-object/from16 v40, p0

    .line 2503
    :goto_9c6
    new-instance v32, Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 2505
    invoke-direct/range {v32 .. v40}, Lcom/spotifry/music/data/spotifried/AgeStats;-><init>(IIILjava/util/List;Ljava/lang/Integer;Ljava/lang/Integer;Ljava/lang/Integer;Lcom/spotifry/music/data/db/SongEntity;)V

    .line 2508
    move-object/from16 v23, v3

    .line 2510
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->size()I

    .line 2513
    move-result v3

    .line 2514
    invoke-virtual {v15}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2517
    move-result-object v0

    .line 2518
    move-wide/from16 v4, v19

    .line 2520
    :goto_9d7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 2523
    move-result v2

    .line 2524
    if-eqz v2, :cond_9ea

    .line 2526
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2529
    move-result-object v2

    .line 2530
    check-cast v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2532
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 2534
    iget v2, v2, Lcom/spotifry/music/data/db/ListenRow;->secondsHeard:I

    .line 2536
    int-to-long v6, v2

    .line 2537
    add-long/2addr v4, v6

    .line 2538
    goto :goto_9d7

    .line 2539
    :cond_9ea
    new-instance v0, Ljava/util/HashSet;

    .line 2541
    invoke-direct {v0}, Ljava/util/HashSet;-><init>()V

    .line 2544
    new-instance v2, Ljava/util/ArrayList;

    .line 2546
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 2549
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2552
    move-result-object v6

    .line 2553
    :cond_9f8
    :goto_9f8
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 2556
    move-result v7

    .line 2557
    if-eqz v7, :cond_a13

    .line 2559
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2562
    move-result-object v7

    .line 2563
    move-object v9, v7

    .line 2564
    check-cast v9, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2566
    iget-object v9, v9, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->row:Lcom/spotifry/music/data/db/ListenRow;

    .line 2568
    iget-object v9, v9, Lcom/spotifry/music/data/db/ListenRow;->songId:Ljava/lang/String;

    .line 2570
    invoke-virtual {v0, v9}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    .line 2573
    move-result v9

    .line 2574
    if-eqz v9, :cond_9f8

    .line 2576
    invoke-virtual {v2, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2579
    goto :goto_9f8

    .line 2580
    :cond_a13
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 2583
    move-result v6

    .line 2584
    invoke-static {v11}, Lkotlin/collections/ArraysKt;->toList([J)Ljava/util/List;

    .line 2587
    move-result-object v0

    .line 2588
    new-instance v2, Lkotlin/ranges/IntRange;

    .line 2590
    add-int/lit8 v7, v30, -0x1

    .line 2592
    move/from16 v9, v21

    .line 2594
    const/4 v10, 0x0

    .line 2595
    invoke-direct {v2, v10, v7, v9}, Lkotlin/ranges/IntProgression;-><init>(III)V

    .line 2598
    invoke-virtual {v2}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 2601
    move-result-object v2

    .line 2602
    move-object v7, v2

    .line 2603
    check-cast v7, Lkotlin/ranges/IntProgressionIterator;

    .line 2605
    iget-boolean v9, v7, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 2607
    if-nez v9, :cond_a33

    .line 2609
    move-object/from16 v2, p0

    .line 2611
    goto :goto_a61

    .line 2612
    :cond_a33
    move-object/from16 v21, v2

    .line 2614
    check-cast v21, Lkotlin/collections/IntIterator;

    .line 2616
    invoke-virtual/range {v21 .. v21}, Lkotlin/collections/IntIterator;->next()Ljava/lang/Object;

    .line 2619
    move-result-object v2

    .line 2620
    iget-boolean v9, v7, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 2622
    if-eqz v9, :cond_a61

    .line 2624
    move-object v9, v2

    .line 2625
    check-cast v9, Ljava/lang/Number;

    .line 2627
    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    .line 2630
    move-result v9

    .line 2631
    aget-wide v15, v11, v9

    .line 2633
    :goto_a48
    invoke-virtual/range {v21 .. v21}, Lkotlin/collections/IntIterator;->next()Ljava/lang/Object;

    .line 2636
    move-result-object v9

    .line 2637
    move-object/from16 v17, v9

    .line 2639
    check-cast v17, Ljava/lang/Number;

    .line 2641
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->intValue()I

    .line 2644
    move-result v17

    .line 2645
    aget-wide v29, v11, v17

    .line 2647
    cmp-long v17, v15, v29

    .line 2649
    if-gez v17, :cond_a5d

    .line 2651
    move-object v2, v9

    .line 2652
    move-wide/from16 v15, v29

    .line 2654
    :cond_a5d
    iget-boolean v9, v7, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 2656
    if-nez v9, :cond_b39

    .line 2658
    :cond_a61
    :goto_a61
    check-cast v2, Ljava/lang/Integer;

    .line 2660
    if-eqz v2, :cond_a7e

    .line 2662
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 2665
    move-result v7

    .line 2666
    aget-wide v15, v11, v7

    .line 2668
    cmp-long v7, v15, v19

    .line 2670
    if-gtz v7, :cond_a71

    .line 2672
    move-object/from16 v2, p0

    .line 2674
    :cond_a71
    if-eqz v2, :cond_a7e

    .line 2676
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 2679
    move-result v2

    .line 2680
    int-to-long v10, v2

    .line 2681
    invoke-virtual {v8, v10, v11}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 2684
    move-result-object v2

    .line 2685
    move-object v9, v2

    .line 2686
    goto :goto_a80

    .line 2687
    :cond_a7e
    move-object/from16 v9, p0

    .line 2689
    :goto_a80
    invoke-static/range {v28 .. v28}, Lkotlin/collections/ArraysKt;->toList([J)Ljava/util/List;

    .line 2692
    move-result-object v10

    .line 2693
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->isEmpty()Z

    .line 2696
    move-result v2

    .line 2697
    if-eqz v2, :cond_a8c

    .line 2699
    const/4 v7, 0x0

    .line 2700
    goto :goto_aa8

    .line 2701
    :cond_a8c
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2704
    move-result-object v2

    .line 2705
    const/4 v7, 0x0

    .line 2706
    :cond_a91
    :goto_a91
    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    .line 2709
    move-result v11

    .line 2710
    if-eqz v11, :cond_aa8

    .line 2712
    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2715
    move-result-object v11

    .line 2716
    check-cast v11, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2718
    iget v11, v11, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->hour:I

    .line 2720
    const/16 v15, 0x9

    .line 2722
    if-ge v11, v15, :cond_a91

    .line 2724
    add-int/lit8 v7, v7, 0x1

    .line 2726
    if-ltz v7, :cond_ada

    .line 2728
    goto :goto_a91

    .line 2729
    :cond_aa8
    :goto_aa8
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->isEmpty()Z

    .line 2732
    move-result v2

    .line 2733
    if-eqz v2, :cond_ab0

    .line 2735
    const/4 v2, 0x0

    .line 2736
    goto :goto_ab7

    .line 2737
    :cond_ab0
    int-to-float v2, v7

    .line 2738
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->size()I

    .line 2741
    move-result v7

    .line 2742
    int-to-float v7, v7

    .line 2743
    div-float/2addr v2, v7

    .line 2744
    :goto_ab7
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->isEmpty()Z

    .line 2747
    move-result v7

    .line 2748
    if-eqz v7, :cond_abf

    .line 2750
    const/4 v7, 0x0

    .line 2751
    goto :goto_ae0

    .line 2752
    :cond_abf
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2755
    move-result-object v7

    .line 2756
    const/16 v22, 0x0

    .line 2758
    :cond_ac5
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 2761
    move-result v15

    .line 2762
    if-eqz v15, :cond_ade

    .line 2764
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2767
    move-result-object v15

    .line 2768
    check-cast v15, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2770
    iget v15, v15, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->hour:I

    .line 2772
    const/4 v11, 0x5

    .line 2773
    if-ge v15, v11, :cond_ac5

    .line 2775
    add-int/lit8 v22, v22, 0x1

    .line 2777
    if-gez v22, :cond_ac5

    .line 2779
    :cond_ada
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwCountOverflow()V

    .line 2782
    throw p0

    .line 2783
    :cond_ade
    move/from16 v7, v22

    .line 2785
    :goto_ae0
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->isEmpty()Z

    .line 2788
    move-result v11

    .line 2789
    if-eqz v11, :cond_ae9

    .line 2791
    const/16 v19, 0x0

    .line 2793
    goto :goto_af3

    .line 2794
    :cond_ae9
    int-to-float v7, v7

    .line 2795
    invoke-virtual/range {v23 .. v23}, Ljava/util/ArrayList;->size()I

    .line 2798
    move-result v11

    .line 2799
    int-to-float v11, v11

    .line 2800
    div-float v11, v7, v11

    .line 2802
    move/from16 v19, v11

    .line 2804
    :goto_af3
    invoke-virtual/range {v27 .. v27}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 2807
    move-result-object v7

    .line 2808
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 2811
    move-result v11

    .line 2812
    if-nez v11, :cond_b06

    .line 2814
    move-object/from16 v21, p0

    .line 2816
    :goto_aff
    move/from16 v16, v18

    .line 2818
    move/from16 v18, v2

    .line 2820
    move-object v2, v8

    .line 2821
    move-object v8, v0

    .line 2822
    goto :goto_b27

    .line 2823
    :cond_b06
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2826
    move-result-object v11

    .line 2827
    check-cast v11, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2829
    iget-object v11, v11, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 2831
    :cond_b0e
    :goto_b0e
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 2834
    move-result v15

    .line 2835
    if-eqz v15, :cond_b24

    .line 2837
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 2840
    move-result-object v15

    .line 2841
    check-cast v15, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;

    .line 2843
    iget-object v15, v15, Lcom/spotifry/music/data/spotifried/SpotifriedStatsKt$spotifriedStats$Line;->date:Ljava/time/LocalDate;

    .line 2845
    invoke-virtual {v11, v15}, Ljava/time/LocalDate;->compareTo(Ljava/lang/Object;)I

    .line 2848
    move-result v16

    .line 2849
    if-lez v16, :cond_b0e

    .line 2851
    move-object v11, v15

    .line 2852
    goto :goto_b0e

    .line 2853
    :cond_b24
    move-object/from16 v21, v11

    .line 2855
    goto :goto_aff

    .line 2856
    :goto_b27
    new-instance v0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 2858
    move/from16 v15, p2

    .line 2860
    move-object/from16 v17, v1

    .line 2862
    move-object/from16 v11, v25

    .line 2864
    move-object/from16 v7, v31

    .line 2866
    move-object/from16 v20, v32

    .line 2868
    move-object/from16 v1, p4

    .line 2870
    invoke-direct/range {v0 .. v21}, Lcom/spotifry/music/data/spotifried/SpotifriedStats;-><init>(Lcom/spotifry/music/data/spotifried/WrappedPeriod;Ljava/time/LocalDate;IJILcom/spotifry/music/data/TopSong;Ljava/util/List;Ljava/time/LocalDate;Ljava/util/List;Lcom/spotifry/music/data/spotifried/ObsessionDay;Ljava/util/ArrayList;Ljava/time/YearMonth;IIILcom/spotifry/music/data/spotifried/ArtistShare;FFLcom/spotifry/music/data/spotifried/AgeStats;Ljava/time/LocalDate;)V

    .line 2873
    return-object v0

    .line 2874
    :cond_b39
    move/from16 v29, v3

    .line 2876
    move-object v3, v1

    .line 2877
    move/from16 v1, v29

    .line 2879
    move/from16 v29, v18

    .line 2881
    move/from16 v18, v14

    .line 2883
    move-object v14, v13

    .line 2884
    move-object v13, v12

    .line 2885
    move-object v12, v3

    .line 2886
    move v3, v1

    .line 2887
    move-object v1, v12

    .line 2888
    move-object v12, v13

    .line 2889
    move-object v13, v14

    .line 2890
    move/from16 v14, v18

    .line 2892
    move/from16 v18, v29

    .line 2894
    goto/16 :goto_a48

    .line 2896
    :cond_b4f
    move/from16 v29, v18

    .line 2898
    move/from16 v18, v14

    .line 2900
    move-object v14, v13

    .line 2901
    move-object v13, v14

    .line 2902
    move/from16 v14, v18

    .line 2904
    move/from16 v18, v29

    .line 2906
    goto/16 :goto_8db

    .line 2908
    :cond_b5b
    move/from16 v29, v18

    .line 2910
    move/from16 v18, v14

    .line 2912
    move-object v14, v13

    .line 2913
    move-object v13, v14

    .line 2914
    move/from16 v14, v18

    .line 2916
    move/from16 v18, v29

    .line 2918
    goto/16 :goto_7d9

    .line 2920
    :cond_b67
    move-object/from16 v31, v7

    .line 2922
    move-object/from16 v7, v31

    .line 2924
    goto/16 :goto_4ad
.end method

###### Class com.spotifry.music.ui.spotifried.SpotifriedViewModel.AnonymousClass1 (com.spotifry.music.ui.spotifried.SpotifriedViewModel$1)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# static fields
.field public static final INSTANCE:Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 1
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;

    .line 3
    const-string v4, "now()Ljava/time/LocalDate;"

    .line 5
    const/4 v5, 0x0

    .line 6
    const/4 v1, 0x0

    .line 7
    const-class v2, Ljava/time/LocalDate;

    .line 9
    const-string v3, "now"

    .line 11
    invoke-direct/range {v0 .. v5}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 14
    sput-object v0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;->INSTANCE:Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 1

    .line 1
    invoke-static {}, Ljava/time/LocalDate;->now()Ljava/time/LocalDate;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
