###### Class com.spotifry.music.ui.spotifried.CardsKt$progress$1$1 (com.spotifry.music.ui.spotifried.CardsKt$progress$1$1)
.class public final Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $delayMs:I

.field public final synthetic $durationMs:I

.field public final synthetic $p:Landroidx/compose/animation/core/Animatable;

.field public label:Z


# direct methods
.method public constructor <init>(Landroidx/compose/animation/core/Animatable;IILkotlin/coroutines/Continuation;)V
    .registers 5

    .line 1
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$p:Landroidx/compose/animation/core/Animatable;

    .line 3
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$durationMs:I

    .line 5
    iput p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$delayMs:I

    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 5

    .line 1
    new-instance p1, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;

    .line 3
    iget v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$durationMs:I

    .line 5
    iget v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$delayMs:I

    .line 7
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$p:Landroidx/compose/animation/core/Animatable;

    .line 9
    invoke-direct {p1, p0, v0, v1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;-><init>(Landroidx/compose/animation/core/Animatable;IILkotlin/coroutines/Continuation;)V

    .line 12
    return-object p1
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 3

    .line 1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 3
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 5
    invoke-virtual {p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 8
    move-result-object p0

    .line 9
    check-cast p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;

    .line 11
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 13
    invoke-virtual {p0, p1}, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 16
    move-result-object p0

    .line 17
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget-boolean v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->label:Z

    .line 3
    const/4 v1, 0x1

    .line 4
    if-eqz v0, :cond_12

    .line 6
    if-ne v0, v1, :cond_b

    .line 8
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 11
    goto :goto_39

    .line 12
    :cond_b
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 14
    invoke-static {p0}, Lorg/jsoup/parser/CharacterReader$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 17
    const/4 p0, 0x0

    .line 18
    return-object p0

    .line 19
    :cond_12
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 22
    move p1, v1

    .line 23
    new-instance v1, Ljava/lang/Float;

    .line 25
    const/high16 v0, 0x3f800000    # 1.0f

    .line 27
    invoke-direct {v1, v0}, Ljava/lang/Float;-><init>(F)V

    .line 30
    sget-object v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->Ease:Landroidx/compose/animation/core/CubicBezierEasing;

    .line 32
    new-instance v2, Landroidx/compose/animation/core/TweenSpec;

    .line 34
    iget v3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$durationMs:I

    .line 36
    iget v4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$delayMs:I

    .line 38
    invoke-direct {v2, v3, v4, v0}, Landroidx/compose/animation/core/TweenSpec;-><init>(IILandroidx/compose/animation/core/Easing;)V

    .line 41
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->label:Z

    .line 43
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;->$p:Landroidx/compose/animation/core/Animatable;

    .line 45
    const/4 v3, 0x0

    .line 46
    const/16 v5, 0xc

    .line 48
    move-object v4, p0

    .line 49
    invoke-static/range {v0 .. v5}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)Ljava/lang/Object;

    .line 52
    move-result-object p0

    .line 53
    sget-object p1, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 55
    if-ne p0, p1, :cond_39

    .line 57
    return-object p1

    .line 58
    :cond_39
    :goto_39
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 60
    return-object p0
.end method
