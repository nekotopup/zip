###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda8 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda8)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$1:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$2:Z

.field public final synthetic f$3:Z

.field public final synthetic f$4:Z

.field public final synthetic f$5:Ljava/lang/String;

.field public final synthetic f$6:I


# direct methods
.method public synthetic constructor <init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;IB)V
    .registers 9

    .line 1
    iput-byte p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->$r8$classId:B

    .line 3
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 5
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$1:Lkotlin/jvm/functions/Function0;

    .line 7
    iput-boolean p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$2:Z

    .line 9
    iput-boolean p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$3:Z

    .line 11
    iput-boolean p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$4:Z

    .line 13
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$5:Ljava/lang/String;

    .line 15
    iput p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$6:I

    .line 17
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 20
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-byte v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->$r8$classId:B

    .line 5
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    iget v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$6:I

    .line 9
    packed-switch v1, :pswitch_data_52

    .line 12
    move-object/from16 v10, p1

    .line 14
    check-cast v10, Landroidx/compose/runtime/ComposerImpl;

    .line 16
    move-object/from16 v1, p2

    .line 18
    check-cast v1, Ljava/lang/Integer;

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    or-int/lit8 v3, v3, 0x1

    .line 25
    invoke-static {v3}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 28
    move-result v11

    .line 29
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 31
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$1:Lkotlin/jvm/functions/Function0;

    .line 33
    iget-boolean v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$2:Z

    .line 35
    iget-boolean v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$3:Z

    .line 37
    iget-boolean v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$4:Z

    .line 39
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$5:Ljava/lang/String;

    .line 41
    invoke-static/range {v4 .. v11}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 44
    return-object v2

    .line 45
    :pswitch_2c
    move-object/from16 v18, p1

    .line 47
    check-cast v18, Landroidx/compose/runtime/ComposerImpl;

    .line 49
    move-object/from16 v1, p2

    .line 51
    check-cast v1, Ljava/lang/Integer;

    .line 53
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 56
    or-int/lit8 v3, v3, 0x1

    .line 58
    invoke-static {v3}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 61
    move-result v19

    .line 62
    iget-object v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 64
    iget-object v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$1:Lkotlin/jvm/functions/Function0;

    .line 66
    iget-boolean v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$2:Z

    .line 68
    iget-boolean v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$3:Z

    .line 70
    iget-boolean v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$4:Z

    .line 72
    iget-object v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;->f$5:Ljava/lang/String;

    .line 74
    move-object/from16 v17, v0

    .line 76
    move/from16 v16, v1

    .line 78
    invoke-static/range {v12 .. v19}, Lcom/spotifry/music/ui/spotifried/CardsKt;->TypeCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 81
    return-object v2

    nop

    .line 83
    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_2c
    .end packed-switch
.end method
