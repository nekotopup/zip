###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda2 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda2)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$1:I

.field public final synthetic f$2:I

.field public final synthetic f$3:Z

.field public final synthetic f$4:I


# direct methods
.method public synthetic constructor <init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZIB)V
    .registers 7

    .line 1
    iput-byte p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->$r8$classId:B

    .line 3
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 5
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$1:I

    .line 7
    iput p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$2:I

    .line 9
    iput-boolean p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$3:Z

    .line 11
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$4:I

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-byte v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->$r8$classId:B

    .line 5
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    iget v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$4:I

    .line 9
    packed-switch v1, :pswitch_data_46

    .line 12
    move-object/from16 v8, p1

    .line 14
    check-cast v8, Landroidx/compose/runtime/ComposerImpl;

    .line 16
    move-object/from16 v1, p2

    .line 18
    check-cast v1, Ljava/lang/Integer;

    .line 20
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    or-int/lit8 v3, v3, 0x1

    .line 25
    invoke-static {v3}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 28
    move-result v9

    .line 29
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 31
    iget v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$1:I

    .line 33
    iget v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$2:I

    .line 35
    iget-boolean v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$3:Z

    .line 37
    invoke-static/range {v4 .. v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 40
    return-object v2

    .line 41
    :pswitch_28
    move-object/from16 v14, p1

    .line 43
    check-cast v14, Landroidx/compose/runtime/ComposerImpl;

    .line 45
    move-object/from16 v1, p2

    .line 47
    check-cast v1, Ljava/lang/Integer;

    .line 49
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 52
    or-int/lit8 v3, v3, 0x1

    .line 54
    invoke-static {v3}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 57
    move-result v15

    .line 58
    iget-object v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 60
    iget v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$1:I

    .line 62
    iget v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$2:I

    .line 64
    iget-boolean v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;->f$3:Z

    .line 66
    invoke-static/range {v10 .. v15}, Lcom/spotifry/music/ui/spotifried/CardsKt;->AgeCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 69
    return-object v2

    nop

    .line 71
    :pswitch_data_46
    .packed-switch 0x0
        :pswitch_28
    .end packed-switch
.end method
