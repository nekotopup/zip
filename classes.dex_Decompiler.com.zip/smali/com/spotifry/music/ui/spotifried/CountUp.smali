###### Class com.spotifry.music.ui.spotifried.CountUp (com.spotifry.music.ui.spotifried.CountUp)
.class public final Lcom/spotifry/music/ui/spotifried/CountUp;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"


# instance fields
.field public final started:Z

.field public final text:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Z)V
    .registers 3

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CountUp;->text:Ljava/lang/String;

    iput-boolean p2, p0, Lcom/spotifry/music/ui/spotifried/CountUp;->started:Z

    return-void
.end method

.method public constructor <init>(ZLjava/lang/String;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CountUp;->started:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CountUp;->text:Ljava/lang/String;

    .line 8
    return-void
.end method
