###### Class com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda36 (com.spotifry.music.ui.spotifried.CardsKt$$ExternalSyntheticLambda36)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:I


# direct methods
.method public synthetic constructor <init>(ILjava/util/Collection;)V
    .registers 4

    .line 1
    const/4 v0, 0x2

    .line 2
    iput-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->$r8$classId:B

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->f$1:I

    .line 9
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->f$0:Ljava/lang/Object;

    .line 11
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;IB)V
    .registers 4

    .line 12
    iput-byte p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->$r8$classId:B

    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->f$0:Ljava/lang/Object;

    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->f$1:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->$r8$classId:B

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    iget-object v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->f$0:Ljava/lang/Object;

    .line 7
    iget p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;->f$1:I

    .line 9
    packed-switch v0, :pswitch_data_72

    .line 12
    check-cast v2, Ljava/util/Collection;

    .line 14
    check-cast p1, Ljava/util/List;

    .line 16
    invoke-interface {p1, p0, v2}, Ljava/util/List;->addAll(ILjava/util/Collection;)Z

    .line 19
    move-result p0

    .line 20
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 23
    move-result-object p0

    .line 24
    return-object p0

    .line 25
    :pswitch_18
    check-cast v2, Landroidx/compose/foundation/lazy/grid/LazyGridState;

    .line 27
    check-cast p1, Landroidx/compose/foundation/lazy/layout/LazyLayoutPrefetchState$NestedPrefetchScopeImpl;

    .line 29
    iget-object v0, v2, Landroidx/compose/foundation/lazy/grid/LazyGridState;->prefetchStrategy:Landroidx/compose/foundation/lazy/DefaultLazyListPrefetchStrategy;

    .line 31
    invoke-static {}, Landroidx/collection/internal/Lock;->getCurrentThreadSnapshot()Landroidx/compose/runtime/snapshots/Snapshot;

    .line 34
    move-result-object v2

    .line 35
    if-eqz v2, :cond_29

    .line 37
    invoke-virtual {v2}, Landroidx/compose/runtime/snapshots/Snapshot;->getReadObserver()Lkotlin/jvm/functions/Function1;

    .line 40
    move-result-object v3

    .line 41
    goto :goto_2a

    .line 42
    :cond_29
    const/4 v3, 0x0

    .line 43
    :goto_2a
    invoke-static {v2}, Landroidx/collection/internal/Lock;->makeCurrentNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;)Landroidx/compose/runtime/snapshots/Snapshot;

    .line 46
    move-result-object v4

    .line 47
    invoke-static {v2, v4, v3}, Landroidx/collection/internal/Lock;->restoreNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;Lkotlin/jvm/functions/Function1;)V

    .line 50
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 53
    iget v0, p1, Landroidx/compose/foundation/lazy/layout/LazyLayoutPrefetchState$NestedPrefetchScopeImpl;->nestedPrefetchItemCount:I

    .line 55
    const/4 v2, -0x1

    .line 56
    if-ne v0, v2, :cond_3a

    .line 58
    const/4 v0, 0x2

    .line 59
    :cond_3a
    const/4 v2, 0x0

    .line 60
    :goto_3b
    if-ge v2, v0, :cond_45

    .line 62
    add-int v3, p0, v2

    .line 64
    invoke-virtual {p1, v3}, Landroidx/compose/foundation/lazy/layout/LazyLayoutPrefetchState$NestedPrefetchScopeImpl;->schedulePrecomposition(I)V

    .line 67
    add-int/lit8 v2, v2, 0x1

    .line 69
    goto :goto_3b

    .line 70
    :cond_45
    return-object v1

    .line 71
    :pswitch_46
    check-cast v2, Landroidx/compose/animation/core/Animatable;

    .line 73
    check-cast p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;

    .line 75
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 78
    invoke-virtual {v2}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 81
    move-result-object v0

    .line 82
    check-cast v0, Ljava/lang/Number;

    .line 84
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 87
    move-result v0

    .line 88
    const/high16 v2, 0x43fa0000    # 500.0f

    .line 90
    const/high16 v3, 0x44e10000    # 1800.0f

    .line 92
    invoke-static {v0, v2, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 95
    move-result v0

    .line 96
    const/high16 v2, 0x41c00000    # 24.0f

    .line 98
    mul-float/2addr v0, v2

    .line 99
    int-to-float p0, p0

    .line 100
    sub-float/2addr v0, p0

    .line 101
    const/high16 p0, 0x40400000    # 3.0f

    .line 103
    div-float/2addr v0, p0

    .line 104
    const/4 p0, 0x0

    .line 105
    const/high16 v2, 0x3f800000    # 1.0f

    .line 107
    invoke-static {v0, p0, v2}, Lkotlin/ResultKt;->coerceIn(FFF)F

    .line 110
    move-result p0

    .line 111
    invoke-virtual {p1, p0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 114
    return-object v1

    .line 115
    :pswitch_data_72
    .packed-switch 0x0
        :pswitch_46
        :pswitch_18
    .end packed-switch
.end method
