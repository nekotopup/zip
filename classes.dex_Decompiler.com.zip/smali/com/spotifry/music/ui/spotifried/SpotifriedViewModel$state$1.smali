###### Class com.spotifry.music.ui.spotifried.SpotifriedViewModel$state$1 (com.spotifry.music.ui.spotifried.SpotifriedViewModel$state$1)
.class public final synthetic Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$state$1;
.super Lkotlin/jvm/internal/AdaptedFunctionReference;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function5;


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 14

    .line 1
    check-cast p1, Ljava/util/List;

    .line 3
    check-cast p2, Ljava/util/List;

    .line 5
    check-cast p3, Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 7
    move-object v7, p4

    .line 8
    check-cast v7, Ljava/lang/String;

    .line 10
    check-cast p5, Lkotlin/coroutines/Continuation;

    .line 12
    iget-object p0, p0, Lkotlin/jvm/internal/AdaptedFunctionReference;->receiver:Ljava/lang/Object;

    .line 14
    check-cast p0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;

    .line 16
    iget-object p4, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->today:Lkotlin/jvm/functions/Function0;

    .line 18
    invoke-interface {p4}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 21
    move-result-object p4

    .line 22
    check-cast p4, Ljava/time/LocalDate;

    .line 24
    invoke-interface {p1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 27
    move-result-object p5

    .line 28
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 31
    move-result v0

    .line 32
    const/4 v1, 0x0

    .line 33
    if-nez v0, :cond_24

    .line 35
    move-object v0, v1

    .line 36
    goto :goto_4a

    .line 37
    :cond_24
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 40
    move-result-object v0

    .line 41
    check-cast v0, Lcom/spotifry/music/data/db/ListenRow;

    .line 43
    iget-wide v2, v0, Lcom/spotifry/music/data/db/ListenRow;->startedAt:J

    .line 45
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 48
    move-result-object v0

    .line 49
    :cond_30
    :goto_30
    invoke-interface {p5}, Ljava/util/Iterator;->hasNext()Z

    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_4a

    .line 55
    invoke-interface {p5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 58
    move-result-object v2

    .line 59
    check-cast v2, Lcom/spotifry/music/data/db/ListenRow;

    .line 61
    iget-wide v2, v2, Lcom/spotifry/music/data/db/ListenRow;->startedAt:J

    .line 63
    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 66
    move-result-object v2

    .line 67
    invoke-virtual {v0, v2}, Ljava/lang/Long;->compareTo(Ljava/lang/Object;)I

    .line 70
    move-result v3

    .line 71
    if-lez v3, :cond_30

    .line 73
    move-object v0, v2

    .line 74
    goto :goto_30

    .line 75
    :cond_4a
    :goto_4a
    if-eqz v0, :cond_60

    .line 77
    invoke-virtual {v0}, Ljava/lang/Number;->longValue()J

    .line 80
    move-result-wide v2

    .line 81
    invoke-static {v2, v3}, Ljava/time/Instant;->ofEpochMilli(J)Ljava/time/Instant;

    .line 84
    move-result-object p5

    .line 85
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->zone:Ljava/time/ZoneId;

    .line 87
    invoke-virtual {p5, v0}, Ljava/time/Instant;->atZone(Ljava/time/ZoneId;)Ljava/time/ZonedDateTime;

    .line 90
    move-result-object p5

    .line 91
    invoke-virtual {p5}, Ljava/time/ZonedDateTime;->toLocalDate()Ljava/time/LocalDate;

    .line 94
    move-result-object p5

    .line 95
    if-nez p5, :cond_61

    .line 97
    :cond_60
    move-object p5, p4

    .line 98
    :cond_61
    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 101
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 104
    invoke-virtual {p4}, Ljava/time/LocalDate;->getYear()I

    .line 107
    move-result v0

    .line 108
    invoke-virtual {p5}, Ljava/time/LocalDate;->getYear()I

    .line 111
    move-result v2

    .line 112
    new-instance v3, Lkotlin/ranges/IntProgression;

    .line 114
    const/4 v4, -0x1

    .line 115
    invoke-direct {v3, v0, v2, v4}, Lkotlin/ranges/IntProgression;-><init>(III)V

    .line 118
    new-instance v0, Ljava/util/ArrayList;

    .line 120
    const/16 v2, 0xa

    .line 122
    invoke-static {v3, v2}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 125
    move-result v4

    .line 126
    invoke-direct {v0, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 129
    invoke-virtual {v3}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 132
    move-result-object v3

    .line 133
    :goto_84
    move-object v4, v3

    .line 134
    check-cast v4, Lkotlin/ranges/IntProgressionIterator;

    .line 136
    iget-boolean v4, v4, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 138
    if-eqz v4, :cond_9a

    .line 140
    move-object v4, v3

    .line 141
    check-cast v4, Lkotlin/collections/IntIterator;

    .line 143
    invoke-virtual {v4}, Lkotlin/collections/IntIterator;->nextInt()I

    .line 146
    move-result v4

    .line 147
    invoke-static {v4, p4}, Lkotlin/text/RegexKt;->calendarYear(ILjava/time/LocalDate;)Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 150
    move-result-object v4

    .line 151
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 154
    goto :goto_84

    .line 155
    :cond_9a
    new-instance v3, Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 157
    const-wide/16 v4, 0x1

    .line 159
    invoke-virtual {p4, v4, v5}, Ljava/time/LocalDate;->minusYears(J)Ljava/time/LocalDate;

    .line 162
    move-result-object v6

    .line 163
    invoke-virtual {v6, v4, v5}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 166
    move-result-object v4

    .line 167
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 170
    const-string v5, "Last 12 months"

    .line 172
    invoke-direct {v3, v4, p4, v5}, Lcom/spotifry/music/data/spotifried/WrappedPeriod;-><init>(Ljava/time/LocalDate;Ljava/time/LocalDate;Ljava/lang/String;)V

    .line 175
    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 178
    move-result-object v0

    .line 179
    new-instance v3, Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 181
    const-string v4, "All time"

    .line 183
    invoke-direct {v3, p5, p4, v4}, Lcom/spotifry/music/data/spotifried/WrappedPeriod;-><init>(Ljava/time/LocalDate;Ljava/time/LocalDate;Ljava/lang/String;)V

    .line 186
    invoke-static {v0, v3}, Lkotlin/collections/CollectionsKt;->plus(Ljava/util/Collection;Ljava/lang/Object;)Ljava/util/ArrayList;

    .line 189
    move-result-object v3

    .line 190
    new-instance p5, Ljava/util/ArrayList;

    .line 192
    invoke-direct {p5}, Ljava/util/ArrayList;-><init>()V

    .line 195
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 198
    move-result-object v0

    .line 199
    :cond_c6
    :goto_c6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 202
    move-result v4

    .line 203
    if-eqz v4, :cond_ed

    .line 205
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 208
    move-result-object v4

    .line 209
    check-cast v4, Lcom/spotifry/music/data/db/SongYearEntity;

    .line 211
    iget-object v5, v4, Lcom/spotifry/music/data/db/SongYearEntity;->year:Ljava/lang/Integer;

    .line 213
    if-eqz v5, :cond_e6

    .line 215
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 218
    move-result v5

    .line 219
    iget-object v4, v4, Lcom/spotifry/music/data/db/SongYearEntity;->songId:Ljava/lang/String;

    .line 221
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 224
    move-result-object v5

    .line 225
    new-instance v6, Lkotlin/Pair;

    .line 227
    invoke-direct {v6, v4, v5}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 230
    goto :goto_e7

    .line 231
    :cond_e6
    move-object v6, v1

    .line 232
    :goto_e7
    if-eqz v6, :cond_c6

    .line 234
    invoke-virtual {p5, v6}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 237
    goto :goto_c6

    .line 238
    :cond_ed
    invoke-static {p5}, Lkotlin/collections/MapsKt__MapsKt;->toMap(Ljava/util/ArrayList;)Ljava/util/Map;

    .line 241
    move-result-object p5

    .line 242
    new-instance v0, Ljava/util/ArrayList;

    .line 244
    invoke-static {p2, v2}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 247
    move-result v4

    .line 248
    invoke-direct {v0, v4}, Ljava/util/ArrayList;-><init>(I)V

    .line 251
    invoke-interface {p2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 254
    move-result-object p2

    .line 255
    :goto_fe
    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    .line 258
    move-result v4

    .line 259
    if-eqz v4, :cond_110

    .line 261
    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 264
    move-result-object v4

    .line 265
    check-cast v4, Lcom/spotifry/music/data/db/SongYearEntity;

    .line 267
    iget-object v4, v4, Lcom/spotifry/music/data/db/SongYearEntity;->songId:Ljava/lang/String;

    .line 269
    invoke-virtual {v0, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 272
    goto :goto_fe

    .line 273
    :cond_110
    invoke-static {v0}, Lkotlin/collections/CollectionsKt;->toSet(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 276
    move-result-object p2

    .line 277
    if-eqz p3, :cond_11b

    .line 279
    invoke-static {p1, p5, p0, p2, p3}, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->build$statsOf(Ljava/util/List;Ljava/util/Map;Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Ljava/util/Set;Lcom/spotifry/music/data/spotifried/WrappedPeriod;)Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 282
    move-result-object p0

    .line 283
    goto :goto_14e

    .line 284
    :cond_11b
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 287
    move-result-object p3

    .line 288
    :cond_11f
    invoke-interface {p3}, Ljava/util/Iterator;->hasNext()Z

    .line 291
    move-result v0

    .line 292
    if-eqz v0, :cond_13d

    .line 294
    invoke-interface {p3}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 297
    move-result-object v0

    .line 298
    check-cast v0, Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 300
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 303
    invoke-static {p1, p5, p0, p2, v0}, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->build$statsOf(Ljava/util/List;Ljava/util/Map;Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Ljava/util/Set;Lcom/spotifry/music/data/spotifried/WrappedPeriod;)Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 306
    move-result-object v0

    .line 307
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->shownCards(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)Ljava/util/List;

    .line 310
    move-result-object v4

    .line 311
    invoke-interface {v4}, Ljava/util/Collection;->isEmpty()Z

    .line 314
    move-result v4

    .line 315
    if-nez v4, :cond_11f

    .line 317
    goto :goto_13e

    .line 318
    :cond_13d
    move-object v0, v1

    .line 319
    :goto_13e
    if-nez v0, :cond_14d

    .line 321
    invoke-virtual {p4}, Ljava/time/LocalDate;->getYear()I

    .line 324
    move-result p3

    .line 325
    invoke-static {p3, p4}, Lkotlin/text/RegexKt;->calendarYear(ILjava/time/LocalDate;)Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 328
    move-result-object p3

    .line 329
    invoke-static {p1, p5, p0, p2, p3}, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->build$statsOf(Ljava/util/List;Ljava/util/Map;Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Ljava/util/Set;Lcom/spotifry/music/data/spotifried/WrappedPeriod;)Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 332
    move-result-object p0

    .line 333
    goto :goto_14e

    .line 334
    :cond_14d
    move-object p0, v0

    .line 335
    :goto_14e
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 337
    move p1, v2

    .line 338
    invoke-static {p0}, Lkotlin/io/ByteStreamsKt;->shownCards(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)Ljava/util/List;

    .line 341
    move-result-object v2

    .line 342
    iget-object p2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->age:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 344
    iget p3, p2, Lcom/spotifry/music/data/spotifried/AgeStats;->songsTotal:I

    .line 346
    iget v5, p2, Lcom/spotifry/music/data/spotifried/AgeStats;->unchecked:I

    .line 348
    sub-int v4, p3, v5

    .line 350
    iget-object p2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 352
    iget-object p2, p2, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->to:Ljava/time/LocalDate;

    .line 354
    invoke-virtual {p2, p4}, Ljava/time/LocalDate;->compareTo(Ljava/time/chrono/ChronoLocalDate;)I

    .line 357
    move-result p2

    .line 358
    if-gez p2, :cond_16a

    .line 360
    :goto_167
    move-object v6, v1

    .line 361
    move-object v1, p0

    .line 362
    goto :goto_177

    .line 363
    :cond_16a
    iget p2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->plays:I

    .line 365
    sub-int/2addr p1, p2

    .line 366
    const/4 p2, 0x1

    .line 367
    invoke-static {p2, p1}, Ljava/lang/Math;->max(II)I

    .line 370
    move-result p1

    .line 371
    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 374
    move-result-object v1

    .line 375
    goto :goto_167

    .line 376
    :goto_177
    invoke-direct/range {v0 .. v7}, Lcom/spotifry/music/ui/spotifried/SpotifriedState;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/util/List;Ljava/util/ArrayList;IILjava/lang/Integer;Ljava/lang/String;)V

    .line 379
    return-object v0
.end method
