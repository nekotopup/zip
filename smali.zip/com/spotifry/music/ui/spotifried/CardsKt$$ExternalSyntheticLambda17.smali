# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$2:Ljava/lang/Integer;

.field public final synthetic f$3:J

.field public final synthetic f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

.field public final synthetic f$5:Ljava/lang/String;

.field public final synthetic f$6:I

.field public final synthetic f$7:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$8:J


# direct methods
.method public synthetic constructor <init>(ZLcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/lang/Integer;JLcom/spotifry/music/ui/spotifried/CountUp;Ljava/lang/String;ILandroidx/compose/animation/core/Animatable;J)V
    .registers 12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$0:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$2:Ljava/lang/Integer;

    .line 10
    iput-wide p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$3:J

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$5:Ljava/lang/String;

    .line 16
    iput p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$6:I

    .line 18
    iput-object p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$7:Landroidx/compose/animation/core/Animatable;

    .line 20
    iput-wide p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$8:J

    .line 22
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 43

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 5
    iget-object v9, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 7
    move-object/from16 v1, p1

    .line 9
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 11
    move-object/from16 v6, p2

    .line 13
    check-cast v6, Landroidx/compose/runtime/ComposerImpl;

    .line 15
    move-object/from16 v3, p3

    .line 17
    check-cast v3, Ljava/lang/Integer;

    .line 19
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 22
    move-result v3

    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    and-int/lit8 v4, v3, 0x6

    .line 28
    const/4 v5, 0x4

    .line 29
    if-nez v4, :cond_28

    .line 31
    invoke-virtual {v6, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 34
    move-result v4

    .line 35
    if-eqz v4, :cond_26

    .line 37
    move v4, v5

    .line 38
    goto :goto_27

    .line 39
    :cond_26
    const/4 v4, 0x2

    .line 40
    :goto_27
    or-int/2addr v3, v4

    .line 41
    :cond_28
    and-int/lit8 v4, v3, 0x13

    .line 43
    const/16 v7, 0x12

    .line 45
    const/4 v8, 0x1

    .line 46
    if-eq v4, v7, :cond_31

    .line 48
    move v4, v8

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    const/4 v4, 0x0

    .line 51
    :goto_32
    and-int/2addr v3, v8

    .line 52
    invoke-virtual {v6, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v3

    .line 56
    if-eqz v3, :cond_295

    .line 58
    new-instance v3, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 60
    invoke-direct {v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 63
    iget-object v4, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->start:Ljava/time/LocalDate;

    .line 65
    iget-wide v11, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 67
    iget-object v7, v9, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->label:Ljava/lang/String;

    .line 69
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 72
    move-result v13

    .line 73
    const-string v14, ", "

    .line 75
    const-string v15, " "

    .line 77
    if-ne v13, v5, :cond_69

    .line 79
    const/4 v5, 0x0

    .line 80
    :goto_4f
    invoke-virtual {v7}, Ljava/lang/String;->length()I

    .line 83
    move-result v13

    .line 84
    if-ge v5, v13, :cond_62

    .line 86
    invoke-virtual {v7, v5}, Ljava/lang/String;->charAt(I)C

    .line 89
    move-result v13

    .line 90
    invoke-static {v13}, Ljava/lang/Character;->isDigit(C)Z

    .line 93
    move-result v13

    .line 94
    if-eqz v13, :cond_69

    .line 96
    add-int/lit8 v5, v5, 0x1

    .line 98
    goto :goto_4f

    .line 99
    :cond_62
    const-string v5, "You gave "

    .line 101
    invoke-static {v5, v7, v15}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 104
    move-result-object v5

    .line 105
    goto :goto_83

    .line 106
    :cond_69
    const-string v5, "Last 12 months"

    .line 108
    invoke-virtual {v7, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 111
    move-result v5

    .line 112
    if-eqz v5, :cond_74

    .line 114
    const-string v5, "Twelve months, "

    .line 116
    goto :goto_83

    .line 117
    :cond_74
    const-string v5, "All time"

    .line 119
    invoke-virtual {v7, v5}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 122
    move-result v5

    .line 123
    if-eqz v5, :cond_7f

    .line 125
    const-string v5, "All told, "

    .line 127
    goto :goto_83

    .line 128
    :cond_7f
    invoke-virtual {v7, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 131
    move-result-object v5

    .line 132
    :goto_83
    invoke-virtual {v3, v5}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 135
    new-instance v16, Landroidx/compose/ui/text/SpanStyle;

    .line 137
    const/16 v34, 0x0

    .line 139
    const v35, 0xffbe

    .line 142
    move-object/from16 v36, v9

    .line 144
    iget-wide v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$3:J

    .line 146
    const-wide/16 v19, 0x0

    .line 148
    const/16 v21, 0x0

    .line 150
    const/16 v22, 0x0

    .line 152
    const/16 v23, 0x0

    .line 154
    const/16 v24, 0x0

    .line 156
    const-string v25, "tnum"

    .line 158
    const-wide/16 v26, 0x0

    .line 160
    const/16 v28, 0x0

    .line 162
    const/16 v29, 0x0

    .line 164
    const/16 v30, 0x0

    .line 166
    const-wide/16 v31, 0x0

    .line 168
    const/16 v33, 0x0

    .line 170
    move-wide/from16 v17, v8

    .line 172
    invoke-direct/range {v16 .. v35}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 175
    move-object/from16 v5, v16

    .line 177
    move-wide/from16 v7, v17

    .line 179
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 181
    iget-object v13, v9, Lcom/spotifry/music/ui/spotifried/CountUp;->text:Ljava/lang/String;

    .line 183
    iget-object v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$5:Ljava/lang/String;

    .line 185
    invoke-static {v13, v15, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 188
    move-result-object v10

    .line 189
    invoke-static {v3, v9, v5, v10}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countSpan(Landroidx/compose/ui/text/AnnotatedString$Builder;Lcom/spotifry/music/ui/spotifried/CountUp;Landroidx/compose/ui/text/SpanStyle;Ljava/lang/String;)V

    .line 192
    invoke-virtual {v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 195
    move-result-object v10

    .line 196
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 198
    iget-boolean v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$0:Z

    .line 200
    const/16 v5, 0x36

    .line 202
    move-wide v15, v11

    .line 203
    const/4 v13, 0x0

    .line 204
    invoke-static {v3, v13, v9, v6, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 207
    move-result-object v11

    .line 208
    sget-object v27, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 210
    const/high16 v30, 0x6000000

    .line 212
    const v31, 0x3fffc

    .line 215
    const-wide/16 v12, 0x0

    .line 217
    move-wide/from16 v18, v15

    .line 219
    move-object/from16 v16, v14

    .line 221
    const-wide/16 v14, 0x0

    .line 223
    move-object/from16 v20, v16

    .line 225
    const/16 v16, 0x0

    .line 227
    move-wide/from16 v21, v18

    .line 229
    const-wide/16 v17, 0x0

    .line 231
    move-object/from16 v23, v20

    .line 233
    const-wide/16 v19, 0x0

    .line 235
    move-wide/from16 v25, v21

    .line 237
    const/16 v21, 0x0

    .line 239
    const/16 v22, 0x0

    .line 241
    move-object/from16 v28, v23

    .line 243
    const/16 v23, 0x0

    .line 245
    const/16 v24, 0x0

    .line 247
    move-wide/from16 v32, v25

    .line 249
    const/16 v25, 0x0

    .line 251
    const/16 v26, 0x0

    .line 253
    const/16 v29, 0x0

    .line 255
    move-object/from16 v37, v28

    .line 257
    move-object/from16 v28, v6

    .line 259
    move-object/from16 v6, v37

    .line 261
    invoke-static/range {v10 .. v31}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 264
    move-object/from16 v10, v28

    .line 266
    const-wide/32 v11, 0x15180

    .line 269
    cmp-long v11, v32, v11

    .line 271
    const v12, 0x1d46319c

    .line 274
    if-ltz v11, :cond_184

    .line 276
    const v11, 0x1e7124bd

    .line 279
    invoke-virtual {v10, v11}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 282
    invoke-static/range {v32 .. v33}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 285
    move-result v11

    .line 286
    invoke-static {v11}, Lcom/spotifry/music/data/Log;->longDuration(I)Ljava/lang/String;

    .line 289
    move-result-object v11

    .line 290
    const-string v13, "That is "

    .line 292
    const-string v14, ", with no break."

    .line 294
    invoke-static {v13, v11, v14}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 297
    move-result-object v11

    .line 298
    const/16 v19, 0x0

    .line 300
    const/16 v20, 0xd

    .line 302
    const/16 v16, 0x0

    .line 304
    const/high16 v17, 0x41600000  # 14.0f

    .line 306
    const/16 v18, 0x0

    .line 308
    move-object v15, v3

    .line 309
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 312
    move-result-object v3

    .line 313
    move-object/from16 v34, v15

    .line 315
    const/4 v13, 0x1

    .line 316
    invoke-static {v3, v13, v9, v10, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 319
    move-result-object v3

    .line 320
    move v15, v13

    .line 321
    invoke-static {v10}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 324
    move-result-wide v12

    .line 325
    sget-object v29, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 327
    const/high16 v32, 0xc00000

    .line 329
    const v33, 0x1fff8

    .line 332
    move/from16 v17, v15

    .line 334
    const-wide/16 v14, 0x0

    .line 336
    const/16 v16, 0x0

    .line 338
    move/from16 v19, v17

    .line 340
    const/16 v17, 0x0

    .line 342
    const/16 v18, 0x0

    .line 344
    move/from16 v22, v19

    .line 346
    const-wide/16 v19, 0x0

    .line 348
    const/16 v21, 0x0

    .line 350
    move/from16 v25, v22

    .line 352
    const-wide/16 v22, 0x0

    .line 354
    const/16 v24, 0x0

    .line 356
    move/from16 v27, v25

    .line 358
    const/16 v25, 0x0

    .line 360
    const/16 v26, 0x0

    .line 362
    move/from16 v30, v27

    .line 364
    const/16 v27, 0x0

    .line 366
    const/16 v28, 0x0

    .line 368
    const/16 v31, 0x0

    .line 370
    move-object/from16 v37, v11

    .line 372
    move-object v11, v3

    .line 373
    move/from16 v35, v30

    .line 375
    move-object/from16 v30, v10

    .line 377
    move-object/from16 v10, v37

    .line 379
    invoke-static/range {v10 .. v33}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 382
    move-object/from16 v10, v30

    .line 384
    const/4 v11, 0x0

    .line 385
    :goto_180
    invoke-virtual {v10, v11}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 388
    goto :goto_18e

    .line 389
    :cond_184
    move-object/from16 v34, v3

    .line 391
    move v3, v12

    .line 392
    const/4 v11, 0x0

    .line 393
    const/16 v35, 0x1

    .line 395
    invoke-virtual {v10, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 398
    goto :goto_180

    .line 399
    :goto_18e
    const/high16 v12, 0x3f800000  # 1.0f

    .line 401
    invoke-static {v1, v12}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 404
    move-result-object v1

    .line 405
    invoke-static {v1, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 408
    move-result-object v12

    .line 409
    sget-object v13, Landroidx/compose/ui/Alignment$Companion;->BottomStart:Landroidx/compose/ui/BiasAlignment;

    .line 411
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;

    .line 413
    move-object v14, v1

    .line 414
    iget v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$6:I

    .line 416
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$2:Ljava/lang/Integer;

    .line 418
    move-object v15, v4

    .line 419
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$7:Landroidx/compose/animation/core/Animatable;

    .line 421
    move-object/from16 v16, v6

    .line 423
    iget-wide v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;->f$8:J

    .line 425
    move-wide/from16 v37, v7

    .line 427
    move-wide v7, v5

    .line 428
    move-wide/from16 v5, v37

    .line 430
    move-object v0, v14

    .line 431
    move-object/from16 v11, v16

    .line 433
    move/from16 v14, v35

    .line 435
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;-><init>(ILcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/lang/Integer;Landroidx/compose/animation/core/Animatable;JJ)V

    .line 438
    move-object v1, v3

    .line 439
    move-object v3, v12

    .line 440
    move-object v4, v13

    .line 441
    move-wide v12, v5

    .line 442
    const v5, -0x1d8a8ca4

    .line 445
    invoke-static {v5, v0, v10}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 448
    move-result-object v5

    .line 449
    const/16 v7, 0xc30

    .line 451
    const/4 v8, 0x4

    .line 452
    move-object v6, v10

    .line 453
    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 456
    if-eqz v1, :cond_28d

    .line 458
    const v0, 0x1e8c731e

    .line 461
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 464
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 467
    move-result v0

    .line 468
    int-to-long v3, v0

    .line 469
    invoke-virtual {v15, v3, v4}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 472
    move-result-object v0

    .line 473
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->daySeconds:Ljava/util/List;

    .line 475
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 478
    move-result v1

    .line 479
    invoke-interface {v2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 482
    move-result-object v1

    .line 483
    check-cast v1, Ljava/lang/Number;

    .line 485
    invoke-virtual {v1}, Ljava/lang/Number;->longValue()J

    .line 488
    move-result-wide v1

    .line 489
    long-to-double v3, v1

    .line 490
    const-wide v5, 0x40ac200000000000L  # 3600.0

    .line 495
    div-double/2addr v3, v5

    .line 496
    invoke-static {v3, v4}, Lkotlin/math/MathKt;->roundToInt(D)I

    .line 499
    move-result v3

    .line 500
    if-lt v3, v14, :cond_1fc

    .line 502
    const-string v1, "hour"

    .line 504
    invoke-static {v3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->plural(ILjava/lang/String;)Ljava/lang/String;

    .line 507
    move-result-object v1

    .line 508
    goto :goto_206

    .line 509
    :cond_1fc
    invoke-static {v1, v2}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 512
    move-result v1

    .line 513
    const-string v2, "minute"

    .line 515
    invoke-static {v1, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->plural(ILjava/lang/String;)Ljava/lang/String;

    .line 518
    move-result-object v1

    .line 519
    :goto_206
    invoke-virtual {v15}, Ljava/time/LocalDate;->getYear()I

    .line 522
    move-result v2

    .line 523
    move-object/from16 v3, v36

    .line 525
    iget-object v3, v3, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->to:Ljava/time/LocalDate;

    .line 527
    invoke-virtual {v3}, Ljava/time/LocalDate;->getYear()I

    .line 530
    move-result v3

    .line 531
    if-eq v2, v3, :cond_217

    .line 533
    const-string v2, "d MMMM yyyy"

    .line 535
    goto :goto_219

    .line 536
    :cond_217
    const-string v2, "d MMMM"

    .line 538
    :goto_219
    sget-object v3, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 540
    invoke-static {v2, v3}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    .line 543
    move-result-object v2

    .line 544
    invoke-virtual {v0, v2}, Ljava/time/LocalDate;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 547
    move-result-object v0

    .line 548
    const-string v2, "Longest day: "

    .line 550
    invoke-static {v2, v1, v11, v0}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 553
    move-result-object v0

    .line 554
    const/16 v19, 0x0

    .line 556
    const/16 v20, 0xd

    .line 558
    const/16 v16, 0x0

    .line 560
    const/high16 v17, 0x41200000  # 10.0f

    .line 562
    const/16 v18, 0x0

    .line 564
    move-object/from16 v15, v34

    .line 566
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 569
    move-result-object v1

    .line 570
    const/4 v2, 0x3

    .line 571
    const/16 v3, 0x36

    .line 573
    invoke-static {v1, v2, v9, v10, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 576
    move-result-object v11

    .line 577
    sget-object v14, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 579
    const/16 v1, 0xe

    .line 581
    invoke-static {v1}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 584
    move-result-wide v17

    .line 585
    const/16 v1, 0x13

    .line 587
    invoke-static {v1}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 590
    move-result-wide v25

    .line 591
    sget-object v19, Landroidx/compose/ui/text/font/FontWeight;->SemiBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 593
    const/16 v28, 0x0

    .line 595
    const v29, 0xfdfff9

    .line 598
    const-wide/16 v15, 0x0

    .line 600
    const/16 v20, 0x0

    .line 602
    const/16 v21, 0x0

    .line 604
    const-wide/16 v22, 0x0

    .line 606
    const/16 v24, 0x0

    .line 608
    const/16 v27, 0x0

    .line 610
    invoke-static/range {v14 .. v29}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 613
    move-result-object v29

    .line 614
    const/16 v32, 0x0

    .line 616
    const v33, 0x1fff8

    .line 619
    const-wide/16 v14, 0x0

    .line 621
    const/16 v16, 0x0

    .line 623
    const/16 v17, 0x0

    .line 625
    const/16 v18, 0x0

    .line 627
    const-wide/16 v19, 0x0

    .line 629
    const/16 v24, 0x0

    .line 631
    const/16 v25, 0x0

    .line 633
    const/16 v26, 0x0

    .line 635
    const/16 v27, 0x0

    .line 637
    const/16 v28, 0x0

    .line 639
    const/16 v31, 0x0

    .line 641
    move-object/from16 v30, v10

    .line 643
    move-object v10, v0

    .line 644
    const/4 v0, 0x0

    .line 645
    invoke-static/range {v10 .. v33}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 648
    move-object/from16 v10, v30

    .line 650
    :goto_289
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 653
    goto :goto_299

    .line 654
    :cond_28d
    const/4 v0, 0x0

    .line 655
    const v14, 0x1d46319c

    .line 658
    invoke-virtual {v10, v14}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 661
    goto :goto_289

    .line 662
    :cond_295
    move-object v10, v6

    .line 663
    invoke-virtual {v10}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 666
    :goto_299
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 668
    return-object v0
.end method
