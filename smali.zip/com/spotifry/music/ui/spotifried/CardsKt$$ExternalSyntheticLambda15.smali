# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$1:J

.field public final synthetic f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$3:F

.field public final synthetic f$4:Lcom/spotifry/music/ui/listening/SunMotion;

.field public final synthetic f$5:Landroidx/compose/ui/text/TextStyle;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;JLcom/spotifry/music/data/spotifried/SpotifriedStats;FLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/text/TextStyle;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 10
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$3:F

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$4:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$5:Landroidx/compose/ui/text/TextStyle;

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 39

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v12, p2

    .line 9
    check-cast v12, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    const/4 v4, 0x4

    .line 25
    if-nez v3, :cond_24

    .line 27
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_22

    .line 33
    move v3, v4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    const/4 v3, 0x2

    .line 36
    :goto_23
    or-int/2addr v2, v3

    .line 37
    :cond_24
    and-int/lit8 v3, v2, 0x13

    .line 39
    const/16 v5, 0x12

    .line 41
    const/4 v6, 0x1

    .line 42
    const/4 v7, 0x0

    .line 43
    if-eq v3, v5, :cond_2e

    .line 45
    move v3, v6

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v3, v7

    .line 48
    :goto_2f
    and-int/2addr v2, v6

    .line 49
    invoke-virtual {v12, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_2e6

    .line 55
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 58
    move-result v2

    .line 59
    const v3, 0x3f8a3d71  # 1.08f

    .line 62
    mul-float/2addr v2, v3

    .line 63
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 65
    invoke-direct {v3, v2}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 68
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 71
    move-result v2

    .line 72
    new-instance v8, Landroidx/compose/ui/unit/Dp;

    .line 74
    invoke-direct {v8, v2}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 77
    invoke-virtual {v3, v8}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 80
    move-result v2

    .line 81
    if-lez v2, :cond_53

    .line 83
    move-object v3, v8

    .line 84
    :cond_53
    sget-object v2, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 86
    iget v3, v3, Landroidx/compose/ui/unit/Dp;->value:F

    .line 88
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->requiredSize-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 91
    move-result-object v8

    .line 92
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 94
    invoke-virtual {v12, v9}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 97
    move-result v10

    .line 98
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 101
    move-result-object v11

    .line 102
    sget-object v13, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 104
    if-nez v10, :cond_6b

    .line 106
    if-ne v11, v13, :cond_74

    .line 108
    :cond_6b
    new-instance v11, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;

    .line 110
    const/4 v10, 0x3

    .line 111
    invoke-direct {v11, v9, v10}, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 114
    invoke-virtual {v12, v11}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 117
    :cond_74
    check-cast v11, Lkotlin/jvm/functions/Function1;

    .line 119
    invoke-static {v8, v11}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 122
    move-result-object v8

    .line 123
    iget-wide v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$1:J

    .line 125
    invoke-virtual {v12, v10, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 128
    move-result v14

    .line 129
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 132
    move-result-object v5

    .line 133
    if-nez v14, :cond_88

    .line 135
    if-ne v5, v13, :cond_92

    .line 137
    :cond_88
    new-instance v5, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 139
    const/16 v14, 0xb

    .line 141
    invoke-direct {v5, v10, v11, v14}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 144
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 147
    :cond_92
    check-cast v5, Lkotlin/jvm/functions/Function1;

    .line 149
    invoke-static {v8, v5, v12, v7}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 152
    invoke-static {v2, v3}, Landroidx/compose/foundation/layout/SizeKt;->requiredSize-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 155
    move-result-object v5

    .line 156
    const-string v8, "sun"

    .line 158
    invoke-static {v5, v8}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 161
    move-result-object v5

    .line 162
    invoke-virtual {v12, v9}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 165
    move-result v8

    .line 166
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 169
    move-result-object v10

    .line 170
    if-nez v8, :cond_ad

    .line 172
    if-ne v10, v13, :cond_b5

    .line 174
    :cond_ad
    new-instance v10, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;

    .line 176
    invoke-direct {v10, v9, v4}, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 179
    invoke-virtual {v12, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 182
    :cond_b5
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 184
    invoke-static {v5, v10}, Landroidx/compose/ui/draw/ClipKt;->drawWithContent(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 187
    move-result-object v4

    .line 188
    sget-object v5, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 190
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 193
    move-result-object v5

    .line 194
    iget-wide v10, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 196
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 199
    move-result v8

    .line 200
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 203
    move-result-object v10

    .line 204
    invoke-static {v12, v4}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 207
    move-result-object v4

    .line 208
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 210
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 213
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 215
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 218
    iget-boolean v14, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 220
    if-eqz v14, :cond_e1

    .line 222
    invoke-virtual {v12, v11}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 225
    goto :goto_e4

    .line 226
    :cond_e1
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 229
    :goto_e4
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 231
    invoke-static {v12, v5, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 234
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 236
    invoke-static {v12, v10, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 239
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 241
    iget-boolean v10, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 243
    if-nez v10, :cond_102

    .line 245
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 248
    move-result-object v10

    .line 249
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 252
    move-result-object v11

    .line 253
    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 256
    move-result v10

    .line 257
    if-nez v10, :cond_105

    .line 259
    :cond_102
    invoke-static {v8, v12, v8, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 262
    :cond_105
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 264
    invoke-static {v12, v4, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 267
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 269
    iget-object v4, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 271
    const/high16 v5, 0x3f800000  # 1.0f

    .line 273
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 276
    move-result-object v5

    .line 277
    move-object v8, v13

    .line 278
    const v13, 0x30006180

    .line 281
    const/16 v14, 0x1e0

    .line 283
    move v10, v3

    .line 284
    iget v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$3:F

    .line 286
    move-object v11, v2

    .line 287
    move-object v2, v4

    .line 288
    const/4 v4, 0x0

    .line 289
    move/from16 v16, v6

    .line 291
    move-object v6, v5

    .line 292
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$4:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 294
    move/from16 v17, v7

    .line 296
    const/4 v7, 0x0

    .line 297
    move-object/from16 v18, v8

    .line 299
    const/4 v8, 0x0

    .line 300
    move-object/from16 v19, v9

    .line 302
    const/4 v9, 0x0

    .line 303
    move/from16 v20, v10

    .line 305
    const/4 v10, 0x0

    .line 306
    move-object/from16 v21, v11

    .line 308
    const/4 v11, 0x0

    .line 309
    move-object/from16 p1, v1

    .line 311
    move/from16 v1, v16

    .line 313
    move/from16 v15, v17

    .line 315
    move-object/from16 v26, v18

    .line 317
    move-object/from16 p3, v19

    .line 319
    const/16 v16, 0x12

    .line 321
    invoke-static/range {v2 .. v14}, Lcom/spotifry/music/ui/listening/SunKt;->Sun(Ljava/util/List;FZLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/Modifier;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function1;Ljava/lang/String;ZLandroidx/compose/runtime/ComposerImpl;II)V

    .line 324
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 327
    const v4, 0x3ee147ae  # 0.44f

    .line 330
    mul-float v4, v4, v20

    .line 332
    sget-object v5, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 334
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 337
    move-result-object v5

    .line 338
    check-cast v5, Landroidx/compose/ui/unit/Density;

    .line 340
    iget-object v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;->f$5:Landroidx/compose/ui/text/TextStyle;

    .line 342
    iget-object v6, v0, Landroidx/compose/ui/text/TextStyle;->paragraphStyle:Landroidx/compose/ui/text/ParagraphStyle;

    .line 344
    iget-wide v6, v6, Landroidx/compose/ui/text/ParagraphStyle;->lineHeight:J

    .line 346
    invoke-interface {v5, v6, v7}, Landroidx/compose/ui/unit/Density;->toDp-GaN1DYA(J)F

    .line 349
    move-result v5

    .line 350
    const/high16 v27, 0x40000000  # 2.0f

    .line 352
    div-float v5, v5, v27

    .line 354
    invoke-virtual/range {p1 .. p1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 357
    move-result v6

    .line 358
    div-float v6, v6, v27

    .line 360
    sub-float/2addr v6, v5

    .line 361
    new-instance v7, Landroidx/compose/ui/unit/Dp;

    .line 363
    invoke-direct {v7, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 366
    invoke-static {v2, v3, v1}, Lcom/spotifry/music/ui/listening/SunKt;->sunReach(Ljava/util/List;FZ)F

    .line 369
    move-result v8

    .line 370
    mul-float v8, v8, v20

    .line 372
    const/high16 v9, 0x41000000  # 8.0f

    .line 374
    add-float/2addr v8, v9

    .line 375
    add-float/2addr v8, v5

    .line 376
    new-instance v10, Landroidx/compose/ui/unit/Dp;

    .line 378
    invoke-direct {v10, v8}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 381
    invoke-virtual {v7, v10}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 384
    move-result v8

    .line 385
    if-gez v8, :cond_183

    .line 387
    move-object v7, v10

    .line 388
    :cond_183
    new-instance v8, Landroidx/compose/ui/unit/Dp;

    .line 390
    invoke-direct {v8, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 393
    invoke-virtual {v7, v8}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 396
    move-result v10

    .line 397
    if-lez v10, :cond_18f

    .line 399
    move-object v7, v8

    .line 400
    :cond_18f
    new-instance v8, Landroidx/compose/ui/unit/Dp;

    .line 402
    invoke-direct {v8, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 405
    invoke-static {v2, v3, v15}, Lcom/spotifry/music/ui/listening/SunKt;->sunReach(Ljava/util/List;FZ)F

    .line 408
    move-result v2

    .line 409
    mul-float v2, v2, v20

    .line 411
    add-float/2addr v2, v9

    .line 412
    add-float/2addr v2, v5

    .line 413
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 415
    invoke-direct {v3, v2}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 418
    invoke-virtual {v8, v3}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 421
    move-result v2

    .line 422
    if-gez v2, :cond_1a8

    .line 424
    move-object v8, v3

    .line 425
    :cond_1a8
    new-instance v2, Landroidx/compose/ui/unit/Dp;

    .line 427
    invoke-direct {v2, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 430
    invoke-virtual {v8, v2}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 433
    move-result v3

    .line 434
    if-lez v3, :cond_1b4

    .line 436
    move-object v8, v2

    .line 437
    :cond_1b4
    invoke-static {v15}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 440
    move-result-object v2

    .line 441
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 443
    const/4 v5, 0x0

    .line 444
    invoke-direct {v3, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 447
    iget v6, v7, Landroidx/compose/ui/unit/Dp;->value:F

    .line 449
    neg-float v6, v6

    .line 450
    new-instance v7, Landroidx/compose/ui/unit/Dp;

    .line 452
    invoke-direct {v7, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 455
    new-instance v6, Lkotlin/Pair;

    .line 457
    invoke-direct {v6, v3, v7}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 460
    new-instance v3, Lkotlin/Pair;

    .line 462
    invoke-direct {v3, v2, v6}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 465
    const/4 v2, 0x6

    .line 466
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 469
    move-result-object v2

    .line 470
    new-instance v6, Landroidx/compose/ui/unit/Dp;

    .line 472
    invoke-direct {v6, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 475
    new-instance v7, Landroidx/compose/ui/unit/Dp;

    .line 477
    invoke-direct {v7, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 480
    new-instance v10, Lkotlin/Pair;

    .line 482
    invoke-direct {v10, v6, v7}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 485
    new-instance v6, Lkotlin/Pair;

    .line 487
    invoke-direct {v6, v2, v10}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 490
    const/16 v2, 0xc

    .line 492
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 495
    move-result-object v2

    .line 496
    new-instance v7, Landroidx/compose/ui/unit/Dp;

    .line 498
    invoke-direct {v7, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 501
    new-instance v10, Lkotlin/Pair;

    .line 503
    invoke-direct {v10, v7, v8}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 506
    new-instance v7, Lkotlin/Pair;

    .line 508
    invoke-direct {v7, v2, v10}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 511
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 514
    move-result-object v2

    .line 515
    neg-float v4, v4

    .line 516
    new-instance v8, Landroidx/compose/ui/unit/Dp;

    .line 518
    invoke-direct {v8, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 521
    new-instance v4, Landroidx/compose/ui/unit/Dp;

    .line 523
    invoke-direct {v4, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 526
    new-instance v10, Lkotlin/Pair;

    .line 528
    invoke-direct {v10, v8, v4}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 531
    new-instance v4, Lkotlin/Pair;

    .line 533
    invoke-direct {v4, v2, v10}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 536
    filled-new-array {v3, v6, v7, v4}, [Lkotlin/Pair;

    .line 539
    move-result-object v2

    .line 540
    invoke-static {v2}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 543
    move-result-object v2

    .line 544
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 547
    move-result-object v28

    .line 548
    :goto_223
    invoke-interface/range {v28 .. v28}, Ljava/util/Iterator;->hasNext()Z

    .line 551
    move-result v2

    .line 552
    if-eqz v2, :cond_2e9

    .line 554
    invoke-interface/range {v28 .. v28}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 557
    move-result-object v2

    .line 558
    check-cast v2, Lkotlin/Pair;

    .line 560
    iget-object v3, v2, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 562
    check-cast v3, Ljava/lang/Number;

    .line 564
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 567
    move-result v3

    .line 568
    iget-object v2, v2, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 570
    check-cast v2, Lkotlin/Pair;

    .line 572
    invoke-static {v3}, Lcom/spotifry/music/data/Log;->hourName(I)Ljava/lang/String;

    .line 575
    move-result-object v4

    .line 576
    iget-object v6, v2, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 578
    check-cast v6, Landroidx/compose/ui/unit/Dp;

    .line 580
    iget v6, v6, Landroidx/compose/ui/unit/Dp;->value:F

    .line 582
    move-object/from16 v11, v21

    .line 584
    invoke-static {v11, v5, v6, v1}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 587
    move-result-object v6

    .line 588
    const/4 v7, 0x2

    .line 589
    invoke-static {v6, v9, v5, v7}, Landroidx/compose/foundation/layout/OffsetKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 592
    move-result-object v6

    .line 593
    invoke-virtual/range {p1 .. p1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 596
    move-result v8

    .line 597
    div-float v8, v8, v27

    .line 599
    sub-float/2addr v8, v9

    .line 600
    iget-object v2, v2, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 602
    check-cast v2, Landroidx/compose/ui/unit/Dp;

    .line 604
    iget v2, v2, Landroidx/compose/ui/unit/Dp;->value:F

    .line 606
    add-float/2addr v8, v2

    .line 607
    new-instance v2, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;

    .line 609
    const/high16 v10, 0x3f000000  # 0.5f

    .line 611
    invoke-direct {v2, v8, v10}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;-><init>(FF)V

    .line 614
    invoke-static {v6, v2}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 617
    move-result-object v2

    .line 618
    move-object/from16 v6, p3

    .line 620
    invoke-virtual {v12, v6}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 623
    move-result v8

    .line 624
    invoke-virtual {v12, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 627
    move-result v10

    .line 628
    or-int/2addr v8, v10

    .line 629
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 632
    move-result-object v10

    .line 633
    if-nez v8, :cond_27f

    .line 635
    move-object/from16 v8, v26

    .line 637
    if-ne v10, v8, :cond_289

    .line 639
    goto :goto_281

    .line 640
    :cond_27f
    move-object/from16 v8, v26

    .line 642
    :goto_281
    new-instance v10, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;

    .line 644
    invoke-direct {v10, v6, v3, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda36;-><init>(Ljava/lang/Object;IB)V

    .line 647
    invoke-virtual {v12, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 650
    :cond_289
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 652
    invoke-static {v2, v10}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 655
    move-result-object v3

    .line 656
    move-object v2, v4

    .line 657
    move v10, v5

    .line 658
    invoke-static {v12}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 661
    move-result-wide v4

    .line 662
    const/16 v24, 0x6000

    .line 664
    const v25, 0x1bff8

    .line 667
    move-object/from16 v19, v6

    .line 669
    const-wide/16 v6, 0x0

    .line 671
    move-object/from16 v18, v8

    .line 673
    const/4 v8, 0x0

    .line 674
    move v14, v9

    .line 675
    const/4 v9, 0x0

    .line 676
    move/from16 v16, v10

    .line 678
    const/4 v10, 0x0

    .line 679
    move-object/from16 v21, v11

    .line 681
    move-object/from16 v22, v12

    .line 683
    const-wide/16 v11, 0x0

    .line 685
    const/4 v13, 0x0

    .line 686
    move/from16 v23, v14

    .line 688
    move/from16 v20, v15

    .line 690
    const-wide/16 v14, 0x0

    .line 692
    move/from16 v26, v16

    .line 694
    const/16 v16, 0x0

    .line 696
    const/16 v17, 0x0

    .line 698
    move-object/from16 v30, v18

    .line 700
    const/16 v18, 0x1

    .line 702
    move-object/from16 v31, v19

    .line 704
    const/16 v19, 0x0

    .line 706
    move/from16 v32, v20

    .line 708
    const/16 v20, 0x0

    .line 710
    move/from16 v33, v23

    .line 712
    const/16 v23, 0x0

    .line 714
    move-object/from16 v34, v21

    .line 716
    move-object/from16 v21, v0

    .line 718
    move-object/from16 v0, v34

    .line 720
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 723
    move-object/from16 p3, v21

    .line 725
    move-object/from16 v21, v0

    .line 727
    move-object/from16 v0, p3

    .line 729
    move-object/from16 v12, v22

    .line 731
    move/from16 v5, v26

    .line 733
    move-object/from16 v26, v30

    .line 735
    move-object/from16 p3, v31

    .line 737
    move/from16 v15, v32

    .line 739
    move/from16 v9, v33

    .line 741
    goto/16 :goto_223

    .line 743
    :cond_2e6
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 746
    :cond_2e9
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 748
    return-object v0
.end method
