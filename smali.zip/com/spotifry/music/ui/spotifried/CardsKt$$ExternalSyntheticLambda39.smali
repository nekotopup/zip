# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/lang/Integer;

.field public final synthetic f$1:Z

.field public final synthetic f$10:I

.field public final synthetic f$11:J

.field public final synthetic f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

.field public final synthetic f$3:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$4:I

.field public final synthetic f$5:I

.field public final synthetic f$6:J

.field public final synthetic f$7:J

.field public final synthetic f$8:Ljava/util/List;

.field public final synthetic f$9:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Integer;ZLcom/spotifry/music/data/spotifried/AgeStats;Landroidx/compose/animation/core/Animatable;IIJJLjava/util/List;IIJ)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$0:Ljava/lang/Integer;

    .line 6
    iput-boolean p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$1:Z

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 12
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$4:I

    .line 14
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$5:I

    .line 16
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$6:J

    .line 18
    iput-wide p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$7:J

    .line 20
    iput-object p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$8:Ljava/util/List;

    .line 22
    iput p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$9:I

    .line 24
    iput p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$10:I

    .line 26
    iput-wide p14, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$11:J

    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 55

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    const-string v3, "14 in "

    .line 21
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    and-int/lit8 v4, v2, 0x6

    .line 26
    if-nez v4, :cond_25

    .line 28
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 31
    move-result v4

    .line 32
    if-eqz v4, :cond_23

    .line 34
    const/4 v4, 0x4

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    const/4 v4, 0x2

    .line 37
    :goto_24
    or-int/2addr v2, v4

    .line 38
    :cond_25
    and-int/lit8 v4, v2, 0x13

    .line 40
    const/16 v6, 0x12

    .line 42
    const/4 v7, 0x1

    .line 43
    const/4 v8, 0x0

    .line 44
    if-eq v4, v6, :cond_2f

    .line 46
    move v4, v7

    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move v4, v8

    .line 49
    :goto_30
    and-int/2addr v2, v7

    .line 50
    invoke-virtual {v5, v2, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 53
    move-result v2

    .line 54
    if-eqz v2, :cond_5cf

    .line 56
    sget-object v9, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 58
    const/16 v2, 0x28

    .line 60
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 63
    move-result-wide v12

    .line 64
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 67
    move-result-wide v20

    .line 68
    const-wide v10, -0x400999999999999aL  # -1.4

    .line 73
    invoke-static {v10, v11}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 76
    move-result-wide v17

    .line 77
    const/16 v23, 0x0

    .line 79
    const v24, 0xfdff7d

    .line 82
    const-wide/16 v10, 0x0

    .line 84
    const/4 v14, 0x0

    .line 85
    const/4 v15, 0x0

    .line 86
    const/16 v16, 0x0

    .line 88
    const/16 v19, 0x0

    .line 90
    const/16 v22, 0x0

    .line 92
    invoke-static/range {v9 .. v24}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 95
    move-result-object v19

    .line 96
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$0:Ljava/lang/Integer;

    .line 98
    iget-wide v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$7:J

    .line 100
    const-string v4, "."

    .line 102
    if-eqz v2, :cond_ff

    .line 104
    const v6, 0x583b13fd

    .line 107
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 110
    new-instance v6, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 112
    invoke-direct {v6}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 115
    const-string v9, "You listen like someone who was "

    .line 117
    invoke-virtual {v6, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 120
    new-instance v20, Landroidx/compose/ui/text/SpanStyle;

    .line 122
    const/16 v38, 0x0

    .line 124
    const v39, 0xfffe

    .line 127
    const-wide/16 v23, 0x0

    .line 129
    const/16 v25, 0x0

    .line 131
    const/16 v26, 0x0

    .line 133
    const/16 v27, 0x0

    .line 135
    const/16 v28, 0x0

    .line 137
    const/16 v29, 0x0

    .line 139
    const-wide/16 v30, 0x0

    .line 141
    const/16 v32, 0x0

    .line 143
    const/16 v33, 0x0

    .line 145
    const/16 v34, 0x0

    .line 147
    const-wide/16 v35, 0x0

    .line 149
    const/16 v37, 0x0

    .line 151
    move-wide/from16 v21, v12

    .line 153
    invoke-direct/range {v20 .. v39}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 156
    move-object/from16 v9, v20

    .line 158
    move-wide/from16 v30, v21

    .line 160
    invoke-virtual {v6, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 163
    move-result v9

    .line 164
    :try_start_a3
    new-instance v10, Ljava/lang/StringBuilder;

    .line 166
    invoke-direct {v10, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 169
    invoke-virtual {v10, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 172
    invoke-virtual {v10, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 175
    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 178
    move-result-object v3

    .line 179
    invoke-virtual {v6, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_b5
    .catchall {:try_start_a3 .. :try_end_b5} :catchall_fa

    .line 182
    invoke-virtual {v6, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 185
    move-object/from16 v29, v2

    .line 187
    invoke-virtual {v6}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 190
    move-result-object v2

    .line 191
    const/16 v22, 0x0

    .line 193
    const v23, 0x3fffe

    .line 196
    const/4 v3, 0x0

    .line 197
    move-object v6, v4

    .line 198
    move-object/from16 v20, v5

    .line 200
    const-wide/16 v4, 0x0

    .line 202
    move-object v9, v6

    .line 203
    const-wide/16 v6, 0x0

    .line 205
    move v11, v8

    .line 206
    const/4 v8, 0x0

    .line 207
    move-object v12, v9

    .line 208
    const-wide/16 v9, 0x0

    .line 210
    move v15, v11

    .line 211
    move-object v14, v12

    .line 212
    const-wide/16 v11, 0x0

    .line 214
    const/4 v13, 0x0

    .line 215
    move-object/from16 v17, v14

    .line 217
    const/4 v14, 0x0

    .line 218
    move/from16 v18, v15

    .line 220
    const/4 v15, 0x0

    .line 221
    const/16 v16, 0x0

    .line 223
    move-object/from16 v24, v17

    .line 225
    const/16 v17, 0x0

    .line 227
    move/from16 v25, v18

    .line 229
    const/16 v18, 0x0

    .line 231
    const/16 v21, 0x0

    .line 233
    move-object/from16 p1, v1

    .line 235
    move-object/from16 v42, v24

    .line 237
    move/from16 v1, v25

    .line 239
    move-object/from16 v41, v29

    .line 241
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 244
    move-object/from16 v5, v20

    .line 246
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 249
    goto/16 :goto_174

    .line 251
    :catchall_fa
    move-exception v0

    .line 252
    invoke-virtual {v6, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 255
    throw v0

    .line 256
    :cond_ff
    move-object/from16 p1, v1

    .line 258
    move-object/from16 v41, v2

    .line 260
    move-object/from16 v42, v4

    .line 262
    move v1, v8

    .line 263
    move-wide/from16 v30, v12

    .line 265
    const v2, 0x583dddd6

    .line 268
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 271
    new-instance v2, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 273
    invoke-direct {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 276
    const-string v3, "How old is "

    .line 278
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 281
    new-instance v20, Landroidx/compose/ui/text/SpanStyle;

    .line 283
    const/16 v38, 0x0

    .line 285
    const v39, 0xfffe

    .line 288
    const-wide/16 v23, 0x0

    .line 290
    const/16 v25, 0x0

    .line 292
    const/16 v26, 0x0

    .line 294
    const/16 v27, 0x0

    .line 296
    const/16 v28, 0x0

    .line 298
    const/16 v29, 0x0

    .line 300
    move-wide/from16 v21, v30

    .line 302
    const-wide/16 v30, 0x0

    .line 304
    const/16 v32, 0x0

    .line 306
    const/16 v33, 0x0

    .line 308
    const/16 v34, 0x0

    .line 310
    const-wide/16 v35, 0x0

    .line 312
    const/16 v37, 0x0

    .line 314
    invoke-direct/range {v20 .. v39}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 317
    move-object/from16 v3, v20

    .line 319
    move-wide/from16 v30, v21

    .line 321
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 324
    move-result v3

    .line 325
    :try_start_144
    const-string v4, "your music?"

    .line 327
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_149
    .catchall {:try_start_144 .. :try_end_149} :catchall_5ca

    .line 330
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 333
    invoke-virtual {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 336
    move-result-object v2

    .line 337
    const/16 v22, 0x0

    .line 339
    const v23, 0x3fffe

    .line 342
    const/4 v3, 0x0

    .line 343
    move-object/from16 v20, v5

    .line 345
    const-wide/16 v4, 0x0

    .line 347
    const-wide/16 v6, 0x0

    .line 349
    const/4 v8, 0x0

    .line 350
    const-wide/16 v9, 0x0

    .line 352
    const-wide/16 v11, 0x0

    .line 354
    const/4 v13, 0x0

    .line 355
    const/4 v14, 0x0

    .line 356
    const/4 v15, 0x0

    .line 357
    const/16 v16, 0x0

    .line 359
    const/16 v17, 0x0

    .line 361
    const/16 v18, 0x0

    .line 363
    const/16 v21, 0x0

    .line 365
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 368
    move-object/from16 v5, v20

    .line 370
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 373
    :goto_174
    iget-boolean v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$1:Z

    .line 375
    const v9, 0x56b97230

    .line 378
    if-eqz v8, :cond_191

    .line 380
    const v2, 0x34652d2e

    .line 383
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 386
    const v2, 0x3f19999a  # 0.6f

    .line 389
    move-object/from16 v10, p1

    .line 391
    invoke-static {v10, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 394
    move-result-object v2

    .line 395
    invoke-static {v5, v2}, Landroidx/compose/foundation/layout/OffsetKt;->Spacer(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)V

    .line 398
    :goto_18d
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 401
    goto :goto_197

    .line 402
    :cond_191
    move-object/from16 v10, p1

    .line 404
    invoke-virtual {v5, v9}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 407
    goto :goto_18d

    .line 408
    :goto_197
    const/high16 v11, 0x3f800000  # 1.0f

    .line 410
    if-eqz v8, :cond_19f

    .line 412
    const v2, 0x3f333333  # 0.7f

    .line 415
    goto :goto_1a0

    .line 416
    :cond_19f
    move v2, v11

    .line 417
    :goto_1a0
    invoke-static {v10, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 420
    move-result-object v2

    .line 421
    invoke-static {v2, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 424
    move-result-object v2

    .line 425
    invoke-static {v2}, Landroidx/compose/ui/draw/ClipKt;->clipToBounds(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 428
    move-result-object v2

    .line 429
    new-instance v20, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;

    .line 431
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$8:Ljava/util/List;

    .line 433
    iget-wide v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$6:J

    .line 435
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 437
    iget v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$9:I

    .line 439
    iget v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$10:I

    .line 441
    iget-wide v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$11:J

    .line 443
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 445
    move-object/from16 v21, v3

    .line 447
    move-object/from16 v24, v4

    .line 449
    move-wide/from16 v22, v6

    .line 451
    move-object/from16 v32, v9

    .line 453
    move/from16 v25, v12

    .line 455
    move/from16 v26, v13

    .line 457
    move-wide/from16 v27, v14

    .line 459
    move-object/from16 v29, v41

    .line 461
    invoke-direct/range {v20 .. v32}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;-><init>(Ljava/util/List;JLandroidx/compose/animation/core/Animatable;IIJLjava/lang/Integer;JLcom/spotifry/music/data/spotifried/AgeStats;)V

    .line 464
    move-object/from16 v3, v20

    .line 466
    move-object/from16 v12, v24

    .line 468
    const v4, 0x5be6f828

    .line 471
    invoke-static {v4, v3, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 474
    move-result-object v4

    .line 475
    const/16 v6, 0xc00

    .line 477
    const/4 v7, 0x6

    .line 478
    const/4 v3, 0x0

    .line 479
    invoke-static/range {v2 .. v7}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 482
    const/16 v2, 0xb

    .line 484
    sget-object v13, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 486
    sget-object v3, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 488
    if-eqz v29, :cond_41d

    .line 490
    const v0, 0x58778822

    .line 493
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 496
    iget-object v0, v9, Lcom/spotifry/music/data/spotifried/AgeStats;->age:Ljava/lang/Integer;

    .line 498
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 501
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 504
    move-result v0

    .line 505
    int-to-float v0, v0

    .line 506
    invoke-virtual {v12}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 509
    move-result-object v4

    .line 510
    check-cast v4, Ljava/lang/Number;

    .line 512
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 515
    move-result v4

    .line 516
    const v6, 0x453b8000  # 3000.0f

    .line 519
    const/high16 v7, 0x44610000  # 900.0f

    .line 521
    invoke-static {v4, v6, v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 524
    move-result v4

    .line 525
    mul-float/2addr v4, v0

    .line 526
    invoke-static {v4}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 529
    move-result v0

    .line 530
    invoke-static {v0}, Lcom/spotifry/music/ui/listening/ListeningScreenKt;->count(I)Ljava/lang/String;

    .line 533
    move-result-object v0

    .line 534
    invoke-virtual {v5, v12}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 537
    move-result v4

    .line 538
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 541
    move-result-object v6

    .line 542
    if-nez v4, :cond_221

    .line 544
    if-ne v6, v3, :cond_22a

    .line 546
    :cond_221
    new-instance v6, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda11;

    .line 548
    const/4 v4, 0x1

    .line 549
    invoke-direct {v6, v12, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda11;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 552
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 555
    :cond_22a
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 557
    iget-object v7, v9, Lcom/spotifry/music/data/spotifried/AgeStats;->years:Ljava/util/List;

    .line 559
    new-instance v8, Lokhttp3/ConnectionPool;

    .line 561
    invoke-direct {v8, v7}, Lokhttp3/ConnectionPool;-><init>(Ljava/lang/Object;)V

    .line 564
    invoke-static {v8}, Lkotlin/math/MathKt;->eachCount(Lkotlin/collections/Grouping;)Ljava/util/Map;

    .line 567
    move-result-object v7

    .line 568
    invoke-interface {v7}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    .line 571
    move-result-object v7

    .line 572
    check-cast v7, Ljava/lang/Iterable;

    .line 574
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 577
    move-result-object v7

    .line 578
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 581
    move-result v8

    .line 582
    const/4 v9, 0x0

    .line 583
    if-nez v8, :cond_24a

    .line 585
    move-object v8, v9

    .line 586
    goto :goto_27c

    .line 587
    :cond_24a
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 590
    move-result-object v8

    .line 591
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 594
    move-result v10

    .line 595
    if-eqz v10, :cond_27c

    .line 597
    move-object v10, v8

    .line 598
    check-cast v10, Ljava/util/Map$Entry;

    .line 600
    invoke-interface {v10}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 603
    move-result-object v10

    .line 604
    check-cast v10, Ljava/lang/Number;

    .line 606
    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    .line 609
    move-result v10

    .line 610
    :cond_261
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 613
    move-result-object v11

    .line 614
    move-object v12, v11

    .line 615
    check-cast v12, Ljava/util/Map$Entry;

    .line 617
    invoke-interface {v12}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 620
    move-result-object v12

    .line 621
    check-cast v12, Ljava/lang/Number;

    .line 623
    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    .line 626
    move-result v12

    .line 627
    if-ge v10, v12, :cond_276

    .line 629
    move-object v8, v11

    .line 630
    move v10, v12

    .line 631
    :cond_276
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 634
    move-result v11

    .line 635
    if-nez v11, :cond_261

    .line 637
    :cond_27c
    :goto_27c
    check-cast v8, Ljava/util/Map$Entry;

    .line 639
    if-eqz v8, :cond_287

    .line 641
    invoke-interface {v8}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 644
    move-result-object v7

    .line 645
    move-object v9, v7

    .line 646
    check-cast v9, Ljava/lang/Integer;

    .line 648
    :cond_287
    if-eqz v9, :cond_2a6

    .line 650
    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    .line 653
    move-result v7

    .line 654
    const/16 v8, 0x776

    .line 656
    const-string v9, "s"

    .line 658
    if-gt v8, v7, :cond_299

    .line 660
    const/16 v8, 0x7c7

    .line 662
    if-ge v7, v8, :cond_299

    .line 664
    rem-int/lit8 v7, v7, 0x64

    .line 666
    :cond_299
    invoke-static {v7, v9}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 669
    move-result-object v7

    .line 670
    const-string v8, " Most of your songs are from the "

    .line 672
    move-object/from16 v12, v42

    .line 674
    invoke-static {v8, v7, v12}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 677
    move-result-object v7

    .line 678
    goto :goto_2a8

    .line 679
    :cond_2a6
    const-string v7, ""

    .line 681
    :goto_2a8
    const-string v8, "Your listening age."

    .line 683
    invoke-virtual {v8, v7}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 686
    move-result-object v26

    .line 687
    const/16 v17, 0x0

    .line 689
    const/16 v18, 0xd

    .line 691
    const/4 v14, 0x0

    .line 692
    const/high16 v15, 0x40c00000  # 6.0f

    .line 694
    const/16 v16, 0x0

    .line 696
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 699
    move-result-object v7

    .line 700
    move-object/from16 v27, v13

    .line 702
    new-instance v8, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 704
    new-instance v9, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 706
    const/4 v10, 0x3

    .line 707
    invoke-direct {v9, v10}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 710
    const/high16 v10, 0x41200000  # 10.0f

    .line 712
    invoke-direct {v8, v10, v9}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 715
    sget-object v9, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 717
    const/4 v10, 0x6

    .line 718
    invoke-static {v8, v9, v5, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 721
    move-result-object v8

    .line 722
    iget-wide v9, v5, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 724
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 727
    move-result v9

    .line 728
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 731
    move-result-object v10

    .line 732
    invoke-static {v5, v7}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 735
    move-result-object v7

    .line 736
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 738
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 741
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 743
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 746
    iget-boolean v12, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 748
    if-eqz v12, :cond_2f1

    .line 750
    invoke-virtual {v5, v11}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 753
    goto :goto_2f4

    .line 754
    :cond_2f1
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 757
    :goto_2f4
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 759
    invoke-static {v5, v8, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 762
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 764
    invoke-static {v5, v10, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 767
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 769
    iget-boolean v10, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 771
    if-nez v10, :cond_312

    .line 773
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 776
    move-result-object v10

    .line 777
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 780
    move-result-object v11

    .line 781
    invoke-static {v10, v11}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 784
    move-result v10

    .line 785
    if-nez v10, :cond_315

    .line 787
    :cond_312
    invoke-static {v9, v5, v9, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 790
    :cond_315
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 792
    invoke-static {v5, v7, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 795
    sget-object v7, Landroidx/compose/ui/layout/AlignmentLineKt;->FirstBaseline:Landroidx/compose/ui/layout/HorizontalAlignmentLine;

    .line 797
    new-instance v8, Landroidx/compose/foundation/layout/WithAlignmentLineElement;

    .line 799
    invoke-direct {v8, v7}, Landroidx/compose/foundation/layout/WithAlignmentLineElement;-><init>(Landroidx/compose/ui/layout/HorizontalAlignmentLine;)V

    .line 802
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 805
    move-result v9

    .line 806
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 809
    move-result-object v10

    .line 810
    if-nez v9, :cond_32d

    .line 812
    if-ne v10, v3, :cond_335

    .line 814
    :cond_32d
    new-instance v10, Landroidx/room/RoomDatabase$$ExternalSyntheticLambda3;

    .line 816
    invoke-direct {v10, v6, v2}, Landroidx/room/RoomDatabase$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/functions/Function0;B)V

    .line 819
    invoke-virtual {v5, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 822
    :cond_335
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 824
    invoke-static {v8, v10}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 827
    move-result-object v8

    .line 828
    sget-object v15, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 830
    sget-object v14, Landroidx/compose/ui/text/font/FontWeight;->Black:Landroidx/compose/ui/text/font/FontWeight;

    .line 832
    const/16 v9, 0x70

    .line 834
    invoke-static {v9}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 837
    move-result-wide v12

    .line 838
    const/16 v9, 0x60

    .line 840
    invoke-static {v9}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 843
    move-result-wide v19

    .line 844
    const-wide v9, -0x3fe999999999999aL  # -5.6

    .line 849
    invoke-static {v9, v10}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 852
    move-result-wide v16

    .line 853
    new-instance v21, Landroidx/compose/ui/text/TextStyle;

    .line 855
    move-object/from16 v9, v21

    .line 857
    const/16 v21, 0x0

    .line 859
    const v22, 0xfdff19

    .line 862
    const-wide/16 v10, 0x0

    .line 864
    const/16 v18, 0x0

    .line 866
    invoke-direct/range {v9 .. v22}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 869
    const/16 v24, 0x0

    .line 871
    const v25, 0x1fff8

    .line 874
    move-object v10, v6

    .line 875
    move-object v11, v7

    .line 876
    const-wide/16 v6, 0x0

    .line 878
    move-object v12, v3

    .line 879
    move-object v3, v8

    .line 880
    const/4 v8, 0x0

    .line 881
    move-object/from16 v21, v9

    .line 883
    const/4 v9, 0x0

    .line 884
    move-object v13, v10

    .line 885
    const/4 v10, 0x0

    .line 886
    move-object v14, v11

    .line 887
    move-object v15, v12

    .line 888
    const-wide/16 v11, 0x0

    .line 890
    move-object/from16 v16, v13

    .line 892
    const/4 v13, 0x0

    .line 893
    move-object/from16 v17, v14

    .line 895
    move-object/from16 v18, v15

    .line 897
    const-wide/16 v14, 0x0

    .line 899
    move-object/from16 v19, v16

    .line 901
    const/16 v16, 0x0

    .line 903
    move-object/from16 v20, v17

    .line 905
    const/16 v17, 0x0

    .line 907
    move-object/from16 v22, v18

    .line 909
    const/16 v18, 0x0

    .line 911
    move-object/from16 v23, v19

    .line 913
    const/16 v19, 0x0

    .line 915
    move-object/from16 v28, v20

    .line 917
    const/16 v20, 0x0

    .line 919
    move-object/from16 v29, v23

    .line 921
    const/16 v23, 0x0

    .line 923
    move v1, v2

    .line 924
    move-object v2, v0

    .line 925
    move-object/from16 v0, v29

    .line 927
    move/from16 v29, v1

    .line 929
    move-object/from16 v43, v22

    .line 931
    move-object/from16 v1, v28

    .line 933
    move-object/from16 v22, v5

    .line 935
    move-wide/from16 v4, v30

    .line 937
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 940
    move-object/from16 v5, v22

    .line 942
    new-instance v2, Landroidx/compose/foundation/layout/WithAlignmentLineElement;

    .line 944
    invoke-direct {v2, v1}, Landroidx/compose/foundation/layout/WithAlignmentLineElement;-><init>(Landroidx/compose/ui/layout/HorizontalAlignmentLine;)V

    .line 947
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 950
    move-result v1

    .line 951
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 954
    move-result-object v3

    .line 955
    if-nez v1, :cond_3c0

    .line 957
    move-object/from16 v1, v43

    .line 959
    if-ne v3, v1, :cond_3ca

    .line 961
    :cond_3c0
    new-instance v3, Landroidx/room/RoomDatabase$$ExternalSyntheticLambda3;

    .line 963
    const/16 v1, 0xc

    .line 965
    invoke-direct {v3, v0, v1}, Landroidx/room/RoomDatabase$$ExternalSyntheticLambda3;-><init>(Lkotlin/jvm/functions/Function0;B)V

    .line 968
    invoke-virtual {v5, v3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 971
    :cond_3ca
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 973
    invoke-static {v2, v3}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 976
    move-result-object v3

    .line 977
    move-object/from16 v22, v5

    .line 979
    invoke-static/range {v22 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 982
    move-result-wide v4

    .line 983
    sget-object v6, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 985
    const v20, 0x10303

    .line 988
    const v21, 0xdfffff

    .line 991
    const-wide/16 v7, 0x0

    .line 993
    const-wide/16 v9, 0x0

    .line 995
    const/4 v11, 0x0

    .line 996
    const/4 v12, 0x0

    .line 997
    const/4 v13, 0x0

    .line 998
    const-wide/16 v14, 0x0

    .line 1000
    const/16 v16, 0x0

    .line 1002
    const-wide/16 v17, 0x0

    .line 1004
    const/16 v19, 0x0

    .line 1006
    invoke-static/range {v6 .. v21}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 1009
    move-result-object v21

    .line 1010
    move-object v0, v6

    .line 1011
    const/16 v24, 0x0

    .line 1013
    const v25, 0x1fff8

    .line 1016
    const-wide/16 v6, 0x0

    .line 1018
    const/4 v8, 0x0

    .line 1019
    const/4 v9, 0x0

    .line 1020
    const/4 v10, 0x0

    .line 1021
    const-wide/16 v11, 0x0

    .line 1023
    const/16 v16, 0x0

    .line 1025
    const/16 v17, 0x0

    .line 1027
    const/16 v18, 0x0

    .line 1029
    const/16 v19, 0x0

    .line 1031
    const/16 v20, 0x0

    .line 1033
    const/16 v23, 0x0

    .line 1035
    move-object/from16 v2, v26

    .line 1037
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1040
    move-object/from16 v5, v22

    .line 1042
    const/4 v13, 0x1

    .line 1043
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1046
    const/4 v15, 0x0

    .line 1047
    invoke-virtual {v5, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1050
    move-object/from16 v30, v0

    .line 1052
    goto/16 :goto_573

    .line 1054
    :cond_41d
    move/from16 v29, v2

    .line 1056
    move-object v1, v3

    .line 1057
    move-object/from16 v27, v13

    .line 1059
    const/4 v13, 0x1

    .line 1060
    const v2, 0x588c8057

    .line 1063
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 1066
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$4:I

    .line 1068
    int-to-float v3, v2

    .line 1069
    iget v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;->f$5:I

    .line 1071
    add-int v7, v2, v0

    .line 1073
    if-lt v7, v13, :cond_433

    .line 1075
    move v13, v7

    .line 1076
    :cond_433
    int-to-float v0, v13

    .line 1077
    div-float v0, v3, v0

    .line 1079
    invoke-static {v2}, Lcom/spotifry/music/ui/listening/ListeningScreenKt;->count(I)Ljava/lang/String;

    .line 1082
    move-result-object v2

    .line 1083
    invoke-static {v7}, Lcom/spotifry/music/ui/listening/ListeningScreenKt;->count(I)Ljava/lang/String;

    .line 1086
    move-result-object v3

    .line 1087
    const-string v4, "Checking song years: "

    .line 1089
    const-string v6, " of "

    .line 1091
    invoke-static {v4, v2, v6, v3}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 1094
    move-result-object v2

    .line 1095
    const/16 v17, 0x0

    .line 1097
    const/16 v18, 0xd

    .line 1099
    const/4 v14, 0x0

    .line 1100
    const/high16 v15, 0x41600000  # 14.0f

    .line 1102
    const/16 v16, 0x0

    .line 1104
    move-object/from16 v13, v27

    .line 1106
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 1109
    move-result-object v3

    .line 1110
    move/from16 v26, v15

    .line 1112
    sget-object v38, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 1114
    sget-object v37, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 1116
    const/16 v4, 0x18

    .line 1118
    invoke-static {v4}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 1121
    move-result-wide v35

    .line 1122
    const/16 v4, 0x1c

    .line 1124
    invoke-static {v4}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 1127
    move-result-wide v42

    .line 1128
    const-wide v6, -0x4026666666666666L  # -0.4

    .line 1133
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 1136
    move-result-wide v39

    .line 1137
    new-instance v32, Landroidx/compose/ui/text/TextStyle;

    .line 1139
    const/16 v44, 0x0

    .line 1141
    const v45, 0xfdff19

    .line 1144
    const-wide/16 v33, 0x0

    .line 1146
    const/16 v41, 0x0

    .line 1148
    invoke-direct/range {v32 .. v45}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 1151
    const/16 v24, 0x0

    .line 1153
    const v25, 0x1fffc

    .line 1156
    move-object/from16 v20, v5

    .line 1158
    const-wide/16 v4, 0x0

    .line 1160
    const-wide/16 v6, 0x0

    .line 1162
    move v9, v8

    .line 1163
    const/4 v8, 0x0

    .line 1164
    move v12, v9

    .line 1165
    const/4 v9, 0x0

    .line 1166
    move-object v13, v10

    .line 1167
    const/4 v10, 0x0

    .line 1168
    move v14, v11

    .line 1169
    move v15, v12

    .line 1170
    const-wide/16 v11, 0x0

    .line 1172
    move-object/from16 v16, v13

    .line 1174
    const/4 v13, 0x0

    .line 1175
    move/from16 v17, v14

    .line 1177
    move/from16 v18, v15

    .line 1179
    const-wide/16 v14, 0x0

    .line 1181
    move-object/from16 v19, v16

    .line 1183
    const/16 v16, 0x0

    .line 1185
    move/from16 v21, v17

    .line 1187
    const/16 v17, 0x0

    .line 1189
    move/from16 v33, v18

    .line 1191
    const/16 v18, 0x0

    .line 1193
    move-object/from16 v34, v19

    .line 1195
    const/16 v19, 0x0

    .line 1197
    move-wide/from16 v35, v22

    .line 1199
    move-object/from16 v22, v20

    .line 1201
    const/16 v20, 0x0

    .line 1203
    const/16 v23, 0x30

    .line 1205
    move-object/from16 v43, v1

    .line 1207
    move/from16 v1, v21

    .line 1209
    move-wide/from16 v49, v30

    .line 1211
    move-object/from16 v21, v32

    .line 1213
    move-object/from16 v46, v34

    .line 1215
    move-wide/from16 v47, v35

    .line 1217
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1220
    move-object/from16 v5, v22

    .line 1222
    const/16 v17, 0x0

    .line 1224
    const/16 v18, 0xd

    .line 1226
    const/4 v14, 0x0

    .line 1227
    const/16 v16, 0x0

    .line 1229
    move/from16 v15, v26

    .line 1231
    move-object/from16 v13, v27

    .line 1233
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 1236
    move-result-object v2

    .line 1237
    invoke-static {v2, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 1240
    move-result-object v1

    .line 1241
    const/high16 v2, 0x40800000  # 4.0f

    .line 1243
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 1246
    move-result-object v1

    .line 1247
    const-string v2, "years_progress"

    .line 1249
    invoke-static {v1, v2}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 1252
    move-result-object v1

    .line 1253
    move-wide/from16 v10, v47

    .line 1255
    invoke-virtual {v5, v10, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 1258
    move-result v2

    .line 1259
    move-wide/from16 v12, v49

    .line 1261
    invoke-virtual {v5, v12, v13}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 1264
    move-result v3

    .line 1265
    or-int/2addr v2, v3

    .line 1266
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 1269
    move-result v3

    .line 1270
    or-int/2addr v2, v3

    .line 1271
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 1274
    move-result-object v3

    .line 1275
    if-nez v2, :cond_500

    .line 1277
    move-object/from16 v15, v43

    .line 1279
    if-ne v3, v15, :cond_50a

    .line 1281
    :cond_500
    new-instance v9, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;

    .line 1283
    move v14, v0

    .line 1284
    invoke-direct/range {v9 .. v14}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;-><init>(JJF)V

    .line 1287
    invoke-virtual {v5, v9}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1290
    move-object v3, v9

    .line 1291
    :cond_50a
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 1293
    invoke-static {v1, v3}, Landroidx/compose/ui/draw/ClipKt;->drawBehind(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 1296
    move-result-object v0

    .line 1297
    const/4 v15, 0x0

    .line 1298
    invoke-static {v0, v5, v15}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 1301
    const/16 v17, 0x0

    .line 1303
    const/16 v18, 0xd

    .line 1305
    const/4 v14, 0x0

    .line 1306
    const/high16 v15, 0x41400000  # 12.0f

    .line 1308
    const/16 v16, 0x0

    .line 1310
    move-object/from16 v13, v27

    .line 1312
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 1315
    move-result-object v3

    .line 1316
    move-object/from16 v22, v5

    .line 1318
    invoke-static/range {v22 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 1321
    move-result-wide v4

    .line 1322
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 1324
    const/high16 v24, 0xc00000

    .line 1326
    const v25, 0x1fff8

    .line 1329
    const-string v2, "Needs 20 songs with a year."

    .line 1331
    const-wide/16 v6, 0x0

    .line 1333
    const/4 v8, 0x0

    .line 1334
    const/4 v9, 0x0

    .line 1335
    const/4 v10, 0x0

    .line 1336
    const-wide/16 v11, 0x0

    .line 1338
    const/4 v13, 0x0

    .line 1339
    const-wide/16 v14, 0x0

    .line 1341
    const/16 v16, 0x0

    .line 1343
    const/16 v17, 0x0

    .line 1345
    const/16 v18, 0x0

    .line 1347
    const/16 v19, 0x0

    .line 1349
    const/16 v20, 0x0

    .line 1351
    const/16 v23, 0x36

    .line 1353
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1356
    move-object/from16 v5, v22

    .line 1358
    if-eqz v33, :cond_566

    .line 1360
    const v0, 0x34681b6e

    .line 1363
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 1366
    const v0, 0x3f4ccccd  # 0.8f

    .line 1369
    move-object/from16 v13, v46

    .line 1371
    invoke-static {v13, v0}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 1374
    move-result-object v0

    .line 1375
    invoke-static {v5, v0}, Landroidx/compose/foundation/layout/OffsetKt;->Spacer(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)V

    .line 1378
    const/4 v15, 0x0

    .line 1379
    :goto_562
    invoke-virtual {v5, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1382
    goto :goto_56e

    .line 1383
    :cond_566
    const v0, 0x56b97230

    .line 1386
    const/4 v15, 0x0

    .line 1387
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 1390
    goto :goto_562

    .line 1391
    :goto_56e
    invoke-virtual {v5, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1394
    move-object/from16 v30, v21

    .line 1396
    :goto_573
    const/16 v17, 0x0

    .line 1398
    const/16 v18, 0xd

    .line 1400
    const/4 v14, 0x0

    .line 1401
    const/high16 v15, 0x41000000  # 8.0f

    .line 1403
    const/16 v16, 0x0

    .line 1405
    move-object/from16 v13, v27

    .line 1407
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 1410
    move-result-object v3

    .line 1411
    move-object/from16 v22, v5

    .line 1413
    invoke-static/range {v22 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 1416
    move-result-wide v4

    .line 1417
    invoke-static/range {v29 .. v29}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 1420
    move-result-wide v33

    .line 1421
    const/16 v0, 0xe

    .line 1423
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 1426
    move-result-wide v41

    .line 1427
    const/16 v44, 0x0

    .line 1429
    const v45, 0xfdfffd

    .line 1432
    const-wide/16 v31, 0x0

    .line 1434
    const/16 v35, 0x0

    .line 1436
    const/16 v36, 0x0

    .line 1438
    const/16 v37, 0x0

    .line 1440
    const-wide/16 v38, 0x0

    .line 1442
    const/16 v40, 0x0

    .line 1444
    const/16 v43, 0x0

    .line 1446
    invoke-static/range {v30 .. v45}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 1449
    move-result-object v21

    .line 1450
    const/16 v24, 0x0

    .line 1452
    const v25, 0x1fff8

    .line 1455
    const-string v2, "Song years from MusicBrainz"

    .line 1457
    const-wide/16 v6, 0x0

    .line 1459
    const/4 v8, 0x0

    .line 1460
    const/4 v9, 0x0

    .line 1461
    const/4 v10, 0x0

    .line 1462
    const-wide/16 v11, 0x0

    .line 1464
    const/4 v13, 0x0

    .line 1465
    const-wide/16 v14, 0x0

    .line 1467
    const/16 v16, 0x0

    .line 1469
    const/16 v17, 0x0

    .line 1471
    const/16 v18, 0x0

    .line 1473
    const/16 v19, 0x0

    .line 1475
    const/16 v20, 0x0

    .line 1477
    const/16 v23, 0x36

    .line 1479
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1482
    goto :goto_5d4

    .line 1483
    :catchall_5ca
    move-exception v0

    .line 1484
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 1487
    throw v0

    .line 1488
    :cond_5cf
    move-object/from16 v22, v5

    .line 1490
    invoke-virtual/range {v22 .. v22}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 1493
    :goto_5d4
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1495
    return-object v0
.end method
