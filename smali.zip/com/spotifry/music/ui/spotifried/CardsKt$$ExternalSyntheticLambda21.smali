# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/lang/Integer;

.field public final synthetic f$1:F

.field public final synthetic f$10:I

.field public final synthetic f$11:J

.field public final synthetic f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

.field public final synthetic f$3:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$4:I

.field public final synthetic f$5:I

.field public final synthetic f$6:J

.field public final synthetic f$7:J

.field public final synthetic f$8:Ljava/util/List;

.field public final synthetic f$9:I


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Integer;FLcom/spotifry/music/data/spotifried/AgeStats;Landroidx/compose/animation/core/Animatable;IIJJLjava/util/List;IIJ)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$0:Ljava/lang/Integer;

    .line 6
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$1:F

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 12
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$4:I

    .line 14
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$5:I

    .line 16
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$6:J

    .line 18
    iput-wide p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$7:J

    .line 20
    iput-object p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$8:Ljava/util/List;

    .line 22
    iput p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$9:I

    .line 24
    iput p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$10:I

    .line 26
    iput-wide p14, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$11:J

    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 28

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 24
    if-nez v4, :cond_23

    .line 26
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v4

    .line 30
    if-eqz v4, :cond_21

    .line 32
    const/4 v4, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v4, 0x2

    .line 35
    :goto_22
    or-int/2addr v3, v4

    .line 36
    :cond_23
    and-int/lit8 v4, v3, 0x13

    .line 38
    const/16 v5, 0x12

    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v7, 0x1

    .line 42
    if-eq v4, v5, :cond_2d

    .line 44
    move v4, v7

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move v4, v6

    .line 47
    :goto_2e
    and-int/2addr v3, v7

    .line 48
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 51
    move-result v3

    .line 52
    if-eqz v3, :cond_80

    .line 54
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$0:Ljava/lang/Integer;

    .line 56
    if-nez v9, :cond_4f

    .line 58
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 61
    move-result v1

    .line 62
    const/high16 v3, 0x44020000  # 520.0f

    .line 64
    invoke-static {v1, v3}, Ljava/lang/Float;->compare(FF)I

    .line 67
    move-result v1

    .line 68
    if-ltz v1, :cond_4f

    .line 70
    const/high16 v1, 0x3fc00000  # 1.5f

    .line 72
    iget v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$1:F

    .line 74
    cmpg-float v1, v3, v1

    .line 76
    if-gez v1, :cond_4f

    .line 78
    move v10, v7

    .line 79
    goto :goto_50

    .line 80
    :cond_4f
    move v10, v6

    .line 81
    :goto_50
    new-instance v8, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;

    .line 83
    iget-object v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$2:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 85
    iget-object v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 87
    iget v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$4:I

    .line 89
    iget v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$5:I

    .line 91
    iget-wide v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$6:J

    .line 93
    iget-wide v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$7:J

    .line 95
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$8:Ljava/util/List;

    .line 97
    iget v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$9:I

    .line 99
    iget v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$10:I

    .line 101
    move-object/from16 v19, v1

    .line 103
    iget-wide v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;->f$11:J

    .line 105
    move-wide/from16 v22, v0

    .line 107
    move-wide/from16 v17, v5

    .line 109
    move/from16 v20, v7

    .line 111
    move/from16 v21, v15

    .line 113
    move-wide v15, v3

    .line 114
    invoke-direct/range {v8 .. v23}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda39;-><init>(Ljava/lang/Integer;ZLcom/spotifry/music/data/spotifried/AgeStats;Landroidx/compose/animation/core/Animatable;IIJJLjava/util/List;IIJ)V

    .line 117
    const v0, 0x3222bc52

    .line 120
    invoke-static {v0, v8, v2}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 123
    move-result-object v0

    .line 124
    const/4 v1, 0x6

    .line 125
    invoke-static {v0, v2, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 128
    goto :goto_83

    .line 129
    :cond_80
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 132
    :goto_83
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 134
    return-object v0
.end method
