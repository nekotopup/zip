# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$1:J

.field public final synthetic f$2:F

.field public final synthetic f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$4:F

.field public final synthetic f$5:Lcom/spotifry/music/ui/listening/SunMotion;

.field public final synthetic f$6:Z


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;JFLcom/spotifry/music/data/spotifried/SpotifriedStats;FLcom/spotifry/music/ui/listening/SunMotion;Z)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$1:J

    .line 8
    iput p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$2:F

    .line 10
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 12
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$4:F

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$5:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 16
    iput-boolean p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$6:Z

    .line 18
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v12, p2

    .line 9
    check-cast v12, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    if-nez v3, :cond_23

    .line 26
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_21

    .line 32
    const/4 v3, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v3, 0x2

    .line 35
    :goto_22
    or-int/2addr v2, v3

    .line 36
    :cond_23
    and-int/lit8 v3, v2, 0x13

    .line 38
    const/16 v5, 0x12

    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v15, 0x1

    .line 42
    if-eq v3, v5, :cond_2d

    .line 44
    move v3, v15

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move v3, v6

    .line 47
    :goto_2e
    and-int/2addr v2, v15

    .line 48
    invoke-virtual {v12, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 51
    move-result v2

    .line 52
    if-eqz v2, :cond_1fa

    .line 54
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 57
    move-result v1

    .line 58
    const v2, 0x3faa3d71  # 1.33f

    .line 61
    mul-float/2addr v1, v2

    .line 62
    sget-object v2, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 64
    invoke-virtual {v12, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 67
    move-result-object v2

    .line 68
    check-cast v2, Landroidx/compose/ui/unit/Density;

    .line 70
    const/high16 v3, 0x430c0000  # 140.0f

    .line 72
    invoke-interface {v2, v3}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 75
    move-result v2

    .line 76
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 78
    const/high16 v5, 0x3f800000  # 1.0f

    .line 80
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 83
    move-result-object v7

    .line 84
    new-instance v8, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 86
    const/16 v9, 0xd

    .line 88
    invoke-direct {v8, v9}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 91
    invoke-static {v7, v8}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 94
    move-result-object v7

    .line 95
    new-instance v8, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 97
    const/16 v9, 0xe

    .line 99
    invoke-direct {v8, v9}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 102
    invoke-static {v7, v8}, Landroidx/compose/ui/draw/ClipKt;->drawWithContent(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 105
    move-result-object v7

    .line 106
    sget-object v8, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 108
    invoke-static {v8, v6}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 111
    move-result-object v9

    .line 112
    iget-wide v10, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 114
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 117
    move-result v10

    .line 118
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 121
    move-result-object v11

    .line 122
    invoke-static {v12, v7}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 125
    move-result-object v7

    .line 126
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 128
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 131
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 133
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 136
    iget-boolean v14, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 138
    if-eqz v14, :cond_8f

    .line 140
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 143
    goto :goto_92

    .line 144
    :cond_8f
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 147
    :goto_92
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 149
    invoke-static {v12, v9, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 152
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 154
    invoke-static {v12, v11, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 157
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 159
    iget-boolean v4, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 161
    if-nez v4, :cond_b0

    .line 163
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 166
    move-result-object v4

    .line 167
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 170
    move-result-object v5

    .line 171
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 174
    move-result v4

    .line 175
    if-nez v4, :cond_b3

    .line 177
    :cond_b0
    invoke-static {v10, v12, v10, v11}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 180
    :cond_b3
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 182
    invoke-static {v12, v7, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 185
    sget-object v5, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    .line 187
    sget-object v7, Landroidx/compose/ui/Alignment$Companion;->BottomCenter:Landroidx/compose/ui/BiasAlignment;

    .line 189
    invoke-virtual {v5, v3, v7}, Landroidx/compose/foundation/layout/BoxScopeInstance;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;)Landroidx/compose/ui/Modifier;

    .line 192
    move-result-object v5

    .line 193
    const/high16 v7, 0x40000000  # 2.0f

    .line 195
    div-float v7, v1, v7

    .line 197
    const/high16 v10, 0x42480000  # 50.0f

    .line 199
    sub-float/2addr v7, v10

    .line 200
    const/4 v10, 0x0

    .line 201
    invoke-static {v5, v10, v7, v15}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 204
    move-result-object v5

    .line 205
    invoke-static {v5, v1}, Landroidx/compose/foundation/layout/SizeKt;->requiredSize-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 208
    move-result-object v1

    .line 209
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 211
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 214
    move-result v7

    .line 215
    invoke-virtual {v12, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 218
    move-result v10

    .line 219
    or-int/2addr v7, v10

    .line 220
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 223
    move-result-object v10

    .line 224
    sget-object v6, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 226
    if-nez v7, :cond_e5

    .line 228
    if-ne v10, v6, :cond_ed

    .line 230
    :cond_e5
    new-instance v10, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 232
    invoke-direct {v10, v5, v2, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 235
    invoke-virtual {v12, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 238
    :cond_ed
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 240
    invoke-static {v1, v10}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 243
    move-result-object v1

    .line 244
    const/4 v2, 0x0

    .line 245
    invoke-static {v8, v2}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 248
    move-result-object v5

    .line 249
    move-object v2, v8

    .line 250
    iget-wide v7, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 252
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 255
    move-result v7

    .line 256
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 259
    move-result-object v8

    .line 260
    invoke-static {v12, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 263
    move-result-object v1

    .line 264
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 267
    iget-boolean v10, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 269
    if-eqz v10, :cond_112

    .line 271
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 274
    goto :goto_115

    .line 275
    :cond_112
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 278
    :goto_115
    invoke-static {v12, v5, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 281
    invoke-static {v12, v8, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 284
    iget-boolean v5, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 286
    if-nez v5, :cond_12d

    .line 288
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 291
    move-result-object v5

    .line 292
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 295
    move-result-object v8

    .line 296
    invoke-static {v5, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 299
    move-result v5

    .line 300
    if-nez v5, :cond_130

    .line 302
    :cond_12d
    invoke-static {v7, v12, v7, v11}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 305
    :cond_130
    invoke-static {v12, v1, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 308
    const/high16 v1, 0x3f800000  # 1.0f

    .line 310
    invoke-static {v3, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 313
    move-result-object v5

    .line 314
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$1:J

    .line 316
    invoke-virtual {v12, v7, v8}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 319
    move-result v1

    .line 320
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 323
    move-result-object v10

    .line 324
    if-nez v1, :cond_147

    .line 326
    if-ne v10, v6, :cond_151

    .line 328
    :cond_147
    new-instance v10, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 330
    const/16 v1, 0xc

    .line 332
    invoke-direct {v10, v7, v8, v1}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 335
    invoke-virtual {v12, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 338
    :cond_151
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 340
    const/4 v1, 0x6

    .line 341
    invoke-static {v5, v10, v12, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 344
    const/high16 v5, 0x3f800000  # 1.0f

    .line 346
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 349
    move-result-object v10

    .line 350
    iget v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$2:F

    .line 352
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 355
    move-result v16

    .line 356
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 359
    move-result-object v1

    .line 360
    if-nez v16, :cond_16b

    .line 362
    if-ne v1, v6, :cond_174

    .line 364
    :cond_16b
    new-instance v1, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda2;

    .line 366
    const/4 v6, 0x2

    .line 367
    invoke-direct {v1, v5, v6}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda2;-><init>(FB)V

    .line 370
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 373
    :cond_174
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 375
    invoke-static {v10, v1}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 378
    move-result-object v1

    .line 379
    const/4 v5, 0x0

    .line 380
    invoke-static {v2, v5}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 383
    move-result-object v2

    .line 384
    iget-wide v5, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 386
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 389
    move-result v5

    .line 390
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 393
    move-result-object v6

    .line 394
    invoke-static {v12, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 397
    move-result-object v1

    .line 398
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 401
    iget-boolean v10, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 403
    if-eqz v10, :cond_198

    .line 405
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 408
    goto :goto_19b

    .line 409
    :cond_198
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 412
    :goto_19b
    invoke-static {v12, v2, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 415
    invoke-static {v12, v6, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 418
    iget-boolean v2, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 420
    if-nez v2, :cond_1b3

    .line 422
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 425
    move-result-object v2

    .line 426
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 429
    move-result-object v6

    .line 430
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 433
    move-result v2

    .line 434
    if-nez v2, :cond_1b6

    .line 436
    :cond_1b3
    invoke-static {v5, v12, v5, v11}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 439
    :cond_1b6
    invoke-static {v12, v1, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 442
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 444
    iget-object v2, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 446
    const/high16 v5, 0x3f800000  # 1.0f

    .line 448
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 451
    move-result-object v6

    .line 452
    const v13, 0x30006180

    .line 455
    const/16 v14, 0x1e0

    .line 457
    iget v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$4:F

    .line 459
    const/4 v4, 0x0

    .line 460
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$5:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 462
    move-wide v8, v7

    .line 463
    const/4 v7, 0x0

    .line 464
    move-wide v9, v8

    .line 465
    const/4 v8, 0x0

    .line 466
    move-wide v10, v9

    .line 467
    const/4 v9, 0x0

    .line 468
    move-wide/from16 v17, v10

    .line 470
    const/4 v10, 0x0

    .line 471
    const/4 v11, 0x0

    .line 472
    move-wide/from16 v19, v17

    .line 474
    invoke-static/range {v2 .. v14}, Lcom/spotifry/music/ui/listening/SunKt;->Sun(Ljava/util/List;FZLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/Modifier;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function1;Ljava/lang/String;ZLandroidx/compose/runtime/ComposerImpl;II)V

    .line 477
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 480
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 483
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 486
    new-instance v2, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;

    .line 488
    iget-boolean v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;->f$6:Z

    .line 490
    move-wide/from16 v8, v19

    .line 492
    invoke-direct {v2, v0, v1, v8, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;-><init>(ZLcom/spotifry/music/data/spotifried/SpotifriedStats;J)V

    .line 495
    const v0, -0x452c89c7

    .line 498
    invoke-static {v0, v2, v12}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 501
    move-result-object v0

    .line 502
    const/4 v1, 0x6

    .line 503
    invoke-static {v0, v12, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 506
    goto :goto_1fd

    .line 507
    :cond_1fa
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 510
    :goto_1fd
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 512
    return-object v0
.end method
