# classes.dex

.class public final Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$share$1$1$1$invokeSuspend$$inlined$filterIsInstance$1;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# static fields
.field public static final INSTANCE:Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$share$1$1$1$invokeSuspend$$inlined$filterIsInstance$1;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$share$1$1$1$invokeSuspend$$inlined$filterIsInstance$1;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$share$1$1$1$invokeSuspend$$inlined$filterIsInstance$1;->INSTANCE:Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$share$1$1$1$invokeSuspend$$inlined$filterIsInstance$1;

    .line 8
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 2

    .line 1
    instance-of p0, p1, Landroid/app/Activity;

    .line 3
    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 6
    move-result-object p0

    .line 7
    return-object p0
.end method
