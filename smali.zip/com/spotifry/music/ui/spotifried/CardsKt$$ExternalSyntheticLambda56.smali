# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/lang/String;

.field public final synthetic f$1:Ljava/lang/String;

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Z

.field public final synthetic f$4:J

.field public final synthetic f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$6:J


# direct methods
.method public synthetic constructor <init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZJLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;J)V
    .registers 10

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$0:Ljava/lang/String;

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$1:Ljava/lang/String;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$2:Ljava/util/List;

    .line 10
    iput-boolean p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$3:Z

    .line 12
    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$4:J

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 16
    iput-wide p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$6:J

    .line 18
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 99

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    iget-wide v3, v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->constraints:J

    .line 24
    and-int/lit8 v6, v2, 0x6

    .line 26
    if-nez v6, :cond_25

    .line 28
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_23

    .line 34
    const/4 v1, 0x4

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    const/4 v1, 0x2

    .line 37
    :goto_24
    or-int/2addr v2, v1

    .line 38
    :cond_25
    and-int/lit8 v1, v2, 0x13

    .line 40
    const/16 v6, 0x12

    .line 42
    const/4 v8, 0x0

    .line 43
    const/4 v9, 0x1

    .line 44
    if-eq v1, v6, :cond_2f

    .line 46
    move v1, v9

    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move v1, v8

    .line 49
    :goto_30
    and-int/2addr v2, v9

    .line 50
    invoke-virtual {v5, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 53
    move-result v1

    .line 54
    if-eqz v1, :cond_54d

    .line 56
    invoke-static {v8, v5, v8, v9}, Landroidx/compose/ui/text/ParagraphKt;->rememberTextMeasurer(ILandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/text/TextMeasurer;

    .line 59
    move-result-object v10

    .line 60
    sget-object v1, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 62
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 65
    move-result-object v1

    .line 66
    check-cast v1, Landroidx/compose/ui/unit/Density;

    .line 68
    sget-object v11, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 70
    const/16 v2, 0x38

    .line 72
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 75
    move-result-wide v14

    .line 76
    const/16 v2, 0x37

    .line 78
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 81
    move-result-wide v22

    .line 82
    const/4 v2, -0x2

    .line 83
    invoke-static {v2}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 86
    move-result-wide v19

    .line 87
    const/16 v25, 0x0

    .line 89
    const v26, 0xfdff7d

    .line 92
    const-wide/16 v12, 0x0

    .line 94
    const/16 v16, 0x0

    .line 96
    const/16 v17, 0x0

    .line 98
    const/16 v18, 0x0

    .line 100
    const/16 v21, 0x0

    .line 102
    const/16 v24, 0x0

    .line 104
    invoke-static/range {v11 .. v26}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 107
    move-result-object v12

    .line 108
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 111
    move-result v2

    .line 112
    const/high16 v11, 0x438c0000  # 280.0f

    .line 114
    invoke-interface {v1, v11}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 117
    move-result v13

    .line 118
    invoke-static {v2, v13}, Ljava/lang/Math;->min(II)I

    .line 121
    move-result v2

    .line 122
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 125
    move-result v13

    .line 126
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$0:Ljava/lang/String;

    .line 128
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 131
    move-result v15

    .line 132
    invoke-virtual {v5, v10}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 135
    move-result v16

    .line 136
    or-int v15, v15, v16

    .line 138
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 141
    move-result v13

    .line 142
    or-int/2addr v15, v13

    .line 143
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 146
    move-result-object v13

    .line 147
    move/from16 p2, v8

    .line 149
    const/16 p3, 0x20

    .line 151
    sget-object v8, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 153
    const/16 v26, 0x0

    .line 155
    if-nez v15, :cond_a1

    .line 157
    if-eq v13, v8, :cond_a1

    .line 159
    move-object v6, v14

    .line 160
    goto/16 :goto_111

    .line 162
    :cond_a1
    invoke-static {v3, v4}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 165
    move-result v13

    .line 166
    int-to-float v13, v13

    .line 167
    const v15, 0x3f7ae148  # 0.98f

    .line 170
    mul-float v17, v13, v15

    .line 172
    new-array v13, v9, [C

    .line 174
    aput-char p3, v13, p2

    .line 176
    invoke-static {v14, v13}, Lkotlin/text/StringsKt;->split$default(Ljava/lang/CharSequence;[C)Ljava/util/List;

    .line 179
    move-result-object v13

    .line 180
    invoke-interface {v13}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 183
    move-result-object v18

    .line 184
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    .line 187
    move-result v13

    .line 188
    if-eqz v13, :cond_549

    .line 190
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 193
    move-result-object v13

    .line 194
    check-cast v13, Ljava/lang/String;

    .line 196
    move-object/from16 v16, v14

    .line 198
    const-wide/16 v14, 0x0

    .line 200
    move-object/from16 v19, v16

    .line 202
    const/16 v16, 0x3fc

    .line 204
    move-object v11, v13

    .line 205
    const/4 v13, 0x0

    .line 206
    move-object/from16 v6, v19

    .line 208
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 211
    move-result-object v11

    .line 212
    iget-wide v13, v11, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 214
    shr-long v13, v13, p3

    .line 216
    long-to-int v11, v13

    .line 217
    :cond_d8
    :goto_d8
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->hasNext()Z

    .line 220
    move-result v13

    .line 221
    if-eqz v13, :cond_fb

    .line 223
    invoke-interface/range {v18 .. v18}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 226
    move-result-object v13

    .line 227
    check-cast v13, Ljava/lang/String;

    .line 229
    const-wide/16 v14, 0x0

    .line 231
    const/16 v16, 0x3fc

    .line 233
    move/from16 v19, v11

    .line 235
    move-object v11, v13

    .line 236
    const/4 v13, 0x0

    .line 237
    move/from16 v7, v19

    .line 239
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 242
    move-result-object v11

    .line 243
    iget-wide v13, v11, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 245
    shr-long v13, v13, p3

    .line 247
    long-to-int v11, v13

    .line 248
    if-lt v7, v11, :cond_d8

    .line 250
    move v11, v7

    .line 251
    goto :goto_d8

    .line 252
    :cond_fb
    move v7, v11

    .line 253
    if-ge v7, v9, :cond_100

    .line 255
    move v11, v9

    .line 256
    goto :goto_101

    .line 257
    :cond_100
    move v11, v7

    .line 258
    :goto_101
    int-to-float v7, v11

    .line 259
    div-float v7, v17, v7

    .line 261
    const/high16 v11, 0x3f800000  # 1.0f

    .line 263
    invoke-static {v11, v7}, Ljava/lang/Math;->min(FF)F

    .line 266
    move-result v7

    .line 267
    invoke-static {v7}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 270
    move-result-object v13

    .line 271
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 274
    :goto_111
    check-cast v13, Ljava/lang/Number;

    .line 276
    invoke-virtual {v13}, Ljava/lang/Number;->floatValue()F

    .line 279
    move-result v7

    .line 280
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 283
    move-result v11

    .line 284
    move v13, v11

    .line 285
    iget-object v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$1:Ljava/lang/String;

    .line 287
    invoke-virtual {v5, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 290
    move-result v14

    .line 291
    or-int/2addr v13, v14

    .line 292
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$2:Ljava/util/List;

    .line 294
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 297
    move-result v15

    .line 298
    or-int/2addr v13, v15

    .line 299
    invoke-virtual {v5, v10}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 302
    move-result v15

    .line 303
    or-int/2addr v13, v15

    .line 304
    invoke-virtual {v5, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 307
    move-result v15

    .line 308
    or-int/2addr v13, v15

    .line 309
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 312
    move-result-object v15

    .line 313
    move-object/from16 v19, v6

    .line 315
    if-nez v13, :cond_149

    .line 317
    if-eq v15, v8, :cond_149

    .line 319
    move/from16 v17, v9

    .line 321
    move-object/from16 v23, v11

    .line 323
    move-object v3, v12

    .line 324
    move-object/from16 v28, v14

    .line 326
    move-object/from16 v32, v19

    .line 328
    goto/16 :goto_245

    .line 330
    :cond_149
    const/high16 v20, 0x3f800000  # 1.0f

    .line 332
    invoke-static/range {v20 .. v20}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 335
    move-result-object v13

    .line 336
    new-instance v15, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 338
    move/from16 v17, v9

    .line 340
    const/16 v9, 0x11

    .line 342
    invoke-direct {v15, v9}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 345
    invoke-static {v13, v15}, Lkotlin/sequences/SequencesKt;->generateSequence(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;)Lkotlin/sequences/Sequence;

    .line 348
    move-result-object v9

    .line 349
    new-instance v13, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 351
    const/16 v15, 0x12

    .line 353
    invoke-direct {v13, v15}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 356
    new-instance v15, Lkotlin/sequences/TakeWhileSequence;

    .line 358
    move/from16 v6, p2

    .line 360
    invoke-direct {v15, v9, v13, v6}, Lkotlin/sequences/TakeWhileSequence;-><init>(Lkotlin/sequences/Sequence;Lkotlin/jvm/functions/Function1;B)V

    .line 363
    new-instance v6, Lkotlin/sequences/FilteringSequence$iterator$1;

    .line 365
    invoke-direct {v6, v15}, Lkotlin/sequences/FilteringSequence$iterator$1;-><init>(Lkotlin/sequences/TakeWhileSequence;)V

    .line 368
    :goto_16f
    invoke-virtual {v6}, Lkotlin/sequences/FilteringSequence$iterator$1;->hasNext()Z

    .line 371
    move-result v9

    .line 372
    if-eqz v9, :cond_22a

    .line 374
    invoke-virtual {v6}, Lkotlin/sequences/FilteringSequence$iterator$1;->next()Ljava/lang/Object;

    .line 377
    move-result-object v9

    .line 378
    move-object v13, v9

    .line 379
    check-cast v13, Ljava/lang/Number;

    .line 381
    invoke-virtual {v13}, Ljava/lang/Number;->floatValue()F

    .line 384
    move-result v13

    .line 385
    move-object v15, v12

    .line 386
    sget-object v12, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 388
    move-wide/from16 v20, v3

    .line 390
    invoke-static/range {v20 .. v21}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 393
    move-result v3

    .line 394
    const/16 v4, 0xd

    .line 396
    move-object/from16 v22, v6

    .line 398
    const/4 v6, 0x0

    .line 399
    invoke-static {v3, v6, v4}, Landroidx/compose/ui/unit/ConstraintsKt;->Constraints$default(III)J

    .line 402
    move-result-wide v23

    .line 403
    const/16 v16, 0x3cc

    .line 405
    move v3, v13

    .line 406
    const/4 v13, 0x3

    .line 407
    move v6, v3

    .line 408
    move-object/from16 v28, v14

    .line 410
    move-object v3, v15

    .line 411
    move-wide/from16 v14, v23

    .line 413
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 416
    move-result-object v12

    .line 417
    move-object/from16 v23, v11

    .line 419
    iget-wide v11, v12, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 421
    const-wide v24, 0xffffffffL

    .line 426
    and-long v11, v11, v24

    .line 428
    long-to-int v11, v11

    .line 429
    const/high16 v12, 0x40c00000  # 6.0f

    .line 431
    invoke-interface {v1, v12}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 434
    move-result v12

    .line 435
    add-int v29, v12, v11

    .line 437
    invoke-static {v3, v7, v6}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type$lambda$235$lambda$234$lambda$220$titleStyle(Landroidx/compose/ui/text/TextStyle;FF)Landroidx/compose/ui/text/TextStyle;

    .line 440
    move-result-object v12

    .line 441
    invoke-static/range {v20 .. v21}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 444
    move-result v11

    .line 445
    const/4 v13, 0x0

    .line 446
    invoke-static {v11, v13, v4}, Landroidx/compose/ui/unit/ConstraintsKt;->Constraints$default(III)J

    .line 449
    move-result-wide v14

    .line 450
    const/4 v13, 0x3

    .line 451
    move-object/from16 v11, v19

    .line 453
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 456
    move-result-object v12

    .line 457
    iget-wide v11, v12, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 459
    and-long v11, v11, v24

    .line 461
    long-to-int v11, v11

    .line 462
    add-int v29, v29, v11

    .line 464
    const/high16 v11, 0x41d00000  # 26.0f

    .line 466
    invoke-interface {v1, v11}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 469
    move-result v11

    .line 470
    add-int v29, v11, v29

    .line 472
    invoke-interface/range {v28 .. v28}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 475
    move-result-object v30

    .line 476
    const/16 v31, 0x0

    .line 478
    :goto_1dd
    invoke-interface/range {v30 .. v30}, Ljava/util/Iterator;->hasNext()Z

    .line 481
    move-result v11

    .line 482
    if-eqz v11, :cond_201

    .line 484
    invoke-interface/range {v30 .. v30}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 487
    move-result-object v11

    .line 488
    check-cast v11, Ljava/lang/String;

    .line 490
    invoke-static {v6}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type$lambda$235$lambda$234$lambda$220$factStyle(F)Landroidx/compose/ui/text/TextStyle;

    .line 493
    move-result-object v12

    .line 494
    const/4 v13, 0x0

    .line 495
    invoke-static {v2, v13, v4}, Landroidx/compose/ui/unit/ConstraintsKt;->Constraints$default(III)J

    .line 498
    move-result-wide v14

    .line 499
    const/16 v16, 0x3dc

    .line 501
    const/4 v13, 0x0

    .line 502
    invoke-static/range {v10 .. v16}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 505
    move-result-object v11

    .line 506
    iget-wide v11, v11, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 508
    and-long v11, v11, v24

    .line 510
    long-to-int v11, v11

    .line 511
    add-int v31, v31, v11

    .line 513
    goto :goto_1dd

    .line 514
    :cond_201
    move-object/from16 v32, v19

    .line 516
    add-int v29, v29, v31

    .line 518
    const/high16 v4, 0x41400000  # 12.0f

    .line 520
    invoke-interface {v1, v4}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 523
    move-result v6

    .line 524
    shl-int/lit8 v6, v6, 0x1

    .line 526
    add-int v29, v29, v6

    .line 528
    sget v6, Lcom/spotifry/music/ui/spotifried/CardsKt;->RISE:F

    .line 530
    invoke-interface {v1, v6}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 533
    move-result v6

    .line 534
    add-int v6, v6, v29

    .line 536
    invoke-static/range {v20 .. v21}, Landroidx/compose/ui/unit/Constraints;->getMaxHeight-impl(J)I

    .line 539
    move-result v11

    .line 540
    if-le v6, v11, :cond_233

    .line 542
    move-object v12, v3

    .line 543
    move-wide/from16 v3, v20

    .line 545
    move-object/from16 v6, v22

    .line 547
    move-object/from16 v11, v23

    .line 549
    move-object/from16 v14, v28

    .line 551
    move-object/from16 v19, v32

    .line 553
    goto/16 :goto_16f

    .line 555
    :cond_22a
    move-object/from16 v23, v11

    .line 557
    move-object v3, v12

    .line 558
    move-object/from16 v28, v14

    .line 560
    move-object/from16 v32, v19

    .line 562
    move-object/from16 v9, v26

    .line 564
    :cond_233
    check-cast v9, Ljava/lang/Float;

    .line 566
    if-eqz v9, :cond_23c

    .line 568
    invoke-virtual {v9}, Ljava/lang/Float;->floatValue()F

    .line 571
    move-result v1

    .line 572
    goto :goto_23e

    .line 573
    :cond_23c
    const/high16 v1, 0x3f000000  # 0.5f

    .line 575
    :goto_23e
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 578
    move-result-object v15

    .line 579
    invoke-virtual {v5, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 582
    :goto_245
    check-cast v15, Ljava/lang/Number;

    .line 584
    invoke-virtual {v15}, Ljava/lang/Number;->floatValue()F

    .line 587
    move-result v1

    .line 588
    invoke-static {v5}, Landroidx/compose/foundation/ImageKt;->rememberScrollState(Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/foundation/ScrollState;

    .line 591
    move-result-object v2

    .line 592
    sget-object v6, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 594
    move/from16 v9, v17

    .line 596
    invoke-static {v6, v2, v9}, Landroidx/compose/foundation/ImageKt;->scroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;Z)Landroidx/compose/ui/Modifier;

    .line 599
    move-result-object v10

    .line 600
    sget v14, Lcom/spotifry/music/ui/spotifried/CardsKt;->RISE:F

    .line 602
    const/4 v15, 0x7

    .line 603
    const/4 v11, 0x0

    .line 604
    const/4 v12, 0x0

    .line 605
    const/4 v13, 0x0

    .line 606
    invoke-static/range {v10 .. v15}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 609
    move-result-object v2

    .line 610
    sget-object v10, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 612
    sget-object v11, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 614
    const/4 v13, 0x0

    .line 615
    invoke-static {v10, v11, v5, v13}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 618
    move-result-object v10

    .line 619
    iget-wide v12, v5, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 621
    invoke-static {v12, v13}, Ljava/lang/Long;->hashCode(J)I

    .line 624
    move-result v12

    .line 625
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 628
    move-result-object v13

    .line 629
    invoke-static {v5, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 632
    move-result-object v2

    .line 633
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 635
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 638
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 640
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 643
    iget-boolean v15, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 645
    if-eqz v15, :cond_28a

    .line 647
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 650
    goto :goto_28d

    .line 651
    :cond_28a
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 654
    :goto_28d
    sget-object v15, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 656
    invoke-static {v5, v10, v15}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 659
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 661
    invoke-static {v5, v13, v10}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 664
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 666
    iget-boolean v4, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 668
    if-nez v4, :cond_2ab

    .line 670
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 673
    move-result-object v4

    .line 674
    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 677
    move-result-object v9

    .line 678
    invoke-static {v4, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 681
    move-result v4

    .line 682
    if-nez v4, :cond_2ae

    .line 684
    :cond_2ab
    invoke-static {v12, v5, v12, v13}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 687
    :cond_2ae
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 689
    invoke-static {v5, v2, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 692
    iget-boolean v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$3:Z

    .line 694
    const/16 v9, 0x36

    .line 696
    move-object/from16 v16, v3

    .line 698
    const/4 v12, 0x0

    .line 699
    invoke-static {v6, v12, v2, v5, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 702
    move-result-object v3

    .line 703
    move-object/from16 v19, v4

    .line 705
    move-object/from16 v20, v5

    .line 707
    invoke-static/range {v20 .. v20}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 710
    move-result-wide v4

    .line 711
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 713
    const v24, 0xc06180

    .line 716
    const v25, 0x1aff8

    .line 719
    move-object/from16 v29, v6

    .line 721
    move/from16 v22, v7

    .line 723
    const-wide/16 v6, 0x0

    .line 725
    move-object/from16 v30, v8

    .line 727
    const/4 v8, 0x0

    .line 728
    const/4 v9, 0x0

    .line 729
    move-object/from16 v33, v10

    .line 731
    const/4 v10, 0x0

    .line 732
    move-object/from16 v34, v11

    .line 734
    move/from16 v35, v12

    .line 736
    const-wide/16 v11, 0x0

    .line 738
    move-object/from16 v36, v13

    .line 740
    const/4 v13, 0x0

    .line 741
    move-object/from16 v37, v14

    .line 743
    move-object/from16 v38, v15

    .line 745
    const-wide/16 v14, 0x0

    .line 747
    move-object/from16 v39, v16

    .line 749
    const/16 v16, 0x2

    .line 751
    const/16 v17, 0x0

    .line 753
    const/16 v18, 0x3

    .line 755
    move-object/from16 v42, v19

    .line 757
    const/16 v19, 0x0

    .line 759
    move/from16 v43, v22

    .line 761
    move-object/from16 v22, v20

    .line 763
    const/16 v20, 0x0

    .line 765
    move/from16 v44, v2

    .line 767
    move-object/from16 v2, v23

    .line 769
    const/16 v23, 0x0

    .line 771
    move/from16 v0, p3

    .line 773
    move/from16 p2, v1

    .line 775
    move-object/from16 v54, v30

    .line 777
    move-object/from16 v50, v33

    .line 779
    move-object/from16 v47, v34

    .line 781
    move/from16 v1, v35

    .line 783
    move-object/from16 v51, v36

    .line 785
    move-object/from16 v48, v37

    .line 787
    move-object/from16 v49, v38

    .line 789
    move-object/from16 v45, v39

    .line 791
    move-object/from16 v52, v42

    .line 793
    move/from16 v46, v43

    .line 795
    move/from16 v53, v44

    .line 797
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 800
    move-object/from16 v5, v22

    .line 802
    const/4 v2, 0x6

    .line 803
    move-object/from16 v6, v32

    .line 805
    invoke-static {v6, v0, v1, v2}, Lkotlin/text/StringsKt;->lastIndexOf$default(Ljava/lang/CharSequence;CII)I

    .line 808
    move-result v0

    .line 809
    const/16 v17, 0x1

    .line 811
    add-int/lit8 v0, v0, 0x1

    .line 813
    new-instance v3, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 815
    invoke-direct {v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 818
    invoke-static {v0, v6}, Lkotlin/text/StringsKt;->take(ILjava/lang/String;)Ljava/lang/String;

    .line 821
    move-result-object v4

    .line 822
    invoke-virtual {v3, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 825
    new-instance v55, Landroidx/compose/ui/text/SpanStyle;

    .line 827
    const/16 v73, 0x0

    .line 829
    const v74, 0xfffe

    .line 832
    move-object/from16 v4, p0

    .line 834
    iget-wide v7, v4, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$4:J

    .line 836
    const-wide/16 v58, 0x0

    .line 838
    const/16 v60, 0x0

    .line 840
    const/16 v61, 0x0

    .line 842
    const/16 v62, 0x0

    .line 844
    const/16 v63, 0x0

    .line 846
    const/16 v64, 0x0

    .line 848
    const-wide/16 v65, 0x0

    .line 850
    const/16 v67, 0x0

    .line 852
    const/16 v68, 0x0

    .line 854
    const/16 v69, 0x0

    .line 856
    const-wide/16 v70, 0x0

    .line 858
    const/16 v72, 0x0

    .line 860
    move-wide/from16 v56, v7

    .line 862
    invoke-direct/range {v55 .. v74}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 865
    move-object/from16 v7, v55

    .line 867
    move-wide/from16 v76, v56

    .line 869
    invoke-virtual {v3, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 872
    move-result v7

    .line 873
    :try_start_368
    invoke-static {v0, v6}, Lkotlin/text/StringsKt;->drop(ILjava/lang/String;)Ljava/lang/String;

    .line 876
    move-result-object v0

    .line 877
    invoke-virtual {v3, v0}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_36f
    .catchall {:try_start_368 .. :try_end_36f} :catchall_544

    .line 880
    invoke-virtual {v3, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 883
    invoke-virtual {v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 886
    move-result-object v2

    .line 887
    const/4 v13, 0x0

    .line 888
    const/16 v14, 0xd

    .line 890
    const/4 v10, 0x0

    .line 891
    const/high16 v11, 0x40c00000  # 6.0f

    .line 893
    const/4 v12, 0x0

    .line 894
    move-object/from16 v9, v29

    .line 896
    invoke-static/range {v9 .. v14}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 899
    move-result-object v3

    .line 900
    move/from16 v6, v53

    .line 902
    const/16 v7, 0x36

    .line 904
    invoke-static {v3, v1, v6, v5, v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 907
    move-result-object v3

    .line 908
    move/from16 v8, p2

    .line 910
    move-object/from16 v12, v45

    .line 912
    move/from16 v7, v46

    .line 914
    invoke-static {v12, v7, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type$lambda$235$lambda$234$lambda$220$titleStyle(Landroidx/compose/ui/text/TextStyle;FF)Landroidx/compose/ui/text/TextStyle;

    .line 917
    move-result-object v19

    .line 918
    const/16 v22, 0x6000

    .line 920
    const v23, 0x3bffc

    .line 923
    move-object/from16 v20, v5

    .line 925
    const-wide/16 v4, 0x0

    .line 927
    move/from16 v44, v6

    .line 929
    const-wide/16 v6, 0x0

    .line 931
    move v9, v8

    .line 932
    const/4 v8, 0x0

    .line 933
    move v11, v9

    .line 934
    const-wide/16 v9, 0x0

    .line 936
    move v13, v11

    .line 937
    const-wide/16 v11, 0x0

    .line 939
    move v14, v13

    .line 940
    const/4 v13, 0x0

    .line 941
    move v15, v14

    .line 942
    const/4 v14, 0x0

    .line 943
    move/from16 v16, v15

    .line 945
    const/4 v15, 0x3

    .line 946
    move/from16 v18, v16

    .line 948
    const/16 v16, 0x0

    .line 950
    move/from16 v40, v17

    .line 952
    const/16 v17, 0x0

    .line 954
    move/from16 v21, v18

    .line 956
    const/16 v18, 0x0

    .line 958
    move/from16 v24, v21

    .line 960
    const/16 v21, 0x0

    .line 962
    move-object/from16 v0, p0

    .line 964
    move/from16 v1, v40

    .line 966
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 969
    move-object/from16 v5, v20

    .line 971
    const/4 v13, 0x0

    .line 972
    const/16 v14, 0xd

    .line 974
    const/4 v10, 0x0

    .line 975
    const/high16 v11, 0x41d00000  # 26.0f

    .line 977
    const/4 v12, 0x0

    .line 978
    move-object/from16 v9, v29

    .line 980
    invoke-static/range {v9 .. v14}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 983
    move-result-object v2

    .line 984
    const/high16 v3, 0x438c0000  # 280.0f

    .line 986
    invoke-static {v2, v3, v1}, Landroidx/compose/foundation/layout/SizeKt;->widthIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FI)Landroidx/compose/ui/Modifier;

    .line 989
    move-result-object v2

    .line 990
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 993
    move-result-object v3

    .line 994
    move-object/from16 v4, v54

    .line 996
    if-ne v3, v4, :cond_3f0

    .line 998
    new-instance v3, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda12;

    .line 1000
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 1002
    const/4 v6, 0x2

    .line 1003
    invoke-direct {v3, v4, v6}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda12;-><init>(Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;B)V

    .line 1006
    invoke-virtual {v5, v3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1009
    :cond_3f0
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 1011
    invoke-static {v2, v3}, Landroidx/compose/ui/layout/RulerKt;->onGloballyPositioned(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 1014
    move-result-object v2

    .line 1015
    new-instance v3, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 1017
    new-instance v4, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 1019
    const/4 v6, 0x3

    .line 1020
    invoke-direct {v4, v6}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 1023
    const/high16 v6, 0x41400000  # 12.0f

    .line 1025
    invoke-direct {v3, v6, v4}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 1028
    move-object/from16 v4, v47

    .line 1030
    const/4 v6, 0x6

    .line 1031
    invoke-static {v3, v4, v5, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 1034
    move-result-object v3

    .line 1035
    iget-wide v6, v5, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 1037
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 1040
    move-result v4

    .line 1041
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 1044
    move-result-object v6

    .line 1045
    invoke-static {v5, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 1048
    move-result-object v2

    .line 1049
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 1052
    iget-boolean v7, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 1054
    if-eqz v7, :cond_427

    .line 1056
    move-object/from16 v7, v48

    .line 1058
    invoke-virtual {v5, v7}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 1061
    :goto_424
    move-object/from16 v7, v49

    .line 1063
    goto :goto_42b

    .line 1064
    :cond_427
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 1067
    goto :goto_424

    .line 1068
    :goto_42b
    invoke-static {v5, v3, v7}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1071
    move-object/from16 v3, v50

    .line 1073
    invoke-static {v5, v6, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1076
    iget-boolean v3, v5, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 1078
    if-nez v3, :cond_448

    .line 1080
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 1083
    move-result-object v3

    .line 1084
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1087
    move-result-object v6

    .line 1088
    invoke-static {v3, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 1091
    move-result v3

    .line 1092
    if-eqz v3, :cond_448

    .line 1094
    :goto_445
    move-object/from16 v3, v52

    .line 1096
    goto :goto_44e

    .line 1097
    :cond_448
    move-object/from16 v3, v51

    .line 1099
    invoke-static {v4, v5, v4, v3}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 1102
    goto :goto_445

    .line 1103
    :goto_44e
    invoke-static {v5, v2, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1106
    const v2, -0x65b9258e

    .line 1109
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 1112
    invoke-interface/range {v28 .. v28}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 1115
    move-result-object v25

    .line 1116
    const/4 v8, 0x0

    .line 1117
    :goto_45c
    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->hasNext()Z

    .line 1120
    move-result v2

    .line 1121
    if-eqz v2, :cond_539

    .line 1123
    invoke-interface/range {v25 .. v25}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1126
    move-result-object v2

    .line 1127
    add-int/lit8 v27, v8, 0x1

    .line 1129
    if-ltz v8, :cond_535

    .line 1131
    check-cast v2, Ljava/lang/String;

    .line 1133
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1136
    const-string v3, "\\d+(?:[.,]\\d+)*%"

    .line 1138
    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 1141
    move-result-object v3

    .line 1142
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1145
    invoke-virtual {v3, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1148
    move-result-object v3

    .line 1149
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1152
    const/4 v13, 0x0

    .line 1153
    invoke-static {v3, v13, v2}, Lkotlin/text/RegexKt;->findNext(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Lkotlin/text/MatcherMatchResult;

    .line 1156
    move-result-object v3

    .line 1157
    if-nez v3, :cond_49a

    .line 1159
    const-string v3, "\\d+(?:[.,]\\d+)*(?: [ap]\\.m\\.)?"

    .line 1161
    invoke-static {v3}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    .line 1164
    move-result-object v3

    .line 1165
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1168
    invoke-virtual {v3, v2}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    .line 1171
    move-result-object v3

    .line 1172
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1175
    invoke-static {v3, v13, v2}, Lkotlin/text/RegexKt;->findNext(Ljava/util/regex/Matcher;ILjava/lang/CharSequence;)Lkotlin/text/MatcherMatchResult;

    .line 1178
    move-result-object v3

    .line 1179
    :cond_49a
    if-eqz v3, :cond_4a1

    .line 1181
    invoke-virtual {v3}, Lkotlin/text/MatcherMatchResult;->getRange()Lkotlin/ranges/IntRange;

    .line 1184
    move-result-object v3

    .line 1185
    goto :goto_4a3

    .line 1186
    :cond_4a1
    move-object/from16 v3, v26

    .line 1188
    :goto_4a3
    new-instance v4, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 1190
    invoke-direct {v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 1193
    if-nez v3, :cond_4ae

    .line 1195
    invoke-virtual {v4, v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 1198
    goto :goto_4f4

    .line 1199
    :cond_4ae
    iget v6, v3, Lkotlin/ranges/IntProgression;->last:I

    .line 1201
    iget v3, v3, Lkotlin/ranges/IntProgression;->first:I

    .line 1203
    const/4 v13, 0x0

    .line 1204
    invoke-virtual {v2, v13, v3}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1207
    move-result-object v7

    .line 1208
    invoke-virtual {v4, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 1211
    new-instance v75, Landroidx/compose/ui/text/SpanStyle;

    .line 1213
    sget-object v80, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 1215
    const/16 v93, 0x0

    .line 1217
    const v94, 0xfffa

    .line 1220
    const-wide/16 v78, 0x0

    .line 1222
    const/16 v81, 0x0

    .line 1224
    const/16 v82, 0x0

    .line 1226
    const/16 v83, 0x0

    .line 1228
    const/16 v84, 0x0

    .line 1230
    const-wide/16 v85, 0x0

    .line 1232
    const/16 v87, 0x0

    .line 1234
    const/16 v88, 0x0

    .line 1236
    const/16 v89, 0x0

    .line 1238
    const-wide/16 v90, 0x0

    .line 1240
    const/16 v92, 0x0

    .line 1242
    invoke-direct/range {v75 .. v94}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 1245
    move-object/from16 v7, v75

    .line 1247
    invoke-virtual {v4, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 1250
    move-result v7

    .line 1251
    add-int/2addr v6, v1

    .line 1252
    :try_start_4e3
    invoke-virtual {v2, v3, v6}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    .line 1255
    move-result-object v3

    .line 1256
    invoke-virtual {v4, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_4ea
    .catchall {:try_start_4e3 .. :try_end_4ea} :catchall_530

    .line 1259
    invoke-virtual {v4, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 1262
    invoke-virtual {v2, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 1265
    move-result-object v2

    .line 1266
    invoke-virtual {v4, v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 1269
    :goto_4f4
    invoke-virtual {v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 1272
    move-result-object v9

    .line 1273
    mul-int/lit16 v8, v8, 0xfa

    .line 1275
    add-int/lit16 v3, v8, 0x3e8

    .line 1277
    const/16 v6, 0xc06

    .line 1279
    const/4 v7, 0x0

    .line 1280
    move-object/from16 v2, v29

    .line 1282
    move/from16 v4, v44

    .line 1284
    invoke-static/range {v2 .. v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->riseAt(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/Modifier;

    .line 1287
    move-result-object v3

    .line 1288
    move-object/from16 v20, v5

    .line 1290
    invoke-static/range {v24 .. v24}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type$lambda$235$lambda$234$lambda$220$factStyle(F)Landroidx/compose/ui/text/TextStyle;

    .line 1293
    move-result-object v19

    .line 1294
    const/16 v22, 0x0

    .line 1296
    const v23, 0x3fff8

    .line 1299
    iget-wide v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;->f$6:J

    .line 1301
    const-wide/16 v6, 0x0

    .line 1303
    const/4 v8, 0x0

    .line 1304
    move-object v2, v9

    .line 1305
    const-wide/16 v9, 0x0

    .line 1307
    const-wide/16 v11, 0x0

    .line 1309
    const/4 v13, 0x0

    .line 1310
    const/4 v14, 0x0

    .line 1311
    const/4 v15, 0x0

    .line 1312
    const/16 v16, 0x0

    .line 1314
    const/16 v17, 0x0

    .line 1316
    const/16 v18, 0x0

    .line 1318
    const/16 v21, 0x0

    .line 1320
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1323
    move-object/from16 v5, v20

    .line 1325
    move/from16 v8, v27

    .line 1327
    goto/16 :goto_45c

    .line 1329
    :catchall_530
    move-exception v0

    .line 1330
    invoke-virtual {v4, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 1333
    throw v0

    .line 1334
    :cond_535
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 1337
    throw v26

    .line 1338
    :cond_539
    const/4 v13, 0x0

    .line 1339
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1342
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1345
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1348
    goto :goto_550

    .line 1349
    :catchall_544
    move-exception v0

    .line 1350
    invoke-virtual {v3, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 1353
    throw v0

    .line 1354
    :cond_549
    invoke-static {}, Landroidx/media3/session/MediaSessionStub$$ExternalSyntheticLambda8;->m$1()V

    .line 1357
    return-object v26

    .line 1358
    :cond_54d
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 1361
    :goto_550
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1363
    return-object v0
.end method
