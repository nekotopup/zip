# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:J

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$4:F

.field public final synthetic f$5:J


# direct methods
.method public synthetic constructor <init>(ZJLjava/util/List;Landroidx/compose/animation/core/Animatable;FJ)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$0:Z

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$2:Ljava/util/List;

    .line 10
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 12
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$4:F

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$5:J

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 30

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 24
    const/4 v5, 0x2

    .line 25
    if-nez v4, :cond_24

    .line 27
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v4

    .line 31
    if-eqz v4, :cond_22

    .line 33
    const/4 v4, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v4, v5

    .line 36
    :goto_23
    or-int/2addr v3, v4

    .line 37
    :cond_24
    and-int/lit8 v4, v3, 0x13

    .line 39
    const/16 v6, 0x12

    .line 41
    const/4 v7, 0x0

    .line 42
    const/4 v8, 0x1

    .line 43
    if-eq v4, v6, :cond_2e

    .line 45
    move v4, v8

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v4, v7

    .line 48
    :goto_2f
    and-int/2addr v3, v8

    .line 49
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v3

    .line 53
    if-eqz v3, :cond_1d9

    .line 55
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 58
    move-result v1

    .line 59
    const/high16 v3, 0x41d00000  # 26.0f

    .line 61
    sub-float/2addr v1, v3

    .line 62
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 64
    invoke-direct {v3, v1}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 67
    new-instance v1, Landroidx/compose/ui/unit/Dp;

    .line 69
    const/high16 v4, 0x433e0000  # 190.0f

    .line 71
    invoke-direct {v1, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 74
    invoke-virtual {v3, v1}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 77
    move-result v4

    .line 78
    if-lez v4, :cond_50

    .line 80
    move-object v3, v1

    .line 81
    :cond_50
    new-instance v1, Landroidx/compose/ui/unit/Dp;

    .line 83
    const/high16 v4, 0x42200000  # 40.0f

    .line 85
    invoke-direct {v1, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 88
    invoke-virtual {v3, v1}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 91
    move-result v4

    .line 92
    if-gez v4, :cond_5e

    .line 94
    move-object v3, v1

    .line 95
    :cond_5e
    const/16 v1, 0x36

    .line 97
    sget-object v4, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 99
    iget-boolean v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$0:Z

    .line 101
    invoke-static {v4, v5, v6, v2, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 104
    move-result-object v1

    .line 105
    sget-object v5, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 107
    sget-object v6, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 109
    invoke-static {v5, v6, v2, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 112
    move-result-object v5

    .line 113
    iget-wide v9, v2, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 115
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 118
    move-result v6

    .line 119
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 122
    move-result-object v9

    .line 123
    invoke-static {v2, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 126
    move-result-object v1

    .line 127
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 129
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 132
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 134
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 137
    iget-boolean v11, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 139
    if-eqz v11, :cond_90

    .line 141
    invoke-virtual {v2, v10}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 144
    goto :goto_93

    .line 145
    :cond_90
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 148
    :goto_93
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 150
    invoke-static {v2, v5, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 153
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 155
    invoke-static {v2, v9, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 158
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 160
    iget-boolean v12, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 162
    if-nez v12, :cond_b1

    .line 164
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 167
    move-result-object v12

    .line 168
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 171
    move-result-object v13

    .line 172
    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 175
    move-result v12

    .line 176
    if-nez v12, :cond_b4

    .line 178
    :cond_b1
    invoke-static {v6, v2, v6, v9}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 181
    :cond_b4
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 183
    invoke-static {v2, v1, v6}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 186
    const/high16 v1, 0x3f800000  # 1.0f

    .line 188
    invoke-static {v4, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 191
    move-result-object v12

    .line 192
    iget v3, v3, Landroidx/compose/ui/unit/Dp;->value:F

    .line 194
    invoke-static {v12, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 197
    move-result-object v3

    .line 198
    iget-wide v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$1:J

    .line 200
    invoke-virtual {v2, v13, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 203
    move-result v12

    .line 204
    iget-object v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$2:Ljava/util/List;

    .line 206
    invoke-virtual {v2, v15}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 209
    move-result v16

    .line 210
    or-int v12, v12, v16

    .line 212
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 214
    invoke-virtual {v2, v8}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 217
    move-result v16

    .line 218
    or-int v12, v12, v16

    .line 220
    iget v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$4:F

    .line 222
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 225
    move-result v16

    .line 226
    or-int v12, v12, v16

    .line 228
    move-object/from16 v16, v8

    .line 230
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;->f$5:J

    .line 232
    invoke-virtual {v2, v7, v8}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 235
    move-result v0

    .line 236
    or-int/2addr v12, v0

    .line 237
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 240
    move-result-object v0

    .line 241
    if-nez v12, :cond_f6

    .line 243
    sget-object v12, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 245
    if-ne v0, v12, :cond_103

    .line 247
    :cond_f6
    new-instance v12, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;

    .line 249
    move/from16 v17, v1

    .line 251
    move-wide/from16 v18, v7

    .line 253
    invoke-direct/range {v12 .. v19}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda55;-><init>(JLjava/util/List;Landroidx/compose/animation/core/Animatable;FJ)V

    .line 256
    invoke-virtual {v2, v12}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 259
    move-object v0, v12

    .line 260
    :cond_103
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 262
    const/4 v1, 0x0

    .line 263
    invoke-static {v3, v0, v2, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 266
    const/high16 v0, 0x3f800000  # 1.0f

    .line 268
    invoke-static {v4, v0}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 271
    move-result-object v12

    .line 272
    const/16 v16, 0x0

    .line 274
    const/16 v17, 0xd

    .line 276
    const/4 v13, 0x0

    .line 277
    const/high16 v14, 0x41000000  # 8.0f

    .line 279
    const/4 v15, 0x0

    .line 280
    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 283
    move-result-object v0

    .line 284
    sget-object v3, Landroidx/compose/foundation/layout/OffsetKt;->SpaceBetween:Landroidx/compose/foundation/layout/Arrangement$Center$1;

    .line 286
    sget-object v4, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 288
    const/4 v7, 0x6

    .line 289
    invoke-static {v3, v4, v2, v7}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 292
    move-result-object v3

    .line 293
    iget-wide v7, v2, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 295
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 298
    move-result v4

    .line 299
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 302
    move-result-object v7

    .line 303
    invoke-static {v2, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 306
    move-result-object v0

    .line 307
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 310
    iget-boolean v8, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 312
    if-eqz v8, :cond_13d

    .line 314
    invoke-virtual {v2, v10}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 317
    goto :goto_140

    .line 318
    :cond_13d
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 321
    :goto_140
    invoke-static {v2, v3, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 324
    invoke-static {v2, v7, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 327
    iget-boolean v3, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 329
    if-nez v3, :cond_158

    .line 331
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 334
    move-result-object v3

    .line 335
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 338
    move-result-object v5

    .line 339
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 342
    move-result v3

    .line 343
    if-nez v3, :cond_15b

    .line 345
    :cond_158
    invoke-static {v4, v2, v4, v9}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 348
    :cond_15b
    invoke-static {v2, v0, v6}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 351
    const v0, -0x49d896a2

    .line 354
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 357
    const-string v0, "18"

    .line 359
    const-string v3, "24"

    .line 361
    const-string v4, "00"

    .line 363
    const-string v5, "06"

    .line 365
    const-string v6, "12"

    .line 367
    filled-new-array {v4, v5, v6, v0, v3}, [Ljava/lang/String;

    .line 370
    move-result-object v0

    .line 371
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 374
    move-result-object v0

    .line 375
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 378
    move-result-object v0

    .line 379
    :goto_17a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 382
    move-result v3

    .line 383
    if-eqz v3, :cond_1ce

    .line 385
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 388
    move-result-object v3

    .line 389
    check-cast v3, Ljava/lang/String;

    .line 391
    invoke-static {v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 394
    move-result-wide v4

    .line 395
    sget-object v6, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 397
    const/16 v7, 0xb

    .line 399
    invoke-static {v7}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 402
    move-result-wide v9

    .line 403
    const/16 v7, 0xe

    .line 405
    invoke-static {v7}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 408
    move-result-wide v17

    .line 409
    const/16 v20, 0x0

    .line 411
    const v21, 0xfdfffd

    .line 414
    const-wide/16 v7, 0x0

    .line 416
    const/4 v11, 0x0

    .line 417
    const/4 v12, 0x0

    .line 418
    const/4 v13, 0x0

    .line 419
    const-wide/16 v14, 0x0

    .line 421
    const/16 v16, 0x0

    .line 423
    const/16 v19, 0x0

    .line 425
    invoke-static/range {v6 .. v21}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 428
    move-result-object v21

    .line 429
    const/16 v24, 0x0

    .line 431
    const v25, 0x1fffa

    .line 434
    move-object/from16 v22, v2

    .line 436
    move-object v2, v3

    .line 437
    const/4 v3, 0x0

    .line 438
    const-wide/16 v6, 0x0

    .line 440
    const/4 v8, 0x0

    .line 441
    const/4 v9, 0x0

    .line 442
    const/4 v10, 0x0

    .line 443
    const-wide/16 v11, 0x0

    .line 445
    const/16 v16, 0x0

    .line 447
    const/16 v17, 0x0

    .line 449
    const/16 v18, 0x0

    .line 451
    const/16 v19, 0x0

    .line 453
    const/16 v20, 0x0

    .line 455
    const/16 v23, 0x0

    .line 457
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 460
    move-object/from16 v2, v22

    .line 462
    goto :goto_17a

    .line 463
    :cond_1ce
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 466
    const/4 v0, 0x1

    .line 467
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 470
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 473
    goto :goto_1dc

    .line 474
    :cond_1d9
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 477
    :goto_1dc
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 479
    return-object v0
.end method
