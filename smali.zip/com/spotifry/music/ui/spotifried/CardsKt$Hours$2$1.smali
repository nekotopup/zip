# classes.dex

.class public final Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $clock:Landroidx/compose/animation/core/Animatable;

.field public final synthetic $r8$classId:B

.field public label:Z


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;Lkotlin/coroutines/Continuation;B)V
    .registers 4

    .line 1
    iput-byte p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$r8$classId:B

    .line 3
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$clock:Landroidx/compose/animation/core/Animatable;

    .line 5
    const/4 p1, 0x2

    .line 6
    invoke-direct {p0, p1, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 9
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 4

    .line 1
    iget-byte p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$r8$classId:B

    .line 3
    packed-switch p1, :pswitch_data_20

    .line 6
    new-instance p1, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;

    .line 8
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$clock:Landroidx/compose/animation/core/Animatable;

    .line 10
    const/4 v0, 0x2

    .line 11
    invoke-direct {p1, p0, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;-><init>(Landroidx/compose/animation/core/Animatable;Lkotlin/coroutines/Continuation;B)V

    .line 14
    return-object p1

    .line 15
    :pswitch_e  #0x1
    new-instance p1, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;

    .line 17
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$clock:Landroidx/compose/animation/core/Animatable;

    .line 19
    const/4 v0, 0x1

    .line 20
    invoke-direct {p1, p0, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;-><init>(Landroidx/compose/animation/core/Animatable;Lkotlin/coroutines/Continuation;B)V

    .line 23
    return-object p1

    .line 24
    :pswitch_17  #0x0
    new-instance p1, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;

    .line 26
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$clock:Landroidx/compose/animation/core/Animatable;

    .line 28
    const/4 v0, 0x0

    .line 29
    invoke-direct {p1, p0, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;-><init>(Landroidx/compose/animation/core/Animatable;Lkotlin/coroutines/Continuation;B)V

    .line 32
    return-object p1

    .line 33
    :pswitch_data_20
    .packed-switch 0x0
        :pswitch_17  #00000000
        :pswitch_e  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$r8$classId:B

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 7
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 9
    packed-switch v0, :pswitch_data_2c

    .line 12
    invoke-virtual {p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;

    .line 18
    invoke-virtual {p0, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x1
    invoke-virtual {p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;

    .line 29
    invoke-virtual {p0, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    :pswitch_21  #0x0
    invoke-virtual {p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 37
    move-result-object p0

    .line 38
    check-cast p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;

    .line 40
    invoke-virtual {p0, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    move-result-object p0

    .line 44
    return-object p0

    .line 45
    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_21  #00000000
        :pswitch_16  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$r8$classId:B

    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 6
    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    .line 8
    sget-object v4, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 10
    const/4 v5, 0x1

    .line 11
    const/4 v6, 0x0

    .line 12
    packed-switch v0, :pswitch_data_9a

    .line 15
    iget-boolean v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->label:Z

    .line 17
    if-eqz v0, :cond_1d

    .line 19
    if-ne v0, v5, :cond_18

    .line 21
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 24
    goto :goto_3d

    .line 25
    :cond_18
    invoke-static {v3}, Lorg/jsoup/parser/CharacterReader$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 28
    move-object v2, v6

    .line 29
    goto :goto_3d

    .line 30
    :cond_1d
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 33
    new-instance v8, Ljava/lang/Float;

    .line 35
    const/high16 p1, 0x3f800000  # 1.0f

    .line 37
    invoke-direct {v8, p1}, Ljava/lang/Float;-><init>(F)V

    .line 40
    const/16 p1, 0xfa

    .line 42
    const/4 v0, 0x6

    .line 43
    invoke-static {p1, v1, v6, v0}, Landroidx/compose/animation/core/ArcSplineKt;->tween$default(IILandroidx/compose/animation/core/Easing;I)Landroidx/compose/animation/core/TweenSpec;

    .line 46
    move-result-object v9

    .line 47
    iput-boolean v5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->label:Z

    .line 49
    iget-object v7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$clock:Landroidx/compose/animation/core/Animatable;

    .line 51
    const/4 v10, 0x0

    .line 52
    const/16 v12, 0xc

    .line 54
    move-object v11, p0

    .line 55
    invoke-static/range {v7 .. v12}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)Ljava/lang/Object;

    .line 58
    move-result-object p0

    .line 59
    if-ne p0, v4, :cond_3d

    .line 61
    move-object v2, v4

    .line 62
    :cond_3d
    :goto_3d
    return-object v2

    .line 63
    :pswitch_3e  #0x1
    move-object v9, p0

    .line 64
    iget-boolean p0, v9, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->label:Z

    .line 66
    if-eqz p0, :cond_4e

    .line 68
    if-ne p0, v5, :cond_49

    .line 70
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 73
    goto :goto_66

    .line 74
    :cond_49
    invoke-static {v3}, Lorg/jsoup/parser/CharacterReader$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 77
    move-object v2, v6

    .line 78
    goto :goto_66

    .line 79
    :cond_4e
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 82
    new-instance v6, Ljava/lang/Float;

    .line 84
    const/4 p0, 0x0

    .line 85
    invoke-direct {v6, p0}, Ljava/lang/Float;-><init>(F)V

    .line 88
    iput-boolean v5, v9, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->label:Z

    .line 90
    iget-object v5, v9, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$clock:Landroidx/compose/animation/core/Animatable;

    .line 92
    const/4 v7, 0x0

    .line 93
    const/4 v8, 0x0

    .line 94
    const/16 v10, 0xe

    .line 96
    invoke-static/range {v5 .. v10}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)Ljava/lang/Object;

    .line 99
    move-result-object p0

    .line 100
    if-ne p0, v4, :cond_66

    .line 102
    move-object v2, v4

    .line 103
    :cond_66
    :goto_66
    return-object v2

    .line 104
    :pswitch_67  #0x0
    move-object v9, p0

    .line 105
    iget-boolean p0, v9, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->label:Z

    .line 107
    if-eqz p0, :cond_77

    .line 109
    if-ne p0, v5, :cond_72

    .line 111
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 114
    goto :goto_99

    .line 115
    :cond_72
    invoke-static {v3}, Lorg/jsoup/parser/CharacterReader$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 118
    move-object v2, v6

    .line 119
    goto :goto_99

    .line 120
    :cond_77
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 123
    new-instance v6, Ljava/lang/Float;

    .line 125
    const p0, 0x451c4000  # 2500.0f

    .line 128
    invoke-direct {v6, p0}, Ljava/lang/Float;-><init>(F)V

    .line 131
    sget-object p0, Landroidx/compose/animation/core/EasingKt;->LinearEasing:Landroidx/collection/ArrayMap$$ExternalSyntheticBUOutline0;

    .line 133
    const/4 p1, 0x2

    .line 134
    const/16 v0, 0x9c4

    .line 136
    invoke-static {v0, v1, p0, p1}, Landroidx/compose/animation/core/ArcSplineKt;->tween$default(IILandroidx/compose/animation/core/Easing;I)Landroidx/compose/animation/core/TweenSpec;

    .line 139
    move-result-object v7

    .line 140
    iput-boolean v5, v9, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->label:Z

    .line 142
    iget-object v5, v9, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;->$clock:Landroidx/compose/animation/core/Animatable;

    .line 144
    const/4 v8, 0x0

    .line 145
    const/16 v10, 0xc

    .line 147
    invoke-static/range {v5 .. v10}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)Ljava/lang/Object;

    .line 150
    move-result-object p0

    .line 151
    if-ne p0, v4, :cond_99

    .line 153
    move-object v2, v4

    .line 154
    :cond_99
    :goto_99
    return-object v2

    .line 155
    :pswitch_data_9a
    .packed-switch 0x0
        :pswitch_67  #00000000
        :pswitch_3e  #00000001
    .end packed-switch
.end method
