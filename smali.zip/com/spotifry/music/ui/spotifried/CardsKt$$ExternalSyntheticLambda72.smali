# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Landroidx/compose/ui/layout/Placeable;

.field public final synthetic f$1:F

.field public final synthetic f$2:F

.field public final synthetic f$3:Landroidx/compose/ui/unit/Constraints;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/layout/Placeable;FFLandroidx/compose/ui/unit/Constraints;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;->f$0:Landroidx/compose/ui/layout/Placeable;

    .line 6
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;->f$1:F

    .line 8
    iput p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;->f$2:F

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;->f$3:Landroidx/compose/ui/unit/Constraints;

    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    iget v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;->f$1:F

    .line 8
    invoke-interface {p1, v0}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 11
    move-result v0

    .line 12
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;->f$0:Landroidx/compose/ui/layout/Placeable;

    .line 14
    iget v2, v1, Landroidx/compose/ui/layout/Placeable;->width:I

    .line 16
    int-to-float v2, v2

    .line 17
    iget v3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;->f$2:F

    .line 19
    mul-float/2addr v2, v3

    .line 20
    invoke-static {v2}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 23
    move-result v2

    .line 24
    sub-int/2addr v0, v2

    .line 25
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda72;->f$3:Landroidx/compose/ui/unit/Constraints;

    .line 27
    iget-wide v2, p0, Landroidx/compose/ui/unit/Constraints;->value:J

    .line 29
    invoke-static {v2, v3}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 32
    move-result p0

    .line 33
    iget v2, v1, Landroidx/compose/ui/layout/Placeable;->width:I

    .line 35
    sub-int/2addr p0, v2

    .line 36
    const/4 v2, 0x0

    .line 37
    invoke-static {v2, p0}, Ljava/lang/Math;->max(II)I

    .line 40
    move-result p0

    .line 41
    invoke-static {v0, v2, p0}, Lkotlin/ResultKt;->coerceIn(III)I

    .line 44
    move-result p0

    .line 45
    const/4 v0, 0x0

    .line 46
    invoke-virtual {p1, v1, p0, v2, v0}, Landroidx/compose/ui/layout/Placeable$PlacementScope;->place(Landroidx/compose/ui/layout/Placeable;IIF)V

    .line 49
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 51
    return-object p0
.end method
