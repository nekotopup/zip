# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:J

.field public final synthetic f$1:J

.field public final synthetic f$2:F


# direct methods
.method public synthetic constructor <init>(JJF)V
    .registers 6

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-wide p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$0:J

    .line 6
    iput-wide p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$1:J

    .line 8
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$2:F

    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 16

    .line 1
    move-object v0, p1

    .line 2
    check-cast v0, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 4
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 10
    move-result-wide v1

    .line 11
    const-wide v12, 0xffffffffL

    .line 16
    and-long/2addr v1, v12

    .line 17
    long-to-int p1, v1

    .line 18
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 21
    move-result p1

    .line 22
    const/high16 v1, 0x40000000  # 2.0f

    .line 24
    div-float/2addr p1, v1

    .line 25
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 28
    move-result v1

    .line 29
    int-to-long v1, v1

    .line 30
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 33
    move-result p1

    .line 34
    int-to-long v3, p1

    .line 35
    const/16 p1, 0x20

    .line 37
    shl-long/2addr v1, p1

    .line 38
    and-long/2addr v3, v12

    .line 39
    or-long v7, v1, v3

    .line 41
    const/4 v10, 0x0

    .line 42
    const/16 v11, 0xf6

    .line 44
    iget-wide v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$0:J

    .line 46
    const-wide/16 v3, 0x0

    .line 48
    const-wide/16 v5, 0x0

    .line 50
    const/4 v9, 0x0

    .line 51
    invoke-static/range {v0 .. v11}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 54
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 57
    move-result-wide v1

    .line 58
    shr-long/2addr v1, p1

    .line 59
    long-to-int v1, v1

    .line 60
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 63
    move-result v1

    .line 64
    iget v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$2:F

    .line 66
    mul-float/2addr v1, v2

    .line 67
    invoke-interface {v0}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 70
    move-result-wide v2

    .line 71
    and-long/2addr v2, v12

    .line 72
    long-to-int v2, v2

    .line 73
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 76
    move-result v2

    .line 77
    invoke-static {v1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 80
    move-result v1

    .line 81
    int-to-long v3, v1

    .line 82
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 85
    move-result v1

    .line 86
    int-to-long v1, v1

    .line 87
    shl-long/2addr v3, p1

    .line 88
    and-long/2addr v1, v12

    .line 89
    or-long v5, v3, v1

    .line 91
    const/16 v11, 0xf2

    .line 93
    iget-wide v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda67;->f$1:J

    .line 95
    const-wide/16 v3, 0x0

    .line 97
    invoke-static/range {v0 .. v11}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 100
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 102
    return-object p0
.end method
