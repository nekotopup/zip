# classes.dex

.class public abstract Lcom/spotifry/music/ui/spotifried/CardsKt;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"


# static fields
.field public static final Ease:Landroidx/compose/animation/core/CubicBezierEasing;

.field public static final Headline:Landroidx/compose/ui/text/TextStyle;

.field public static final RISE:F

.field public static final Sub:Landroidx/compose/ui/text/TextStyle;

.field public static final WIDE_BAR:F

.field public static final english:Ljava/util/Locale;


# direct methods
.method static constructor <clinit>()V
    .registers 18

    .line 1
    new-instance v0, Landroidx/compose/animation/core/CubicBezierEasing;

    .line 3
    const/high16 v1, 0x3f800000  # 1.0f

    .line 5
    const v2, 0x3e99999a  # 0.3f

    .line 8
    const v3, 0x3e23d70a  # 0.16f

    .line 11
    invoke-direct {v0, v3, v1, v2, v1}, Landroidx/compose/animation/core/CubicBezierEasing;-><init>(FFFF)V

    .line 14
    sput-object v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->Ease:Landroidx/compose/animation/core/CubicBezierEasing;

    .line 16
    sget-object v10, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 18
    sget-object v9, Landroidx/compose/ui/text/font/FontWeight;->Black:Landroidx/compose/ui/text/font/FontWeight;

    .line 20
    const/16 v0, 0x2e

    .line 22
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 25
    move-result-wide v7

    .line 26
    const/16 v0, 0x2d

    .line 28
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 31
    move-result-wide v14

    .line 32
    const-wide v0, -0x4006666666666666L  # -1.6

    .line 37
    invoke-static {v0, v1}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 40
    move-result-wide v11

    .line 41
    new-instance v4, Landroidx/compose/ui/text/TextStyle;

    .line 43
    const/16 v16, 0x0

    .line 45
    const v17, 0xfdff59

    .line 48
    const-wide/16 v5, 0x0

    .line 50
    const/4 v13, 0x0

    .line 51
    invoke-direct/range {v4 .. v17}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 54
    sput-object v4, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 56
    const/16 v0, 0xf

    .line 58
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 61
    move-result-wide v7

    .line 62
    const/16 v0, 0x16

    .line 64
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 67
    move-result-wide v14

    .line 68
    new-instance v4, Landroidx/compose/ui/text/TextStyle;

    .line 70
    const v17, 0xfdffdd

    .line 73
    const/4 v9, 0x0

    .line 74
    const-wide/16 v11, 0x0

    .line 76
    invoke-direct/range {v4 .. v17}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 79
    sput-object v4, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 81
    sget-object v0, Ljava/util/Locale;->ENGLISH:Ljava/util/Locale;

    .line 83
    sput-object v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 85
    const/high16 v0, 0x41600000  # 14.0f

    .line 87
    sput v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->WIDE_BAR:F

    .line 89
    const/high16 v0, 0x41900000  # 18.0f

    .line 91
    sput v0, Lcom/spotifry/music/ui/spotifried/CardsKt;->RISE:F

    .line 93
    return-void
.end method

.method public static final Age(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 31

    .line 1
    move-object/from16 v1, p0

    .line 3
    move/from16 v4, p3

    .line 5
    move-object/from16 v8, p4

    .line 7
    move/from16 v0, p5

    .line 9
    const v2, 0x43ca2b59

    .line 12
    invoke-virtual {v8, v2}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 15
    and-int/lit8 v2, v0, 0x6

    .line 17
    if-nez v2, :cond_1d

    .line 19
    invoke-virtual {v8, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 22
    move-result v2

    .line 23
    if-eqz v2, :cond_1a

    .line 25
    const/4 v2, 0x4

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v2, 0x2

    .line 28
    :goto_1b
    or-int/2addr v2, v0

    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move v2, v0

    .line 31
    :goto_1e
    and-int/lit8 v3, v0, 0x30

    .line 33
    move/from16 v14, p1

    .line 35
    if-nez v3, :cond_30

    .line 37
    invoke-virtual {v8, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 40
    move-result v3

    .line 41
    if-eqz v3, :cond_2d

    .line 43
    const/16 v3, 0x20

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    const/16 v3, 0x10

    .line 48
    :goto_2f
    or-int/2addr v2, v3

    .line 49
    :cond_30
    and-int/lit16 v3, v0, 0x180

    .line 51
    move/from16 v15, p2

    .line 53
    if-nez v3, :cond_42

    .line 55
    invoke-virtual {v8, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 58
    move-result v3

    .line 59
    if-eqz v3, :cond_3f

    .line 61
    const/16 v3, 0x100

    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    const/16 v3, 0x80

    .line 66
    :goto_41
    or-int/2addr v2, v3

    .line 67
    :cond_42
    and-int/lit16 v3, v0, 0xc00

    .line 69
    if-nez v3, :cond_52

    .line 71
    invoke-virtual {v8, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 74
    move-result v3

    .line 75
    if-eqz v3, :cond_4f

    .line 77
    const/16 v3, 0x800

    .line 79
    goto :goto_51

    .line 80
    :cond_4f
    const/16 v3, 0x400

    .line 82
    :goto_51
    or-int/2addr v2, v3

    .line 83
    :cond_52
    and-int/lit16 v3, v2, 0x493

    .line 85
    const/16 v5, 0x492

    .line 87
    if-eq v3, v5, :cond_5a

    .line 89
    const/4 v3, 0x1

    .line 90
    goto :goto_5b

    .line 91
    :cond_5a
    const/4 v3, 0x0

    .line 92
    :goto_5b
    and-int/lit8 v5, v2, 0x1

    .line 94
    invoke-virtual {v8, v5, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 97
    move-result v3

    .line 98
    if-eqz v3, :cond_1c6

    .line 100
    sget-object v3, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 102
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 105
    move-result-object v5

    .line 106
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 108
    iget-wide v9, v5, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 110
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 113
    move-result-object v3

    .line 114
    check-cast v3, Landroidx/compose/material3/ColorScheme;

    .line 116
    iget-wide v11, v3, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 118
    const v3, 0x3e0f5c29  # 0.14f

    .line 121
    invoke-static {v3, v11, v12}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 124
    move-result-wide v16

    .line 125
    move-wide/from16 v23, v11

    .line 127
    iget-object v12, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->age:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 129
    iget-object v3, v12, Lcom/spotifry/music/data/spotifried/AgeStats;->typicalYear:Ljava/lang/Integer;

    .line 131
    iget-object v5, v12, Lcom/spotifry/music/data/spotifried/AgeStats;->years:Ljava/util/List;

    .line 133
    iget-object v7, v12, Lcom/spotifry/music/data/spotifried/AgeStats;->age:Ljava/lang/Integer;

    .line 135
    if-nez v7, :cond_89

    .line 137
    const/4 v3, 0x0

    .line 138
    :cond_89
    invoke-virtual {v8, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 141
    move-result v7

    .line 142
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 145
    move-result-object v11

    .line 146
    if-nez v7, :cond_9d

    .line 148
    sget-object v7, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 150
    if-eq v11, v7, :cond_9d

    .line 152
    move/from16 v19, v2

    .line 154
    move-object/from16 v21, v3

    .line 156
    goto/16 :goto_14b

    .line 158
    :cond_9d
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    .line 161
    move-result-object v7

    .line 162
    new-instance v11, Ljava/util/LinkedHashMap;

    .line 164
    invoke-direct {v11}, Ljava/util/LinkedHashMap;-><init>()V

    .line 167
    invoke-interface {v7}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 170
    move-result-object v7

    .line 171
    :goto_aa
    invoke-interface {v7}, Ljava/util/Iterator;->hasNext()Z

    .line 174
    move-result v18

    .line 175
    if-eqz v18, :cond_d8

    .line 177
    invoke-interface {v7}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 180
    move-result-object v6

    .line 181
    move-object/from16 v19, v6

    .line 183
    check-cast v19, Ljava/lang/Number;

    .line 185
    invoke-virtual/range {v19 .. v19}, Ljava/lang/Number;->intValue()I

    .line 188
    move-result v19

    .line 189
    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 192
    move-result-object v13

    .line 193
    invoke-virtual {v11, v13}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 196
    move-result-object v19

    .line 197
    if-nez v19, :cond_d0

    .line 199
    new-instance v0, Ljava/util/ArrayList;

    .line 201
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 204
    invoke-interface {v11, v13, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 207
    move-object/from16 v19, v0

    .line 209
    :cond_d0
    move-object/from16 v0, v19

    .line 211
    check-cast v0, Ljava/util/List;

    .line 213
    invoke-interface {v0, v6}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 216
    goto :goto_aa

    .line 217
    :cond_d8
    new-instance v0, Ljava/util/ArrayList;

    .line 219
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 222
    invoke-virtual {v11}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 225
    move-result-object v6

    .line 226
    invoke-interface {v6}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    .line 229
    move-result-object v6

    .line 230
    :goto_e5
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 233
    move-result v7

    .line 234
    if-eqz v7, :cond_143

    .line 236
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 239
    move-result-object v7

    .line 240
    check-cast v7, Ljava/util/Map$Entry;

    .line 242
    invoke-interface {v7}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 245
    move-result-object v11

    .line 246
    check-cast v11, Ljava/lang/Number;

    .line 248
    invoke-virtual {v11}, Ljava/lang/Number;->intValue()I

    .line 251
    move-result v11

    .line 252
    invoke-interface {v7}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 255
    move-result-object v7

    .line 256
    check-cast v7, Ljava/util/List;

    .line 258
    invoke-static {v7}, Lkotlin/io/ByteStreamsKt;->getIndices(Ljava/util/Collection;)Lkotlin/ranges/IntRange;

    .line 261
    move-result-object v7

    .line 262
    new-instance v13, Ljava/util/ArrayList;

    .line 264
    move/from16 v19, v2

    .line 266
    move-object/from16 v21, v3

    .line 268
    const/16 v2, 0xa

    .line 270
    invoke-static {v7, v2}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 273
    move-result v3

    .line 274
    invoke-direct {v13, v3}, Ljava/util/ArrayList;-><init>(I)V

    .line 277
    invoke-virtual {v7}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 280
    move-result-object v2

    .line 281
    :goto_118
    move-object v3, v2

    .line 282
    check-cast v3, Lkotlin/ranges/IntProgressionIterator;

    .line 284
    iget-boolean v3, v3, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 286
    if-eqz v3, :cond_13b

    .line 288
    move-object v3, v2

    .line 289
    check-cast v3, Lkotlin/collections/IntIterator;

    .line 291
    invoke-virtual {v3}, Lkotlin/collections/IntIterator;->nextInt()I

    .line 294
    move-result v3

    .line 295
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 298
    move-result-object v7

    .line 299
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 302
    move-result-object v3

    .line 303
    move-object/from16 v22, v2

    .line 305
    new-instance v2, Lkotlin/Pair;

    .line 307
    invoke-direct {v2, v7, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 310
    invoke-virtual {v13, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 313
    move-object/from16 v2, v22

    .line 315
    goto :goto_118

    .line 316
    :cond_13b
    invoke-static {v13, v0}, Lkotlin/collections/CollectionsKt__MutableCollectionsKt;->addAll$1(Ljava/lang/Iterable;Ljava/util/Collection;)V

    .line 319
    move/from16 v2, v19

    .line 321
    move-object/from16 v3, v21

    .line 323
    goto :goto_e5

    .line 324
    :cond_143
    move/from16 v19, v2

    .line 326
    move-object/from16 v21, v3

    .line 328
    invoke-virtual {v8, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 331
    move-object v11, v0

    .line 332
    :goto_14b
    check-cast v11, Ljava/util/List;

    .line 334
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->minOrNull(Ljava/lang/Iterable;)Ljava/lang/Comparable;

    .line 337
    move-result-object v0

    .line 338
    check-cast v0, Ljava/lang/Integer;

    .line 340
    const/16 v2, 0x7a8

    .line 342
    if-eqz v0, :cond_15e

    .line 344
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 347
    move-result v0

    .line 348
    :goto_15b
    const/16 v20, 0xa

    .line 350
    goto :goto_160

    .line 351
    :cond_15e
    move v0, v2

    .line 352
    goto :goto_15b

    .line 353
    :goto_160
    div-int/lit8 v0, v0, 0xa

    .line 355
    mul-int/lit8 v0, v0, 0xa

    .line 357
    invoke-static {v2, v0}, Ljava/lang/Math;->min(II)I

    .line 360
    move-result v0

    .line 361
    iget-object v2, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 363
    iget-object v2, v2, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->to:Ljava/time/LocalDate;

    .line 365
    invoke-virtual {v2}, Ljava/time/LocalDate;->getYear()I

    .line 368
    move-result v2

    .line 369
    invoke-static {v5}, Lkotlin/collections/CollectionsKt;->maxOrNull(Ljava/lang/Iterable;)Ljava/lang/Comparable;

    .line 372
    move-result-object v3

    .line 373
    check-cast v3, Ljava/lang/Integer;

    .line 375
    if-eqz v3, :cond_17d

    .line 377
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 380
    move-result v6

    .line 381
    goto :goto_17e

    .line 382
    :cond_17d
    const/4 v6, 0x0

    .line 383
    :goto_17e
    add-int/lit8 v3, v0, 0x14

    .line 385
    invoke-static {v6, v3}, Ljava/lang/Math;->max(II)I

    .line 388
    move-result v3

    .line 389
    invoke-static {v2, v3}, Ljava/lang/Math;->max(II)I

    .line 392
    move-result v22

    .line 393
    shr-int/lit8 v2, v19, 0x9

    .line 395
    and-int/lit8 v2, v2, 0xe

    .line 397
    or-int/lit8 v2, v2, 0x30

    .line 399
    const v3, 0x458fc000  # 4600.0f

    .line 402
    invoke-static {v4, v3, v8, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->clock(ZFLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/Animatable;

    .line 405
    move-result-object v13

    .line 406
    sget-object v2, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 408
    invoke-virtual {v8, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 411
    move-result-object v2

    .line 412
    check-cast v2, Landroidx/compose/ui/unit/Density;

    .line 414
    invoke-interface {v2}, Landroidx/compose/ui/unit/Density;->getFontScale()F

    .line 417
    move-result v2

    .line 418
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 420
    const/high16 v5, 0x3f800000  # 1.0f

    .line 422
    invoke-static {v3, v5}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 425
    move-result-object v5

    .line 426
    move-wide/from16 v18, v9

    .line 428
    new-instance v9, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;

    .line 430
    move-object/from16 v20, v11

    .line 432
    move-object/from16 v10, v21

    .line 434
    move/from16 v21, v0

    .line 436
    move v11, v2

    .line 437
    invoke-direct/range {v9 .. v24}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda21;-><init>(Ljava/lang/Integer;FLcom/spotifry/music/data/spotifried/AgeStats;Landroidx/compose/animation/core/Animatable;IIJJLjava/util/List;IIJ)V

    .line 440
    const v0, -0x68baddd1

    .line 443
    invoke-static {v0, v9, v8}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 446
    move-result-object v7

    .line 447
    const/16 v9, 0xc06

    .line 449
    const/4 v10, 0x6

    .line 450
    const/4 v6, 0x0

    .line 451
    invoke-static/range {v5 .. v10}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 454
    goto :goto_1c9

    .line 455
    :cond_1c6
    invoke-virtual/range {p4 .. p4}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 458
    :goto_1c9
    invoke-virtual/range {p4 .. p4}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 461
    move-result-object v7

    .line 462
    if-eqz v7, :cond_1dd

    .line 464
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;

    .line 466
    const/4 v6, 0x1

    .line 467
    move/from16 v2, p1

    .line 469
    move/from16 v3, p2

    .line 471
    move/from16 v5, p5

    .line 473
    invoke-direct/range {v0 .. v6}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZIB)V

    .line 476
    iput-object v0, v7, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 478
    :cond_1dd
    return-void
.end method

.method public static final Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F
    .registers 5

    .line 1
    invoke-virtual {p0}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 4
    move-result p0

    .line 5
    const/high16 v0, 0x41000000  # 8.0f

    .line 7
    sub-float/2addr p0, v0

    .line 8
    sub-int/2addr p3, p1

    .line 9
    int-to-float p3, p3

    .line 10
    sub-int/2addr p2, p1

    .line 11
    int-to-float p1, p2

    .line 12
    div-float/2addr p3, p1

    .line 13
    mul-float/2addr p3, p0

    .line 14
    const/high16 p0, 0x40800000  # 4.0f

    .line 16
    add-float/2addr p3, p0

    .line 17
    return p3
.end method

.method public static final AgeCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 14

    .line 1
    const v0, 0x71655a09

    .line 4
    invoke-virtual {p4, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p5, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p4, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p5

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p5

    .line 23
    :goto_16
    and-int/lit8 v1, p5, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p4, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit16 v1, p5, 0x180

    .line 41
    if-nez v1, :cond_36

    .line 43
    invoke-virtual {p4, p2}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 46
    move-result v1

    .line 47
    if-eqz v1, :cond_33

    .line 49
    const/16 v1, 0x100

    .line 51
    goto :goto_35

    .line 52
    :cond_33
    const/16 v1, 0x80

    .line 54
    :goto_35
    or-int/2addr v0, v1

    .line 55
    :cond_36
    and-int/lit16 v1, p5, 0xc00

    .line 57
    if-nez v1, :cond_46

    .line 59
    invoke-virtual {p4, p3}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 62
    move-result v1

    .line 63
    if-eqz v1, :cond_43

    .line 65
    const/16 v1, 0x800

    .line 67
    goto :goto_45

    .line 68
    :cond_43
    const/16 v1, 0x400

    .line 70
    :goto_45
    or-int/2addr v0, v1

    .line 71
    :cond_46
    and-int/lit16 v1, v0, 0x493

    .line 73
    const/16 v2, 0x492

    .line 75
    const/4 v3, 0x1

    .line 76
    const/4 v7, 0x0

    .line 77
    if-eq v1, v2, :cond_50

    .line 79
    move v1, v3

    .line 80
    goto :goto_51

    .line 81
    :cond_50
    move v1, v7

    .line 82
    :goto_51
    and-int/lit8 v2, v0, 0x1

    .line 84
    invoke-virtual {p4, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 87
    move-result v1

    .line 88
    if-eqz v1, :cond_a0

    .line 90
    if-eqz p3, :cond_66

    .line 92
    const v1, 0x16a6341

    .line 95
    invoke-virtual {p4, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 98
    invoke-virtual {p4, v7}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 101
    move v1, v3

    .line 102
    goto :goto_73

    .line 103
    :cond_66
    const v1, -0x5288f385

    .line 106
    invoke-virtual {p4, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 109
    invoke-static {p4}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 112
    move-result v1

    .line 113
    invoke-virtual {p4, v7}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 116
    :goto_73
    iget-object v2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 118
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 121
    move-result-object v5

    .line 122
    invoke-virtual {p4, v2, v5}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 125
    move-result-object v2

    .line 126
    iget-object v5, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->age:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 128
    iget-object v5, v5, Lcom/spotifry/music/data/spotifried/AgeStats;->age:Ljava/lang/Integer;

    .line 130
    if-nez v5, :cond_84

    .line 132
    move v3, v7

    .line 133
    :cond_84
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 136
    move-result-object v3

    .line 137
    invoke-virtual {p4, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 140
    move-result-object v2

    .line 141
    const v3, -0x5288e28c

    .line 144
    invoke-virtual {p4, v3, v2}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 147
    and-int/lit16 v5, v0, 0x3fe

    .line 149
    move-object v0, p0

    .line 150
    move v2, p2

    .line 151
    move-object v4, p4

    .line 152
    move v3, v1

    .line 153
    move v1, p1

    .line 154
    invoke-static/range {v0 .. v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 157
    invoke-virtual {p4, v7}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 160
    goto :goto_a3

    .line 161
    :cond_a0
    invoke-virtual {p4}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 164
    :goto_a3
    invoke-virtual {p4}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 167
    move-result-object v7

    .line 168
    if-eqz v7, :cond_b6

    .line 170
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;

    .line 172
    const/4 v6, 0x0

    .line 173
    move-object v1, p0

    .line 174
    move v2, p1

    .line 175
    move v3, p2

    .line 176
    move v4, p3

    .line 177
    move v5, p5

    .line 178
    invoke-direct/range {v0 .. v6}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda2;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZIB)V

    .line 181
    iput-object v0, v7, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 183
    :cond_b6
    return-void
.end method

.method public static final CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 10

    .line 1
    const v0, -0x7effe444

    .line 4
    invoke-virtual {p1, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p2, 0x3

    .line 9
    const/4 v1, 0x0

    .line 10
    const/4 v2, 0x2

    .line 11
    const/4 v3, 0x1

    .line 12
    if-eq v0, v2, :cond_f

    .line 14
    move v0, v3

    .line 15
    goto :goto_10

    .line 16
    :cond_f
    move v0, v1

    .line 17
    :goto_10
    and-int/lit8 v2, p2, 0x1

    .line 19
    invoke-virtual {p1, v2, v0}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_8a

    .line 25
    sget-object v0, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 27
    const/high16 v2, 0x3f800000  # 1.0f

    .line 29
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 32
    move-result-object v0

    .line 33
    const/high16 v2, 0x41a00000  # 20.0f

    .line 35
    const/high16 v4, 0x41e00000  # 28.0f

    .line 37
    const/high16 v5, 0x41d00000  # 26.0f

    .line 39
    invoke-static {v0, v5, v2, v5, v4}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0(Landroidx/compose/ui/Modifier;FFFF)Landroidx/compose/ui/Modifier;

    .line 42
    move-result-object v0

    .line 43
    sget-object v2, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 45
    sget-object v4, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 47
    invoke-static {v2, v4, p1, v1}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 50
    move-result-object v1

    .line 51
    iget-wide v4, p1, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 53
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 56
    move-result v2

    .line 57
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 60
    move-result-object v4

    .line 61
    invoke-static {p1, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 64
    move-result-object v0

    .line 65
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 67
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 70
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 72
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 75
    iget-boolean v6, p1, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 77
    if-eqz v6, :cond_52

    .line 79
    invoke-virtual {p1, v5}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 82
    goto :goto_55

    .line 83
    :cond_52
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 86
    :goto_55
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 88
    invoke-static {p1, v1, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 91
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 93
    invoke-static {p1, v4, v1}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 96
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 98
    iget-boolean v4, p1, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 100
    if-nez v4, :cond_73

    .line 102
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 105
    move-result-object v4

    .line 106
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    move-result-object v5

    .line 110
    invoke-static {v4, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 113
    move-result v4

    .line 114
    if-nez v4, :cond_76

    .line 116
    :cond_73
    invoke-static {v2, p1, v2, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 119
    :cond_76
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 121
    invoke-static {p1, v0, v1}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 124
    const/16 v0, 0x36

    .line 126
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 129
    move-result-object v0

    .line 130
    sget-object v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 132
    invoke-virtual {p0, v1, p1, v0}, Landroidx/compose/runtime/internal/ComposableLambdaImpl;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 135
    invoke-virtual {p1, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 138
    goto :goto_8d

    .line 139
    :cond_8a
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 142
    :goto_8d
    invoke-virtual {p1}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 145
    move-result-object p1

    .line 146
    if-eqz p1, :cond_9b

    .line 148
    new-instance v0, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda137;

    .line 150
    const/4 v1, 0x7

    .line 151
    invoke-direct {v0, p0, p2, v1}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda137;-><init>(Landroidx/compose/runtime/internal/ComposableLambdaImpl;IB)V

    .line 154
    iput-object v0, p1, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 156
    :cond_9b
    return-void
.end method

.method public static final Day(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lcom/spotifry/music/data/spotifried/ObsessionDay;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 23

    .line 1
    move-object/from16 v3, p0

    .line 3
    move-object/from16 v2, p1

    .line 5
    move/from16 v1, p2

    .line 7
    move-object/from16 v14, p3

    .line 9
    move/from16 v15, p4

    .line 11
    const v0, 0x34ffe115

    .line 14
    invoke-virtual {v14, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 17
    and-int/lit8 v0, v15, 0x6

    .line 19
    if-nez v0, :cond_1f

    .line 21
    invoke-virtual {v14, v3}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1c

    .line 27
    const/4 v0, 0x4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v0, 0x2

    .line 30
    :goto_1d
    or-int/2addr v0, v15

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v0, v15

    .line 33
    :goto_20
    and-int/lit8 v4, v15, 0x30

    .line 35
    if-nez v4, :cond_30

    .line 37
    invoke-virtual {v14, v2}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 40
    move-result v4

    .line 41
    if-eqz v4, :cond_2d

    .line 43
    const/16 v4, 0x20

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    const/16 v4, 0x10

    .line 48
    :goto_2f
    or-int/2addr v0, v4

    .line 49
    :cond_30
    and-int/lit16 v4, v15, 0x180

    .line 51
    if-nez v4, :cond_40

    .line 53
    invoke-virtual {v14, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 56
    move-result v4

    .line 57
    if-eqz v4, :cond_3d

    .line 59
    const/16 v4, 0x100

    .line 61
    goto :goto_3f

    .line 62
    :cond_3d
    const/16 v4, 0x80

    .line 64
    :goto_3f
    or-int/2addr v0, v4

    .line 65
    :cond_40
    and-int/lit16 v4, v0, 0x93

    .line 67
    const/16 v5, 0x92

    .line 69
    const/4 v6, 0x1

    .line 70
    if-eq v4, v5, :cond_49

    .line 72
    move v4, v6

    .line 73
    goto :goto_4a

    .line 74
    :cond_49
    const/4 v4, 0x0

    .line 75
    :goto_4a
    and-int/lit8 v5, v0, 0x1

    .line 77
    invoke-virtual {v14, v5, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 80
    move-result v4

    .line 81
    if-eqz v4, :cond_d1

    .line 83
    sget-object v4, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 85
    invoke-virtual {v14, v4}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 88
    move-result-object v5

    .line 89
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 91
    iget-wide v7, v5, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 93
    invoke-virtual {v14, v4}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 96
    move-result-object v4

    .line 97
    check-cast v4, Landroidx/compose/material3/ColorScheme;

    .line 99
    iget-wide v4, v4, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 101
    const v9, 0x3e0f5c29  # 0.14f

    .line 104
    invoke-static {v9, v4, v5}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 107
    move-result-wide v9

    .line 108
    invoke-virtual {v14, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 111
    move-result v11

    .line 112
    invoke-virtual {v14}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 115
    move-result-object v12

    .line 116
    if-nez v11, :cond_79

    .line 118
    sget-object v11, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 120
    if-ne v12, v11, :cond_82

    .line 122
    :cond_79
    iget-object v11, v2, Lcom/spotifry/music/data/spotifried/ObsessionDay;->startHours:Ljava/util/ArrayList;

    .line 124
    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->sorted(Ljava/lang/Iterable;)Ljava/util/List;

    .line 127
    move-result-object v12

    .line 128
    invoke-virtual {v14, v12}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 131
    :cond_82
    move-object v11, v12

    .line 132
    check-cast v11, Ljava/util/List;

    .line 134
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 137
    move-result v12

    .line 138
    if-lt v12, v6, :cond_8c

    .line 140
    move v6, v12

    .line 141
    :cond_8c
    int-to-float v6, v6

    .line 142
    const/high16 v12, 0x44fa0000  # 2000.0f

    .line 144
    div-float/2addr v12, v6

    .line 145
    const/high16 v6, 0x428c0000  # 70.0f

    .line 147
    invoke-static {v6, v12}, Ljava/lang/Math;->min(FF)F

    .line 150
    move-result v13

    .line 151
    invoke-interface {v11}, Ljava/util/List;->size()I

    .line 154
    move-result v6

    .line 155
    int-to-float v6, v6

    .line 156
    mul-float/2addr v6, v13

    .line 157
    const/high16 v12, 0x43fa0000  # 500.0f

    .line 159
    add-float/2addr v6, v12

    .line 160
    const v12, 0x44098000  # 550.0f

    .line 163
    add-float/2addr v6, v12

    .line 164
    shr-int/lit8 v12, v0, 0x6

    .line 166
    and-int/lit8 v12, v12, 0xe

    .line 168
    invoke-static {v1, v6, v14, v12}, Lcom/spotifry/music/ui/spotifried/CardsKt;->clock(ZFLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/Animatable;

    .line 171
    move-result-object v12

    .line 172
    iget v6, v2, Lcom/spotifry/music/data/spotifried/ObsessionDay;->plays:I

    .line 174
    shr-int/lit8 v0, v0, 0x3

    .line 176
    and-int/lit8 v0, v0, 0x70

    .line 178
    or-int/lit16 v0, v0, 0x180

    .line 180
    const/16 v2, 0x1c2

    .line 182
    invoke-static {v6, v2, v0, v14, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countUp(IIILandroidx/compose/runtime/ComposerImpl;Z)Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 185
    move-result-object v6

    .line 186
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;

    .line 188
    move-wide/from16 v16, v7

    .line 190
    move-wide v7, v4

    .line 191
    move-wide/from16 v4, v16

    .line 193
    move-object/from16 v2, p1

    .line 195
    invoke-direct/range {v0 .. v13}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;-><init>(ZLcom/spotifry/music/data/spotifried/ObsessionDay;Lcom/spotifry/music/data/spotifried/SpotifriedStats;JLcom/spotifry/music/ui/spotifried/CountUp;JJLjava/util/List;Landroidx/compose/animation/core/Animatable;F)V

    .line 198
    const v4, 0x39868052

    .line 201
    invoke-static {v4, v0, v14}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 204
    move-result-object v0

    .line 205
    const/4 v4, 0x6

    .line 206
    invoke-static {v0, v14, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 209
    goto :goto_d4

    .line 210
    :cond_d1
    invoke-virtual {v14}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 213
    :goto_d4
    invoke-virtual {v14}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 216
    move-result-object v0

    .line 217
    if-eqz v0, :cond_e1

    .line 219
    new-instance v4, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;

    .line 221
    invoke-direct {v4, v3, v2, v1, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lcom/spotifry/music/data/spotifried/ObsessionDay;ZI)V

    .line 224
    iput-object v4, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 226
    :cond_e1
    return-void
.end method

.method public static final DayCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 10

    .line 1
    const v0, 0x36a75860

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_7d

    .line 58
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->obsession:Lcom/spotifry/music/data/spotifried/ObsessionDay;

    .line 60
    if-nez v1, :cond_4d

    .line 62
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 65
    move-result-object p2

    .line 66
    if-eqz p2, :cond_8e

    .line 68
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 70
    const/16 v1, 0x9

    .line 72
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 75
    :goto_4a
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 77
    return-void

    .line 78
    :cond_4d
    if-eqz p1, :cond_59

    .line 80
    const v2, 0x1c2748ca

    .line 83
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 86
    :goto_55
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 89
    goto :goto_64

    .line 90
    :cond_59
    const v2, 0x2a32d1d2

    .line 93
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 96
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 99
    move-result v3

    .line 100
    goto :goto_55

    .line 101
    :goto_64
    iget-object v2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 103
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 106
    move-result-object v5

    .line 107
    invoke-virtual {p2, v2, v5}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 110
    move-result-object v2

    .line 111
    const v5, 0x2a32d4c9

    .line 114
    invoke-virtual {p2, v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 117
    and-int/lit8 v0, v0, 0xe

    .line 119
    invoke-static {p0, v1, v3, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Day(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lcom/spotifry/music/data/spotifried/ObsessionDay;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 122
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 125
    goto :goto_80

    .line 126
    :cond_7d
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 129
    :goto_80
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 132
    move-result-object p2

    .line 133
    if-eqz p2, :cond_8e

    .line 135
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 137
    const/16 v1, 0xa

    .line 139
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 142
    goto :goto_4a

    .line 143
    :cond_8e
    return-void
.end method

.method public static final Hours(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 24

    .line 1
    move-object/from16 v2, p0

    .line 3
    move/from16 v1, p1

    .line 5
    move-object/from16 v12, p2

    .line 7
    move/from16 v13, p3

    .line 9
    iget-wide v3, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 11
    const v0, 0x77d49923

    .line 14
    invoke-virtual {v12, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 17
    and-int/lit8 v0, v13, 0x6

    .line 19
    if-nez v0, :cond_1f

    .line 21
    invoke-virtual {v12, v2}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 24
    move-result v0

    .line 25
    if-eqz v0, :cond_1c

    .line 27
    const/4 v0, 0x4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v0, 0x2

    .line 30
    :goto_1d
    or-int/2addr v0, v13

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v0, v13

    .line 33
    :goto_20
    and-int/lit8 v5, v13, 0x30

    .line 35
    if-nez v5, :cond_30

    .line 37
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 40
    move-result v5

    .line 41
    if-eqz v5, :cond_2d

    .line 43
    const/16 v5, 0x20

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    const/16 v5, 0x10

    .line 48
    :goto_2f
    or-int/2addr v0, v5

    .line 49
    :cond_30
    and-int/lit8 v5, v0, 0x13

    .line 51
    const/16 v6, 0x12

    .line 53
    const/4 v8, 0x1

    .line 54
    if-eq v5, v6, :cond_39

    .line 56
    move v5, v8

    .line 57
    goto :goto_3a

    .line 58
    :cond_39
    const/4 v5, 0x0

    .line 59
    :goto_3a
    and-int/lit8 v6, v0, 0x1

    .line 61
    invoke-virtual {v12, v6, v5}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 64
    move-result v5

    .line 65
    if-eqz v5, :cond_10e

    .line 67
    sget-object v5, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 69
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 72
    move-result-object v6

    .line 73
    check-cast v6, Landroidx/compose/material3/ColorScheme;

    .line 75
    iget-wide v9, v6, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 77
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 80
    move-result-object v5

    .line 81
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 83
    iget-wide v5, v5, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 85
    const v11, 0x3e4ccccd  # 0.2f

    .line 88
    invoke-static {v11, v5, v6}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 91
    move-result-wide v5

    .line 92
    long-to-double v14, v3

    .line 93
    const-wide v16, 0x40ac200000000000L  # 3600.0

    .line 98
    div-double v14, v14, v16

    .line 100
    invoke-static {v14, v15}, Lkotlin/math/MathKt;->roundToInt(D)I

    .line 103
    move-result v11

    .line 104
    if-lt v11, v8, :cond_7a

    .line 106
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 109
    move-result-object v3

    .line 110
    if-ne v11, v8, :cond_72

    .line 112
    const-string v4, "hour."

    .line 114
    goto :goto_74

    .line 115
    :cond_72
    const-string v4, "hours."

    .line 117
    :goto_74
    new-instance v8, Lkotlin/Pair;

    .line 119
    invoke-direct {v8, v3, v4}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 122
    goto :goto_8e

    .line 123
    :cond_7a
    invoke-static {v3, v4}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 126
    move-result v3

    .line 127
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 130
    move-result-object v4

    .line 131
    if-ne v3, v8, :cond_87

    .line 133
    const-string v3, "minute."

    .line 135
    goto :goto_89

    .line 136
    :cond_87
    const-string v3, "minutes."

    .line 138
    :goto_89
    new-instance v8, Lkotlin/Pair;

    .line 140
    invoke-direct {v8, v4, v3}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 143
    :goto_8e
    iget-object v3, v8, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 145
    check-cast v3, Ljava/lang/Number;

    .line 147
    invoke-virtual {v3}, Ljava/lang/Number;->intValue()I

    .line 150
    move-result v3

    .line 151
    iget-object v4, v8, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 153
    check-cast v4, Ljava/lang/String;

    .line 155
    and-int/lit8 v0, v0, 0x70

    .line 157
    or-int/lit16 v0, v0, 0x180

    .line 159
    const/16 v8, 0x1c2

    .line 161
    invoke-static {v3, v8, v0, v12, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countUp(IIILandroidx/compose/runtime/ComposerImpl;Z)Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 164
    move-result-object v0

    .line 165
    iget-object v3, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->daySeconds:Ljava/util/List;

    .line 167
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 170
    move-result v8

    .line 171
    iget-object v3, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->longestDay:Ljava/time/LocalDate;

    .line 173
    const/4 v11, 0x0

    .line 174
    if-eqz v3, :cond_c2

    .line 176
    sget-object v14, Ljava/time/temporal/ChronoUnit;->DAYS:Ljava/time/temporal/ChronoUnit;

    .line 178
    iget-object v15, v2, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->start:Ljava/time/LocalDate;

    .line 180
    invoke-virtual {v14, v15, v3}, Ljava/time/temporal/ChronoUnit;->between(Ljava/time/temporal/Temporal;Ljava/time/temporal/Temporal;)J

    .line 183
    move-result-wide v14

    .line 184
    long-to-int v3, v14

    .line 185
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 188
    move-result-object v14

    .line 189
    if-ltz v3, :cond_c2

    .line 191
    if-ge v3, v8, :cond_c2

    .line 193
    move-object v3, v14

    .line 194
    goto :goto_c3

    .line 195
    :cond_c2
    move-object v3, v11

    .line 196
    :goto_c3
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 199
    move-result-object v14

    .line 200
    sget-object v15, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 202
    if-ne v14, v15, :cond_d9

    .line 204
    if-eqz v1, :cond_d1

    .line 206
    const v14, 0x451c4000  # 2500.0f

    .line 209
    goto :goto_d2

    .line 210
    :cond_d1
    const/4 v14, 0x0

    .line 211
    :goto_d2
    invoke-static {v14}, Landroidx/compose/animation/core/ArcSplineKt;->Animatable$default(F)Landroidx/compose/animation/core/Animatable;

    .line 214
    move-result-object v14

    .line 215
    invoke-virtual {v12, v14}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 218
    :cond_d9
    check-cast v14, Landroidx/compose/animation/core/Animatable;

    .line 220
    invoke-virtual {v12, v14}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 223
    move-result v16

    .line 224
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 227
    move-result-object v7

    .line 228
    if-nez v16, :cond_e7

    .line 230
    if-ne v7, v15, :cond_f0

    .line 232
    :cond_e7
    new-instance v7, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;

    .line 234
    const/4 v15, 0x0

    .line 235
    invoke-direct {v7, v14, v11, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$Hours$2$1;-><init>(Landroidx/compose/animation/core/Animatable;Lkotlin/coroutines/Continuation;B)V

    .line 238
    invoke-virtual {v12, v7}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 241
    :cond_f0
    check-cast v7, Lkotlin/jvm/functions/Function2;

    .line 243
    invoke-static {v12, v14, v7}, Landroidx/compose/runtime/AnchoredGroupPath;->LaunchedEffect(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 246
    move-object v7, v4

    .line 247
    move-wide/from16 v18, v5

    .line 249
    move-object v6, v0

    .line 250
    move-wide v4, v9

    .line 251
    move-wide/from16 v10, v18

    .line 253
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;

    .line 255
    move-object v9, v14

    .line 256
    invoke-direct/range {v0 .. v11}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda17;-><init>(ZLcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/lang/Integer;JLcom/spotifry/music/ui/spotifried/CountUp;Ljava/lang/String;ILandroidx/compose/animation/core/Animatable;J)V

    .line 259
    const v3, -0x366e1fa

    .line 262
    invoke-static {v3, v0, v12}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 265
    move-result-object v0

    .line 266
    const/4 v3, 0x6

    .line 267
    invoke-static {v0, v12, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 270
    goto :goto_111

    .line 271
    :cond_10e
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 274
    :goto_111
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 277
    move-result-object v0

    .line 278
    if-eqz v0, :cond_11f

    .line 280
    new-instance v3, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 282
    const/4 v4, 0x3

    .line 283
    invoke-direct {v3, v2, v1, v13, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 286
    iput-object v3, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 288
    :cond_11f
    return-void
.end method

.method public static final HoursCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 9

    .line 1
    const v0, 0x77e2fd3

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_69

    .line 58
    if-eqz p1, :cond_45

    .line 60
    const v1, -0xa7f2b49

    .line 63
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 66
    :goto_41
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 69
    goto :goto_50

    .line 70
    :cond_45
    const v1, 0x20b19445

    .line 73
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 76
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 79
    move-result v3

    .line 80
    goto :goto_41

    .line 81
    :goto_50
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 83
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {p2, v1, v2}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 90
    move-result-object v1

    .line 91
    const v2, 0x20b19739

    .line 94
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 97
    and-int/lit8 v0, v0, 0xe

    .line 99
    invoke-static {p0, v3, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Hours(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 102
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 105
    goto :goto_6c

    .line 106
    :cond_69
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 109
    :goto_6c
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 112
    move-result-object p2

    .line 113
    if-eqz p2, :cond_7b

    .line 115
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 117
    const/16 v1, 0xb

    .line 119
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 122
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 124
    :cond_7b
    return-void
.end method

.method public static final Intro(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 24

    .line 1
    move-object/from16 v5, p0

    .line 3
    move/from16 v8, p1

    .line 5
    move-object/from16 v9, p2

    .line 7
    move/from16 v10, p3

    .line 9
    const v0, -0x419f8980

    .line 12
    invoke-virtual {v9, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 15
    and-int/lit8 v0, v10, 0x6

    .line 17
    if-nez v0, :cond_1d

    .line 19
    invoke-virtual {v9, v5}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 22
    move-result v0

    .line 23
    if-eqz v0, :cond_1a

    .line 25
    const/4 v0, 0x4

    .line 26
    goto :goto_1b

    .line 27
    :cond_1a
    const/4 v0, 0x2

    .line 28
    :goto_1b
    or-int/2addr v0, v10

    .line 29
    goto :goto_1e

    .line 30
    :cond_1d
    move v0, v10

    .line 31
    :goto_1e
    and-int/lit8 v1, v10, 0x30

    .line 33
    if-nez v1, :cond_2e

    .line 35
    invoke-virtual {v9, v8}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 38
    move-result v1

    .line 39
    if-eqz v1, :cond_2b

    .line 41
    const/16 v1, 0x20

    .line 43
    goto :goto_2d

    .line 44
    :cond_2b
    const/16 v1, 0x10

    .line 46
    :goto_2d
    or-int/2addr v0, v1

    .line 47
    :cond_2e
    and-int/lit8 v1, v0, 0x13

    .line 49
    const/16 v2, 0x12

    .line 51
    if-eq v1, v2, :cond_36

    .line 53
    const/4 v1, 0x1

    .line 54
    goto :goto_37

    .line 55
    :cond_36
    const/4 v1, 0x0

    .line 56
    :goto_37
    and-int/lit8 v2, v0, 0x1

    .line 58
    invoke-virtual {v9, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 61
    move-result v1

    .line 62
    if-eqz v1, :cond_ef

    .line 64
    sget-object v1, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 66
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 69
    move-result-object v1

    .line 70
    check-cast v1, Landroidx/compose/material3/ColorScheme;

    .line 72
    iget-wide v1, v1, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 74
    iget-wide v6, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 76
    iget-object v4, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 78
    invoke-static {v6, v7}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 81
    move-result v6

    .line 82
    invoke-static {v6}, Lcom/spotifry/music/data/Log;->sunScale(I)F

    .line 85
    move-result v6

    .line 86
    invoke-static {v4, v6, v8, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rememberSunMotion(Ljava/util/List;FZLandroidx/compose/runtime/ComposerImpl;)Lcom/spotifry/music/ui/listening/SunMotion;

    .line 89
    move-result-object v7

    .line 90
    invoke-static {v4}, Lkotlin/io/ByteStreamsKt;->getIndices(Ljava/util/Collection;)Lkotlin/ranges/IntRange;

    .line 93
    move-result-object v11

    .line 94
    invoke-virtual {v11}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 97
    move-result-object v11

    .line 98
    move-object v12, v11

    .line 99
    check-cast v12, Lkotlin/ranges/IntProgressionIterator;

    .line 101
    iget-boolean v13, v12, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 103
    if-nez v13, :cond_6a

    .line 105
    const/4 v4, 0x0

    .line 106
    goto :goto_a8

    .line 107
    :cond_6a
    check-cast v11, Lkotlin/collections/IntIterator;

    .line 109
    invoke-virtual {v11}, Lkotlin/collections/IntIterator;->next()Ljava/lang/Object;

    .line 112
    move-result-object v13

    .line 113
    iget-boolean v14, v12, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 115
    if-eqz v14, :cond_a7

    .line 117
    move-object v14, v13

    .line 118
    check-cast v14, Ljava/lang/Number;

    .line 120
    invoke-virtual {v14}, Ljava/lang/Number;->intValue()I

    .line 123
    move-result v14

    .line 124
    invoke-interface {v4, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 127
    move-result-object v14

    .line 128
    check-cast v14, Ljava/lang/Number;

    .line 130
    invoke-virtual {v14}, Ljava/lang/Number;->longValue()J

    .line 133
    move-result-wide v14

    .line 134
    :goto_85
    invoke-virtual {v11}, Lkotlin/collections/IntIterator;->next()Ljava/lang/Object;

    .line 137
    move-result-object v16

    .line 138
    move-object/from16 v17, v16

    .line 140
    check-cast v17, Ljava/lang/Number;

    .line 142
    invoke-virtual/range {v17 .. v17}, Ljava/lang/Number;->intValue()I

    .line 145
    move-result v3

    .line 146
    invoke-interface {v4, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 149
    move-result-object v3

    .line 150
    check-cast v3, Ljava/lang/Number;

    .line 152
    invoke-virtual {v3}, Ljava/lang/Number;->longValue()J

    .line 155
    move-result-wide v18

    .line 156
    cmp-long v3, v14, v18

    .line 158
    if-gez v3, :cond_a3

    .line 160
    move-object/from16 v13, v16

    .line 162
    move-wide/from16 v14, v18

    .line 164
    :cond_a3
    iget-boolean v3, v12, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 166
    if-nez v3, :cond_ea

    .line 168
    :cond_a7
    move-object v4, v13

    .line 169
    :goto_a8
    check-cast v4, Ljava/lang/Integer;

    .line 171
    if-eqz v4, :cond_b1

    .line 173
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 176
    move-result v3

    .line 177
    goto :goto_b2

    .line 178
    :cond_b1
    const/4 v3, 0x0

    .line 179
    :goto_b2
    neg-int v3, v3

    .line 180
    int-to-float v3, v3

    .line 181
    const/high16 v4, 0x41700000  # 15.0f

    .line 183
    mul-float/2addr v4, v3

    .line 184
    shr-int/lit8 v0, v0, 0x3

    .line 186
    and-int/lit8 v0, v0, 0xe

    .line 188
    or-int/lit16 v0, v0, 0x1b0

    .line 190
    const/16 v3, 0xc8

    .line 192
    const/16 v11, 0x578

    .line 194
    invoke-static {v3, v11, v0, v9, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 197
    move-result-object v0

    .line 198
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 200
    const/high16 v11, 0x3f800000  # 1.0f

    .line 202
    invoke-static {v3, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 205
    move-result-object v3

    .line 206
    invoke-static {v3}, Landroidx/compose/ui/draw/ClipKt;->clipToBounds(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 209
    move-result-object v11

    .line 210
    move-wide v2, v1

    .line 211
    move-object v1, v0

    .line 212
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;

    .line 214
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda23;-><init>(Landroidx/compose/animation/core/Animatable;JFLcom/spotifry/music/data/spotifried/SpotifriedStats;FLcom/spotifry/music/ui/listening/SunMotion;Z)V

    .line 217
    move-object v6, v5

    .line 218
    const v1, 0x2bbac5d6

    .line 221
    invoke-static {v1, v0, v9}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 224
    move-result-object v2

    .line 225
    const/16 v4, 0xc06

    .line 227
    const/4 v5, 0x6

    .line 228
    const/4 v1, 0x0

    .line 229
    move-object v3, v9

    .line 230
    move-object v0, v11

    .line 231
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 234
    goto :goto_f3

    .line 235
    :cond_ea
    move-wide v2, v1

    .line 236
    move-object/from16 v9, p2

    .line 238
    move-wide v1, v2

    .line 239
    goto :goto_85

    .line 240
    :cond_ef
    move-object v6, v5

    .line 241
    invoke-virtual/range {p2 .. p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 244
    :goto_f3
    invoke-virtual/range {p2 .. p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 247
    move-result-object v0

    .line 248
    if-eqz v0, :cond_101

    .line 250
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 252
    const/4 v2, 0x5

    .line 253
    invoke-direct {v1, v6, v8, v10, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 256
    iput-object v1, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 258
    :cond_101
    return-void
.end method

.method public static final IntroCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 9

    .line 1
    const v0, 0x3ff216b0

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_69

    .line 58
    if-eqz p1, :cond_45

    .line 60
    const v1, 0x6d1fa4ba

    .line 63
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 66
    :goto_41
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 69
    goto :goto_50

    .line 70
    :cond_45
    const v1, 0xbc737e2

    .line 73
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 76
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 79
    move-result v3

    .line 80
    goto :goto_41

    .line 81
    :goto_50
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 83
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {p2, v1, v2}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 90
    move-result-object v1

    .line 91
    const v2, 0xbc73ad6

    .line 94
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 97
    and-int/lit8 v0, v0, 0xe

    .line 99
    invoke-static {p0, v3, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Intro(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 102
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 105
    goto :goto_6c

    .line 106
    :cond_69
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 109
    :goto_6c
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 112
    move-result-object p2

    .line 113
    if-eqz p2, :cond_7a

    .line 115
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 117
    const/4 v1, 0x7

    .line 118
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 121
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 123
    :cond_7a
    return-void
.end method

.method public static final Months(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 22

    .line 1
    move-object/from16 v5, p0

    .line 3
    move/from16 v6, p1

    .line 5
    move-object/from16 v12, p2

    .line 7
    move/from16 v13, p3

    .line 9
    const v0, -0x60c4e9dd

    .line 12
    invoke-virtual {v12, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 15
    and-int/lit8 v0, v13, 0x6

    .line 17
    const/4 v1, 0x4

    .line 18
    if-nez v0, :cond_1e

    .line 20
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 23
    move-result v0

    .line 24
    if-eqz v0, :cond_1b

    .line 26
    move v0, v1

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    const/4 v0, 0x2

    .line 29
    :goto_1c
    or-int/2addr v0, v13

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v0, v13

    .line 32
    :goto_1f
    and-int/lit8 v2, v13, 0x30

    .line 34
    if-nez v2, :cond_2f

    .line 36
    invoke-virtual {v12, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 39
    move-result v2

    .line 40
    if-eqz v2, :cond_2c

    .line 42
    const/16 v2, 0x20

    .line 44
    goto :goto_2e

    .line 45
    :cond_2c
    const/16 v2, 0x10

    .line 47
    :goto_2e
    or-int/2addr v0, v2

    .line 48
    :cond_2f
    and-int/lit8 v2, v0, 0x13

    .line 50
    const/16 v3, 0x12

    .line 52
    const/4 v7, 0x1

    .line 53
    if-eq v2, v3, :cond_38

    .line 55
    move v2, v7

    .line 56
    goto :goto_39

    .line 57
    :cond_38
    const/4 v2, 0x0

    .line 58
    :goto_39
    and-int/2addr v0, v7

    .line 59
    invoke-virtual {v12, v0, v2}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 62
    move-result v0

    .line 63
    const/4 v14, 0x6

    .line 64
    if-eqz v0, :cond_111

    .line 66
    sget-object v0, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 68
    invoke-virtual {v12, v0}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 71
    move-result-object v2

    .line 72
    check-cast v2, Landroidx/compose/material3/ColorScheme;

    .line 74
    iget-wide v2, v2, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 76
    invoke-virtual {v12, v0}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 79
    move-result-object v0

    .line 80
    check-cast v0, Landroidx/compose/material3/ColorScheme;

    .line 82
    iget-wide v8, v0, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 84
    const v0, 0x3e0f5c29  # 0.14f

    .line 87
    invoke-static {v0, v8, v9}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 90
    move-result-wide v8

    .line 91
    iget-object v0, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->months:Ljava/util/ArrayList;

    .line 93
    iget-object v10, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 95
    iget-object v10, v10, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->label:Ljava/lang/String;

    .line 97
    iget-object v11, v5, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->changeMonth:Ljava/time/YearMonth;

    .line 99
    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 102
    move-result-object v15

    .line 103
    const/16 v16, 0x0

    .line 105
    :goto_68
    invoke-interface {v15}, Ljava/util/Iterator;->hasNext()Z

    .line 108
    move-result v17

    .line 109
    if-eqz v17, :cond_81

    .line 111
    invoke-interface {v15}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 114
    move-result-object v17

    .line 115
    move-object/from16 v4, v17

    .line 117
    check-cast v4, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 119
    iget-object v4, v4, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 121
    invoke-virtual {v4, v11}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 124
    move-result v4

    .line 125
    if-nez v4, :cond_83

    .line 127
    add-int/lit8 v16, v16, 0x1

    .line 129
    goto :goto_68

    .line 130
    :cond_81
    const/16 v16, -0x1

    .line 132
    :cond_83
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 135
    move-result-object v4

    .line 136
    if-gez v16, :cond_8a

    .line 138
    const/4 v4, 0x0

    .line 139
    :cond_8a
    if-eqz v4, :cond_91

    .line 141
    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    .line 144
    move-result v4

    .line 145
    goto :goto_95

    .line 146
    :cond_91
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 149
    move-result v4

    .line 150
    :goto_95
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 153
    move-result v11

    .line 154
    const/16 v15, 0xc

    .line 156
    sub-int/2addr v11, v15

    .line 157
    invoke-static {v11, v4}, Ljava/lang/Math;->min(II)I

    .line 160
    move-result v4

    .line 161
    if-gez v4, :cond_a3

    .line 163
    const/4 v4, 0x0

    .line 164
    :cond_a3
    invoke-static {v0, v4}, Lkotlin/collections/CollectionsKt;->drop(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 167
    move-result-object v0

    .line 168
    invoke-static {v0, v15}, Lkotlin/collections/CollectionsKt;->take(Ljava/lang/Iterable;I)Ljava/util/List;

    .line 171
    move-result-object v4

    .line 172
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 175
    move-result-object v0

    .line 176
    check-cast v0, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 178
    iget-object v0, v0, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 180
    invoke-virtual {v0}, Ljava/time/YearMonth;->getYear()I

    .line 183
    move-result v0

    .line 184
    invoke-static {v4}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 187
    move-result-object v11

    .line 188
    check-cast v11, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 190
    iget-object v11, v11, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 192
    invoke-virtual {v11}, Ljava/time/YearMonth;->getYear()I

    .line 195
    move-result v11

    .line 196
    if-eq v0, v11, :cond_c7

    .line 198
    move v11, v7

    .line 199
    goto :goto_c8

    .line 200
    :cond_c7
    const/4 v11, 0x0

    .line 201
    :goto_c8
    if-eqz v11, :cond_cd

    .line 203
    const-string v0, "MMM \'\'yy"

    .line 205
    goto :goto_cf

    .line 206
    :cond_cd
    const-string v0, "MMM"

    .line 208
    :goto_cf
    sget-object v15, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 210
    invoke-static {v0, v15}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    .line 213
    move-result-object v0

    .line 214
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 217
    move-result v15

    .line 218
    if-ne v15, v1, :cond_f1

    .line 220
    const/4 v1, 0x0

    .line 221
    :goto_dc
    invoke-virtual {v10}, Ljava/lang/String;->length()I

    .line 224
    move-result v15

    .line 225
    if-ge v1, v15, :cond_ef

    .line 227
    invoke-virtual {v10, v1}, Ljava/lang/String;->charAt(I)C

    .line 230
    move-result v15

    .line 231
    invoke-static {v15}, Ljava/lang/Character;->isDigit(C)Z

    .line 234
    move-result v15

    .line 235
    if-eqz v15, :cond_f1

    .line 237
    add-int/lit8 v1, v1, 0x1

    .line 239
    goto :goto_dc

    .line 240
    :cond_ef
    move v1, v7

    .line 241
    goto :goto_f2

    .line 242
    :cond_f1
    const/4 v1, 0x0

    .line 243
    :goto_f2
    sget-object v7, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 245
    invoke-virtual {v12, v7}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 248
    move-result-object v7

    .line 249
    check-cast v7, Landroidx/compose/ui/unit/Density;

    .line 251
    const/high16 v10, 0x41600000  # 14.0f

    .line 253
    invoke-interface {v7, v10}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 256
    move-result v7

    .line 257
    move-object v10, v0

    .line 258
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;

    .line 260
    invoke-direct/range {v0 .. v11}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;-><init>(ZJLjava/util/List;Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZFJLjava/time/format/DateTimeFormatter;Z)V

    .line 263
    const v1, -0x4cf8d260

    .line 266
    invoke-static {v1, v0, v12}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 269
    move-result-object v0

    .line 270
    invoke-static {v0, v12, v14}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 273
    goto :goto_114

    .line 274
    :cond_111
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 277
    :goto_114
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 280
    move-result-object v0

    .line 281
    if-eqz v0, :cond_121

    .line 283
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 285
    invoke-direct {v1, v5, v6, v13, v14}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 288
    iput-object v1, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 290
    :cond_121
    return-void
.end method

.method public static final MonthsCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 10

    .line 1
    const v0, -0x12a1d32d

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_84

    .line 58
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->months:Ljava/util/ArrayList;

    .line 60
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 63
    move-result v1

    .line 64
    if-eqz v1, :cond_51

    .line 66
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 69
    move-result-object p2

    .line 70
    if-eqz p2, :cond_93

    .line 72
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 74
    const/16 v1, 0xc

    .line 76
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 79
    :goto_4e
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 81
    return-void

    .line 82
    :cond_51
    if-eqz p1, :cond_5e

    .line 84
    const v1, -0x3dbbbcc9

    .line 87
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 90
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 93
    move v1, v3

    .line 94
    goto :goto_6b

    .line 95
    :cond_5e
    const v1, 0xe8655c5

    .line 98
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 101
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 104
    move-result v1

    .line 105
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 108
    :goto_6b
    iget-object v2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 110
    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 113
    move-result-object v5

    .line 114
    invoke-virtual {p2, v2, v5}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 117
    move-result-object v2

    .line 118
    const v5, 0xe8658ba

    .line 121
    invoke-virtual {p2, v5, v2}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 124
    and-int/lit8 v0, v0, 0xe

    .line 126
    invoke-static {p0, v1, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Months(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 129
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 132
    goto :goto_87

    .line 133
    :cond_84
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 136
    :goto_87
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 139
    move-result-object p2

    .line 140
    if-eqz p2, :cond_93

    .line 142
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 144
    invoke-direct {v0, p0, p1, p3, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 147
    goto :goto_4e

    .line 148
    :cond_93
    return-void
.end method

.method public static final SunCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 9

    .line 1
    const v0, 0x3a01db10

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p3

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p3

    .line 23
    :goto_16
    and-int/lit8 v1, p3, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit8 v1, v0, 0x13

    .line 41
    const/16 v2, 0x12

    .line 43
    const/4 v3, 0x1

    .line 44
    const/4 v4, 0x0

    .line 45
    if-eq v1, v2, :cond_30

    .line 47
    move v1, v3

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v1, v4

    .line 50
    :goto_31
    and-int/lit8 v2, v0, 0x1

    .line 52
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v1

    .line 56
    if-eqz v1, :cond_69

    .line 58
    if-eqz p1, :cond_45

    .line 60
    const v1, 0x5df4fc9a

    .line 63
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 66
    :goto_41
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 69
    goto :goto_50

    .line 70
    :cond_45
    const v1, -0x3f089bfe

    .line 73
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 76
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 79
    move-result v3

    .line 80
    goto :goto_41

    .line 81
    :goto_50
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 83
    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 86
    move-result-object v2

    .line 87
    invoke-virtual {p2, v1, v2}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 90
    move-result-object v1

    .line 91
    const v2, -0x3f089904

    .line 94
    invoke-virtual {p2, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 97
    and-int/lit8 v0, v0, 0xe

    .line 99
    invoke-static {p0, v3, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->SunPortrait(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 102
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 105
    goto :goto_6c

    .line 106
    :cond_69
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 109
    :goto_6c
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 112
    move-result-object p2

    .line 113
    if-eqz p2, :cond_7b

    .line 115
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 117
    const/16 v1, 0x8

    .line 119
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 122
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 124
    :cond_7b
    return-void
.end method

.method public static final SunPortrait(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 42

    .line 1
    move-object/from16 v4, p0

    .line 3
    move/from16 v8, p1

    .line 5
    move-object/from16 v3, p2

    .line 7
    const v0, -0x4fcc6165

    .line 10
    invoke-virtual {v3, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 13
    and-int/lit8 v0, p3, 0x6

    .line 15
    const/4 v2, 0x2

    .line 16
    if-nez v0, :cond_1d

    .line 18
    invoke-virtual {v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_19

    .line 24
    const/4 v0, 0x4

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    move v0, v2

    .line 27
    :goto_1a
    or-int v0, p3, v0

    .line 29
    goto :goto_1f

    .line 30
    :cond_1d
    move/from16 v0, p3

    .line 32
    :goto_1f
    and-int/lit8 v5, p3, 0x30

    .line 34
    if-nez v5, :cond_2f

    .line 36
    invoke-virtual {v3, v8}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 39
    move-result v5

    .line 40
    if-eqz v5, :cond_2c

    .line 42
    const/16 v5, 0x20

    .line 44
    goto :goto_2e

    .line 45
    :cond_2c
    const/16 v5, 0x10

    .line 47
    :goto_2e
    or-int/2addr v0, v5

    .line 48
    :cond_2f
    and-int/lit8 v5, v0, 0x13

    .line 50
    const/16 v6, 0x12

    .line 52
    const/4 v7, 0x0

    .line 53
    if-eq v5, v6, :cond_38

    .line 55
    const/4 v5, 0x1

    .line 56
    goto :goto_39

    .line 57
    :cond_38
    move v5, v7

    .line 58
    :goto_39
    and-int/lit8 v6, v0, 0x1

    .line 60
    invoke-virtual {v3, v6, v5}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 63
    move-result v5

    .line 64
    if-eqz v5, :cond_280

    .line 66
    sget-object v5, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 68
    invoke-virtual {v3, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 71
    move-result-object v5

    .line 72
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 74
    iget-wide v11, v5, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 76
    iget-wide v5, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 78
    invoke-static {v5, v6}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 81
    move-result v5

    .line 82
    invoke-static {v5}, Lcom/spotifry/music/data/Log;->sunScale(I)F

    .line 85
    move-result v5

    .line 86
    iget-object v6, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 88
    shl-int/lit8 v10, v0, 0x3

    .line 90
    and-int/lit16 v10, v10, 0x380

    .line 92
    invoke-static {v6, v5, v8, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rememberSunMotion(Ljava/util/List;FZLandroidx/compose/runtime/ComposerImpl;)Lcom/spotifry/music/ui/listening/SunMotion;

    .line 95
    move-result-object v6

    .line 96
    shr-int/lit8 v0, v0, 0x3

    .line 98
    const/16 v13, 0xe

    .line 100
    and-int/2addr v0, v13

    .line 101
    or-int/lit8 v0, v0, 0x30

    .line 103
    const v14, 0x450fc000  # 2300.0f

    .line 106
    invoke-static {v8, v14, v3, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->clock(ZFLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/Animatable;

    .line 109
    move-result-object v0

    .line 110
    const/16 v14, 0xb

    .line 112
    invoke-static {v14}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 115
    move-result-wide v18

    .line 116
    invoke-static {v13}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 119
    move-result-wide v26

    .line 120
    sget-object v20, Landroidx/compose/ui/text/font/FontWeight;->SemiBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 122
    new-instance v13, Landroidx/compose/ui/graphics/Shadow;

    .line 124
    sget-wide v14, Landroidx/compose/ui/graphics/Color;->Black:J

    .line 126
    invoke-direct {v13, v2, v14, v15}, Landroidx/compose/ui/graphics/Shadow;-><init>(IJ)V

    .line 129
    const/16 v29, 0x0

    .line 131
    const v30, 0xfddff9

    .line 134
    sget-object v15, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 136
    const-wide/16 v16, 0x0

    .line 138
    const/16 v21, 0x0

    .line 140
    const/16 v22, 0x0

    .line 142
    const-wide/16 v23, 0x0

    .line 144
    const/16 v28, 0x0

    .line 146
    move-object/from16 v25, v13

    .line 148
    invoke-static/range {v15 .. v30}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 151
    move-result-object v33

    .line 152
    sget-object v13, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 154
    const/high16 v14, 0x3f800000  # 1.0f

    .line 156
    invoke-static {v13, v14}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 159
    move-result-object v15

    .line 160
    const/high16 v19, 0x41e00000  # 28.0f

    .line 162
    const/16 v20, 0x5

    .line 164
    const/16 v16, 0x0

    .line 166
    const/high16 v17, 0x41a00000  # 20.0f

    .line 168
    const/16 v18, 0x0

    .line 170
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 173
    move-result-object v15

    .line 174
    sget-object v9, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 176
    sget-object v14, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 178
    invoke-static {v9, v14, v3, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 181
    move-result-object v1

    .line 182
    iget-wide v7, v3, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 184
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 187
    move-result v7

    .line 188
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 191
    move-result-object v8

    .line 192
    invoke-static {v3, v15}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 195
    move-result-object v15

    .line 196
    sget-object v18, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 198
    invoke-virtual/range {v18 .. v18}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 201
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 203
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 206
    move-object/from16 v35, v0

    .line 208
    iget-boolean v0, v3, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 210
    if-eqz v0, :cond_d7

    .line 212
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 215
    goto :goto_da

    .line 216
    :cond_d7
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 219
    :goto_da
    sget-object v0, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 221
    invoke-static {v3, v1, v0}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 224
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 226
    invoke-static {v3, v8, v1}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 229
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 231
    move/from16 v36, v5

    .line 233
    iget-boolean v5, v3, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 235
    if-nez v5, :cond_fd

    .line 237
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 240
    move-result-object v5

    .line 241
    move-object/from16 v37, v6

    .line 243
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 246
    move-result-object v6

    .line 247
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 250
    move-result v5

    .line 251
    if-nez v5, :cond_102

    .line 253
    goto :goto_ff

    .line 254
    :cond_fd
    move-object/from16 v37, v6

    .line 256
    :goto_ff
    invoke-static {v7, v3, v7, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 259
    :cond_102
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 261
    invoke-static {v3, v15, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 264
    const/high16 v6, 0x41d00000  # 26.0f

    .line 266
    const/4 v7, 0x0

    .line 267
    const/4 v15, 0x2

    .line 268
    invoke-static {v13, v6, v7, v15}, Landroidx/compose/foundation/layout/OffsetKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 271
    move-result-object v6

    .line 272
    const/4 v7, 0x0

    .line 273
    invoke-static {v9, v14, v3, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 276
    move-result-object v9

    .line 277
    move v7, v10

    .line 278
    move-wide/from16 v18, v11

    .line 280
    iget-wide v10, v3, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 282
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 285
    move-result v10

    .line 286
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 289
    move-result-object v11

    .line 290
    invoke-static {v3, v6}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 293
    move-result-object v6

    .line 294
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 297
    iget-boolean v12, v3, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 299
    if-eqz v12, :cond_130

    .line 301
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 304
    goto :goto_133

    .line 305
    :cond_130
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 308
    :goto_133
    invoke-static {v3, v9, v0}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 311
    invoke-static {v3, v11, v1}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 314
    iget-boolean v0, v3, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 316
    if-nez v0, :cond_14b

    .line 318
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 321
    move-result-object v0

    .line 322
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 325
    move-result-object v1

    .line 326
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 329
    move-result v0

    .line 330
    if-nez v0, :cond_14e

    .line 332
    :cond_14b
    invoke-static {v10, v3, v10, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 335
    :cond_14e
    invoke-static {v3, v6, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 338
    new-instance v1, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 340
    invoke-direct {v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 343
    iget-object v0, v4, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 345
    iget-object v0, v0, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->label:Ljava/lang/String;

    .line 347
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 350
    move-result v2

    .line 351
    const/4 v5, 0x4

    .line 352
    if-ne v2, v5, :cond_178

    .line 354
    const/4 v2, 0x0

    .line 355
    :goto_162
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 358
    move-result v5

    .line 359
    if-ge v2, v5, :cond_175

    .line 361
    invoke-virtual {v0, v2}, Ljava/lang/String;->charAt(I)C

    .line 364
    move-result v5

    .line 365
    invoke-static {v5}, Ljava/lang/Character;->isDigit(C)Z

    .line 368
    move-result v5

    .line 369
    if-eqz v5, :cond_178

    .line 371
    add-int/lit8 v2, v2, 0x1

    .line 373
    goto :goto_162

    .line 374
    :cond_175
    const-string v0, "This is your year as "

    .line 376
    goto :goto_190

    .line 377
    :cond_178
    const-string v2, "Last 12 months"

    .line 379
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 382
    move-result v2

    .line 383
    if-eqz v2, :cond_183

    .line 385
    const-string v0, "This is your twelve months as "

    .line 387
    goto :goto_190

    .line 388
    :cond_183
    const-string v2, "All time"

    .line 390
    invoke-virtual {v0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 393
    move-result v0

    .line 394
    if-eqz v0, :cond_18e

    .line 396
    const-string v0, "This is all your listening as "

    .line 398
    goto :goto_190

    .line 399
    :cond_18e
    const-string v0, "This is your listening as "

    .line 401
    :goto_190
    invoke-virtual {v1, v0}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 404
    new-instance v10, Landroidx/compose/ui/text/SpanStyle;

    .line 406
    const/16 v28, 0x0

    .line 408
    const v29, 0xfffe

    .line 411
    move-object v0, v13

    .line 412
    const-wide/16 v13, 0x0

    .line 414
    move/from16 v34, v15

    .line 416
    const/4 v15, 0x0

    .line 417
    const/high16 v2, 0x3f800000  # 1.0f

    .line 419
    const/16 v16, 0x0

    .line 421
    const/16 v17, 0x0

    .line 423
    move-wide/from16 v11, v18

    .line 425
    const/16 v18, 0x0

    .line 427
    const/16 v19, 0x0

    .line 429
    const-wide/16 v20, 0x0

    .line 431
    const/16 v22, 0x0

    .line 433
    const/16 v23, 0x0

    .line 435
    const/16 v24, 0x0

    .line 437
    const-wide/16 v25, 0x0

    .line 439
    const/16 v27, 0x0

    .line 441
    invoke-direct/range {v10 .. v29}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 444
    move-wide v5, v11

    .line 445
    invoke-virtual {v1, v10}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 448
    move-result v8

    .line 449
    :try_start_1c0
    const-string v9, "a sun."

    .line 451
    invoke-virtual {v1, v9}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_1c5
    .catchall {:try_start_1c0 .. :try_end_1c5} :catchall_27b

    .line 454
    invoke-virtual {v1, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 457
    invoke-virtual {v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 460
    move-result-object v9

    .line 461
    or-int/lit8 v1, v7, 0x36

    .line 463
    move/from16 v8, p1

    .line 465
    const/4 v7, 0x0

    .line 466
    invoke-static {v0, v7, v8, v3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 469
    move-result-object v10

    .line 470
    const/high16 v29, 0x6000000

    .line 472
    const/4 v7, 0x1

    .line 473
    const v30, 0x3fffc

    .line 476
    const-wide/16 v11, 0x0

    .line 478
    const-wide/16 v13, 0x0

    .line 480
    const/4 v15, 0x0

    .line 481
    const-wide/16 v16, 0x0

    .line 483
    const-wide/16 v18, 0x0

    .line 485
    const/16 v20, 0x0

    .line 487
    const/16 v21, 0x0

    .line 489
    const/16 v22, 0x0

    .line 491
    const/16 v23, 0x0

    .line 493
    const/16 v24, 0x0

    .line 495
    const/16 v25, 0x0

    .line 497
    sget-object v26, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 499
    const/16 v28, 0x0

    .line 501
    move-object/from16 v27, v3

    .line 503
    move v3, v7

    .line 504
    invoke-static/range {v9 .. v30}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 507
    move-object/from16 v7, v27

    .line 509
    const/16 v17, 0x0

    .line 511
    const/16 v18, 0xd

    .line 513
    const/4 v14, 0x0

    .line 514
    const/high16 v15, 0x41600000  # 14.0f

    .line 516
    const/16 v16, 0x0

    .line 518
    move-object v13, v0

    .line 519
    invoke-static/range {v13 .. v18}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 522
    move-result-object v0

    .line 523
    invoke-static {v0, v3, v8, v7, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 526
    move-result-object v10

    .line 527
    invoke-static {v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 530
    move-result-wide v11

    .line 531
    const/high16 v31, 0xc00000

    .line 533
    const v32, 0x1fff8

    .line 536
    const-string v9, "Each ray is one hour of your day. Longer means you listened more. Nobody else has this one."

    .line 538
    const-wide/16 v13, 0x0

    .line 540
    const/4 v15, 0x0

    .line 541
    const/16 v16, 0x0

    .line 543
    const/16 v17, 0x0

    .line 545
    const-wide/16 v18, 0x0

    .line 547
    const/16 v20, 0x0

    .line 549
    const-wide/16 v21, 0x0

    .line 551
    const/16 v24, 0x0

    .line 553
    const/16 v25, 0x0

    .line 555
    const/16 v26, 0x0

    .line 557
    const/16 v27, 0x0

    .line 559
    sget-object v28, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 561
    const/16 v30, 0x6

    .line 563
    move-object/from16 v29, v7

    .line 565
    invoke-static/range {v9 .. v32}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 568
    move-object/from16 v9, v29

    .line 570
    invoke-virtual {v9, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 573
    new-instance v0, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 575
    invoke-direct {v0, v2, v3}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 578
    invoke-static {v0, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 581
    move-result-object v10

    .line 582
    const/4 v14, 0x0

    .line 583
    const/16 v15, 0xd

    .line 585
    const/4 v11, 0x0

    .line 586
    const/high16 v12, 0x41400000  # 12.0f

    .line 588
    const/4 v13, 0x0

    .line 589
    invoke-static/range {v10 .. v15}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 592
    move-result-object v10

    .line 593
    sget-object v11, Landroidx/compose/ui/Alignment$Companion;->Center:Landroidx/compose/ui/BiasAlignment;

    .line 595
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;

    .line 597
    move/from16 v12, p3

    .line 599
    move v13, v3

    .line 600
    move-wide v2, v5

    .line 601
    move-object/from16 v7, v33

    .line 603
    move/from16 v15, v34

    .line 605
    move-object/from16 v1, v35

    .line 607
    move/from16 v5, v36

    .line 609
    move-object/from16 v6, v37

    .line 611
    invoke-direct/range {v0 .. v7}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda15;-><init>(Landroidx/compose/animation/core/Animatable;JLcom/spotifry/music/data/spotifried/SpotifriedStats;FLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/text/TextStyle;)V

    .line 614
    move-object v6, v4

    .line 615
    const v1, -0x36adf099

    .line 618
    invoke-static {v1, v0, v9}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 621
    move-result-object v2

    .line 622
    const/16 v4, 0xc30

    .line 624
    const/4 v5, 0x4

    .line 625
    move-object v3, v9

    .line 626
    move-object v0, v10

    .line 627
    move-object v1, v11

    .line 628
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 631
    invoke-virtual {v3, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 634
    move v0, v8

    .line 635
    goto :goto_288

    .line 636
    :catchall_27b
    move-exception v0

    .line 637
    invoke-virtual {v1, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 640
    throw v0

    .line 641
    :cond_280
    move/from16 v12, p3

    .line 643
    move v15, v2

    .line 644
    move-object v6, v4

    .line 645
    move v0, v8

    .line 646
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 649
    :goto_288
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 652
    move-result-object v1

    .line 653
    if-eqz v1, :cond_295

    .line 655
    new-instance v2, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 657
    invoke-direct {v2, v6, v0, v12, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 660
    iput-object v2, v1, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 662
    :cond_295
    return-void
.end method

.method public static final TopSong(Lcom/spotifry/music/data/TopSong;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 25

    .line 1
    move-object/from16 v2, p0

    .line 3
    move/from16 v1, p1

    .line 5
    move-object/from16 v8, p2

    .line 7
    move/from16 v11, p3

    .line 9
    const v0, -0x17e552c2

    .line 12
    invoke-virtual {v8, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 15
    invoke-virtual {v8, v2}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 18
    move-result v0

    .line 19
    const/4 v3, 0x4

    .line 20
    const/4 v4, 0x2

    .line 21
    if-eqz v0, :cond_18

    .line 23
    move v0, v3

    .line 24
    goto :goto_19

    .line 25
    :cond_18
    move v0, v4

    .line 26
    :goto_19
    or-int/2addr v0, v11

    .line 27
    invoke-virtual {v8, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 30
    move-result v5

    .line 31
    if-eqz v5, :cond_23

    .line 33
    const/16 v5, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v5, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v5

    .line 39
    and-int/lit8 v5, v0, 0x13

    .line 41
    const/16 v6, 0x12

    .line 43
    const/4 v12, 0x1

    .line 44
    const/4 v13, 0x0

    .line 45
    if-eq v5, v6, :cond_30

    .line 47
    move v5, v12

    .line 48
    goto :goto_31

    .line 49
    :cond_30
    move v5, v13

    .line 50
    :goto_31
    and-int/lit8 v6, v0, 0x1

    .line 52
    invoke-virtual {v8, v6, v5}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_169

    .line 58
    sget-object v5, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 60
    invoke-virtual {v8, v5}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 63
    move-result-object v5

    .line 64
    check-cast v5, Landroidx/compose/material3/ColorScheme;

    .line 66
    iget-wide v5, v5, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 68
    iget v7, v2, Lcom/spotifry/music/data/TopSong;->plays:I

    .line 70
    and-int/lit8 v0, v0, 0x70

    .line 72
    or-int/lit16 v0, v0, 0x180

    .line 74
    const/16 v9, 0x2bc

    .line 76
    invoke-static {v7, v9, v0, v8, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countUp(IIILandroidx/compose/runtime/ComposerImpl;Z)Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 79
    move-result-object v0

    .line 80
    if-eqz v1, :cond_5f

    .line 82
    const v3, 0x386a275f

    .line 85
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 88
    invoke-virtual {v8, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 91
    move-wide v14, v5

    .line 92
    const/4 v3, 0x0

    .line 93
    const/16 v16, 0x0

    .line 95
    goto :goto_92

    .line 96
    :cond_5f
    const v7, 0x4c247b06  # 4.311759E7f

    .line 99
    invoke-virtual {v8, v7}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 102
    const-string v7, "rings"

    .line 104
    invoke-static {v7, v8, v13}, Landroidx/compose/animation/core/ArcSplineKt;->rememberInfiniteTransition(Ljava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/InfiniteTransition;

    .line 107
    move-result-object v7

    .line 108
    const/16 v9, 0xc80

    .line 110
    sget-object v10, Landroidx/compose/animation/core/EasingKt;->LinearEasing:Landroidx/collection/ArrayMap$$ExternalSyntheticBUOutline0;

    .line 112
    invoke-static {v9, v13, v10, v4}, Landroidx/compose/animation/core/ArcSplineKt;->tween$default(IILandroidx/compose/animation/core/Easing;I)Landroidx/compose/animation/core/TweenSpec;

    .line 115
    move-result-object v4

    .line 116
    sget-object v9, Landroidx/compose/animation/core/RepeatMode;->Restart:Landroidx/compose/animation/core/RepeatMode;

    .line 118
    const/16 v16, 0x0

    .line 120
    const-wide/16 v14, 0x0

    .line 122
    invoke-static {v4, v9, v14, v15, v3}, Landroidx/compose/animation/core/ArcSplineKt;->infiniteRepeatable-9IiC70o$default(Landroidx/compose/animation/core/DurationBasedAnimationSpec;Landroidx/compose/animation/core/RepeatMode;JI)Landroidx/compose/animation/core/InfiniteRepeatableSpec;

    .line 125
    move-result-object v3

    .line 126
    const/16 v9, 0x71b8

    .line 128
    const/4 v10, 0x0

    .line 129
    const/4 v4, 0x0

    .line 130
    move-wide/from16 v19, v5

    .line 132
    const/high16 v5, 0x3f800000  # 1.0f

    .line 134
    move-object v6, v3

    .line 135
    move-object v3, v7

    .line 136
    const-string v7, "ring"

    .line 138
    move-wide/from16 v14, v19

    .line 140
    invoke-static/range {v3 .. v10}, Landroidx/compose/animation/core/ArcSplineKt;->animateFloat(Landroidx/compose/animation/core/InfiniteTransition;FFLandroidx/compose/animation/core/InfiniteRepeatableSpec;Ljava/lang/String;Landroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/animation/core/InfiniteTransition$TransitionAnimationState;

    .line 143
    move-result-object v3

    .line 144
    invoke-virtual {v8, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 147
    :goto_92
    const/high16 v4, 0x41900000  # 18.0f

    .line 149
    invoke-static {v4}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    .line 152
    move-result-object v6

    .line 153
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 156
    move-result-object v4

    .line 157
    sget-object v5, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 159
    if-ne v4, v5, :cond_a7

    .line 161
    invoke-static/range {v16 .. v16}, Landroidx/compose/runtime/AnchoredGroupPath;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 164
    move-result-object v4

    .line 165
    invoke-virtual {v8, v4}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 168
    :cond_a7
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .line 170
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 173
    move-result-object v7

    .line 174
    if-ne v7, v5, :cond_b6

    .line 176
    invoke-static/range {v16 .. v16}, Landroidx/compose/runtime/AnchoredGroupPath;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 179
    move-result-object v7

    .line 180
    invoke-virtual {v8, v7}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 183
    :cond_b6
    move-object/from16 v18, v7

    .line 185
    check-cast v18, Landroidx/compose/runtime/MutableState;

    .line 187
    sget-object v7, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 189
    const/high16 v9, 0x3f800000  # 1.0f

    .line 191
    invoke-static {v7, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 194
    move-result-object v7

    .line 195
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 198
    move-result-object v9

    .line 199
    if-ne v9, v5, :cond_d2

    .line 201
    new-instance v9, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda30;

    .line 203
    const/16 v10, 0x1b

    .line 205
    invoke-direct {v9, v4, v10}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda30;-><init>(Landroidx/compose/runtime/MutableState;B)V

    .line 208
    invoke-virtual {v8, v9}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 211
    :cond_d2
    check-cast v9, Lkotlin/jvm/functions/Function1;

    .line 213
    invoke-static {v7, v9}, Landroidx/compose/ui/layout/RulerKt;->onPlaced(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 216
    move-result-object v7

    .line 217
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 220
    move-result v9

    .line 221
    invoke-virtual {v8, v14, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 224
    move-result v10

    .line 225
    or-int/2addr v9, v10

    .line 226
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 229
    move-result-object v10

    .line 230
    if-nez v9, :cond_ec

    .line 232
    if-eq v10, v5, :cond_ec

    .line 234
    move-wide/from16 v19, v14

    .line 236
    goto :goto_fb

    .line 237
    :cond_ec
    move-wide/from16 v19, v14

    .line 239
    new-instance v15, Landroidx/compose/ui/text/MultiParagraph$$ExternalSyntheticLambda0;

    .line 241
    move-object/from16 v16, v3

    .line 243
    move-object/from16 v17, v4

    .line 245
    invoke-direct/range {v15 .. v20}, Landroidx/compose/ui/text/MultiParagraph$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/animation/core/InfiniteTransition$TransitionAnimationState;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;J)V

    .line 248
    invoke-virtual {v8, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 251
    move-object v10, v15

    .line 252
    :goto_fb
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 254
    invoke-static {v7, v10}, Landroidx/compose/ui/draw/ClipKt;->drawBehind(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 257
    move-result-object v3

    .line 258
    sget-object v4, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 260
    invoke-static {v4, v13}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 263
    move-result-object v4

    .line 264
    iget-wide v9, v8, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 266
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 269
    move-result v5

    .line 270
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 273
    move-result-object v7

    .line 274
    invoke-static {v8, v3}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 277
    move-result-object v3

    .line 278
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 280
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 283
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 285
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 288
    iget-boolean v10, v8, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 290
    if-eqz v10, :cond_127

    .line 292
    invoke-virtual {v8, v9}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 295
    goto :goto_12a

    .line 296
    :cond_127
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 299
    :goto_12a
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 301
    invoke-static {v8, v4, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 304
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 306
    invoke-static {v8, v7, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 309
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 311
    iget-boolean v7, v8, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 313
    if-nez v7, :cond_148

    .line 315
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 318
    move-result-object v7

    .line 319
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 322
    move-result-object v9

    .line 323
    invoke-static {v7, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 326
    move-result v7

    .line 327
    if-nez v7, :cond_14b

    .line 329
    :cond_148
    invoke-static {v5, v8, v5, v4}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 332
    :cond_14b
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 334
    invoke-static {v8, v3, v4}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 337
    move-object v7, v0

    .line 338
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;

    .line 340
    move-object/from16 v3, v18

    .line 342
    move-wide/from16 v4, v19

    .line 344
    invoke-direct/range {v0 .. v7}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;-><init>(ZLcom/spotifry/music/data/TopSong;Landroidx/compose/runtime/MutableState;JLandroidx/compose/foundation/shape/RoundedCornerShape;Lcom/spotifry/music/ui/spotifried/CountUp;)V

    .line 347
    const v3, 0x473b8ca7

    .line 350
    invoke-static {v3, v0, v8}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 353
    move-result-object v0

    .line 354
    const/4 v3, 0x6

    .line 355
    invoke-static {v0, v8, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 358
    invoke-virtual {v8, v12}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 361
    goto :goto_16d

    .line 362
    :cond_169
    const/4 v3, 0x6

    .line 363
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 366
    :goto_16d
    invoke-virtual {v8}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 369
    move-result-object v0

    .line 370
    if-eqz v0, :cond_17a

    .line 372
    new-instance v4, Landroidx/compose/material3/SliderDefaults$$ExternalSyntheticLambda4;

    .line 374
    invoke-direct {v4, v2, v1, v11, v3}, Landroidx/compose/material3/SliderDefaults$$ExternalSyntheticLambda4;-><init>(Ljava/lang/Object;ZIB)V

    .line 377
    iput-object v4, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 379
    :cond_17a
    return-void
.end method

.method public static final TopSongCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V
    .registers 10

    .line 1
    const v0, 0x171840ce

    .line 4
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p3, 0x6

    .line 9
    const/4 v1, 0x4

    .line 10
    if-nez v0, :cond_16

    .line 12
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 15
    move-result v0

    .line 16
    if-eqz v0, :cond_13

    .line 18
    move v0, v1

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 v0, 0x2

    .line 21
    :goto_14
    or-int/2addr v0, p3

    .line 22
    goto :goto_17

    .line 23
    :cond_16
    move v0, p3

    .line 24
    :goto_17
    and-int/lit8 v2, p3, 0x30

    .line 26
    if-nez v2, :cond_27

    .line 28
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 31
    move-result v2

    .line 32
    if-eqz v2, :cond_24

    .line 34
    const/16 v2, 0x20

    .line 36
    goto :goto_26

    .line 37
    :cond_24
    const/16 v2, 0x10

    .line 39
    :goto_26
    or-int/2addr v0, v2

    .line 40
    :cond_27
    and-int/lit8 v2, v0, 0x13

    .line 42
    const/16 v3, 0x12

    .line 44
    const/4 v4, 0x1

    .line 45
    const/4 v5, 0x0

    .line 46
    if-eq v2, v3, :cond_31

    .line 48
    move v2, v4

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v2, v5

    .line 51
    :goto_32
    and-int/2addr v0, v4

    .line 52
    invoke-virtual {p2, v0, v2}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v0

    .line 56
    if-eqz v0, :cond_79

    .line 58
    iget-object v0, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->topSong:Lcom/spotifry/music/data/TopSong;

    .line 60
    if-nez v0, :cond_4b

    .line 62
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 65
    move-result-object p2

    .line 66
    if-eqz p2, :cond_88

    .line 68
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 70
    invoke-direct {v0, p0, p1, p3, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 73
    :goto_48
    iput-object v0, p2, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 75
    return-void

    .line 76
    :cond_4b
    if-eqz p1, :cond_57

    .line 78
    const v2, -0x70a096a4

    .line 81
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 84
    :goto_53
    invoke-virtual {p2, v5}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 87
    goto :goto_62

    .line 88
    :cond_57
    const v2, -0x4df4a900

    .line 91
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 94
    invoke-static {p2}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 97
    move-result v4

    .line 98
    goto :goto_53

    .line 99
    :goto_62
    iget-object v2, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 101
    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 104
    move-result-object v3

    .line 105
    invoke-virtual {p2, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 108
    move-result-object v2

    .line 109
    const v3, -0x4df4a608

    .line 112
    invoke-virtual {p2, v3, v2}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 115
    invoke-static {v0, v4, p2, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->TopSong(Lcom/spotifry/music/data/TopSong;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 118
    invoke-virtual {p2, v5}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 121
    goto :goto_7c

    .line 122
    :cond_79
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 125
    :goto_7c
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 128
    move-result-object p2

    .line 129
    if-eqz p2, :cond_88

    .line 131
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;

    .line 133
    invoke-direct {v0, p0, p1, p3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZIB)V

    .line 136
    goto :goto_48

    .line 137
    :cond_88
    return-void
.end method

.method public static final Type(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 41

    .line 1
    move-object/from16 v1, p0

    .line 3
    move/from16 v3, p2

    .line 5
    move-object/from16 v0, p5

    .line 7
    move-object/from16 v2, p6

    .line 9
    move/from16 v4, p7

    .line 11
    const v5, -0x23e16b89

    .line 14
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 17
    and-int/lit8 v5, v4, 0x6

    .line 19
    if-nez v5, :cond_1f

    .line 21
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 24
    move-result v5

    .line 25
    if-eqz v5, :cond_1c

    .line 27
    const/4 v5, 0x4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v5, 0x2

    .line 30
    :goto_1d
    or-int/2addr v5, v4

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v5, v4

    .line 33
    :goto_20
    and-int/lit8 v6, v4, 0x30

    .line 35
    if-nez v6, :cond_32

    .line 37
    move-object/from16 v9, p1

    .line 39
    invoke-virtual {v2, v9}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 42
    move-result v6

    .line 43
    if-eqz v6, :cond_2f

    .line 45
    const/16 v6, 0x20

    .line 47
    goto :goto_31

    .line 48
    :cond_2f
    const/16 v6, 0x10

    .line 50
    :goto_31
    or-int/2addr v5, v6

    .line 51
    :cond_32
    and-int/lit16 v6, v4, 0x180

    .line 53
    if-nez v6, :cond_42

    .line 55
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 58
    move-result v6

    .line 59
    if-eqz v6, :cond_3f

    .line 61
    const/16 v6, 0x100

    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    const/16 v6, 0x80

    .line 66
    :goto_41
    or-int/2addr v5, v6

    .line 67
    :cond_42
    and-int/lit16 v6, v4, 0xc00

    .line 69
    if-nez v6, :cond_54

    .line 71
    move/from16 v11, p3

    .line 73
    invoke-virtual {v2, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 76
    move-result v6

    .line 77
    if-eqz v6, :cond_51

    .line 79
    const/16 v6, 0x800

    .line 81
    goto :goto_53

    .line 82
    :cond_51
    const/16 v6, 0x400

    .line 84
    :goto_53
    or-int/2addr v5, v6

    .line 85
    :cond_54
    and-int/lit16 v6, v4, 0x6000

    .line 87
    if-nez v6, :cond_66

    .line 89
    move/from16 v12, p4

    .line 91
    invoke-virtual {v2, v12}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 94
    move-result v6

    .line 95
    if-eqz v6, :cond_63

    .line 97
    const/16 v6, 0x4000

    .line 99
    goto :goto_65

    .line 100
    :cond_63
    const/16 v6, 0x2000

    .line 102
    :goto_65
    or-int/2addr v5, v6

    .line 103
    :cond_66
    const/high16 v6, 0x30000

    .line 105
    and-int/2addr v6, v4

    .line 106
    if-nez v6, :cond_77

    .line 108
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 111
    move-result v6

    .line 112
    if-eqz v6, :cond_74

    .line 114
    const/high16 v6, 0x20000

    .line 116
    goto :goto_76

    .line 117
    :cond_74
    const/high16 v6, 0x10000

    .line 119
    :goto_76
    or-int/2addr v5, v6

    .line 120
    :cond_77
    const v6, 0x12493

    .line 123
    and-int/2addr v6, v5

    .line 124
    const v7, 0x12492

    .line 127
    if-eq v6, v7, :cond_82

    .line 129
    const/4 v6, 0x1

    .line 130
    goto :goto_83

    .line 131
    :cond_82
    const/4 v6, 0x0

    .line 132
    :goto_83
    and-int/lit8 v7, v5, 0x1

    .line 134
    invoke-virtual {v2, v7, v6}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 137
    move-result v6

    .line 138
    if-eqz v6, :cond_3df

    .line 140
    sget-object v6, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 142
    invoke-virtual {v2, v6}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 145
    move-result-object v7

    .line 146
    check-cast v7, Landroidx/compose/material3/ColorScheme;

    .line 148
    iget-wide v13, v7, Landroidx/compose/material3/ColorScheme;->primary:J

    .line 150
    invoke-virtual {v2, v6}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 153
    move-result-object v6

    .line 154
    check-cast v6, Landroidx/compose/material3/ColorScheme;

    .line 156
    iget-wide v6, v6, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 158
    iget-wide v8, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->seconds:J

    .line 160
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->listenerType(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)Lcom/spotifry/music/data/spotifried/ListenerType;

    .line 163
    move-result-object v15

    .line 164
    sget-object v10, Lcom/spotifry/music/data/spotifried/ListenerType;->REGULAR:Lcom/spotifry/music/data/spotifried/ListenerType;

    .line 166
    if-ne v15, v10, :cond_b8

    .line 168
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->peakHour(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)I

    .line 171
    move-result v10

    .line 172
    invoke-static {v10}, Lcom/spotifry/music/data/Log;->hourKind(I)Ljava/lang/String;

    .line 175
    move-result-object v10

    .line 176
    const-string v15, "The "

    .line 178
    const-string v4, " Regular"

    .line 180
    invoke-static {v15, v10, v4}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 183
    move-result-object v4

    .line 184
    goto :goto_ba

    .line 185
    :cond_b8
    iget-object v4, v15, Lcom/spotifry/music/data/spotifried/ListenerType;->title:Ljava/lang/String;

    .line 187
    :goto_ba
    const-string v10, "."

    .line 189
    invoke-virtual {v4, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 192
    move-result-object v4

    .line 193
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 196
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    .line 199
    move-result v15

    .line 200
    if-nez v15, :cond_ce

    .line 202
    const-string v15, "You are"

    .line 204
    :goto_cb
    move-object/from16 v18, v15

    .line 206
    goto :goto_d5

    .line 207
    :cond_ce
    const-string v15, ", you are"

    .line 209
    invoke-virtual {v0, v15}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 212
    move-result-object v15

    .line 213
    goto :goto_cb

    .line 214
    :goto_d5
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 217
    move-result v15

    .line 218
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 221
    move-result-object v0

    .line 222
    move-object/from16 v19, v4

    .line 224
    sget-object v4, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 226
    move/from16 v20, v5

    .line 228
    if-nez v15, :cond_f1

    .line 230
    if-eq v0, v4, :cond_f1

    .line 232
    move-object/from16 v30, v4

    .line 234
    move-wide/from16 v23, v6

    .line 236
    move-wide/from16 v26, v8

    .line 238
    move-wide/from16 v28, v13

    .line 240
    goto/16 :goto_319

    .line 242
    :cond_f1
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->listenerType(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)Lcom/spotifry/music/data/spotifried/ListenerType;

    .line 245
    move-result-object v0

    .line 246
    iget v15, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->plays:I

    .line 248
    iget v5, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->newSongs:I

    .line 250
    move-object/from16 v22, v0

    .line 252
    iget-object v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->age:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 254
    move-wide/from16 v23, v6

    .line 256
    iget v6, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->replayedSongs:I

    .line 258
    iget v7, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->songs:I

    .line 260
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->peakHour(Lcom/spotifry/music/data/spotifried/SpotifriedStats;)I

    .line 263
    move-result v25

    .line 264
    move-wide/from16 v26, v8

    .line 266
    invoke-static/range {v25 .. v25}, Lcom/spotifry/music/data/Log;->hourName(I)Ljava/lang/String;

    .line 269
    move-result-object v8

    .line 270
    const-string v9, "Your busiest hour was "

    .line 272
    invoke-virtual {v9, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 275
    move-result-object v8

    .line 276
    invoke-virtual {v8, v10}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    .line 279
    move-result v9

    .line 280
    if-nez v9, :cond_11d

    .line 282
    invoke-virtual {v8, v10}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 285
    move-result-object v8

    .line 286
    :cond_11d
    sget-object v9, Ljava/util/Locale;->US:Ljava/util/Locale;

    .line 288
    iget-object v11, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->daySeconds:Ljava/util/List;

    .line 290
    invoke-static {v11}, Lkotlin/collections/CollectionsKt;->maxOrNull(Ljava/lang/Iterable;)Ljava/lang/Comparable;

    .line 293
    move-result-object v11

    .line 294
    check-cast v11, Ljava/lang/Long;

    .line 296
    if-eqz v11, :cond_130

    .line 298
    invoke-virtual {v11}, Ljava/lang/Long;->longValue()J

    .line 301
    move-result-wide v28

    .line 302
    :goto_12d
    move-wide/from16 v11, v28

    .line 304
    goto :goto_133

    .line 305
    :cond_130
    const-wide/16 v28, 0x0

    .line 307
    goto :goto_12d

    .line 308
    :goto_133
    long-to-double v11, v11

    .line 309
    const-wide v28, 0x40ac200000000000L  # 3600.0

    .line 314
    div-double v11, v11, v28

    .line 316
    invoke-static {v11, v12}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    .line 319
    move-result-object v11

    .line 320
    filled-new-array {v11}, [Ljava/lang/Object;

    .line 323
    move-result-object v11

    .line 324
    const/4 v12, 0x1

    .line 325
    invoke-static {v11, v12}, Ljava/util/Arrays;->copyOf([Ljava/lang/Object;I)[Ljava/lang/Object;

    .line 328
    move-result-object v11

    .line 329
    const-string v12, "%.1f"

    .line 331
    invoke-static {v9, v12, v11}, Ljava/lang/String;->format(Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 334
    move-result-object v9

    .line 335
    const-string v11, "song"

    .line 337
    invoke-static {v15, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 340
    move-result-object v12

    .line 341
    move-wide/from16 v28, v13

    .line 343
    const-string v13, "You played "

    .line 345
    const-string v14, " in total."

    .line 347
    invoke-static {v13, v12, v14}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 350
    move-result-object v12

    .line 351
    invoke-virtual/range {v22 .. v22}, Ljava/lang/Enum;->ordinal()I

    .line 354
    move-result v22

    .line 355
    const/high16 v25, 0x42c80000  # 100.0f

    .line 357
    move-object/from16 v30, v4

    .line 359
    const-string v4, " of "

    .line 361
    const-string v3, "You replayed "

    .line 363
    const-string v2, " hours of music."

    .line 365
    move-object/from16 v31, v0

    .line 367
    const-string v0, "Your longest day was "

    .line 369
    move/from16 v32, v6

    .line 371
    const-string v6, "different song"

    .line 373
    packed-switch v22, :pswitch_data_400

    .line 376
    invoke-static {}, Landroidx/media3/session/MediaSessionStub$$ExternalSyntheticLambda8;->m()V

    .line 379
    return-void

    .line 380
    :pswitch_17b  #0x7
    invoke-static {v15, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 383
    move-result-object v0

    .line 384
    invoke-static {v13, v0, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 387
    move-result-object v0

    .line 388
    invoke-static {v7, v6}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 391
    move-result-object v2

    .line 392
    if-nez v32, :cond_18c

    .line 394
    const-string v3, "none came back."

    .line 396
    goto :goto_196

    .line 397
    :cond_18c
    invoke-static/range {v32 .. v32}, Lkotlin/io/ByteStreamsKt;->num(I)Ljava/lang/String;

    .line 400
    move-result-object v3

    .line 401
    const-string v4, " came back."

    .line 403
    invoke-virtual {v3, v4}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 406
    move-result-object v3

    .line 407
    :goto_196
    const-string v4, "That was "

    .line 409
    const-string v5, ", and "

    .line 411
    invoke-static {v4, v2, v5, v3}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 414
    move-result-object v2

    .line 415
    filled-new-array {v8, v0, v2}, [Ljava/lang/String;

    .line 418
    move-result-object v0

    .line 419
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 422
    move-result-object v0

    .line 423
    :goto_1a6
    move-object/from16 v2, p6

    .line 425
    goto/16 :goto_316

    .line 427
    :pswitch_1aa  #0x6
    iget v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->earlyShare:F

    .line 429
    mul-float v0, v0, v25

    .line 431
    invoke-static {v0}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 434
    move-result v0

    .line 435
    const-string v2, "% of your plays started before 9 a.m."

    .line 437
    invoke-static {v0, v2}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 440
    move-result-object v0

    .line 441
    filled-new-array {v0, v8, v12}, [Ljava/lang/String;

    .line 444
    move-result-object v0

    .line 445
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 448
    move-result-object v0

    .line 449
    goto :goto_1a6

    .line 450
    :pswitch_1c1  #0x5
    invoke-static {v0, v9, v2}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 453
    move-result-object v0

    .line 454
    const-wide/16 v2, 0xe10

    .line 456
    div-long v8, v26, v2

    .line 458
    long-to-int v2, v8

    .line 459
    const-string v3, "hour"

    .line 461
    invoke-static {v2, v3}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 464
    move-result-object v2

    .line 465
    const-string v3, "In all you listened for "

    .line 467
    invoke-static {v3, v2, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 470
    move-result-object v2

    .line 471
    filled-new-array {v0, v2, v12}, [Ljava/lang/String;

    .line 474
    move-result-object v0

    .line 475
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 478
    move-result-object v0

    .line 479
    goto :goto_1a6

    .line 480
    :pswitch_1df  #0x4
    iget-object v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->topArtist:Lcom/spotifry/music/data/spotifried/ArtistShare;

    .line 482
    if-eqz v0, :cond_1e7

    .line 484
    iget-object v2, v0, Lcom/spotifry/music/data/spotifried/ArtistShare;->name:Ljava/lang/String;

    .line 486
    if-nez v2, :cond_1e9

    .line 488
    :cond_1e7
    const-string v2, "One artist"

    .line 490
    :cond_1e9
    if-eqz v0, :cond_1ee

    .line 492
    iget v0, v0, Lcom/spotifry/music/data/spotifried/ArtistShare;->share:F

    .line 494
    goto :goto_1ef

    .line 495
    :cond_1ee
    const/4 v0, 0x0

    .line 496
    :goto_1ef
    mul-float v0, v0, v25

    .line 498
    invoke-static {v0}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 501
    move-result v0

    .line 502
    new-instance v4, Ljava/lang/StringBuilder;

    .line 504
    invoke-direct {v4, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 507
    const-string v2, " took "

    .line 509
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 512
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 515
    const-string v0, "% of your listening."

    .line 517
    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 520
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 523
    move-result-object v0

    .line 524
    invoke-static {v7, v6}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 527
    move-result-object v2

    .line 528
    invoke-static {v13, v2, v14}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 531
    move-result-object v2

    .line 532
    if-nez v32, :cond_218

    .line 534
    const-string v3, "You never replayed any of them."

    .line 536
    goto :goto_222

    .line 537
    :cond_218
    invoke-static/range {v32 .. v32}, Lkotlin/io/ByteStreamsKt;->num(I)Ljava/lang/String;

    .line 540
    move-result-object v4

    .line 541
    const-string v5, " of them."

    .line 543
    invoke-static {v3, v4, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 546
    move-result-object v3

    .line 547
    :goto_222
    filled-new-array {v0, v2, v3}, [Ljava/lang/String;

    .line 550
    move-result-object v0

    .line 551
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 554
    move-result-object v0

    .line 555
    goto/16 :goto_1a6

    .line 557
    :pswitch_22c  #0x3
    invoke-static {v5}, Lkotlin/io/ByteStreamsKt;->num(I)Ljava/lang/String;

    .line 560
    move-result-object v0

    .line 561
    invoke-static {v7, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 564
    move-result-object v2

    .line 565
    const/4 v12, 0x1

    .line 566
    if-ne v5, v12, :cond_23a

    .line 568
    const-string v3, "was"

    .line 570
    goto :goto_23c

    .line 571
    :cond_23a
    const-string v3, "were"

    .line 573
    :goto_23c
    const-string v6, " "

    .line 575
    invoke-static {v0, v4, v2, v6, v3}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 578
    move-result-object v0

    .line 579
    const-string v2, " new to you."

    .line 581
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 584
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 587
    move-result-object v0

    .line 588
    if-nez v7, :cond_24f

    .line 590
    const/4 v15, 0x0

    .line 591
    goto :goto_258

    .line 592
    :cond_24f
    int-to-float v2, v5

    .line 593
    int-to-float v3, v7

    .line 594
    div-float/2addr v2, v3

    .line 595
    mul-float v2, v2, v25

    .line 597
    invoke-static {v2}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 600
    move-result v15

    .line 601
    :goto_258
    const-string v2, "That is "

    .line 603
    const-string v3, "% fresh music."

    .line 605
    invoke-static {v15, v2, v3}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 608
    move-result-object v2

    .line 609
    if-nez v32, :cond_265

    .line 611
    const-string v3, "None of your songs got a replay."

    .line 613
    goto :goto_273

    .line 614
    :cond_265
    move/from16 v4, v32

    .line 616
    invoke-static {v4, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 619
    move-result-object v3

    .line 620
    const-string v4, "Only "

    .line 622
    const-string v5, " got a replay."

    .line 624
    invoke-static {v4, v3, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 627
    move-result-object v3

    .line 628
    :goto_273
    filled-new-array {v0, v2, v3}, [Ljava/lang/String;

    .line 631
    move-result-object v0

    .line 632
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 635
    move-result-object v0

    .line 636
    goto/16 :goto_1a6

    .line 638
    :pswitch_27d  #0x2
    iget v3, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->longestStreak:I

    .line 640
    const-string v4, "day"

    .line 642
    invoke-static {v3, v4}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 645
    move-result-object v3

    .line 646
    const-string v4, "You listened "

    .line 648
    const-string v5, " in a row."

    .line 650
    invoke-static {v4, v3, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 653
    move-result-object v3

    .line 654
    invoke-static {v0, v9, v2}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 657
    move-result-object v0

    .line 658
    filled-new-array {v3, v12, v0}, [Ljava/lang/String;

    .line 661
    move-result-object v0

    .line 662
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 665
    move-result-object v0

    .line 666
    goto/16 :goto_1a6

    .line 668
    :pswitch_29b  #0x1
    move-object/from16 v0, v31

    .line 670
    iget-object v2, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->typicalYear:Ljava/lang/Integer;

    .line 672
    if-nez v2, :cond_2a3

    .line 674
    const-string v2, "an unknown year"

    .line 676
    :cond_2a3
    new-instance v3, Ljava/lang/StringBuilder;

    .line 678
    const-string v5, "A typical song of yours came out in "

    .line 680
    invoke-direct {v3, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 683
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 686
    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 689
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 692
    move-result-object v2

    .line 693
    iget v3, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->songsWithYear:I

    .line 695
    invoke-static {v3}, Lkotlin/io/ByteStreamsKt;->num(I)Ljava/lang/String;

    .line 698
    move-result-object v3

    .line 699
    iget v5, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->songsTotal:I

    .line 701
    invoke-static {v5, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 704
    move-result-object v5

    .line 705
    const-string v6, "Release years are known for "

    .line 707
    invoke-static {v6, v3, v4, v5, v10}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 710
    move-result-object v3

    .line 711
    iget-object v4, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->oldestYear:Ljava/lang/Integer;

    .line 713
    if-eqz v4, :cond_2d5

    .line 715
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 718
    move-result v0

    .line 719
    const-string v4, "Your oldest song is from "

    .line 721
    invoke-static {v0, v4, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 724
    move-result-object v0

    .line 725
    goto :goto_2e5

    .line 726
    :cond_2d5
    iget-object v0, v0, Lcom/spotifry/music/data/spotifried/AgeStats;->age:Ljava/lang/Integer;

    .line 728
    if-eqz v0, :cond_2de

    .line 730
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 733
    move-result v15

    .line 734
    goto :goto_2df

    .line 735
    :cond_2de
    const/4 v15, 0x0

    .line 736
    :goto_2df
    const-string v0, "Your listening age is "

    .line 738
    invoke-static {v15, v0, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILjava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 741
    move-result-object v0

    .line 742
    :goto_2e5
    filled-new-array {v2, v3, v0}, [Ljava/lang/String;

    .line 745
    move-result-object v0

    .line 746
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 749
    move-result-object v0

    .line 750
    goto/16 :goto_1a6

    .line 752
    :pswitch_2ef  #0x0
    move/from16 v4, v32

    .line 754
    iget v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->nightShare:F

    .line 756
    mul-float v0, v0, v25

    .line 758
    invoke-static {v0}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 761
    move-result v0

    .line 762
    const-string v2, "% of your plays started between midnight and 5 a.m."

    .line 764
    invoke-static {v0, v2}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 767
    move-result-object v0

    .line 768
    if-nez v4, :cond_304

    .line 770
    const-string v2, "You never replayed a song."

    .line 772
    goto :goto_30c

    .line 773
    :cond_304
    invoke-static {v4, v11}, Lkotlin/io/ByteStreamsKt;->count(ILjava/lang/String;)Ljava/lang/String;

    .line 776
    move-result-object v2

    .line 777
    invoke-static {v3, v2, v10}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 780
    move-result-object v2

    .line 781
    :goto_30c
    filled-new-array {v0, v2, v8}, [Ljava/lang/String;

    .line 784
    move-result-object v0

    .line 785
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 788
    move-result-object v0

    .line 789
    goto/16 :goto_1a6

    .line 791
    :goto_316
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 794
    :goto_319
    move-object/from16 v17, v0

    .line 796
    check-cast v17, Ljava/util/List;

    .line 798
    invoke-static/range {v26 .. v27}, Lcom/spotifry/music/data/Log;->minutesOf(J)I

    .line 801
    move-result v0

    .line 802
    invoke-static {v0}, Lcom/spotifry/music/data/Log;->sunScale(I)F

    .line 805
    move-result v0

    .line 806
    iget-object v3, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 808
    move/from16 v4, p2

    .line 810
    invoke-static {v3, v0, v4, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rememberSunMotion(Ljava/util/List;FZLandroidx/compose/runtime/ComposerImpl;)Lcom/spotifry/music/ui/listening/SunMotion;

    .line 813
    move-result-object v8

    .line 814
    shr-int/lit8 v5, v20, 0x6

    .line 816
    and-int/lit8 v5, v5, 0xe

    .line 818
    or-int/lit16 v5, v5, 0x1b0

    .line 820
    const/16 v3, 0x578

    .line 822
    const/4 v15, 0x0

    .line 823
    invoke-static {v15, v3, v5, v2, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 826
    move-result-object v3

    .line 827
    const/16 v6, 0x76c

    .line 829
    const/16 v7, 0x320

    .line 831
    invoke-static {v6, v7, v5, v2, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 834
    move-result-object v10

    .line 835
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 838
    move-result-object v5

    .line 839
    move-object/from16 v6, v30

    .line 841
    if-ne v5, v6, :cond_356

    .line 843
    new-instance v5, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda11;

    .line 845
    invoke-direct {v5, v10, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda11;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 848
    invoke-static {v5}, Landroidx/compose/runtime/SnapshotStateKt__DerivedStateKt;->derivedStateOf(Lkotlin/jvm/functions/Function0;)Landroidx/compose/runtime/DerivedSnapshotState;

    .line 851
    move-result-object v5

    .line 852
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 855
    :cond_356
    move-object/from16 v20, v5

    .line 857
    check-cast v20, Landroidx/compose/runtime/State;

    .line 859
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 862
    move-result-object v5

    .line 863
    if-ne v5, v6, :cond_36a

    .line 865
    new-instance v5, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 867
    const-wide/16 v11, -0x3e8

    .line 869
    invoke-direct {v5, v11, v12}, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;-><init>(J)V

    .line 872
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 875
    :cond_36a
    check-cast v5, Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 877
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 880
    move-result-object v7

    .line 881
    if-ne v7, v6, :cond_37c

    .line 883
    new-instance v7, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 885
    const/4 v9, 0x0

    .line 886
    invoke-direct {v7, v9}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;-><init>(F)V

    .line 889
    invoke-virtual {v2, v7}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 892
    goto :goto_37d

    .line 893
    :cond_37c
    const/4 v9, 0x0

    .line 894
    :goto_37d
    check-cast v7, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 896
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 899
    move-result-object v11

    .line 900
    if-ne v11, v6, :cond_38d

    .line 902
    new-instance v11, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 904
    invoke-direct {v11, v9}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;-><init>(F)V

    .line 907
    invoke-virtual {v2, v11}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 910
    :cond_38d
    check-cast v11, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 912
    sget-object v9, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 914
    const/high16 v12, 0x3f800000  # 1.0f

    .line 916
    invoke-static {v9, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 919
    move-result-object v9

    .line 920
    invoke-static {v9}, Landroidx/compose/ui/draw/ClipKt;->clipToBounds(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 923
    move-result-object v9

    .line 924
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 927
    move-result-object v12

    .line 928
    if-ne v12, v6, :cond_3aa

    .line 930
    new-instance v12, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda12;

    .line 932
    const/4 v15, 0x0

    .line 933
    invoke-direct {v12, v7, v15}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda12;-><init>(Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;B)V

    .line 936
    invoke-virtual {v2, v12}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 939
    :cond_3aa
    check-cast v12, Lkotlin/jvm/functions/Function1;

    .line 941
    invoke-static {v9, v12}, Landroidx/compose/ui/layout/RulerKt;->onGloballyPositioned(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 944
    move-result-object v21

    .line 945
    move v2, v0

    .line 946
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;

    .line 948
    move-object/from16 v9, p1

    .line 950
    move/from16 v12, p4

    .line 952
    move-object/from16 v16, v18

    .line 954
    move-object/from16 v15, v19

    .line 956
    move-wide/from16 v13, v23

    .line 958
    move/from16 v18, v4

    .line 960
    move-object/from16 v19, v5

    .line 962
    move-object v5, v7

    .line 963
    move-object v4, v11

    .line 964
    move-wide/from16 v6, v28

    .line 966
    move/from16 v11, p3

    .line 968
    invoke-direct/range {v0 .. v20}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;FLandroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;JLcom/spotifry/music/ui/listening/SunMotion;Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/core/Animatable;ZZJLjava/lang/String;Ljava/lang/String;Ljava/util/List;ZLandroidx/compose/runtime/ParcelableSnapshotMutableLongState;Landroidx/compose/runtime/State;)V

    .line 971
    const v1, 0x3af60bcd

    .line 974
    move-object/from16 v2, p6

    .line 976
    invoke-static {v1, v0, v2}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 979
    move-result-object v0

    .line 980
    const/16 v4, 0xc06

    .line 982
    const/4 v5, 0x6

    .line 983
    const/4 v1, 0x0

    .line 984
    move-object v3, v2

    .line 985
    move-object v2, v0

    .line 986
    move-object/from16 v0, v21

    .line 988
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 991
    goto :goto_3e2

    .line 992
    :cond_3df
    invoke-virtual/range {p6 .. p6}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 995
    :goto_3e2
    invoke-virtual/range {p6 .. p6}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 998
    move-result-object v9

    .line 999
    if-eqz v9, :cond_3fe

    .line 1001
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;

    .line 1003
    const/4 v8, 0x1

    .line 1004
    move-object/from16 v1, p0

    .line 1006
    move-object/from16 v2, p1

    .line 1008
    move/from16 v3, p2

    .line 1010
    move/from16 v4, p3

    .line 1012
    move/from16 v5, p4

    .line 1014
    move-object/from16 v6, p5

    .line 1016
    move/from16 v7, p7

    .line 1018
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;IB)V

    .line 1021
    iput-object v0, v9, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 1023
    :cond_3fe
    return-void

    nop

    .line 1025
    :pswitch_data_400
    .packed-switch 0x0
        :pswitch_2ef  #00000000
        :pswitch_29b  #00000001
        :pswitch_27d  #00000002
        :pswitch_22c  #00000003
        :pswitch_1df  #00000004
        :pswitch_1c1  #00000005
        :pswitch_1aa  #00000006
        :pswitch_17b  #00000007
    .end packed-switch
.end method

.method public static final Type$lambda$235$lambda$234$lambda$220$factStyle(F)Landroidx/compose/ui/text/TextStyle;
    .registers 18

    .line 1
    sget-object v1, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 3
    iget-object v0, v1, Landroidx/compose/ui/text/TextStyle;->spanStyle:Landroidx/compose/ui/text/SpanStyle;

    .line 5
    iget-wide v2, v0, Landroidx/compose/ui/text/SpanStyle;->fontSize:J

    .line 7
    invoke-static {v2, v3}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 10
    const-wide v4, 0xff00000000L

    .line 15
    and-long v6, v2, v4

    .line 17
    invoke-static {v2, v3}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 20
    move-result v0

    .line 21
    mul-float v0, v0, p0

    .line 23
    invoke-static {v0, v6, v7}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 26
    move-result-wide v2

    .line 27
    const/16 v0, 0x14

    .line 29
    invoke-static {v0}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 32
    move-result-wide v6

    .line 33
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 36
    and-long/2addr v4, v6

    .line 37
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 40
    move-result v0

    .line 41
    mul-float v0, v0, p0

    .line 43
    invoke-static {v0, v4, v5}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 46
    move-result-wide v12

    .line 47
    const/4 v15, 0x0

    .line 48
    const v16, 0xfdfffd

    .line 51
    move-wide v4, v2

    .line 52
    const-wide/16 v2, 0x0

    .line 54
    const/4 v6, 0x0

    .line 55
    const/4 v7, 0x0

    .line 56
    const/4 v8, 0x0

    .line 57
    const-wide/16 v9, 0x0

    .line 59
    const/4 v11, 0x0

    .line 60
    const/4 v14, 0x0

    .line 61
    invoke-static/range {v1 .. v16}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 64
    move-result-object v0

    .line 65
    return-object v0
.end method

.method public static final Type$lambda$235$lambda$234$lambda$220$titleStyle(Landroidx/compose/ui/text/TextStyle;FF)Landroidx/compose/ui/text/TextStyle;
    .registers 20

    .line 1
    move-object/from16 v1, p0

    .line 3
    iget-object v0, v1, Landroidx/compose/ui/text/TextStyle;->spanStyle:Landroidx/compose/ui/text/SpanStyle;

    .line 5
    iget-wide v2, v0, Landroidx/compose/ui/text/SpanStyle;->fontSize:J

    .line 7
    invoke-static {v2, v3}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 10
    const-wide v4, 0xff00000000L

    .line 15
    and-long v6, v2, v4

    .line 17
    invoke-static {v2, v3}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 20
    move-result v2

    .line 21
    mul-float v2, v2, p1

    .line 23
    invoke-static {v2, v6, v7}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 26
    move-result-wide v2

    .line 27
    invoke-static {v2, v3}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 30
    and-long v6, v2, v4

    .line 32
    invoke-static {v2, v3}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 35
    move-result v2

    .line 36
    mul-float v2, v2, p2

    .line 38
    invoke-static {v2, v6, v7}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 41
    move-result-wide v2

    .line 42
    iget-object v6, v1, Landroidx/compose/ui/text/TextStyle;->paragraphStyle:Landroidx/compose/ui/text/ParagraphStyle;

    .line 44
    iget-wide v6, v6, Landroidx/compose/ui/text/ParagraphStyle;->lineHeight:J

    .line 46
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 49
    and-long v8, v6, v4

    .line 51
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 54
    move-result v6

    .line 55
    mul-float v6, v6, p1

    .line 57
    invoke-static {v6, v8, v9}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 60
    move-result-wide v6

    .line 61
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 64
    and-long v8, v6, v4

    .line 66
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 69
    move-result v6

    .line 70
    mul-float v6, v6, p2

    .line 72
    invoke-static {v6, v8, v9}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 75
    move-result-wide v12

    .line 76
    iget-wide v6, v0, Landroidx/compose/ui/text/SpanStyle;->letterSpacing:J

    .line 78
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 81
    and-long v8, v6, v4

    .line 83
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 86
    move-result v0

    .line 87
    mul-float v0, v0, p1

    .line 89
    invoke-static {v0, v8, v9}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 92
    move-result-wide v6

    .line 93
    invoke-static {v6, v7}, Lkotlin/UnsignedKt;->checkArithmetic--R2X_6o(J)V

    .line 96
    and-long/2addr v4, v6

    .line 97
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/TextUnit;->getValue-impl(J)F

    .line 100
    move-result v0

    .line 101
    mul-float v0, v0, p2

    .line 103
    invoke-static {v0, v4, v5}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 106
    move-result-wide v9

    .line 107
    const/4 v15, 0x0

    .line 108
    const v16, 0xfdff7d

    .line 111
    move-wide v4, v2

    .line 112
    const-wide/16 v2, 0x0

    .line 114
    const/4 v6, 0x0

    .line 115
    const/4 v7, 0x0

    .line 116
    const/4 v8, 0x0

    .line 117
    const/4 v11, 0x0

    .line 118
    const/4 v14, 0x0

    .line 119
    invoke-static/range {v1 .. v16}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 122
    move-result-object v0

    .line 123
    return-object v0
.end method

.method public static final TypeCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 18

    .line 1
    move-object/from16 v6, p6

    .line 3
    move/from16 v8, p7

    .line 5
    const v0, -0x1fe5a0b9

    .line 8
    invoke-virtual {v6, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 11
    and-int/lit8 v0, v8, 0x6

    .line 13
    if-nez v0, :cond_19

    .line 15
    invoke-virtual {v6, p0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 18
    move-result v0

    .line 19
    if-eqz v0, :cond_16

    .line 21
    const/4 v0, 0x4

    .line 22
    goto :goto_17

    .line 23
    :cond_16
    const/4 v0, 0x2

    .line 24
    :goto_17
    or-int/2addr v0, v8

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    move v0, v8

    .line 27
    :goto_1a
    and-int/lit8 v1, v8, 0x30

    .line 29
    if-nez v1, :cond_2a

    .line 31
    invoke-virtual {v6, p1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 34
    move-result v1

    .line 35
    if-eqz v1, :cond_27

    .line 37
    const/16 v1, 0x20

    .line 39
    goto :goto_29

    .line 40
    :cond_27
    const/16 v1, 0x10

    .line 42
    :goto_29
    or-int/2addr v0, v1

    .line 43
    :cond_2a
    and-int/lit16 v1, v8, 0x180

    .line 45
    if-nez v1, :cond_3a

    .line 47
    invoke-virtual {v6, p2}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 50
    move-result v1

    .line 51
    if-eqz v1, :cond_37

    .line 53
    const/16 v1, 0x100

    .line 55
    goto :goto_39

    .line 56
    :cond_37
    const/16 v1, 0x80

    .line 58
    :goto_39
    or-int/2addr v0, v1

    .line 59
    :cond_3a
    and-int/lit16 v1, v8, 0xc00

    .line 61
    if-nez v1, :cond_4a

    .line 63
    invoke-virtual {v6, p3}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 66
    move-result v1

    .line 67
    if-eqz v1, :cond_47

    .line 69
    const/16 v1, 0x800

    .line 71
    goto :goto_49

    .line 72
    :cond_47
    const/16 v1, 0x400

    .line 74
    :goto_49
    or-int/2addr v0, v1

    .line 75
    :cond_4a
    and-int/lit16 v1, v8, 0x6000

    .line 77
    if-nez v1, :cond_5a

    .line 79
    invoke-virtual {v6, p4}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 82
    move-result v1

    .line 83
    if-eqz v1, :cond_57

    .line 85
    const/16 v1, 0x4000

    .line 87
    goto :goto_59

    .line 88
    :cond_57
    const/16 v1, 0x2000

    .line 90
    :goto_59
    or-int/2addr v0, v1

    .line 91
    :cond_5a
    const/high16 v1, 0x30000

    .line 93
    and-int/2addr v1, v8

    .line 94
    if-nez v1, :cond_6b

    .line 96
    invoke-virtual {v6, p5}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 99
    move-result v1

    .line 100
    if-eqz v1, :cond_68

    .line 102
    const/high16 v1, 0x20000

    .line 104
    goto :goto_6a

    .line 105
    :cond_68
    const/high16 v1, 0x10000

    .line 107
    :goto_6a
    or-int/2addr v0, v1

    .line 108
    :cond_6b
    const v1, 0x12493

    .line 111
    and-int/2addr v1, v0

    .line 112
    const v2, 0x12492

    .line 115
    const/4 v7, 0x1

    .line 116
    const/4 v9, 0x0

    .line 117
    if-eq v1, v2, :cond_78

    .line 119
    move v1, v7

    .line 120
    goto :goto_79

    .line 121
    :cond_78
    move v1, v9

    .line 122
    :goto_79
    and-int/lit8 v2, v0, 0x1

    .line 124
    invoke-virtual {v6, v2, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 127
    move-result v1

    .line 128
    if-eqz v1, :cond_ba

    .line 130
    if-eqz p2, :cond_8e

    .line 132
    const v1, 0x1cf86923

    .line 135
    invoke-virtual {v6, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 138
    :goto_89
    invoke-virtual {v6, v9}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 141
    move v2, v7

    .line 142
    goto :goto_99

    .line 143
    :cond_8e
    const v1, 0x42ffc259

    .line 146
    invoke-virtual {v6, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 149
    invoke-static {v6}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 152
    move-result v7

    .line 153
    goto :goto_89

    .line 154
    :goto_99
    iget-object v1, p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 156
    invoke-static {v2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 159
    move-result-object v7

    .line 160
    invoke-virtual {v6, v1, v7}, Landroidx/compose/runtime/ComposerImpl;->joinKey(Ljava/lang/Object;Ljava/lang/Boolean;)Ljava/lang/Object;

    .line 163
    move-result-object v1

    .line 164
    const v7, 0x42ffc56c

    .line 167
    invoke-virtual {v6, v7, v1}, Landroidx/compose/runtime/ComposerImpl;->startMovableGroup(ILjava/lang/Object;)V

    .line 170
    const v1, 0x7fc7e

    .line 173
    and-int v7, v0, v1

    .line 175
    move-object v0, p0

    .line 176
    move-object v1, p1

    .line 177
    move v3, p3

    .line 178
    move v4, p4

    .line 179
    move-object v5, p5

    .line 180
    invoke-static/range {v0 .. v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Type(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 183
    invoke-virtual {v6, v9}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 186
    goto :goto_bd

    .line 187
    :cond_ba
    invoke-virtual {v6}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 190
    :goto_bd
    invoke-virtual {v6}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 193
    move-result-object v9

    .line 194
    if-eqz v9, :cond_d3

    .line 196
    new-instance v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;

    .line 198
    const/4 v8, 0x0

    .line 199
    move-object v1, p0

    .line 200
    move-object v2, p1

    .line 201
    move v3, p2

    .line 202
    move v4, p3

    .line 203
    move v5, p4

    .line 204
    move-object v6, p5

    .line 205
    move/from16 v7, p7

    .line 207
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda8;-><init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;IB)V

    .line 210
    iput-object v0, v9, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 212
    :cond_d3
    return-void
.end method

.method public static final clock(ZFLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/animation/core/Animatable;
    .registers 9

    .line 1
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 7
    if-ne v0, v1, :cond_14

    .line 9
    if-eqz p0, :cond_c

    .line 11
    move p0, p1

    .line 12
    goto :goto_d

    .line 13
    :cond_c
    const/4 p0, 0x0

    .line 14
    :goto_d
    invoke-static {p0}, Landroidx/compose/animation/core/ArcSplineKt;->Animatable$default(F)Landroidx/compose/animation/core/Animatable;

    .line 17
    move-result-object v0

    .line 18
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 21
    :cond_14
    check-cast v0, Landroidx/compose/animation/core/Animatable;

    .line 23
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 26
    move-result p0

    .line 27
    and-int/lit8 v2, p3, 0x70

    .line 29
    xor-int/lit8 v2, v2, 0x30

    .line 31
    const/4 v3, 0x0

    .line 32
    const/16 v4, 0x20

    .line 34
    if-le v2, v4, :cond_29

    .line 36
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 39
    move-result v2

    .line 40
    if-nez v2, :cond_2d

    .line 42
    :cond_29
    and-int/lit8 p3, p3, 0x30

    .line 44
    if-ne p3, v4, :cond_2f

    .line 46
    :cond_2d
    const/4 p3, 0x1

    .line 47
    goto :goto_30

    .line 48
    :cond_2f
    move p3, v3

    .line 49
    :goto_30
    or-int/2addr p0, p3

    .line 50
    invoke-virtual {p2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 53
    move-result-object p3

    .line 54
    if-nez p0, :cond_39

    .line 56
    if-ne p3, v1, :cond_42

    .line 58
    :cond_39
    new-instance p3, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;

    .line 60
    const/4 p0, 0x0

    .line 61
    invoke-direct {p3, v0, p1, p0, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;-><init>(Ljava/lang/Object;FLkotlin/coroutines/Continuation;B)V

    .line 64
    invoke-virtual {p2, p3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 67
    :cond_42
    check-cast p3, Lkotlin/jvm/functions/Function2;

    .line 69
    invoke-static {p2, v0, p3}, Landroidx/compose/runtime/AnchoredGroupPath;->LaunchedEffect(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 72
    return-object v0
.end method

.method public static final countSpan(Landroidx/compose/ui/text/AnnotatedString$Builder;Lcom/spotifry/music/ui/spotifried/CountUp;Landroidx/compose/ui/text/SpanStyle;Ljava/lang/String;)V
    .registers 6

    .line 1
    iget-boolean p1, p1, Lcom/spotifry/music/ui/spotifried/CountUp;->started:Z

    .line 3
    if-nez p1, :cond_d

    .line 5
    sget-wide v0, Landroidx/compose/ui/graphics/Color;->Transparent:J

    .line 7
    const p1, 0xfffe

    .line 10
    invoke-static {p2, v0, v1, p1}, Landroidx/compose/ui/text/SpanStyle;->copy-GSF8kmg$default(Landroidx/compose/ui/text/SpanStyle;JI)Landroidx/compose/ui/text/SpanStyle;

    .line 13
    move-result-object p2

    .line 14
    :cond_d
    invoke-virtual {p0, p2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 17
    move-result p1

    .line 18
    :try_start_11
    invoke-virtual {p0, p3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_14
    .catchall {:try_start_11 .. :try_end_14} :catchall_18

    .line 21
    invoke-virtual {p0, p1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 24
    return-void

    .line 25
    :catchall_18
    move-exception p2

    .line 26
    invoke-virtual {p0, p1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 29
    throw p2
.end method

.method public static final countUp(IIILandroidx/compose/runtime/ComposerImpl;Z)Lcom/spotifry/music/ui/spotifried/CountUp;
    .registers 6

    .line 1
    shr-int/lit8 p2, p2, 0x3

    .line 3
    and-int/lit8 v0, p2, 0xe

    .line 5
    or-int/lit16 v0, v0, 0x180

    .line 7
    and-int/lit8 p2, p2, 0x70

    .line 9
    or-int/2addr v0, p2

    .line 10
    const/16 p2, 0x384

    .line 12
    invoke-static {p1, p2, v0, p3, p4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 15
    move-result-object p1

    .line 16
    invoke-virtual {p1}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 19
    move-result-object p1

    .line 20
    check-cast p1, Ljava/lang/Number;

    .line 22
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 25
    move-result p1

    .line 26
    new-instance p2, Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 28
    int-to-float p0, p0

    .line 29
    mul-float/2addr p0, p1

    .line 30
    invoke-static {p0}, Lkotlin/math/MathKt;->roundToInt(F)I

    .line 33
    move-result p0

    .line 34
    invoke-static {p0}, Lcom/spotifry/music/ui/listening/ListeningScreenKt;->count(I)Ljava/lang/String;

    .line 37
    move-result-object p0

    .line 38
    const/4 p3, 0x0

    .line 39
    cmpl-float p1, p1, p3

    .line 41
    if-lez p1, :cond_2c

    .line 43
    const/4 p1, 0x1

    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    const/4 p1, 0x0

    .line 46
    :goto_2d
    invoke-direct {p2, p0, p1}, Lcom/spotifry/music/ui/spotifried/CountUp;-><init>(Ljava/lang/String;Z)V

    .line 49
    return-object p2
.end method

.method public static final plural(ILjava/lang/String;)Ljava/lang/String;
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, v0, :cond_6

    .line 4
    const-string v0, ""

    .line 6
    goto :goto_8

    .line 7
    :cond_6
    const-string v0, "s"

    .line 9
    :goto_8
    new-instance v1, Ljava/lang/StringBuilder;

    .line 11
    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    .line 14
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 17
    const-string p0, " "

    .line 19
    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 25
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    move-result-object p0

    .line 32
    return-object p0
.end method

.method public static final progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;
    .registers 11

    .line 1
    invoke-virtual {p3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 7
    if-ne v0, v1, :cond_15

    .line 9
    if-eqz p4, :cond_d

    .line 11
    const/high16 p4, 0x3f800000  # 1.0f

    .line 13
    goto :goto_e

    .line 14
    :cond_d
    const/4 p4, 0x0

    .line 15
    :goto_e
    invoke-static {p4}, Landroidx/compose/animation/core/ArcSplineKt;->Animatable$default(F)Landroidx/compose/animation/core/Animatable;

    .line 18
    move-result-object v0

    .line 19
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 22
    :cond_15
    check-cast v0, Landroidx/compose/animation/core/Animatable;

    .line 24
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 27
    move-result p4

    .line 28
    and-int/lit16 v2, p2, 0x380

    .line 30
    xor-int/lit16 v2, v2, 0x180

    .line 32
    const/4 v3, 0x0

    .line 33
    const/4 v4, 0x1

    .line 34
    const/16 v5, 0x100

    .line 36
    if-le v2, v5, :cond_2b

    .line 38
    invoke-virtual {p3, p1}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 41
    move-result v2

    .line 42
    if-nez v2, :cond_2f

    .line 44
    :cond_2b
    and-int/lit16 v2, p2, 0x180

    .line 46
    if-ne v2, v5, :cond_31

    .line 48
    :cond_2f
    move v2, v4

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v2, v3

    .line 51
    :goto_32
    or-int/2addr p4, v2

    .line 52
    and-int/lit8 v2, p2, 0x70

    .line 54
    xor-int/lit8 v2, v2, 0x30

    .line 56
    const/16 v5, 0x20

    .line 58
    if-le v2, v5, :cond_41

    .line 60
    invoke-virtual {p3, p0}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 63
    move-result v2

    .line 64
    if-nez v2, :cond_45

    .line 66
    :cond_41
    and-int/lit8 p2, p2, 0x30

    .line 68
    if-ne p2, v5, :cond_46

    .line 70
    :cond_45
    move v3, v4

    .line 71
    :cond_46
    or-int/2addr p4, v3

    .line 72
    invoke-virtual {p3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 75
    move-result-object p2

    .line 76
    if-nez p4, :cond_4f

    .line 78
    if-ne p2, v1, :cond_58

    .line 80
    :cond_4f
    new-instance p2, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;

    .line 82
    const/4 p4, 0x0

    .line 83
    invoke-direct {p2, v0, p1, p0, p4}, Lcom/spotifry/music/ui/spotifried/CardsKt$progress$1$1;-><init>(Landroidx/compose/animation/core/Animatable;IILkotlin/coroutines/Continuation;)V

    .line 86
    invoke-virtual {p3, p2}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 89
    :cond_58
    check-cast p2, Lkotlin/jvm/functions/Function2;

    .line 91
    invoke-static {p3, v0, p2}, Landroidx/compose/runtime/AnchoredGroupPath;->LaunchedEffect(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 94
    return-object v0
.end method

.method public static final rememberSunMotion(Ljava/util/List;FZLandroidx/compose/runtime/ComposerImpl;)Lcom/spotifry/music/ui/listening/SunMotion;
    .registers 10

    .line 1
    invoke-virtual {p3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 7
    if-ne v0, v1, :cond_51

    .line 9
    new-instance v0, Lcom/spotifry/music/ui/listening/SunMotion;

    .line 11
    invoke-direct {v0}, Lcom/spotifry/music/ui/listening/SunMotion;-><init>()V

    .line 14
    if-eqz p2, :cond_4e

    .line 16
    invoke-static {p0}, Lkotlin/collections/CollectionsKt;->maxOrNull(Ljava/lang/Iterable;)Ljava/lang/Comparable;

    .line 19
    move-result-object p2

    .line 20
    check-cast p2, Ljava/lang/Long;

    .line 22
    if-eqz p2, :cond_1c

    .line 24
    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    .line 27
    move-result-wide v1

    .line 28
    goto :goto_1e

    .line 29
    :cond_1c
    const-wide/16 v1, 0x0

    .line 31
    :goto_1e
    const-wide/16 v3, 0x1

    .line 33
    cmp-long p2, v1, v3

    .line 35
    if-gez p2, :cond_25

    .line 37
    move-wide v1, v3

    .line 38
    :cond_25
    long-to-float p2, v1

    .line 39
    invoke-interface {p0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 42
    move-result-object p0

    .line 43
    const/4 v1, 0x0

    .line 44
    :goto_2b
    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    .line 47
    move-result v2

    .line 48
    if-eqz v2, :cond_4c

    .line 50
    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 53
    move-result-object v2

    .line 54
    add-int/lit8 v3, v1, 0x1

    .line 56
    if-ltz v1, :cond_47

    .line 58
    check-cast v2, Ljava/lang/Number;

    .line 60
    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    .line 63
    move-result-wide v4

    .line 64
    long-to-float v2, v4

    .line 65
    div-float/2addr v2, p2

    .line 66
    iget-object v4, v0, Lcom/spotifry/music/ui/listening/SunMotion;->now:[F

    .line 68
    aput v2, v4, v1

    .line 70
    move v1, v3

    .line 71
    goto :goto_2b

    .line 72
    :cond_47
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 75
    const/4 p0, 0x0

    .line 76
    throw p0

    .line 77
    :cond_4c
    iput p1, v0, Lcom/spotifry/music/ui/listening/SunMotion;->scale:F

    .line 79
    :cond_4e
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 82
    :cond_51
    check-cast v0, Lcom/spotifry/music/ui/listening/SunMotion;

    .line 84
    return-object v0
.end method

.method public static final rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;
    .registers 11

    .line 1
    mul-int/lit16 v1, p1, 0xb4

    .line 3
    and-int/lit16 v4, p4, 0x38e

    .line 5
    const/4 v5, 0x4

    .line 6
    move-object v0, p0

    .line 7
    move v2, p2

    .line 8
    move-object v3, p3

    .line 9
    invoke-static/range {v0 .. v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->riseAt(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/Modifier;

    .line 12
    move-result-object p0

    .line 13
    return-object p0
.end method

.method public static final riseAt(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/Modifier;
    .registers 8

    .line 1
    and-int/lit8 p5, p5, 0x4

    .line 3
    if-eqz p5, :cond_7

    .line 5
    const/16 p5, 0x384

    .line 7
    goto :goto_9

    .line 8
    :cond_7
    const/16 p5, 0x320

    .line 10
    :goto_9
    shr-int/lit8 v0, p4, 0x6

    .line 12
    and-int/lit8 v0, v0, 0xe

    .line 14
    and-int/lit8 v1, p4, 0x70

    .line 16
    or-int/2addr v0, v1

    .line 17
    shr-int/lit8 p4, p4, 0x3

    .line 19
    and-int/lit16 p4, p4, 0x380

    .line 21
    or-int/2addr v0, p4

    .line 22
    invoke-static {p1, p5, v0, p3, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 25
    move-result-object p1

    .line 26
    sget-object p2, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 28
    invoke-virtual {p3, p2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 31
    move-result-object p2

    .line 32
    check-cast p2, Landroidx/compose/ui/unit/Density;

    .line 34
    sget p4, Lcom/spotifry/music/ui/spotifried/CardsKt;->RISE:F

    .line 36
    invoke-interface {p2, p4}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 39
    move-result p2

    .line 40
    invoke-virtual {p3, p1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 43
    move-result p4

    .line 44
    invoke-virtual {p3, p2}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 47
    move-result p5

    .line 48
    or-int/2addr p4, p5

    .line 49
    invoke-virtual {p3}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 52
    move-result-object p5

    .line 53
    if-nez p4, :cond_3a

    .line 55
    sget-object p4, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 57
    if-ne p5, p4, :cond_43

    .line 59
    :cond_3a
    new-instance p5, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 61
    const/4 p4, 0x0

    .line 62
    invoke-direct {p5, p1, p2, p4}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 65
    invoke-virtual {p3, p5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 68
    :cond_43
    check-cast p5, Lkotlin/jvm/functions/Function1;

    .line 70
    invoke-static {p0, p5}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 73
    move-result-object p0

    .line 74
    return-object p0
.end method

.method public static final soft(Landroidx/compose/runtime/ComposerImpl;)J
    .registers 3

    .line 1
    sget-object v0, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 3
    invoke-virtual {p0, v0}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Landroidx/compose/material3/ColorScheme;

    .line 9
    iget-wide v0, p0, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 11
    const p0, 0x3f23d70a  # 0.64f

    .line 14
    invoke-static {p0, v0, v1}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 17
    move-result-wide v0

    .line 18
    return-wide v0
.end method

.method public static final stepAt(FFF)F
    .registers 3

    .line 1
    sub-float/2addr p0, p1

    .line 2
    div-float/2addr p0, p2

    .line 3
    const/4 p1, 0x0

    .line 4
    const/high16 p2, 0x3f800000  # 1.0f

    .line 6
    invoke-static {p0, p1, p2}, Lkotlin/ResultKt;->coerceIn(FFF)F

    .line 9
    move-result p0

    .line 10
    sget-object p1, Lcom/spotifry/music/ui/spotifried/CardsKt;->Ease:Landroidx/compose/animation/core/CubicBezierEasing;

    .line 12
    invoke-virtual {p1, p0}, Landroidx/compose/animation/core/CubicBezierEasing;->transform(F)F

    .line 15
    move-result p0

    .line 16
    return p0
.end method
