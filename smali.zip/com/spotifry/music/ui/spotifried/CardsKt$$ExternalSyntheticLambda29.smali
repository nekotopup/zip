# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:J

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$4:Z

.field public final synthetic f$5:F

.field public final synthetic f$6:J

.field public final synthetic f$7:Ljava/time/format/DateTimeFormatter;

.field public final synthetic f$8:Z


# direct methods
.method public synthetic constructor <init>(ZJLjava/util/List;Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZFJLjava/time/format/DateTimeFormatter;Z)V
    .registers 12

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$0:Z

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$2:Ljava/util/List;

    .line 10
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 12
    iput-boolean p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$4:Z

    .line 14
    iput p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$5:F

    .line 16
    iput-wide p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$6:J

    .line 18
    iput-object p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$7:Ljava/time/format/DateTimeFormatter;

    .line 20
    iput-boolean p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$8:Z

    .line 22
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 30

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    if-nez v3, :cond_23

    .line 26
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_21

    .line 32
    const/4 v3, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v3, 0x2

    .line 35
    :goto_22
    or-int/2addr v2, v3

    .line 36
    :cond_23
    and-int/lit8 v3, v2, 0x13

    .line 38
    const/16 v4, 0x12

    .line 40
    const/4 v6, 0x1

    .line 41
    if-eq v3, v4, :cond_2c

    .line 43
    move v3, v6

    .line 44
    goto :goto_2d

    .line 45
    :cond_2c
    const/4 v3, 0x0

    .line 46
    :goto_2d
    and-int/2addr v2, v6

    .line 47
    invoke-virtual {v5, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 50
    move-result v2

    .line 51
    if-eqz v2, :cond_d6

    .line 53
    new-instance v2, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 55
    invoke-direct {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 58
    iget-boolean v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$0:Z

    .line 60
    if-eqz v3, :cond_40

    .line 62
    const-string v3, "Your year,\n"

    .line 64
    goto :goto_42

    .line 65
    :cond_40
    const-string v3, "Your months,\n"

    .line 67
    :goto_42
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 70
    new-instance v6, Landroidx/compose/ui/text/SpanStyle;

    .line 72
    const/16 v24, 0x0

    .line 74
    const v25, 0xfffe

    .line 77
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$1:J

    .line 79
    const-wide/16 v9, 0x0

    .line 81
    const/4 v11, 0x0

    .line 82
    const/4 v12, 0x0

    .line 83
    const/4 v13, 0x0

    .line 84
    const/4 v14, 0x0

    .line 85
    const/4 v15, 0x0

    .line 86
    const-wide/16 v16, 0x0

    .line 88
    const/16 v18, 0x0

    .line 90
    const/16 v19, 0x0

    .line 92
    const/16 v20, 0x0

    .line 94
    const-wide/16 v21, 0x0

    .line 96
    const/16 v23, 0x0

    .line 98
    invoke-direct/range {v6 .. v25}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 101
    move-wide/from16 v24, v7

    .line 103
    invoke-virtual {v2, v6}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 106
    move-result v3

    .line 107
    :try_start_6a
    const-string v4, "in order."

    .line 109
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_6f
    .catchall {:try_start_6a .. :try_end_6f} :catchall_d1

    .line 112
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 115
    invoke-virtual {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 118
    move-result-object v2

    .line 119
    sget-object v19, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 121
    const/high16 v22, 0x6000000

    .line 123
    const v23, 0x3fffe

    .line 126
    const/4 v3, 0x0

    .line 127
    move-object/from16 v20, v5

    .line 129
    const-wide/16 v4, 0x0

    .line 131
    const-wide/16 v6, 0x0

    .line 133
    const/4 v8, 0x0

    .line 134
    const-wide/16 v9, 0x0

    .line 136
    const-wide/16 v11, 0x0

    .line 138
    const/4 v13, 0x0

    .line 139
    const/4 v14, 0x0

    .line 140
    const/4 v15, 0x0

    .line 141
    const/16 v16, 0x0

    .line 143
    const/16 v17, 0x0

    .line 145
    const/16 v18, 0x0

    .line 147
    const/16 v21, 0x0

    .line 149
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 152
    move-object/from16 v5, v20

    .line 154
    const/high16 v2, 0x3f800000  # 1.0f

    .line 156
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 159
    move-result-object v1

    .line 160
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 163
    move-result-object v6

    .line 164
    const/4 v10, 0x0

    .line 165
    const/16 v11, 0xd

    .line 167
    const/4 v7, 0x0

    .line 168
    const/high16 v8, 0x41b00000  # 22.0f

    .line 170
    const/4 v9, 0x0

    .line 171
    invoke-static/range {v6 .. v11}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 174
    move-result-object v2

    .line 175
    new-instance v7, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;

    .line 177
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$2:Ljava/util/List;

    .line 179
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$3:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 181
    iget-boolean v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$4:Z

    .line 183
    iget v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$5:F

    .line 185
    iget-wide v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$6:J

    .line 187
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$7:Ljava/time/format/DateTimeFormatter;

    .line 189
    iget-boolean v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda29;->f$8:Z

    .line 191
    move-wide/from16 v16, v24

    .line 193
    invoke-direct/range {v7 .. v17}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;-><init>(Ljava/util/List;Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZFJLjava/time/format/DateTimeFormatter;ZJ)V

    .line 196
    const v0, -0x774a7cf6

    .line 199
    invoke-static {v0, v7, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 202
    move-result-object v4

    .line 203
    const/16 v6, 0xc00

    .line 205
    const/4 v7, 0x6

    .line 206
    invoke-static/range {v2 .. v7}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 209
    goto :goto_db

    .line 210
    :catchall_d1
    move-exception v0

    .line 211
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 214
    throw v0

    .line 215
    :cond_d6
    move-object/from16 v20, v5

    .line 217
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 220
    :goto_db
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 222
    return-object v0
.end method
