# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$2:Z

.field public final synthetic f$3:F

.field public final synthetic f$4:J

.field public final synthetic f$5:Ljava/time/format/DateTimeFormatter;

.field public final synthetic f$6:Z

.field public final synthetic f$7:J


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZFJLjava/time/format/DateTimeFormatter;ZJ)V
    .registers 11

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$0:Ljava/util/List;

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 8
    iput-boolean p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$2:Z

    .line 10
    iput p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$3:F

    .line 12
    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$4:J

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$5:Ljava/time/format/DateTimeFormatter;

    .line 16
    iput-boolean p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$6:Z

    .line 18
    iput-wide p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$7:J

    .line 20
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 55

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 24
    const/4 v5, 0x2

    .line 25
    if-nez v4, :cond_24

    .line 27
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v4

    .line 31
    if-eqz v4, :cond_22

    .line 33
    const/4 v4, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v4, v5

    .line 36
    :goto_23
    or-int/2addr v3, v4

    .line 37
    :cond_24
    and-int/lit8 v4, v3, 0x13

    .line 39
    const/16 v6, 0x12

    .line 41
    const/4 v7, 0x0

    .line 42
    const/4 v8, 0x1

    .line 43
    if-eq v4, v6, :cond_2e

    .line 45
    move v4, v8

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v4, v7

    .line 48
    :goto_2f
    and-int/2addr v3, v8

    .line 49
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v3

    .line 53
    if-eqz v3, :cond_318

    .line 55
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 58
    move-result v1

    .line 59
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$0:Ljava/util/List;

    .line 61
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 64
    move-result v4

    .line 65
    int-to-float v4, v4

    .line 66
    div-float/2addr v1, v4

    .line 67
    new-instance v4, Landroidx/compose/ui/unit/Dp;

    .line 69
    invoke-direct {v4, v1}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 72
    new-instance v1, Landroidx/compose/ui/unit/Dp;

    .line 74
    const/high16 v6, 0x42900000  # 72.0f

    .line 76
    invoke-direct {v1, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 79
    invoke-virtual {v4, v1}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 82
    move-result v6

    .line 83
    if-lez v6, :cond_55

    .line 85
    move-object v4, v1

    .line 86
    :cond_55
    sget-object v15, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 88
    sget-object v14, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 90
    const v1, 0x3ee66666  # 0.45f

    .line 93
    iget v4, v4, Landroidx/compose/ui/unit/Dp;->value:F

    .line 95
    mul-float/2addr v1, v4

    .line 96
    const/high16 v6, 0x41b00000  # 22.0f

    .line 98
    const/high16 v9, 0x41400000  # 12.0f

    .line 100
    invoke-static {v1, v9, v6}, Lkotlin/ResultKt;->coerceIn(FFF)F

    .line 103
    move-result v1

    .line 104
    const-wide v10, 0x100000000L

    .line 109
    invoke-static {v1, v10, v11}, Lkotlin/UnsignedKt;->pack(FJ)J

    .line 112
    move-result-wide v12

    .line 113
    const-wide v10, -0x402ccccccccccccdL  # -0.3

    .line 118
    invoke-static {v10, v11}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 121
    move-result-wide v16

    .line 122
    new-instance v21, Landroidx/compose/ui/text/TextStyle;

    .line 124
    move v1, v9

    .line 125
    move-object/from16 v9, v21

    .line 127
    const/16 v21, 0x0

    .line 129
    const v22, 0xffff59

    .line 132
    const-wide/16 v10, 0x0

    .line 134
    const/16 v18, 0x0

    .line 136
    const-wide/16 v19, 0x0

    .line 138
    invoke-direct/range {v9 .. v22}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 141
    move-object/from16 v26, v9

    .line 143
    sget-object v9, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 145
    const/16 v6, 0xc

    .line 147
    invoke-static {v6}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 150
    move-result-wide v12

    .line 151
    const/16 v6, 0xe

    .line 153
    invoke-static {v6}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 156
    move-result-wide v20

    .line 157
    sget-object v14, Landroidx/compose/ui/text/font/FontWeight;->SemiBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 159
    const/16 v23, 0x0

    .line 161
    const v24, 0xfdfff9

    .line 164
    const/4 v15, 0x0

    .line 165
    const/16 v16, 0x0

    .line 167
    const-wide/16 v17, 0x0

    .line 169
    const/16 v19, 0x0

    .line 171
    const/16 v22, 0x0

    .line 173
    invoke-static/range {v9 .. v24}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 176
    move-result-object v21

    .line 177
    sget-object v9, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 179
    sget-object v10, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 181
    invoke-static {v9, v10, v2, v7}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 184
    move-result-object v9

    .line 185
    iget-wide v10, v2, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 187
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 190
    move-result v10

    .line 191
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 194
    move-result-object v11

    .line 195
    sget-object v12, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 197
    invoke-static {v2, v12}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 200
    move-result-object v13

    .line 201
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 203
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 206
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 208
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 211
    iget-boolean v15, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 213
    if-eqz v15, :cond_da

    .line 215
    invoke-virtual {v2, v14}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 218
    goto :goto_dd

    .line 219
    :cond_da
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 222
    :goto_dd
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 224
    invoke-static {v2, v9, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 227
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 229
    invoke-static {v2, v11, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 232
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 234
    iget-boolean v11, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 236
    if-nez v11, :cond_fb

    .line 238
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 241
    move-result-object v11

    .line 242
    invoke-static {v10}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 245
    move-result-object v14

    .line 246
    invoke-static {v11, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 249
    move-result v11

    .line 250
    if-nez v11, :cond_fe

    .line 252
    :cond_fb
    invoke-static {v10, v2, v10, v9}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 255
    :cond_fe
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 257
    invoke-static {v2, v13, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 260
    const v9, 0x77fb555b

    .line 263
    invoke-virtual {v2, v9}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 266
    invoke-interface {v3}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 269
    move-result-object v43

    .line 270
    move v3, v7

    .line 271
    :goto_10e
    invoke-interface/range {v43 .. v43}, Ljava/util/Iterator;->hasNext()Z

    .line 274
    move-result v9

    .line 275
    if-eqz v9, :cond_30f

    .line 277
    invoke-interface/range {v43 .. v43}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 280
    move-result-object v9

    .line 281
    add-int/lit8 v44, v3, 0x1

    .line 283
    if-ltz v3, :cond_30a

    .line 285
    check-cast v9, Lcom/spotifry/music/data/spotifried/MonthTop;

    .line 287
    iget-object v10, v9, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 289
    iget-object v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 291
    iget-object v11, v11, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->changeMonth:Ljava/time/YearMonth;

    .line 293
    invoke-virtual {v10, v11}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 296
    move-result v27

    .line 297
    mul-int/lit8 v3, v3, 0x5a

    .line 299
    add-int/lit16 v3, v3, 0xc8

    .line 301
    const/16 v10, 0x2bc

    .line 303
    const/16 v11, 0x180

    .line 305
    iget-boolean v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$2:Z

    .line 307
    invoke-static {v3, v10, v11, v2, v13}, Lcom/spotifry/music/ui/spotifried/CardsKt;->progress(IIILandroidx/compose/runtime/ComposerImpl;Z)Landroidx/compose/animation/core/Animatable;

    .line 310
    move-result-object v3

    .line 311
    const/high16 v10, 0x3f800000  # 1.0f

    .line 313
    invoke-static {v12, v10}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 316
    move-result-object v11

    .line 317
    invoke-static {v11, v4}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 320
    move-result-object v11

    .line 321
    if-eqz v27, :cond_145

    .line 323
    const-string v13, "change_month"

    .line 325
    goto :goto_147

    .line 326
    :cond_145
    const-string v13, "month"

    .line 328
    :goto_147
    invoke-static {v11, v13}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 331
    move-result-object v11

    .line 332
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 335
    move-result v13

    .line 336
    iget v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$3:F

    .line 338
    invoke-virtual {v2, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 341
    move-result v15

    .line 342
    or-int/2addr v13, v15

    .line 343
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 346
    move-result-object v15

    .line 347
    sget-object v7, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 349
    if-nez v13, :cond_160

    .line 351
    if-ne v15, v7, :cond_168

    .line 353
    :cond_160
    new-instance v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 355
    invoke-direct {v15, v3, v14, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 358
    invoke-virtual {v2, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 361
    :cond_168
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 363
    invoke-static {v11, v15}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 366
    move-result-object v3

    .line 367
    iget-wide v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$4:J

    .line 369
    invoke-virtual {v2, v13, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 372
    move-result v11

    .line 373
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 376
    move-result-object v15

    .line 377
    if-nez v11, :cond_17c

    .line 379
    if-ne v15, v7, :cond_184

    .line 381
    :cond_17c
    new-instance v15, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 383
    invoke-direct {v15, v13, v14, v6}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 386
    invoke-virtual {v2, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 389
    :cond_184
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 391
    invoke-static {v3, v15}, Landroidx/compose/ui/draw/ClipKt;->drawBehind(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 394
    move-result-object v3

    .line 395
    new-instance v7, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 397
    new-instance v11, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 399
    const/4 v13, 0x3

    .line 400
    invoke-direct {v11, v13}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 403
    invoke-direct {v7, v1, v11}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 406
    sget-object v11, Landroidx/compose/ui/Alignment$Companion;->CenterVertically:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 408
    const/16 v13, 0x36

    .line 410
    invoke-static {v7, v11, v2, v13}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 413
    move-result-object v7

    .line 414
    iget-wide v13, v2, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 416
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 419
    move-result v11

    .line 420
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 423
    move-result-object v13

    .line 424
    invoke-static {v2, v3}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 427
    move-result-object v3

    .line 428
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 430
    invoke-virtual {v14}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 433
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 435
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 438
    iget-boolean v15, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 440
    if-eqz v15, :cond_1bd

    .line 442
    invoke-virtual {v2, v14}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 445
    goto :goto_1c0

    .line 446
    :cond_1bd
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 449
    :goto_1c0
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 451
    invoke-static {v2, v7, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 454
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 456
    invoke-static {v2, v13, v7}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 459
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 461
    iget-boolean v13, v2, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 463
    if-nez v13, :cond_1de

    .line 465
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 468
    move-result-object v13

    .line 469
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 472
    move-result-object v14

    .line 473
    invoke-static {v13, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 476
    move-result v13

    .line 477
    if-nez v13, :cond_1e1

    .line 479
    :cond_1de
    invoke-static {v11, v2, v11, v7}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 482
    :cond_1e1
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 484
    invoke-static {v2, v3, v7}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 487
    iget-object v3, v9, Lcom/spotifry/music/data/spotifried/MonthTop;->month:Ljava/time/YearMonth;

    .line 489
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$5:Ljava/time/format/DateTimeFormatter;

    .line 491
    invoke-virtual {v3, v7}, Ljava/time/YearMonth;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 494
    move-result-object v3

    .line 495
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 498
    iget-boolean v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$6:Z

    .line 500
    if-eqz v7, :cond_1f8

    .line 502
    const/high16 v7, 0x42500000  # 52.0f

    .line 504
    goto :goto_1fa

    .line 505
    :cond_1f8
    const/high16 v7, 0x42000000  # 32.0f

    .line 507
    :goto_1fa
    invoke-static {v12, v7}, Landroidx/compose/foundation/layout/SizeKt;->width-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 510
    move-result-object v7

    .line 511
    move v13, v4

    .line 512
    move v11, v5

    .line 513
    invoke-static {v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 516
    move-result-wide v4

    .line 517
    const/16 v24, 0x6000

    .line 519
    const v25, 0x1bff8

    .line 522
    move-object/from16 v22, v2

    .line 524
    move-object v2, v3

    .line 525
    move v14, v6

    .line 526
    move-object v3, v7

    .line 527
    const-wide/16 v6, 0x0

    .line 529
    const/4 v8, 0x0

    .line 530
    move-object/from16 v16, v9

    .line 532
    const/4 v9, 0x0

    .line 533
    move/from16 v17, v10

    .line 535
    const/4 v10, 0x0

    .line 536
    move/from16 v19, v11

    .line 538
    move-object/from16 v18, v12

    .line 540
    const-wide/16 v11, 0x0

    .line 542
    move/from16 v20, v13

    .line 544
    const/4 v13, 0x0

    .line 545
    move/from16 v23, v14

    .line 547
    const-wide/16 v14, 0x0

    .line 549
    move-object/from16 v29, v16

    .line 551
    const/16 v16, 0x0

    .line 553
    move/from16 v30, v17

    .line 555
    const/16 v17, 0x0

    .line 557
    move-object/from16 v31, v18

    .line 559
    const/16 v18, 0x1

    .line 561
    move/from16 v32, v19

    .line 563
    const/16 v19, 0x0

    .line 565
    move/from16 v33, v20

    .line 567
    const/16 v20, 0x0

    .line 569
    move/from16 v34, v23

    .line 571
    const/16 v23, 0x0

    .line 573
    move-object/from16 v1, v29

    .line 575
    move/from16 v0, v30

    .line 577
    move-object/from16 v46, v31

    .line 579
    move/from16 v47, v32

    .line 581
    move/from16 v48, v33

    .line 583
    move/from16 v45, v34

    .line 585
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 588
    move/from16 v28, v27

    .line 590
    move-object/from16 v27, v21

    .line 592
    iget-object v1, v1, Lcom/spotifry/music/data/spotifried/MonthTop;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 594
    iget-object v2, v1, Lcom/spotifry/music/data/db/SongEntity;->title:Ljava/lang/String;

    .line 596
    new-instance v3, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 598
    const/4 v1, 0x1

    .line 599
    invoke-direct {v3, v0, v1}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 602
    move-object/from16 v0, p0

    .line 604
    iget-wide v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda46;->f$7:J

    .line 606
    if-eqz v28, :cond_261

    .line 608
    move-wide v6, v4

    .line 609
    goto :goto_263

    .line 610
    :cond_261
    sget-wide v6, Landroidx/compose/ui/graphics/Color;->Unspecified:J

    .line 612
    :goto_263
    const/16 v24, 0x6180

    .line 614
    const v25, 0x1aff8

    .line 617
    move-wide v8, v4

    .line 618
    move-wide v4, v6

    .line 619
    const-wide/16 v6, 0x0

    .line 621
    move-wide v9, v8

    .line 622
    const/4 v8, 0x0

    .line 623
    move-wide v10, v9

    .line 624
    const/4 v9, 0x0

    .line 625
    move-wide v11, v10

    .line 626
    const/4 v10, 0x0

    .line 627
    move-wide v13, v11

    .line 628
    const-wide/16 v11, 0x0

    .line 630
    move-wide v14, v13

    .line 631
    const/4 v13, 0x0

    .line 632
    move-wide/from16 v16, v14

    .line 634
    const-wide/16 v14, 0x0

    .line 636
    move-wide/from16 v17, v16

    .line 638
    const/16 v16, 0x2

    .line 640
    move-wide/from16 v18, v17

    .line 642
    const/16 v17, 0x0

    .line 644
    move-wide/from16 v19, v18

    .line 646
    const/16 v18, 0x1

    .line 648
    move-wide/from16 v20, v19

    .line 650
    const/16 v19, 0x0

    .line 652
    move-wide/from16 v29, v20

    .line 654
    const/16 v20, 0x0

    .line 656
    const/16 v23, 0x0

    .line 658
    move-object/from16 v21, v26

    .line 660
    move-wide/from16 v49, v29

    .line 662
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 665
    move-object/from16 v2, v22

    .line 667
    if-eqz v28, :cond_2ed

    .line 669
    const v3, -0x489302c7

    .line 672
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 675
    const/16 v3, 0xb

    .line 677
    invoke-static {v3}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 680
    move-result-wide v30

    .line 681
    const/16 v41, 0x0

    .line 683
    const v42, 0xfffffd

    .line 686
    const-wide/16 v28, 0x0

    .line 688
    const/16 v32, 0x0

    .line 690
    const/16 v33, 0x0

    .line 692
    const/16 v34, 0x0

    .line 694
    const-wide/16 v35, 0x0

    .line 696
    const/16 v37, 0x0

    .line 698
    const-wide/16 v38, 0x0

    .line 700
    const/16 v40, 0x0

    .line 702
    invoke-static/range {v27 .. v42}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 705
    move-result-object v21

    .line 706
    const/16 v24, 0x0

    .line 708
    const v25, 0x1fffa

    .line 711
    move-object/from16 v22, v2

    .line 713
    const-string v2, "taste changed"

    .line 715
    const/4 v3, 0x0

    .line 716
    const-wide/16 v6, 0x0

    .line 718
    const/4 v8, 0x0

    .line 719
    const/4 v9, 0x0

    .line 720
    const/4 v10, 0x0

    .line 721
    const-wide/16 v11, 0x0

    .line 723
    const/4 v13, 0x0

    .line 724
    const-wide/16 v14, 0x0

    .line 726
    const/16 v16, 0x0

    .line 728
    const/16 v17, 0x0

    .line 730
    const/16 v18, 0x0

    .line 732
    const/16 v19, 0x0

    .line 734
    const/16 v20, 0x0

    .line 736
    const/16 v23, 0x6

    .line 738
    move-wide/from16 v4, v49

    .line 740
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 743
    move-object/from16 v2, v22

    .line 745
    const/4 v3, 0x0

    .line 746
    :goto_2e9
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 749
    goto :goto_2f5

    .line 750
    :cond_2ed
    const/4 v3, 0x0

    .line 751
    const v4, 0x33f01a54

    .line 754
    invoke-virtual {v2, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 757
    goto :goto_2e9

    .line 758
    :goto_2f5
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 761
    move v8, v1

    .line 762
    move v7, v3

    .line 763
    move-object/from16 v21, v27

    .line 765
    move/from16 v3, v44

    .line 767
    move/from16 v6, v45

    .line 769
    move-object/from16 v12, v46

    .line 771
    move/from16 v5, v47

    .line 773
    move/from16 v4, v48

    .line 775
    const/high16 v1, 0x41400000  # 12.0f

    .line 777
    goto/16 :goto_10e

    .line 779
    :cond_30a
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 782
    const/4 v0, 0x0

    .line 783
    throw v0

    .line 784
    :cond_30f
    move v3, v7

    .line 785
    move v1, v8

    .line 786
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 789
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 792
    goto :goto_31b

    .line 793
    :cond_318
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 796
    :goto_31b
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 798
    return-object v0
.end method
