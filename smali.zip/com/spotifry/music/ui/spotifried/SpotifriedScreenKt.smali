# classes.dex

.class public abstract Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"


# static fields
.field public static final lambda$1523791782:Landroidx/compose/runtime/internal/ComposableLambdaImpl;


# direct methods
.method static constructor <clinit>()V
    .registers 4

    .line 1
    new-instance v0, Lkotlin/coroutines/CombinedContext$$ExternalSyntheticLambda0;

    .line 3
    const/4 v1, 0x4

    .line 4
    invoke-direct {v0, v1}, Lkotlin/coroutines/CombinedContext$$ExternalSyntheticLambda0;-><init>(B)V

    .line 7
    new-instance v1, Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 9
    const v2, 0x5ad337a6

    .line 12
    const/4 v3, 0x0

    .line 13
    invoke-direct {v1, v2, v3, v0}, Landroidx/compose/runtime/internal/ComposableLambdaImpl;-><init>(IZLjava/lang/Object;)V

    .line 16
    sput-object v1, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt;->lambda$1523791782:Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 18
    return-void
.end method

.method public static final NotEnough(Ljava/lang/Integer;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 32

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    const v2, 0x30eea8ea

    .line 8
    invoke-virtual {v1, v2}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 11
    invoke-virtual {v1, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 14
    move-result v2

    .line 15
    const/4 v3, 0x2

    .line 16
    if-eqz v2, :cond_13

    .line 18
    const/4 v2, 0x4

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    move v2, v3

    .line 21
    :goto_14
    or-int v2, p2, v2

    .line 23
    and-int/lit8 v4, v2, 0x3

    .line 25
    const/4 v5, 0x1

    .line 26
    const/4 v6, 0x0

    .line 27
    if-eq v4, v3, :cond_1e

    .line 29
    move v4, v5

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v4, v6

    .line 32
    :goto_1f
    and-int/2addr v2, v5

    .line 33
    invoke-virtual {v1, v2, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 36
    move-result v2

    .line 37
    if-eqz v2, :cond_15a

    .line 39
    const/high16 v2, 0x3f800000  # 1.0f

    .line 41
    sget-object v4, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 43
    invoke-static {v4, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 46
    move-result-object v2

    .line 47
    const/high16 v7, 0x41a00000  # 20.0f

    .line 49
    const/4 v8, 0x0

    .line 50
    invoke-static {v2, v7, v8, v3}, Landroidx/compose/foundation/layout/OffsetKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 53
    move-result-object v2

    .line 54
    sget-object v3, Landroidx/compose/foundation/layout/OffsetKt;->Center:Landroidx/compose/foundation/layout/Arrangement$Center$1;

    .line 56
    sget-object v7, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 58
    const/4 v8, 0x6

    .line 59
    invoke-static {v3, v7, v1, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 62
    move-result-object v3

    .line 63
    iget-wide v7, v1, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 65
    invoke-static {v7, v8}, Ljava/lang/Long;->hashCode(J)I

    .line 68
    move-result v7

    .line 69
    invoke-virtual {v1}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 72
    move-result-object v8

    .line 73
    invoke-static {v1, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 76
    move-result-object v2

    .line 77
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 79
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 82
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 84
    invoke-virtual {v1}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 87
    iget-boolean v10, v1, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 89
    if-eqz v10, :cond_5e

    .line 91
    invoke-virtual {v1, v9}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 94
    goto :goto_61

    .line 95
    :cond_5e
    invoke-virtual {v1}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 98
    :goto_61
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 100
    invoke-static {v1, v3, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 103
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 105
    invoke-static {v1, v8, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 108
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 110
    iget-boolean v8, v1, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 112
    if-nez v8, :cond_7f

    .line 114
    invoke-virtual {v1}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 117
    move-result-object v8

    .line 118
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 121
    move-result-object v9

    .line 122
    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 125
    move-result v8

    .line 126
    if-nez v8, :cond_82

    .line 128
    :cond_7f
    invoke-static {v7, v1, v7, v3}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 131
    :cond_82
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 133
    invoke-static {v1, v2, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 136
    sget-object v2, Landroidx/compose/material3/TypographyKt;->LocalTypography:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 138
    invoke-virtual {v1, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 141
    move-result-object v3

    .line 142
    check-cast v3, Landroidx/compose/material3/Typography;

    .line 144
    iget-object v3, v3, Landroidx/compose/material3/Typography;->headlineMedium:Landroidx/compose/ui/text/TextStyle;

    .line 146
    const/16 v23, 0x0

    .line 148
    const v24, 0x1fffe

    .line 151
    const-string v1, "Not enough listening yet"

    .line 153
    move-object v7, v2

    .line 154
    const/4 v2, 0x0

    .line 155
    move-object/from16 v20, v3

    .line 157
    move-object v8, v4

    .line 158
    const-wide/16 v3, 0x0

    .line 160
    move v9, v5

    .line 161
    const-wide/16 v5, 0x0

    .line 163
    move-object v11, v7

    .line 164
    const/4 v7, 0x0

    .line 165
    move-object v12, v8

    .line 166
    const/4 v8, 0x0

    .line 167
    move v13, v9

    .line 168
    const/4 v9, 0x0

    .line 169
    move-object v14, v11

    .line 170
    const-wide/16 v10, 0x0

    .line 172
    move-object/from16 v16, v12

    .line 174
    const/4 v12, 0x0

    .line 175
    move/from16 v18, v13

    .line 177
    move-object/from16 v17, v14

    .line 179
    const-wide/16 v13, 0x0

    .line 181
    const/4 v15, 0x0

    .line 182
    move-object/from16 v21, v16

    .line 184
    const/16 v16, 0x0

    .line 186
    move-object/from16 v22, v17

    .line 188
    const/16 v17, 0x0

    .line 190
    move/from16 v25, v18

    .line 192
    const/16 v18, 0x0

    .line 194
    const/16 v19, 0x0

    .line 196
    move-object/from16 v27, v22

    .line 198
    const/16 v22, 0x6

    .line 200
    move/from16 v0, v25

    .line 202
    move-object/from16 v28, v27

    .line 204
    move-object/from16 v25, v21

    .line 206
    move-object/from16 v21, p1

    .line 208
    invoke-static/range {v1 .. v24}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 211
    move-object/from16 v1, v21

    .line 213
    if-eqz p0, :cond_14e

    .line 215
    const v2, -0x7e55fa2e

    .line 218
    invoke-virtual {v1, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 221
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Integer;->intValue()I

    .line 224
    move-result v2

    .line 225
    if-ne v2, v0, :cond_e5

    .line 227
    const-string v2, "play"

    .line 229
    goto :goto_e7

    .line 230
    :cond_e5
    const-string v2, "plays"

    .line 232
    :goto_e7
    new-instance v3, Ljava/lang/StringBuilder;

    .line 234
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 237
    move-object/from16 v4, p0

    .line 239
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 242
    const-string v5, " more "

    .line 244
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 247
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 250
    const-string v2, " to go"

    .line 252
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 255
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 258
    move-result-object v2

    .line 259
    const/4 v11, 0x0

    .line 260
    const/16 v12, 0xd

    .line 262
    const/4 v8, 0x0

    .line 263
    const/high16 v9, 0x41000000  # 8.0f

    .line 265
    const/4 v10, 0x0

    .line 266
    move-object/from16 v7, v25

    .line 268
    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 271
    move-result-object v3

    .line 272
    move-object/from16 v14, v28

    .line 274
    invoke-virtual {v1, v14}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 277
    move-result-object v5

    .line 278
    check-cast v5, Landroidx/compose/material3/Typography;

    .line 280
    iget-object v5, v5, Landroidx/compose/material3/Typography;->bodyLarge:Landroidx/compose/ui/text/TextStyle;

    .line 282
    sget-object v6, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 284
    invoke-virtual {v1, v6}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 287
    move-result-object v6

    .line 288
    check-cast v6, Landroidx/compose/material3/ColorScheme;

    .line 290
    iget-wide v6, v6, Landroidx/compose/material3/ColorScheme;->onSurfaceVariant:J

    .line 292
    const/16 v23, 0x0

    .line 294
    const v24, 0x1fff8

    .line 297
    move-object v1, v2

    .line 298
    move-object v2, v3

    .line 299
    move-object/from16 v20, v5

    .line 301
    move-wide v3, v6

    .line 302
    const-wide/16 v5, 0x0

    .line 304
    const/4 v7, 0x0

    .line 305
    const/4 v8, 0x0

    .line 306
    const/4 v9, 0x0

    .line 307
    const-wide/16 v10, 0x0

    .line 309
    const/4 v12, 0x0

    .line 310
    const-wide/16 v13, 0x0

    .line 312
    const/4 v15, 0x0

    .line 313
    const/16 v16, 0x0

    .line 315
    const/16 v17, 0x0

    .line 317
    const/16 v18, 0x0

    .line 319
    const/16 v19, 0x0

    .line 321
    const/16 v22, 0x30

    .line 323
    move-object/from16 v21, p1

    .line 325
    invoke-static/range {v1 .. v24}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 328
    move-object/from16 v1, v21

    .line 330
    const/4 v15, 0x0

    .line 331
    :goto_14a
    invoke-virtual {v1, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 334
    goto :goto_156

    .line 335
    :cond_14e
    const/4 v15, 0x0

    .line 336
    const v2, -0x7edb4112

    .line 339
    invoke-virtual {v1, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 342
    goto :goto_14a

    .line 343
    :goto_156
    invoke-virtual {v1, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 346
    goto :goto_15d

    .line 347
    :cond_15a
    invoke-virtual {v1}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 350
    :goto_15d
    invoke-virtual {v1}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 353
    move-result-object v0

    .line 354
    if-eqz v0, :cond_170

    .line 356
    new-instance v1, Landroidx/compose/runtime/ComposerKt$$ExternalSyntheticLambda1;

    .line 358
    const/16 v2, 0x1d

    .line 360
    move-object/from16 v4, p0

    .line 362
    move/from16 v3, p2

    .line 364
    invoke-direct {v1, v4, v3, v2}, Landroidx/compose/runtime/ComposerKt$$ExternalSyntheticLambda1;-><init>(Ljava/lang/Object;IB)V

    .line 367
    iput-object v1, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 369
    :cond_170
    return-void
.end method

.method public static final SpotifriedScreen-942rkJo(Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Lkotlin/jvm/functions/Function0;FLkotlin/jvm/functions/Function4;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 23

    .line 1
    move-object/from16 v1, p0

    .line 3
    move-object/from16 v9, p4

    .line 5
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 8
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    const v0, 0x26a0a9f1

    .line 14
    invoke-virtual {v9, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 17
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 20
    move-result v0

    .line 21
    const/4 v2, 0x4

    .line 22
    if-eqz v0, :cond_19

    .line 24
    move v0, v2

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    const/4 v0, 0x2

    .line 27
    :goto_1a
    or-int v0, p5, v0

    .line 29
    move-object/from16 v3, p1

    .line 31
    invoke-virtual {v9, v3}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 34
    move-result v4

    .line 35
    if-eqz v4, :cond_27

    .line 37
    const/16 v4, 0x20

    .line 39
    goto :goto_29

    .line 40
    :cond_27
    const/16 v4, 0x10

    .line 42
    :goto_29
    or-int/2addr v0, v4

    .line 43
    move/from16 v4, p2

    .line 45
    invoke-virtual {v9, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 48
    move-result v5

    .line 49
    if-eqz v5, :cond_35

    .line 51
    const/16 v5, 0x100

    .line 53
    goto :goto_37

    .line 54
    :cond_35
    const/16 v5, 0x80

    .line 56
    :goto_37
    or-int/2addr v0, v5

    .line 57
    or-int/lit16 v0, v0, 0x400

    .line 59
    and-int/lit16 v5, v0, 0x493

    .line 61
    const/16 v6, 0x492

    .line 63
    const/4 v7, 0x0

    .line 64
    const/4 v8, 0x1

    .line 65
    if-eq v5, v6, :cond_44

    .line 67
    move v5, v8

    .line 68
    goto :goto_45

    .line 69
    :cond_44
    move v5, v7

    .line 70
    :goto_45
    and-int/2addr v0, v8

    .line 71
    invoke-virtual {v9, v0, v5}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 74
    move-result v0

    .line 75
    if-eqz v0, :cond_146

    .line 77
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->startDefaults()V

    .line 80
    and-int/lit8 v0, p5, 0x1

    .line 82
    sget-object v5, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 84
    if-eqz v0, :cond_61

    .line 86
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->getDefaultsInvalid()Z

    .line 89
    move-result v0

    .line 90
    if-nez v0, :cond_61

    .line 92
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 95
    move-object/from16 v16, p3

    .line 97
    goto :goto_74

    .line 98
    :cond_61
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 101
    move-result-object v0

    .line 102
    if-ne v0, v5, :cond_70

    .line 104
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;

    .line 106
    const/4 v6, 0x0

    .line 107
    invoke-direct {v0, v2, v6}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 110
    invoke-virtual {v9, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 113
    :cond_70
    check-cast v0, Lkotlin/jvm/functions/Function4;

    .line 115
    move-object/from16 v16, v0

    .line 117
    :goto_74
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->endDefaults()V

    .line 120
    iget-object v0, v1, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;->state:Lkotlinx/coroutines/flow/ReadonlyStateFlow;

    .line 122
    const/4 v2, 0x7

    .line 123
    invoke-static {v0, v9, v7, v2}, Lkotlin/text/CharsKt;->collectAsStateWithLifecycle(Lkotlinx/coroutines/flow/StateFlow;Landroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/runtime/MutableState;

    .line 126
    move-result-object v0

    .line 127
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 130
    move-result-object v0

    .line 131
    move-object v15, v0

    .line 132
    check-cast v15, Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 134
    if-nez v15, :cond_9c

    .line 136
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 139
    move-result-object v7

    .line 140
    if-eqz v7, :cond_161

    .line 142
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda0;

    .line 144
    const/4 v6, 0x0

    .line 145
    move/from16 v5, p5

    .line 147
    move-object v2, v3

    .line 148
    move v3, v4

    .line 149
    move-object/from16 v4, v16

    .line 151
    invoke-direct/range {v0 .. v6}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Lkotlin/jvm/functions/Function0;FLkotlin/jvm/functions/Function4;IB)V

    .line 154
    :goto_99
    iput-object v0, v7, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 156
    return-void

    .line 157
    :cond_9c
    move-object/from16 v4, v16

    .line 159
    iget-object v0, v15, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->stats:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 161
    iget-object v0, v0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 163
    filled-new-array {v0}, [Ljava/lang/Object;

    .line 166
    move-result-object v0

    .line 167
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 170
    move-result-object v1

    .line 171
    if-ne v1, v5, :cond_b6

    .line 173
    new-instance v1, Ldev/chrisbanes/haze/HazeStyleKt$$ExternalSyntheticLambda0;

    .line 175
    const/16 v2, 0x9

    .line 177
    invoke-direct {v1, v2}, Ldev/chrisbanes/haze/HazeStyleKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 180
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 183
    :cond_b6
    check-cast v1, Lkotlin/jvm/functions/Function0;

    .line 185
    const/16 v2, 0x30

    .line 187
    invoke-static {v0, v1, v9, v2}, Landroidx/compose/runtime/saveable/SaverKt;->rememberSaveable([Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/ComposerImpl;I)Ljava/lang/Object;

    .line 190
    move-result-object v0

    .line 191
    check-cast v0, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 193
    sget-object v1, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->LocalContext:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 195
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 198
    move-result-object v1

    .line 199
    move-object v14, v1

    .line 200
    check-cast v14, Landroid/content/Context;

    .line 202
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 205
    move-result-object v1

    .line 206
    if-ne v1, v5, :cond_d6

    .line 208
    invoke-static {v9}, Landroidx/compose/runtime/AnchoredGroupPath;->createCompositionCoroutineScope(Landroidx/compose/runtime/ComposerImpl;)Lkotlinx/coroutines/CoroutineScope;

    .line 211
    move-result-object v1

    .line 212
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 215
    :cond_d6
    move-object v11, v1

    .line 216
    check-cast v11, Lkotlinx/coroutines/CoroutineScope;

    .line 218
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 221
    move-result-object v1

    .line 222
    if-ne v1, v5, :cond_e8

    .line 224
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 226
    invoke-static {v1}, Landroidx/compose/runtime/AnchoredGroupPath;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 229
    move-result-object v1

    .line 230
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 233
    :cond_e8
    move-object v12, v1

    .line 234
    check-cast v12, Landroidx/compose/runtime/MutableState;

    .line 236
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 239
    move-result-object v1

    .line 240
    if-ne v1, v5, :cond_fa

    .line 242
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 244
    invoke-static {v1}, Landroidx/compose/runtime/AnchoredGroupPath;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 247
    move-result-object v1

    .line 248
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 251
    :cond_fa
    move-object v13, v1

    .line 252
    check-cast v13, Landroidx/compose/runtime/MutableState;

    .line 254
    invoke-virtual {v9, v11}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 257
    move-result v1

    .line 258
    invoke-virtual {v9, v14}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 261
    move-result v2

    .line 262
    or-int/2addr v1, v2

    .line 263
    invoke-virtual {v9, v15}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 266
    move-result v2

    .line 267
    or-int/2addr v1, v2

    .line 268
    invoke-virtual {v9, v4}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 271
    move-result v2

    .line 272
    or-int/2addr v1, v2

    .line 273
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 276
    move-result-object v2

    .line 277
    if-nez v1, :cond_11b

    .line 279
    if-eq v2, v5, :cond_11b

    .line 281
    move-object/from16 v16, v4

    .line 283
    goto :goto_126

    .line 284
    :cond_11b
    new-instance v10, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda83;

    .line 286
    move-object/from16 v16, v4

    .line 288
    invoke-direct/range {v10 .. v16}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda83;-><init>(Lkotlinx/coroutines/CoroutineScope;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;Landroid/content/Context;Lcom/spotifry/music/ui/spotifried/SpotifriedState;Lkotlin/jvm/functions/Function4;)V

    .line 291
    invoke-virtual {v9, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 294
    move-object v2, v10

    .line 295
    :goto_126
    move-object v6, v2

    .line 296
    check-cast v6, Lkotlin/jvm/functions/Function0;

    .line 298
    move-object v5, v0

    .line 299
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;

    .line 301
    move-object/from16 v4, p0

    .line 303
    move-object/from16 v2, p1

    .line 305
    move/from16 v1, p2

    .line 307
    move-object v7, v12

    .line 308
    move-object v8, v13

    .line 309
    move-object v3, v15

    .line 310
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;-><init>(FLkotlin/jvm/functions/Function0;Lcom/spotifry/music/ui/spotifried/SpotifriedState;Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V

    .line 313
    const v1, 0x2dffb712

    .line 316
    invoke-static {v1, v0, v9}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 319
    move-result-object v0

    .line 320
    const/4 v1, 0x6

    .line 321
    invoke-static {v0, v9, v1}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt;->StoryTheme(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 324
    move-object/from16 v4, v16

    .line 326
    goto :goto_14b

    .line 327
    :cond_146
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 330
    move-object/from16 v4, p3

    .line 332
    :goto_14b
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 335
    move-result-object v7

    .line 336
    if-eqz v7, :cond_161

    .line 338
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda0;

    .line 340
    const/4 v6, 0x1

    .line 341
    move-object/from16 v1, p0

    .line 343
    move-object/from16 v2, p1

    .line 345
    move/from16 v3, p2

    .line 347
    move/from16 v5, p5

    .line 349
    invoke-direct/range {v0 .. v6}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda0;-><init>(Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Lkotlin/jvm/functions/Function0;FLkotlin/jvm/functions/Function4;IB)V

    .line 352
    goto/16 :goto_99

    .line 354
    :cond_161
    return-void
.end method

.method public static final StoryCard(Lcom/spotifry/music/data/spotifried/CardId;Lcom/spotifry/music/ui/spotifried/SpotifriedState;ZLkotlin/jvm/functions/Function0;ZZLandroidx/compose/runtime/ComposerImpl;II)V
    .registers 24

    .line 1
    move-object/from16 v2, p1

    .line 3
    move-object/from16 v7, p6

    .line 5
    move/from16 v0, p7

    .line 7
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    iget-object v3, v2, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->stats:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 15
    const v1, 0x7257201a

    .line 18
    invoke-virtual {v7, v1}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 21
    and-int/lit8 v1, v0, 0x6

    .line 23
    if-nez v1, :cond_27

    .line 25
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 28
    move-result v1

    .line 29
    invoke-virtual {v7, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_24

    .line 35
    const/4 v1, 0x4

    .line 36
    goto :goto_25

    .line 37
    :cond_24
    const/4 v1, 0x2

    .line 38
    :goto_25
    or-int/2addr v1, v0

    .line 39
    goto :goto_28

    .line 40
    :cond_27
    move v1, v0

    .line 41
    :goto_28
    and-int/lit8 v4, v0, 0x30

    .line 43
    if-nez v4, :cond_38

    .line 45
    invoke-virtual {v7, v2}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 48
    move-result v4

    .line 49
    if-eqz v4, :cond_35

    .line 51
    const/16 v4, 0x20

    .line 53
    goto :goto_37

    .line 54
    :cond_35
    const/16 v4, 0x10

    .line 56
    :goto_37
    or-int/2addr v1, v4

    .line 57
    :cond_38
    and-int/lit8 v4, p8, 0x4

    .line 59
    if-eqz v4, :cond_41

    .line 61
    or-int/lit16 v1, v1, 0x180

    .line 63
    :cond_3e
    move/from16 v5, p2

    .line 65
    goto :goto_53

    .line 66
    :cond_41
    and-int/lit16 v5, v0, 0x180

    .line 68
    if-nez v5, :cond_3e

    .line 70
    move/from16 v5, p2

    .line 72
    invoke-virtual {v7, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 75
    move-result v6

    .line 76
    if-eqz v6, :cond_50

    .line 78
    const/16 v6, 0x100

    .line 80
    goto :goto_52

    .line 81
    :cond_50
    const/16 v6, 0x80

    .line 83
    :goto_52
    or-int/2addr v1, v6

    .line 84
    :goto_53
    and-int/lit16 v6, v0, 0xc00

    .line 86
    if-nez v6, :cond_65

    .line 88
    move-object/from16 v6, p3

    .line 90
    invoke-virtual {v7, v6}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 93
    move-result v8

    .line 94
    if-eqz v8, :cond_62

    .line 96
    const/16 v8, 0x800

    .line 98
    goto :goto_64

    .line 99
    :cond_62
    const/16 v8, 0x400

    .line 101
    :goto_64
    or-int/2addr v1, v8

    .line 102
    :cond_65
    and-int/lit8 v8, p8, 0x10

    .line 104
    if-eqz v8, :cond_6e

    .line 106
    or-int/lit16 v1, v1, 0x6000

    .line 108
    :cond_6b
    move/from16 v9, p4

    .line 110
    goto :goto_80

    .line 111
    :cond_6e
    and-int/lit16 v9, v0, 0x6000

    .line 113
    if-nez v9, :cond_6b

    .line 115
    move/from16 v9, p4

    .line 117
    invoke-virtual {v7, v9}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 120
    move-result v10

    .line 121
    if-eqz v10, :cond_7d

    .line 123
    const/16 v10, 0x4000

    .line 125
    goto :goto_7f

    .line 126
    :cond_7d
    const/16 v10, 0x2000

    .line 128
    :goto_7f
    or-int/2addr v1, v10

    .line 129
    :goto_80
    and-int/lit8 v10, p8, 0x20

    .line 131
    const/high16 v11, 0x30000

    .line 133
    if-eqz v10, :cond_8a

    .line 135
    or-int/2addr v1, v11

    .line 136
    :cond_87
    move/from16 v11, p5

    .line 138
    goto :goto_9b

    .line 139
    :cond_8a
    and-int/2addr v11, v0

    .line 140
    if-nez v11, :cond_87

    .line 142
    move/from16 v11, p5

    .line 144
    invoke-virtual {v7, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 147
    move-result v12

    .line 148
    if-eqz v12, :cond_98

    .line 150
    const/high16 v12, 0x20000

    .line 152
    goto :goto_9a

    .line 153
    :cond_98
    const/high16 v12, 0x10000

    .line 155
    :goto_9a
    or-int/2addr v1, v12

    .line 156
    :goto_9b
    const v12, 0x12493

    .line 159
    and-int/2addr v12, v1

    .line 160
    const v13, 0x12492

    .line 163
    const/4 v14, 0x0

    .line 164
    if-eq v12, v13, :cond_a7

    .line 166
    const/4 v12, 0x1

    .line 167
    goto :goto_a8

    .line 168
    :cond_a7
    move v12, v14

    .line 169
    :goto_a8
    and-int/lit8 v13, v1, 0x1

    .line 171
    invoke-virtual {v7, v13, v12}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 174
    move-result v12

    .line 175
    if-eqz v12, :cond_17f

    .line 177
    if-eqz v4, :cond_b3

    .line 179
    move v5, v14

    .line 180
    :cond_b3
    if-eqz v8, :cond_b7

    .line 182
    move v6, v14

    .line 183
    goto :goto_b8

    .line 184
    :cond_b7
    move v6, v9

    .line 185
    :goto_b8
    if-eqz v10, :cond_bb

    .line 187
    move v11, v14

    .line 188
    :cond_bb
    invoke-virtual {p0}, Ljava/lang/Enum;->ordinal()I

    .line 191
    move-result v4

    .line 192
    packed-switch v4, :pswitch_data_198

    .line 195
    const p0, 0x390f999a

    .line 198
    invoke-virtual {v7, p0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 201
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 204
    invoke-static {}, Landroidx/media3/session/MediaSessionStub$$ExternalSyntheticLambda8;->m()V

    .line 207
    return-void

    .line 208
    :pswitch_cf  #0x7
    const v4, 0x390fcedc

    .line 211
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 214
    iget-object v8, v2, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->name:Ljava/lang/String;

    .line 216
    shr-int/lit8 v4, v1, 0x6

    .line 218
    and-int/lit8 v4, v4, 0x70

    .line 220
    and-int/lit16 v9, v1, 0x380

    .line 222
    or-int/2addr v4, v9

    .line 223
    shr-int/lit8 v1, v1, 0x3

    .line 225
    and-int/lit16 v9, v1, 0x1c00

    .line 227
    or-int/2addr v4, v9

    .line 228
    const v9, 0xe000

    .line 231
    and-int/2addr v1, v9

    .line 232
    or-int v10, v4, v1

    .line 234
    move-object/from16 v4, p3

    .line 236
    move-object v9, v7

    .line 237
    move v7, v11

    .line 238
    invoke-static/range {v3 .. v10}, Lcom/spotifry/music/ui/spotifried/CardsKt;->TypeCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lkotlin/jvm/functions/Function0;ZZZLjava/lang/String;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 241
    move-object v7, v9

    .line 242
    move v9, v6

    .line 243
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 246
    goto/16 :goto_17b

    .line 248
    :pswitch_f7  #0x6
    move v9, v6

    .line 249
    const v4, 0x390fc855

    .line 252
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 255
    shr-int/lit8 v1, v1, 0x3

    .line 257
    and-int/lit8 v1, v1, 0x70

    .line 259
    invoke-static {v3, v5, v7, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->SunCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 262
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 265
    goto/16 :goto_17b

    .line 267
    :pswitch_10a  #0x5
    move v9, v6

    .line 268
    const v4, 0x390fc1b8

    .line 271
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 274
    shr-int/lit8 v1, v1, 0x3

    .line 276
    and-int/lit8 v1, v1, 0x70

    .line 278
    invoke-static {v3, v5, v7, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->MonthsCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 281
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 284
    goto :goto_17b

    .line 285
    :pswitch_11c  #0x4
    move v9, v6

    .line 286
    const v4, 0x390fbb15

    .line 289
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 292
    shr-int/lit8 v1, v1, 0x3

    .line 294
    and-int/lit8 v1, v1, 0x70

    .line 296
    invoke-static {v3, v5, v7, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->DayCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 299
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 302
    goto :goto_17b

    .line 303
    :pswitch_12e  #0x3
    move v9, v6

    .line 304
    const v4, 0x390fb0f5

    .line 307
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 310
    iget v4, v2, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->checked:I

    .line 312
    move v6, v5

    .line 313
    iget v5, v2, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->unchecked:I

    .line 315
    shl-int/lit8 v1, v1, 0x3

    .line 317
    and-int/lit16 v8, v1, 0x1c00

    .line 319
    invoke-static/range {v3 .. v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->AgeCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;IIZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 322
    move v5, v6

    .line 323
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 326
    goto :goto_17b

    .line 327
    :pswitch_146  #0x2
    move v9, v6

    .line 328
    const v4, 0x390faa57  # 1.3700999E-4f

    .line 331
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 334
    shr-int/lit8 v1, v1, 0x3

    .line 336
    and-int/lit8 v1, v1, 0x70

    .line 338
    invoke-static {v3, v5, v7, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->HoursCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 341
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 344
    goto :goto_17b

    .line 345
    :pswitch_158  #0x1
    move v9, v6

    .line 346
    const v4, 0x390fa359

    .line 349
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 352
    shr-int/lit8 v1, v1, 0x3

    .line 354
    and-int/lit8 v1, v1, 0x70

    .line 356
    invoke-static {v3, v5, v7, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->TopSongCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 359
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 362
    goto :goto_17b

    .line 363
    :pswitch_16a  #0x0
    move v9, v6

    .line 364
    const v4, 0x390f9c37

    .line 367
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 370
    shr-int/lit8 v1, v1, 0x3

    .line 372
    and-int/lit8 v1, v1, 0x70

    .line 374
    invoke-static {v3, v5, v7, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->IntroCard(Lcom/spotifry/music/data/spotifried/SpotifriedStats;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 377
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 380
    :goto_17b
    move v3, v5

    .line 381
    move v5, v9

    .line 382
    move v6, v11

    .line 383
    goto :goto_183

    .line 384
    :cond_17f
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 387
    goto :goto_17b

    .line 388
    :goto_183
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 391
    move-result-object v9

    .line 392
    if-eqz v9, :cond_197

    .line 394
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda12;

    .line 396
    move-object v1, p0

    .line 397
    move-object/from16 v4, p3

    .line 399
    move/from16 v7, p7

    .line 401
    move/from16 v8, p8

    .line 403
    invoke-direct/range {v0 .. v8}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda12;-><init>(Lcom/spotifry/music/data/spotifried/CardId;Lcom/spotifry/music/ui/spotifried/SpotifriedState;ZLkotlin/jvm/functions/Function0;ZZII)V

    .line 406
    iput-object v0, v9, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 408
    :cond_197
    return-void

    .line 409
    :pswitch_data_198
    .packed-switch 0x0
        :pswitch_16a  #00000000
        :pswitch_158  #00000001
        :pswitch_146  #00000002
        :pswitch_12e  #00000003
        :pswitch_11c  #00000004
        :pswitch_10a  #00000005
        :pswitch_f7  #00000006
        :pswitch_cf  #00000007
    .end packed-switch
.end method

.method public static final StoryShell(Ljava/util/List;ILkotlin/jvm/functions/Function1;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 23

    .line 1
    move-object/from16 v1, p0

    .line 3
    move/from16 v2, p1

    .line 5
    move-object/from16 v3, p2

    .line 7
    move-object/from16 v11, p4

    .line 9
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 12
    const v0, 0x5d98d9

    .line 15
    invoke-virtual {v11, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 18
    invoke-virtual {v11, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 21
    move-result v0

    .line 22
    if-eqz v0, :cond_19

    .line 24
    const/4 v0, 0x4

    .line 25
    goto :goto_1a

    .line 26
    :cond_19
    const/4 v0, 0x2

    .line 27
    :goto_1a
    or-int v0, p5, v0

    .line 29
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 32
    move-result v4

    .line 33
    if-eqz v4, :cond_25

    .line 35
    const/16 v4, 0x20

    .line 37
    goto :goto_27

    .line 38
    :cond_25
    const/16 v4, 0x10

    .line 40
    :goto_27
    or-int/2addr v0, v4

    .line 41
    invoke-virtual {v11, v3}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 44
    move-result v4

    .line 45
    if-eqz v4, :cond_31

    .line 47
    const/16 v4, 0x100

    .line 49
    goto :goto_33

    .line 50
    :cond_31
    const/16 v4, 0x80

    .line 52
    :goto_33
    or-int/2addr v0, v4

    .line 53
    and-int/lit16 v4, v0, 0x493

    .line 55
    const/16 v5, 0x492

    .line 57
    const/4 v15, 0x0

    .line 58
    if-eq v4, v5, :cond_3d

    .line 60
    const/4 v4, 0x1

    .line 61
    goto :goto_3e

    .line 62
    :cond_3d
    move v4, v15

    .line 63
    :goto_3e
    and-int/lit8 v5, v0, 0x1

    .line 65
    invoke-virtual {v11, v5, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 68
    move-result v4

    .line 69
    if-eqz v4, :cond_2a2

    .line 71
    invoke-static {v11}, Lcom/spotifry/music/ui/listening/SunKt;->rememberNoMotion(Landroidx/compose/runtime/ComposerImpl;)Z

    .line 74
    move-result v4

    .line 75
    sget-object v5, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 77
    const/high16 v7, 0x3f800000  # 1.0f

    .line 79
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 82
    move-result-object v8

    .line 83
    sget-object v9, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 85
    sget-object v6, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 87
    invoke-static {v9, v6, v11, v15}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 90
    move-result-object v6

    .line 91
    iget-wide v12, v11, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 93
    invoke-static {v12, v13}, Ljava/lang/Long;->hashCode(J)I

    .line 96
    move-result v9

    .line 97
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 100
    move-result-object v12

    .line 101
    invoke-static {v11, v8}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 104
    move-result-object v8

    .line 105
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 107
    invoke-virtual {v13}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 112
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 115
    iget-boolean v14, v11, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 117
    if-eqz v14, :cond_7a

    .line 119
    invoke-virtual {v11, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 122
    goto :goto_7d

    .line 123
    :cond_7a
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 126
    :goto_7d
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 128
    invoke-static {v11, v6, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 131
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 133
    invoke-static {v11, v12, v6}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 136
    sget-object v12, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 138
    iget-boolean v15, v11, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 140
    if-nez v15, :cond_9b

    .line 142
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 145
    move-result-object v15

    .line 146
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 149
    move-result-object v10

    .line 150
    invoke-static {v15, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 153
    move-result v10

    .line 154
    if-nez v10, :cond_9e

    .line 156
    :cond_9b
    invoke-static {v9, v11, v9, v12}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 159
    :cond_9e
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 161
    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 164
    invoke-static {v5, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 167
    move-result-object v8

    .line 168
    const/high16 v10, 0x41a00000  # 20.0f

    .line 170
    const/high16 v15, 0x41400000  # 12.0f

    .line 172
    invoke-static {v8, v10, v15}, Landroidx/compose/foundation/layout/OffsetKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    .line 175
    move-result-object v8

    .line 176
    new-instance v10, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 178
    new-instance v15, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 180
    const/4 v7, 0x3

    .line 181
    invoke-direct {v15, v7}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 184
    const/high16 v7, 0x40800000  # 4.0f

    .line 186
    invoke-direct {v10, v7, v15}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 189
    sget-object v7, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 191
    const/4 v15, 0x6

    .line 192
    invoke-static {v10, v7, v11, v15}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 195
    move-result-object v7

    .line 196
    move v10, v4

    .line 197
    move-object v15, v5

    .line 198
    iget-wide v4, v11, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 200
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 203
    move-result v4

    .line 204
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 207
    move-result-object v5

    .line 208
    invoke-static {v11, v8}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 211
    move-result-object v8

    .line 212
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 215
    move/from16 v16, v10

    .line 217
    iget-boolean v10, v11, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 219
    if-eqz v10, :cond_e0

    .line 221
    invoke-virtual {v11, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 224
    goto :goto_e3

    .line 225
    :cond_e0
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 228
    :goto_e3
    invoke-static {v11, v7, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 231
    invoke-static {v11, v5, v6}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 234
    iget-boolean v5, v11, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 236
    if-nez v5, :cond_fb

    .line 238
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 241
    move-result-object v5

    .line 242
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 245
    move-result-object v6

    .line 246
    invoke-static {v5, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 249
    move-result v5

    .line 250
    if-nez v5, :cond_fe

    .line 252
    :cond_fb
    invoke-static {v4, v11, v4, v12}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 255
    :cond_fe
    invoke-static {v11, v8, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 258
    const v4, 0x209fc799

    .line 261
    invoke-virtual {v11, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 264
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->getIndices(Ljava/util/Collection;)Lkotlin/ranges/IntRange;

    .line 267
    move-result-object v4

    .line 268
    invoke-virtual {v4}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 271
    move-result-object v10

    .line 272
    :goto_10f
    move-object v4, v10

    .line 273
    check-cast v4, Lkotlin/ranges/IntProgressionIterator;

    .line 275
    iget-boolean v4, v4, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 277
    if-eqz v4, :cond_184

    .line 279
    move-object v4, v10

    .line 280
    check-cast v4, Lkotlin/collections/IntIterator;

    .line 282
    invoke-virtual {v4}, Lkotlin/collections/IntIterator;->nextInt()I

    .line 285
    move-result v4

    .line 286
    if-gt v4, v2, :cond_122

    .line 288
    const/high16 v4, 0x3f800000  # 1.0f

    .line 290
    goto :goto_125

    .line 291
    :cond_122
    const v4, 0x3e3851ec  # 0.18f

    .line 294
    :goto_125
    if-eqz v16, :cond_12d

    .line 296
    new-instance v5, Landroidx/compose/animation/core/SnapSpec;

    .line 298
    invoke-direct {v5}, Ljava/lang/Object;-><init>()V

    .line 301
    goto :goto_137

    .line 302
    :cond_12d
    const/16 v5, 0x12c

    .line 304
    const/16 v6, 0x96

    .line 306
    const/4 v7, 0x0

    .line 307
    const/4 v8, 0x4

    .line 308
    invoke-static {v5, v6, v7, v8}, Landroidx/compose/animation/core/ArcSplineKt;->tween$default(IILandroidx/compose/animation/core/Easing;I)Landroidx/compose/animation/core/TweenSpec;

    .line 311
    move-result-object v5

    .line 312
    :goto_137
    const/16 v8, 0xc00

    .line 314
    const/16 v9, 0x14

    .line 316
    const-string v6, "segment"

    .line 318
    move-object v7, v11

    .line 319
    const/high16 v12, 0x3f800000  # 1.0f

    .line 321
    const/4 v13, 0x1

    .line 322
    invoke-static/range {v4 .. v9}, Landroidx/compose/animation/core/AnimateAsStateKt;->animateFloatAsState(FLandroidx/compose/animation/core/FiniteAnimationSpec;Ljava/lang/String;Landroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/runtime/State;

    .line 325
    move-result-object v4

    .line 326
    new-instance v5, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 328
    invoke-direct {v5, v12, v13}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 331
    const/high16 v6, 0x40400000  # 3.0f

    .line 333
    invoke-static {v5, v6}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 336
    move-result-object v5

    .line 337
    const-string v6, "segment"

    .line 339
    invoke-static {v5, v6}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 342
    move-result-object v5

    .line 343
    const/high16 v6, 0x40000000  # 2.0f

    .line 345
    invoke-static {v6}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    .line 348
    move-result-object v6

    .line 349
    invoke-static {v5, v6}, Landroidx/compose/ui/draw/ClipKt;->clip(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    .line 352
    move-result-object v5

    .line 353
    sget-object v6, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 355
    invoke-virtual {v7, v6}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 358
    move-result-object v6

    .line 359
    check-cast v6, Landroidx/compose/material3/ColorScheme;

    .line 361
    iget-wide v8, v6, Landroidx/compose/material3/ColorScheme;->onBackground:J

    .line 363
    invoke-interface {v4}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 366
    move-result-object v4

    .line 367
    check-cast v4, Ljava/lang/Number;

    .line 369
    invoke-virtual {v4}, Ljava/lang/Number;->floatValue()F

    .line 372
    move-result v4

    .line 373
    invoke-static {v4, v8, v9}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 376
    move-result-wide v8

    .line 377
    sget-object v4, Landroidx/compose/ui/graphics/ColorKt;->RectangleShape:Landroidx/compose/ui/graphics/RectangleShapeKt$RectangleShape$1;

    .line 379
    invoke-static {v5, v8, v9, v4}, Landroidx/compose/foundation/ImageKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    .line 382
    move-result-object v4

    .line 383
    const/4 v5, 0x0

    .line 384
    invoke-static {v4, v7, v5}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 387
    move-object v11, v7

    .line 388
    goto :goto_10f

    .line 389
    :cond_184
    move-object v7, v11

    .line 390
    move/from16 v11, v16

    .line 392
    const/4 v5, 0x0

    .line 393
    const/high16 v12, 0x3f800000  # 1.0f

    .line 395
    const/4 v13, 0x1

    .line 396
    invoke-virtual {v7, v5}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 399
    invoke-virtual {v7, v13}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 402
    new-instance v4, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 404
    invoke-direct {v4, v12, v13}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 407
    invoke-static {v4, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 410
    move-result-object v4

    .line 411
    const-string v5, "tap"

    .line 413
    invoke-static {v4, v5}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 416
    move-result-object v4

    .line 417
    and-int/lit8 v5, v0, 0x70

    .line 419
    const/16 v6, 0x20

    .line 421
    if-ne v5, v6, :cond_1a8

    .line 423
    move v6, v13

    .line 424
    goto :goto_1a9

    .line 425
    :cond_1a8
    const/4 v6, 0x0

    .line 426
    :goto_1a9
    invoke-virtual {v7, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 429
    move-result v8

    .line 430
    or-int/2addr v6, v8

    .line 431
    and-int/lit16 v0, v0, 0x380

    .line 433
    const/16 v8, 0x100

    .line 435
    if-ne v0, v8, :cond_1b6

    .line 437
    move v8, v13

    .line 438
    goto :goto_1b7

    .line 439
    :cond_1b6
    const/4 v8, 0x0

    .line 440
    :goto_1b7
    or-int/2addr v6, v8

    .line 441
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 444
    move-result-object v8

    .line 445
    sget-object v9, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 447
    if-nez v6, :cond_1c2

    .line 449
    if-ne v8, v9, :cond_1ca

    .line 451
    :cond_1c2
    new-instance v8, Lcom/spotifry/music/ui/FadeBarKt$$ExternalSyntheticLambda4;

    .line 453
    invoke-direct {v8, v2, v1, v3}, Lcom/spotifry/music/ui/FadeBarKt$$ExternalSyntheticLambda4;-><init>(ILjava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 456
    invoke-virtual {v7, v8}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 459
    :cond_1ca
    check-cast v8, Lkotlin/jvm/functions/Function1;

    .line 461
    const/4 v6, 0x0

    .line 462
    invoke-static {v4, v6, v8}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 465
    move-result-object v4

    .line 466
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 469
    move-result-object v6

    .line 470
    const/16 v8, 0x20

    .line 472
    if-ne v5, v8, :cond_1db

    .line 474
    move v5, v13

    .line 475
    goto :goto_1dc

    .line 476
    :cond_1db
    const/4 v5, 0x0

    .line 477
    :goto_1dc
    invoke-virtual {v7, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 480
    move-result v8

    .line 481
    or-int/2addr v5, v8

    .line 482
    const/16 v8, 0x100

    .line 484
    if-ne v0, v8, :cond_1e7

    .line 486
    move v0, v13

    .line 487
    goto :goto_1e8

    .line 488
    :cond_1e7
    const/4 v0, 0x0

    .line 489
    :goto_1e8
    or-int/2addr v5, v0

    .line 490
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 493
    move-result-object v0

    .line 494
    if-nez v5, :cond_1f1

    .line 496
    if-ne v0, v9, :cond_1f9

    .line 498
    :cond_1f1
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;

    .line 500
    invoke-direct {v0, v2, v1, v3}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;-><init>(ILjava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 503
    invoke-virtual {v7, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 506
    :cond_1f9
    check-cast v0, Landroidx/compose/ui/input/pointer/PointerInputEventHandler;

    .line 508
    sget-object v5, Landroidx/compose/ui/input/pointer/SuspendingPointerInputFilterKt;->EmptyPointerEvent:Landroidx/compose/ui/input/pointer/PointerEvent;

    .line 510
    new-instance v5, Landroidx/compose/ui/input/pointer/SuspendPointerInputElement;

    .line 512
    const/4 v8, 0x4

    .line 513
    invoke-direct {v5, v1, v6, v0, v8}, Landroidx/compose/ui/input/pointer/SuspendPointerInputElement;-><init>(Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/ui/input/pointer/PointerInputEventHandler;I)V

    .line 516
    invoke-interface {v4, v5}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 519
    move-result-object v0

    .line 520
    sget-object v4, Landroidx/compose/ui/Alignment$Companion;->Center:Landroidx/compose/ui/BiasAlignment;

    .line 522
    const/4 v5, 0x0

    .line 523
    invoke-static {v4, v5}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 526
    move-result-object v5

    .line 527
    iget-wide v13, v7, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 529
    invoke-static {v13, v14}, Ljava/lang/Long;->hashCode(J)I

    .line 532
    move-result v6

    .line 533
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 536
    move-result-object v8

    .line 537
    invoke-static {v7, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 540
    move-result-object v0

    .line 541
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 543
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 546
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 548
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 551
    iget-boolean v13, v7, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 553
    if-eqz v13, :cond_22e

    .line 555
    invoke-virtual {v7, v10}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 558
    goto :goto_231

    .line 559
    :cond_22e
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 562
    :goto_231
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 564
    invoke-static {v7, v5, v10}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 567
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 569
    invoke-static {v7, v8, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 572
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 574
    iget-boolean v8, v7, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 576
    if-nez v8, :cond_24f

    .line 578
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 581
    move-result-object v8

    .line 582
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 585
    move-result-object v10

    .line 586
    invoke-static {v8, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 589
    move-result v8

    .line 590
    if-nez v8, :cond_252

    .line 592
    :cond_24f
    invoke-static {v6, v7, v6, v5}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 595
    :cond_252
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 597
    invoke-static {v7, v0, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 600
    invoke-static {v1}, Lkotlin/io/ByteStreamsKt;->getIndices(Ljava/util/Collection;)Lkotlin/ranges/IntRange;

    .line 603
    move-result-object v0

    .line 604
    invoke-static {v2, v0}, Lkotlin/ResultKt;->coerceIn(ILkotlin/ranges/IntRange;)I

    .line 607
    move-result v0

    .line 608
    invoke-interface {v1, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 611
    move-result-object v0

    .line 612
    invoke-static {v15, v12}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 615
    move-result-object v5

    .line 616
    invoke-virtual {v7, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(Z)Z

    .line 619
    move-result v6

    .line 620
    invoke-virtual {v7}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 623
    move-result-object v8

    .line 624
    if-nez v6, :cond_273

    .line 626
    if-ne v8, v9, :cond_27c

    .line 628
    :cond_273
    new-instance v8, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda3;

    .line 630
    const/4 v13, 0x1

    .line 631
    invoke-direct {v8, v13, v11}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda3;-><init>(BZ)V

    .line 634
    invoke-virtual {v7, v8}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 637
    :cond_27c
    move-object v6, v8

    .line 638
    check-cast v6, Lkotlin/jvm/functions/Function1;

    .line 640
    new-instance v8, Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase$$ExternalSyntheticLambda0;

    .line 642
    move-object/from16 v13, p3

    .line 644
    const/4 v9, 0x2

    .line 645
    invoke-direct {v8, v13, v9}, Landroidx/sqlite/db/framework/FrameworkSQLiteDatabase$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;B)V

    .line 648
    const v9, -0x8cb6a87

    .line 651
    invoke-static {v9, v8, v7}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 654
    move-result-object v10

    .line 655
    const v12, 0x186c30

    .line 658
    const-string v8, "card"

    .line 660
    const/4 v9, 0x0

    .line 661
    move-object v11, v7

    .line 662
    move-object v7, v4

    .line 663
    move-object v4, v0

    .line 664
    invoke-static/range {v4 .. v12}, Landroidx/compose/animation/Scale;->AnimatedContent(Ljava/lang/Object;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/BiasAlignment;Ljava/lang/String;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 667
    const/4 v0, 0x1

    .line 668
    invoke-virtual {v11, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 671
    invoke-virtual {v11, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 674
    goto :goto_2a7

    .line 675
    :cond_2a2
    move-object/from16 v13, p3

    .line 677
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 680
    :goto_2a7
    invoke-virtual {v11}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 683
    move-result-object v7

    .line 684
    if-eqz v7, :cond_2b9

    .line 686
    new-instance v0, Lcom/spotifry/music/ui/home/ArtistPageKt$$ExternalSyntheticLambda12;

    .line 688
    const/16 v6, 0x10

    .line 690
    move/from16 v5, p5

    .line 692
    move-object v4, v13

    .line 693
    invoke-direct/range {v0 .. v6}, Lcom/spotifry/music/ui/home/ArtistPageKt$$ExternalSyntheticLambda12;-><init>(Ljava/lang/Object;ILjava/lang/Object;Lkotlin/Function;IB)V

    .line 696
    iput-object v0, v7, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 698
    :cond_2b9
    return-void
.end method

.method public static final StoryTheme(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V
    .registers 11

    .line 1
    const v0, -0xe910ddf

    .line 4
    invoke-virtual {p1, v0}, Landroidx/compose/runtime/ComposerImpl;->startRestartGroup(I)Landroidx/compose/runtime/ComposerImpl;

    .line 7
    and-int/lit8 v0, p2, 0x3

    .line 9
    const/4 v1, 0x2

    .line 10
    if-eq v0, v1, :cond_d

    .line 12
    const/4 v0, 0x1

    .line 13
    goto :goto_e

    .line 14
    :cond_d
    const/4 v0, 0x0

    .line 15
    :goto_e
    and-int/lit8 v1, p2, 0x1

    .line 17
    invoke-virtual {p1, v1, v0}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 20
    move-result v0

    .line 21
    if-eqz v0, :cond_2f

    .line 23
    sget-wide v1, Lcom/spotifry/music/ui/theme/ColorKt;->StoryBlack:J

    .line 25
    new-instance v0, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda137;

    .line 27
    const/16 v3, 0x9

    .line 29
    invoke-direct {v0, p0, v3}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda137;-><init>(Landroidx/compose/runtime/internal/ComposableLambdaImpl;B)V

    .line 32
    const v3, -0x15b43e2b

    .line 35
    invoke-static {v3, v0, p1}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 38
    move-result-object v4

    .line 39
    const/16 v6, 0x186

    .line 41
    const/4 v7, 0x2

    .line 42
    const/4 v3, 0x0

    .line 43
    move-object v5, p1

    .line 44
    invoke-static/range {v1 .. v7}, Lcom/spotifry/music/ui/theme/ThemeKt;->AlwaysDark-KTwxG1Y(JZLandroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 47
    goto :goto_33

    .line 48
    :cond_2f
    move-object v5, p1

    .line 49
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 52
    :goto_33
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 55
    move-result-object p1

    .line 56
    if-eqz p1, :cond_42

    .line 58
    new-instance v0, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda137;

    .line 60
    const/16 v1, 0xa

    .line 62
    invoke-direct {v0, p0, p2, v1}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda137;-><init>(Landroidx/compose/runtime/internal/ComposableLambdaImpl;IB)V

    .line 65
    iput-object v0, p1, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 67
    :cond_42
    return-void
.end method
