# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$1:F

.field public final synthetic f$2:F

.field public final synthetic f$3:F

.field public final synthetic f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;FFFLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 6
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$1:F

    .line 8
    iput p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$2:F

    .line 10
    iput p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$3:F

    .line 12
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 14
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    check-cast p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;

    .line 3
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 6
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 8
    invoke-virtual {v0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 11
    move-result-object v0

    .line 12
    check-cast v0, Ljava/lang/Number;

    .line 14
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 17
    move-result v0

    .line 18
    const v1, 0x3f0ccccd  # 0.55f

    .line 21
    mul-float/2addr v0, v1

    .line 22
    invoke-virtual {p1, v0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 25
    iget-object v0, p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->graphicsDensity:Landroidx/compose/ui/unit/Density;

    .line 27
    invoke-interface {v0}, Landroidx/compose/ui/unit/Density;->getDensity()F

    .line 30
    move-result v0

    .line 31
    iget v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$1:F

    .line 33
    mul-float/2addr v0, v1

    .line 34
    iget-object v1, p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->graphicsDensity:Landroidx/compose/ui/unit/Density;

    .line 36
    invoke-interface {v1}, Landroidx/compose/ui/unit/Density;->getDensity()F

    .line 39
    move-result v1

    .line 40
    const/high16 v2, 0x42700000  # 60.0f

    .line 42
    mul-float/2addr v1, v2

    .line 43
    sub-float/2addr v0, v1

    .line 44
    iget-object v1, p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->graphicsDensity:Landroidx/compose/ui/unit/Density;

    .line 46
    invoke-interface {v1}, Landroidx/compose/ui/unit/Density;->getDensity()F

    .line 49
    move-result v1

    .line 50
    iget v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$2:F

    .line 52
    mul-float/2addr v1, v2

    .line 53
    iget v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$3:F

    .line 55
    mul-float/2addr v1, v2

    .line 56
    sub-float/2addr v0, v1

    .line 57
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 59
    invoke-virtual {v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;->getFloatValue()F

    .line 62
    move-result v1

    .line 63
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;->f$5:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 65
    invoke-virtual {p0}, Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;->getFloatValue()F

    .line 68
    move-result p0

    .line 69
    sub-float/2addr v1, p0

    .line 70
    iget-object p0, p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->graphicsDensity:Landroidx/compose/ui/unit/Density;

    .line 72
    invoke-interface {p0}, Landroidx/compose/ui/unit/Density;->getDensity()F

    .line 75
    move-result p0

    .line 76
    const/high16 v2, 0x41c00000  # 24.0f

    .line 78
    mul-float/2addr p0, v2

    .line 79
    add-float/2addr p0, v1

    .line 80
    sub-float/2addr p0, v0

    .line 81
    const/4 v0, 0x0

    .line 82
    cmpg-float v1, p0, v0

    .line 84
    if-gez v1, :cond_56

    .line 86
    move p0, v0

    .line 87
    :cond_56
    invoke-virtual {p1, p0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setTranslationY(F)V

    .line 90
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 92
    return-object p0
.end method
