# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Ljava/util/List;

.field public final synthetic f$1:J

.field public final synthetic f$2:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$3:I

.field public final synthetic f$4:I

.field public final synthetic f$5:J

.field public final synthetic f$6:Ljava/lang/Integer;

.field public final synthetic f$7:J

.field public final synthetic f$8:Lcom/spotifry/music/data/spotifried/AgeStats;


# direct methods
.method public synthetic constructor <init>(Ljava/util/List;JLandroidx/compose/animation/core/Animatable;IIJLjava/lang/Integer;JLcom/spotifry/music/data/spotifried/AgeStats;)V
    .registers 13

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$0:Ljava/util/List;

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 10
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$3:I

    .line 12
    iput p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$4:I

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$5:J

    .line 16
    iput-object p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$6:Ljava/lang/Integer;

    .line 18
    iput-wide p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$7:J

    .line 20
    iput-object p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$8:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 22
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 68

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v4, v3, 0x6

    .line 24
    if-nez v4, :cond_23

    .line 26
    invoke-virtual {v2, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v4

    .line 30
    if-eqz v4, :cond_21

    .line 32
    const/4 v4, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v4, 0x2

    .line 35
    :goto_22
    or-int/2addr v3, v4

    .line 36
    :cond_23
    and-int/lit8 v4, v3, 0x13

    .line 38
    const/16 v6, 0x12

    .line 40
    const/4 v7, 0x1

    .line 41
    const/4 v8, 0x0

    .line 42
    if-eq v4, v6, :cond_2d

    .line 44
    move v4, v7

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move v4, v8

    .line 47
    :goto_2e
    and-int/lit8 v6, v3, 0x1

    .line 49
    invoke-virtual {v2, v6, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v4

    .line 53
    if-eqz v4, :cond_4c8

    .line 55
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 58
    move-result v4

    .line 59
    const/high16 v6, 0x41b00000  # 22.0f

    .line 61
    sub-float/2addr v4, v6

    .line 62
    sget-object v9, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 64
    const/16 v10, 0xb

    .line 66
    invoke-static {v10}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 69
    move-result-wide v12

    .line 70
    const/16 v25, 0xe

    .line 72
    invoke-static/range {v25 .. v25}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 75
    move-result-wide v20

    .line 76
    const/16 v23, 0x0

    .line 78
    const v24, 0xfdfffd

    .line 81
    const-wide/16 v10, 0x0

    .line 83
    const/4 v14, 0x0

    .line 84
    const/4 v15, 0x0

    .line 85
    const/16 v16, 0x0

    .line 87
    const-wide/16 v17, 0x0

    .line 89
    const/16 v19, 0x0

    .line 91
    const/16 v22, 0x0

    .line 93
    invoke-static/range {v9 .. v24}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 96
    move-result-object v9

    .line 97
    sget-object v10, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 99
    invoke-virtual {v2, v10}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 102
    move-result-object v10

    .line 103
    check-cast v10, Landroidx/compose/ui/unit/Density;

    .line 105
    iget-object v11, v9, Landroidx/compose/ui/text/TextStyle;->paragraphStyle:Landroidx/compose/ui/text/ParagraphStyle;

    .line 107
    iget-wide v11, v11, Landroidx/compose/ui/text/ParagraphStyle;->lineHeight:J

    .line 109
    invoke-interface {v10, v11, v12}, Landroidx/compose/ui/unit/Density;->toDp-GaN1DYA(J)F

    .line 112
    move-result v42

    .line 113
    iget-object v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$0:Ljava/util/List;

    .line 115
    invoke-interface {v11}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 118
    move-result-object v12

    .line 119
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 122
    move-result v13

    .line 123
    const/16 v43, 0x0

    .line 125
    if-nez v13, :cond_81

    .line 127
    move-object/from16 v13, v43

    .line 129
    goto :goto_b3

    .line 130
    :cond_81
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 133
    move-result-object v13

    .line 134
    check-cast v13, Lkotlin/Pair;

    .line 136
    iget-object v13, v13, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 138
    check-cast v13, Ljava/lang/Number;

    .line 140
    invoke-virtual {v13}, Ljava/lang/Number;->intValue()I

    .line 143
    move-result v13

    .line 144
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 147
    move-result-object v13

    .line 148
    :cond_93
    :goto_93
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 151
    move-result v14

    .line 152
    if-eqz v14, :cond_b3

    .line 154
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 157
    move-result-object v14

    .line 158
    check-cast v14, Lkotlin/Pair;

    .line 160
    iget-object v14, v14, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 162
    check-cast v14, Ljava/lang/Number;

    .line 164
    invoke-virtual {v14}, Ljava/lang/Number;->intValue()I

    .line 167
    move-result v14

    .line 168
    invoke-static {v14}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 171
    move-result-object v14

    .line 172
    invoke-virtual {v13, v14}, Ljava/lang/Integer;->compareTo(Ljava/lang/Object;)I

    .line 175
    move-result v15

    .line 176
    if-gez v15, :cond_93

    .line 178
    move-object v13, v14

    .line 179
    goto :goto_93

    .line 180
    :cond_b3
    :goto_b3
    if-eqz v13, :cond_ba

    .line 182
    invoke-virtual {v13}, Ljava/lang/Integer;->intValue()I

    .line 185
    move-result v12

    .line 186
    goto :goto_bb

    .line 187
    :cond_ba
    move v12, v8

    .line 188
    :goto_bb
    const/high16 v13, 0x41400000  # 12.0f

    .line 190
    sub-float v44, v4, v13

    .line 192
    add-float v13, v6, v42

    .line 194
    const/high16 v14, 0x41000000  # 8.0f

    .line 196
    add-float/2addr v13, v14

    .line 197
    const/high16 v26, 0x40800000  # 4.0f

    .line 199
    add-float v13, v13, v26

    .line 201
    sub-float v13, v44, v13

    .line 203
    const/4 v15, 0x0

    .line 204
    const/high16 v6, 0x41200000  # 10.0f

    .line 206
    if-nez v12, :cond_d1

    .line 208
    :goto_cf
    move v12, v6

    .line 209
    goto :goto_fa

    .line 210
    :cond_d1
    new-instance v5, Landroidx/compose/ui/unit/Dp;

    .line 212
    invoke-direct {v5, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 215
    new-instance v6, Landroidx/compose/ui/unit/Dp;

    .line 217
    invoke-direct {v6, v13}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 220
    new-instance v13, Landroidx/compose/ui/unit/Dp;

    .line 222
    invoke-direct {v13, v15}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 225
    invoke-virtual {v6, v13}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 228
    move-result v16

    .line 229
    if-gez v16, :cond_e7

    .line 231
    move-object v6, v13

    .line 232
    :cond_e7
    iget v6, v6, Landroidx/compose/ui/unit/Dp;->value:F

    .line 234
    int-to-float v12, v12

    .line 235
    div-float/2addr v6, v12

    .line 236
    new-instance v12, Landroidx/compose/ui/unit/Dp;

    .line 238
    invoke-direct {v12, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 241
    invoke-virtual {v5, v12}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 244
    move-result v6

    .line 245
    if-lez v6, :cond_f7

    .line 247
    move-object v5, v12

    .line 248
    :cond_f7
    iget v6, v5, Landroidx/compose/ui/unit/Dp;->value:F

    .line 250
    goto :goto_cf

    .line 251
    :goto_fa
    const v5, 0x3f4ccccd  # 0.8f

    .line 254
    mul-float/2addr v5, v12

    .line 255
    new-instance v6, Landroidx/compose/ui/unit/Dp;

    .line 257
    invoke-direct {v6, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 260
    new-instance v5, Landroidx/compose/ui/unit/Dp;

    .line 262
    const/high16 v13, 0x40400000  # 3.0f

    .line 264
    invoke-direct {v5, v13}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 267
    new-instance v13, Landroidx/compose/ui/unit/Dp;

    .line 269
    invoke-direct {v13, v14}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 272
    invoke-static {v6, v5, v13}, Lkotlin/ResultKt;->coerceIn(Landroidx/compose/ui/unit/Dp;Landroidx/compose/ui/unit/Dp;Landroidx/compose/ui/unit/Dp;)Ljava/lang/Comparable;

    .line 275
    move-result-object v5

    .line 276
    check-cast v5, Landroidx/compose/ui/unit/Dp;

    .line 278
    iget v5, v5, Landroidx/compose/ui/unit/Dp;->value:F

    .line 280
    const/high16 v6, 0x41900000  # 18.0f

    .line 282
    invoke-interface {v10, v6}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 285
    move-result v6

    .line 286
    invoke-static {v8, v2, v8, v7}, Landroidx/compose/ui/text/ParagraphKt;->rememberTextMeasurer(ILandroidx/compose/runtime/ComposerImpl;II)Landroidx/compose/ui/text/TextMeasurer;

    .line 289
    move-result-object v45

    .line 290
    sget-object v13, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 292
    move-object/from16 v16, v1

    .line 294
    const/high16 v1, 0x3f800000  # 1.0f

    .line 296
    move/from16 p3, v3

    .line 298
    invoke-static {v13, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 301
    move-result-object v3

    .line 302
    invoke-virtual {v2, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 305
    move-result v17

    .line 306
    move-object/from16 v19, v3

    .line 308
    move/from16 v18, v4

    .line 310
    iget-wide v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$1:J

    .line 312
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 315
    move-result v20

    .line 316
    or-int v17, v17, v20

    .line 318
    invoke-virtual {v2, v11}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 321
    move-result v20

    .line 322
    or-int v17, v17, v20

    .line 324
    move/from16 v20, v7

    .line 326
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 328
    invoke-virtual {v2, v7}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 331
    move-result v21

    .line 332
    or-int v17, v17, v21

    .line 334
    move-object/from16 v21, v10

    .line 336
    iget v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$3:I

    .line 338
    invoke-virtual {v2, v10}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 341
    move-result v22

    .line 342
    or-int v17, v17, v22

    .line 344
    move-object/from16 v22, v11

    .line 346
    iget v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$4:I

    .line 348
    invoke-virtual {v2, v11}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 351
    move-result v23

    .line 352
    or-int v17, v17, v23

    .line 354
    invoke-virtual {v2, v12}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 357
    move-result v23

    .line 358
    or-int v17, v17, v23

    .line 360
    move-object/from16 v23, v13

    .line 362
    move/from16 v24, v14

    .line 364
    iget-wide v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$5:J

    .line 366
    invoke-virtual {v2, v13, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 369
    move-result v27

    .line 370
    or-int v17, v17, v27

    .line 372
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 375
    move-result v27

    .line 376
    or-int v17, v17, v27

    .line 378
    and-int/lit8 v1, p3, 0xe

    .line 380
    const/4 v8, 0x4

    .line 381
    if-ne v1, v8, :cond_181

    .line 383
    move/from16 v1, v20

    .line 385
    goto :goto_182

    .line 386
    :cond_181
    const/4 v1, 0x0

    .line 387
    :goto_182
    or-int v17, v17, v1

    .line 389
    move v1, v6

    .line 390
    iget-object v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$6:Ljava/lang/Integer;

    .line 392
    invoke-virtual {v2, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 395
    move-result v25

    .line 396
    or-int v17, v17, v25

    .line 398
    move-object/from16 v28, v9

    .line 400
    iget-wide v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$7:J

    .line 402
    invoke-virtual {v2, v8, v9}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 405
    move-result v29

    .line 406
    or-int v17, v17, v29

    .line 408
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 411
    move-result-object v15

    .line 412
    sget-object v0, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 414
    if-nez v17, :cond_1bb

    .line 416
    if-eq v15, v0, :cond_1bb

    .line 418
    move-object/from16 v46, v0

    .line 420
    move/from16 v48, v1

    .line 422
    move-object v0, v2

    .line 423
    move-object/from16 v55, v6

    .line 425
    move-wide/from16 v56, v8

    .line 427
    move v3, v10

    .line 428
    move v4, v11

    .line 429
    move/from16 v53, v12

    .line 431
    move-object/from16 v2, v16

    .line 433
    move-object/from16 v49, v19

    .line 435
    move-object/from16 v47, v21

    .line 437
    move-object/from16 v54, v22

    .line 439
    move-object/from16 v50, v23

    .line 441
    move/from16 v52, v24

    .line 443
    goto :goto_1e3

    .line 444
    :cond_1bb
    move v15, v1

    .line 445
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;

    .line 447
    move-object/from16 v46, v0

    .line 449
    move-object v0, v2

    .line 450
    move/from16 v48, v15

    .line 452
    move/from16 v2, v18

    .line 454
    move-object/from16 v49, v19

    .line 456
    move-object/from16 v47, v21

    .line 458
    move-object/from16 v50, v23

    .line 460
    move/from16 v52, v24

    .line 462
    move v15, v5

    .line 463
    move-object/from16 v5, v22

    .line 465
    invoke-direct/range {v1 .. v16}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;-><init>(FJLjava/util/List;Ljava/lang/Integer;Landroidx/compose/animation/core/Animatable;JIIFJFLandroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;)V

    .line 468
    move-object/from16 v54, v5

    .line 470
    move-object/from16 v55, v6

    .line 472
    move-wide/from16 v56, v8

    .line 474
    move v3, v10

    .line 475
    move v4, v11

    .line 476
    move/from16 v53, v12

    .line 478
    move-object/from16 v2, v16

    .line 480
    invoke-virtual {v0, v1}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 483
    move-object v15, v1

    .line 484
    :goto_1e3
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 486
    const/4 v1, 0x6

    .line 487
    move-object/from16 v5, v49

    .line 489
    invoke-static {v5, v15, v0, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 492
    sub-int v11, v4, v3

    .line 494
    const/16 v1, 0x64

    .line 496
    if-le v11, v1, :cond_1f4

    .line 498
    const/16 v1, 0x28

    .line 500
    goto :goto_1f6

    .line 501
    :cond_1f4
    const/16 v1, 0x14

    .line 503
    :goto_1f6
    const v5, -0x1f59f95

    .line 506
    invoke-virtual {v0, v5}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 509
    new-instance v5, Lkotlin/ranges/IntRange;

    .line 511
    add-int v10, v3, v1

    .line 513
    const/4 v6, 0x1

    .line 514
    sub-int/2addr v10, v6

    .line 515
    div-int/2addr v10, v1

    .line 516
    mul-int/2addr v10, v1

    .line 517
    invoke-direct {v5, v10, v4, v6}, Lkotlin/ranges/IntProgression;-><init>(III)V

    .line 520
    invoke-static {v1, v5}, Lkotlin/ResultKt;->step(ILkotlin/ranges/IntRange;)Lkotlin/ranges/IntProgression;

    .line 523
    move-result-object v1

    .line 524
    invoke-virtual {v1}, Lkotlin/ranges/IntProgression;->iterator()Ljava/util/Iterator;

    .line 527
    move-result-object v1

    .line 528
    :goto_20f
    move-object v5, v1

    .line 529
    check-cast v5, Lkotlin/ranges/IntProgressionIterator;

    .line 531
    iget-boolean v5, v5, Lkotlin/ranges/IntProgressionIterator;->hasNext:Z

    .line 533
    const/high16 v8, 0x3f000000  # 0.5f

    .line 535
    if-eqz v5, :cond_28d

    .line 537
    move-object v5, v1

    .line 538
    check-cast v5, Lkotlin/collections/IntIterator;

    .line 540
    invoke-virtual {v5}, Lkotlin/collections/IntIterator;->nextInt()I

    .line 543
    move-result v5

    .line 544
    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    .line 547
    move-result-object v9

    .line 548
    sget-object v10, Landroidx/compose/ui/Alignment$Companion;->BottomStart:Landroidx/compose/ui/BiasAlignment;

    .line 550
    move-object/from16 v11, v50

    .line 552
    invoke-virtual {v2, v11, v10}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;)Landroidx/compose/ui/Modifier;

    .line 555
    move-result-object v10

    .line 556
    invoke-static {v2, v3, v4, v5}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 559
    move-result v5

    .line 560
    new-instance v12, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;

    .line 562
    invoke-direct {v12, v5, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;-><init>(FF)V

    .line 565
    invoke-static {v10, v12}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 568
    move-result-object v5

    .line 569
    move v10, v3

    .line 570
    move v8, v4

    .line 571
    move-object v3, v5

    .line 572
    invoke-static {v0}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 575
    move-result-wide v4

    .line 576
    const/16 v24, 0x0

    .line 578
    const v25, 0x1fff8

    .line 581
    move-object v12, v7

    .line 582
    const-wide/16 v6, 0x0

    .line 584
    move v13, v8

    .line 585
    const/4 v8, 0x0

    .line 586
    move-object/from16 v16, v2

    .line 588
    move-object v2, v9

    .line 589
    const/4 v9, 0x0

    .line 590
    move v14, v10

    .line 591
    const/4 v10, 0x0

    .line 592
    move-object v15, v12

    .line 593
    const-wide/16 v11, 0x0

    .line 595
    move/from16 v17, v13

    .line 597
    const/4 v13, 0x0

    .line 598
    move/from16 v19, v14

    .line 600
    move-object/from16 v18, v15

    .line 602
    const-wide/16 v14, 0x0

    .line 604
    move-object/from16 v21, v16

    .line 606
    const/16 v16, 0x0

    .line 608
    move/from16 v22, v17

    .line 610
    const/16 v17, 0x0

    .line 612
    move-object/from16 v23, v18

    .line 614
    const/16 v18, 0x0

    .line 616
    move/from16 v27, v19

    .line 618
    const/16 v19, 0x0

    .line 620
    const/16 v20, 0x0

    .line 622
    move-object/from16 v29, v23

    .line 624
    const/16 v23, 0x0

    .line 626
    move-object/from16 p1, v1

    .line 628
    move/from16 v59, v22

    .line 630
    move/from16 v1, v27

    .line 632
    move-object/from16 v58, v29

    .line 634
    move-object/from16 v22, v0

    .line 636
    move-object/from16 v0, v21

    .line 638
    move-object/from16 v21, v28

    .line 640
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 643
    move-object v2, v0

    .line 644
    move v3, v1

    .line 645
    move-object/from16 v0, v22

    .line 647
    move-object/from16 v7, v58

    .line 649
    move/from16 v4, v59

    .line 651
    move-object/from16 v1, p1

    .line 653
    goto :goto_20f

    .line 654
    :cond_28d
    move-object v1, v2

    .line 655
    move-object v2, v0

    .line 656
    move-object v0, v1

    .line 657
    move v1, v3

    .line 658
    move/from16 v59, v4

    .line 660
    move-object/from16 v58, v7

    .line 662
    const/4 v3, 0x0

    .line 663
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 666
    if-eqz v55, :cond_352

    .line 668
    const v3, -0x1f58a3d

    .line 671
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 674
    invoke-static/range {v55 .. v55}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 677
    move-result-object v3

    .line 678
    invoke-virtual/range {v55 .. v55}, Ljava/lang/Integer;->intValue()I

    .line 681
    move-result v4

    .line 682
    move/from16 v5, v59

    .line 684
    invoke-static {v0, v1, v5, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 687
    move-result v4

    .line 688
    new-instance v6, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;

    .line 690
    invoke-direct {v6, v4, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;-><init>(FF)V

    .line 693
    move-object/from16 v4, v50

    .line 695
    invoke-static {v4, v6}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 698
    move-result-object v15

    .line 699
    const/16 v19, 0x0

    .line 701
    const/16 v20, 0xd

    .line 703
    const/16 v16, 0x0

    .line 705
    const/16 v18, 0x0

    .line 707
    move/from16 v17, v26

    .line 709
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 712
    move-result-object v6

    .line 713
    move/from16 v49, v17

    .line 715
    move-object/from16 v7, v58

    .line 717
    invoke-virtual {v2, v7}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 720
    move-result v8

    .line 721
    move/from16 v15, v48

    .line 723
    invoke-virtual {v2, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 726
    move-result v9

    .line 727
    or-int/2addr v8, v9

    .line 728
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 731
    move-result-object v9

    .line 732
    if-nez v8, :cond_2e2

    .line 734
    move-object/from16 v8, v46

    .line 736
    if-ne v9, v8, :cond_2ed

    .line 738
    goto :goto_2e4

    .line 739
    :cond_2e2
    move-object/from16 v8, v46

    .line 741
    :goto_2e4
    new-instance v9, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 743
    const/4 v10, 0x4

    .line 744
    invoke-direct {v9, v7, v15, v10}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 747
    invoke-virtual {v2, v9}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 750
    :cond_2ed
    check-cast v9, Lkotlin/jvm/functions/Function1;

    .line 752
    invoke-static {v6, v9}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 755
    move-result-object v6

    .line 756
    const/16 v9, 0xc

    .line 758
    invoke-static {v9}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 761
    move-result-wide v29

    .line 762
    sget-object v31, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 764
    const/16 v40, 0x0

    .line 766
    const v41, 0xfffff9

    .line 769
    move-object/from16 v21, v28

    .line 771
    const-wide/16 v27, 0x0

    .line 773
    const/16 v32, 0x0

    .line 775
    const/16 v33, 0x0

    .line 777
    const-wide/16 v34, 0x0

    .line 779
    const/16 v36, 0x0

    .line 781
    const-wide/16 v37, 0x0

    .line 783
    const/16 v39, 0x0

    .line 785
    move-object/from16 v26, v21

    .line 787
    invoke-static/range {v26 .. v41}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 790
    move-result-object v21

    .line 791
    move-object/from16 v28, v26

    .line 793
    const/16 v24, 0x0

    .line 795
    const v25, 0x1fff8

    .line 798
    move-object/from16 v22, v2

    .line 800
    move-object v2, v3

    .line 801
    move-object v3, v6

    .line 802
    move-object v12, v7

    .line 803
    const-wide/16 v6, 0x0

    .line 805
    move-object/from16 v46, v8

    .line 807
    const/4 v8, 0x0

    .line 808
    const/4 v9, 0x0

    .line 809
    const/4 v10, 0x0

    .line 810
    move-object/from16 v29, v12

    .line 812
    const-wide/16 v11, 0x0

    .line 814
    const/4 v13, 0x0

    .line 815
    const-wide/16 v14, 0x0

    .line 817
    const/16 v16, 0x0

    .line 819
    const/16 v17, 0x0

    .line 821
    const/16 v18, 0x0

    .line 823
    const/16 v19, 0x0

    .line 825
    const/16 v20, 0x0

    .line 827
    const/16 v23, 0x0

    .line 829
    move-object/from16 v60, v4

    .line 831
    move/from16 v62, v5

    .line 833
    move-object/from16 v61, v29

    .line 835
    move-object/from16 v63, v46

    .line 837
    move-wide/from16 v4, v56

    .line 839
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 842
    move-object/from16 v2, v22

    .line 844
    const/4 v3, 0x0

    .line 845
    :goto_34c
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 848
    move-object/from16 v4, p0

    .line 850
    goto :goto_364

    .line 851
    :cond_352
    move/from16 v49, v26

    .line 853
    move-object/from16 v63, v46

    .line 855
    move-object/from16 v60, v50

    .line 857
    move-object/from16 v61, v58

    .line 859
    move/from16 v62, v59

    .line 861
    const/4 v3, 0x0

    .line 862
    const v4, -0x3e60c006

    .line 865
    invoke-virtual {v2, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 868
    goto :goto_34c

    .line 869
    :goto_364
    iget-object v4, v4, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda63;->f$8:Lcom/spotifry/music/data/spotifried/AgeStats;

    .line 871
    iget-object v4, v4, Lcom/spotifry/music/data/spotifried/AgeStats;->oldestYear:Ljava/lang/Integer;

    .line 873
    if-nez v4, :cond_375

    .line 875
    const v0, -0x3cb62000  # -201.875f

    .line 878
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 881
    :goto_370
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 884
    goto/16 :goto_4cb

    .line 886
    :cond_375
    const v3, -0x3cb61fff

    .line 889
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 892
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 895
    move-result v3

    .line 896
    const-string v4, ", your oldest"

    .line 898
    invoke-static {v3, v4}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(ILjava/lang/String;)Ljava/lang/String;

    .line 901
    move-result-object v27

    .line 902
    const-wide/16 v30, 0x0

    .line 904
    const/16 v32, 0x3fc

    .line 906
    const/16 v29, 0x0

    .line 908
    move-object/from16 v26, v45

    .line 910
    invoke-static/range {v26 .. v32}, Landroidx/compose/ui/text/TextMeasurer;->measure-wNUYSr0$default(Landroidx/compose/ui/text/TextMeasurer;Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;IJI)Landroidx/compose/ui/text/TextLayoutResult;

    .line 913
    move-result-object v4

    .line 914
    iget-wide v4, v4, Landroidx/compose/ui/text/TextLayoutResult;->size:J

    .line 916
    const/16 v6, 0x20

    .line 918
    shr-long/2addr v4, v6

    .line 919
    long-to-int v4, v4

    .line 920
    move-object/from16 v10, v47

    .line 922
    invoke-interface {v10, v4}, Landroidx/compose/ui/unit/Density;->toDp-u2uoSUM(I)F

    .line 925
    move-result v4

    .line 926
    move/from16 v13, v62

    .line 928
    invoke-static {v0, v1, v13, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 931
    move-result v5

    .line 932
    add-float v5, v5, v49

    .line 934
    sub-float/2addr v5, v4

    .line 935
    new-instance v6, Landroidx/compose/ui/unit/Dp;

    .line 937
    invoke-direct {v6, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 940
    new-instance v5, Landroidx/compose/ui/unit/Dp;

    .line 942
    const/4 v7, 0x0

    .line 943
    invoke-direct {v5, v7}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 946
    invoke-virtual {v6, v5}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 949
    move-result v8

    .line 950
    if-gez v8, :cond_3b8

    .line 952
    move-object v6, v5

    .line 953
    :cond_3b8
    new-instance v5, Ljava/util/ArrayList;

    .line 955
    invoke-direct {v5}, Ljava/util/ArrayList;-><init>()V

    .line 958
    invoke-interface/range {v54 .. v54}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 961
    move-result-object v8

    .line 962
    :cond_3c1
    :goto_3c1
    invoke-interface {v8}, Ljava/util/Iterator;->hasNext()Z

    .line 965
    move-result v9

    .line 966
    if-eqz v9, :cond_3f1

    .line 968
    invoke-interface {v8}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 971
    move-result-object v9

    .line 972
    move-object v10, v9

    .line 973
    check-cast v10, Lkotlin/Pair;

    .line 975
    iget v11, v6, Landroidx/compose/ui/unit/Dp;->value:F

    .line 977
    sub-float v12, v11, v49

    .line 979
    add-float/2addr v11, v4

    .line 980
    add-float v11, v11, v49

    .line 982
    iget-object v10, v10, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 984
    check-cast v10, Ljava/lang/Number;

    .line 986
    invoke-virtual {v10}, Ljava/lang/Number;->intValue()I

    .line 989
    move-result v10

    .line 990
    invoke-static {v0, v1, v13, v10}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 993
    move-result v10

    .line 994
    invoke-static {v10, v12}, Ljava/lang/Float;->compare(FF)I

    .line 997
    move-result v12

    .line 998
    if-ltz v12, :cond_3c1

    .line 1000
    invoke-static {v10, v11}, Ljava/lang/Float;->compare(FF)I

    .line 1003
    move-result v10

    .line 1004
    if-gtz v10, :cond_3c1

    .line 1006
    invoke-virtual {v5, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1009
    goto :goto_3c1

    .line 1010
    :cond_3f1
    invoke-virtual {v5}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 1013
    move-result-object v4

    .line 1014
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1017
    move-result v5

    .line 1018
    if-eqz v5, :cond_42f

    .line 1020
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1023
    move-result-object v5

    .line 1024
    check-cast v5, Lkotlin/Pair;

    .line 1026
    iget-object v5, v5, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 1028
    check-cast v5, Ljava/lang/Number;

    .line 1030
    invoke-virtual {v5}, Ljava/lang/Number;->intValue()I

    .line 1033
    move-result v5

    .line 1034
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1037
    move-result-object v5

    .line 1038
    :cond_40d
    :goto_40d
    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    .line 1041
    move-result v6

    .line 1042
    if-eqz v6, :cond_42d

    .line 1044
    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 1047
    move-result-object v6

    .line 1048
    check-cast v6, Lkotlin/Pair;

    .line 1050
    iget-object v6, v6, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 1052
    check-cast v6, Ljava/lang/Number;

    .line 1054
    invoke-virtual {v6}, Ljava/lang/Number;->intValue()I

    .line 1057
    move-result v6

    .line 1058
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1061
    move-result-object v6

    .line 1062
    invoke-virtual {v5, v6}, Ljava/lang/Integer;->compareTo(Ljava/lang/Object;)I

    .line 1065
    move-result v8

    .line 1066
    if-gez v8, :cond_40d

    .line 1068
    move-object v5, v6

    .line 1069
    goto :goto_40d

    .line 1070
    :cond_42d
    move-object/from16 v43, v5

    .line 1072
    :cond_42f
    if-eqz v43, :cond_436

    .line 1074
    invoke-virtual/range {v43 .. v43}, Ljava/lang/Integer;->intValue()I

    .line 1077
    move-result v8

    .line 1078
    goto :goto_437

    .line 1079
    :cond_436
    const/4 v8, 0x0

    .line 1080
    :goto_437
    int-to-float v4, v8

    .line 1081
    mul-float v12, v53, v4

    .line 1083
    sub-float v44, v44, v12

    .line 1085
    sub-float v44, v44, v49

    .line 1087
    sub-float v44, v44, v52

    .line 1089
    sub-float v4, v44, v42

    .line 1091
    if-nez v55, :cond_44d

    .line 1093
    invoke-static {v4, v7}, Ljava/lang/Float;->compare(FF)I

    .line 1096
    move-result v5

    .line 1097
    if-gez v5, :cond_44d

    .line 1099
    :goto_44a
    const/4 v3, 0x0

    .line 1100
    goto/16 :goto_370

    .line 1102
    :cond_44d
    if-nez v55, :cond_453

    .line 1104
    :goto_44f
    move-object/from16 v11, v60

    .line 1106
    const/4 v6, 0x1

    .line 1107
    goto :goto_469

    .line 1108
    :cond_453
    new-instance v5, Landroidx/compose/ui/unit/Dp;

    .line 1110
    invoke-direct {v5, v4}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 1113
    new-instance v4, Landroidx/compose/ui/unit/Dp;

    .line 1115
    const/high16 v6, 0x41b00000  # 22.0f

    .line 1117
    invoke-direct {v4, v6}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 1120
    invoke-virtual {v5, v4}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 1123
    move-result v6

    .line 1124
    if-gez v6, :cond_466

    .line 1126
    move-object v5, v4

    .line 1127
    :cond_466
    iget v4, v5, Landroidx/compose/ui/unit/Dp;->value:F

    .line 1129
    goto :goto_44f

    .line 1130
    :goto_469
    invoke-static {v11, v7, v4, v6}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 1133
    move-result-object v4

    .line 1134
    invoke-static {v0, v1, v13, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 1137
    move-result v0

    .line 1138
    add-float v0, v0, v49

    .line 1140
    new-instance v1, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;

    .line 1142
    const/high16 v3, 0x3f800000  # 1.0f

    .line 1144
    invoke-direct {v1, v0, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda50;-><init>(FF)V

    .line 1147
    invoke-static {v4, v1}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 1150
    move-result-object v0

    .line 1151
    move-object/from16 v7, v61

    .line 1153
    invoke-virtual {v2, v7}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 1156
    move-result v1

    .line 1157
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 1160
    move-result-object v3

    .line 1161
    if-nez v1, :cond_48e

    .line 1163
    move-object/from16 v8, v63

    .line 1165
    if-ne v3, v8, :cond_497

    .line 1167
    :cond_48e
    new-instance v3, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;

    .line 1169
    const/4 v1, 0x5

    .line 1170
    invoke-direct {v3, v7, v1}, Lcom/spotifry/music/ui/components/FadeInKt$$ExternalSyntheticLambda1;-><init>(Landroidx/compose/animation/core/Animatable;B)V

    .line 1173
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1176
    :cond_497
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 1178
    invoke-static {v0, v3}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 1181
    move-result-object v3

    .line 1182
    invoke-static {v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 1185
    move-result-wide v4

    .line 1186
    const/16 v24, 0x6000

    .line 1188
    const v25, 0x1bff8

    .line 1191
    const-wide/16 v6, 0x0

    .line 1193
    const/4 v8, 0x0

    .line 1194
    const/4 v9, 0x0

    .line 1195
    const/4 v10, 0x0

    .line 1196
    const-wide/16 v11, 0x0

    .line 1198
    const/4 v13, 0x0

    .line 1199
    const-wide/16 v14, 0x0

    .line 1201
    const/16 v16, 0x0

    .line 1203
    const/16 v17, 0x0

    .line 1205
    const/16 v18, 0x1

    .line 1207
    const/16 v19, 0x0

    .line 1209
    const/16 v20, 0x0

    .line 1211
    const/16 v23, 0x0

    .line 1213
    move-object/from16 v22, v2

    .line 1215
    move-object/from16 v2, v27

    .line 1217
    move-object/from16 v21, v28

    .line 1219
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1222
    move-object/from16 v2, v22

    .line 1224
    goto :goto_44a

    .line 1225
    :cond_4c8
    invoke-virtual {v2}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 1228
    :goto_4cb
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1230
    return-object v0
.end method
