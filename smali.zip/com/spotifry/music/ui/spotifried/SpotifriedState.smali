# classes.dex

.class public final Lcom/spotifry/music/ui/spotifried/SpotifriedState;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"


# instance fields
.field public final cards:Ljava/util/List;

.field public final checked:I

.field public final choices:Ljava/util/ArrayList;

.field public final morePlays:Ljava/lang/Integer;

.field public final name:Ljava/lang/String;

.field public final stats:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final unchecked:I


# direct methods
.method public constructor <init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/util/List;Ljava/util/ArrayList;IILjava/lang/Integer;Ljava/lang/String;)V
    .registers 8

    .line 1
    invoke-virtual {p7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->stats:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 9
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->cards:Ljava/util/List;

    .line 11
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->choices:Ljava/util/ArrayList;

    .line 13
    iput p4, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->checked:I

    .line 15
    iput p5, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->unchecked:I

    .line 17
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->morePlays:Ljava/lang/Integer;

    .line 19
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->name:Ljava/lang/String;

    .line 21
    return-void
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .registers 4

    .line 1
    if-eq p0, p1, :cond_48

    .line 3
    instance-of v0, p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 5
    if-eqz v0, :cond_46

    .line 7
    check-cast p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 9
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->stats:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 11
    iget-object v1, p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->stats:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 13
    invoke-virtual {v0, v1}, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->equals(Ljava/lang/Object;)Z

    .line 16
    move-result v0

    .line 17
    if-eqz v0, :cond_46

    .line 19
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->cards:Ljava/util/List;

    .line 21
    iget-object v1, p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->cards:Ljava/util/List;

    .line 23
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 26
    move-result v0

    .line 27
    if-eqz v0, :cond_46

    .line 29
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->choices:Ljava/util/ArrayList;

    .line 31
    iget-object v1, p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->choices:Ljava/util/ArrayList;

    .line 33
    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 36
    move-result v0

    .line 37
    if-eqz v0, :cond_46

    .line 39
    iget v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->checked:I

    .line 41
    iget v1, p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->checked:I

    .line 43
    if-ne v0, v1, :cond_46

    .line 45
    iget v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->unchecked:I

    .line 47
    iget v1, p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->unchecked:I

    .line 49
    if-ne v0, v1, :cond_46

    .line 51
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->morePlays:Ljava/lang/Integer;

    .line 53
    iget-object v1, p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->morePlays:Ljava/lang/Integer;

    .line 55
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 58
    move-result v0

    .line 59
    if-eqz v0, :cond_46

    .line 61
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->name:Ljava/lang/String;

    .line 63
    iget-object p1, p1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->name:Ljava/lang/String;

    .line 65
    invoke-static {p0, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 68
    move-result p0

    .line 69
    if-nez p0, :cond_48

    .line 71
    :cond_46
    const/4 p0, 0x0

    .line 72
    return p0

    .line 73
    :cond_48
    const/4 p0, 0x1

    .line 74
    return p0
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    iget-object v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->stats:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 3
    invoke-virtual {v0}, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hashCode()I

    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 9
    mul-int/2addr v0, v1

    .line 10
    iget-object v2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->cards:Ljava/util/List;

    .line 12
    invoke-static {v0, v2, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILjava/util/List;I)I

    .line 15
    move-result v0

    .line 16
    iget-object v2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->choices:Ljava/util/ArrayList;

    .line 18
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 21
    move-result v2

    .line 22
    add-int/2addr v2, v0

    .line 23
    mul-int/2addr v2, v1

    .line 24
    iget v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->checked:I

    .line 26
    invoke-static {v0, v2, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(III)I

    .line 29
    move-result v0

    .line 30
    iget v2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->unchecked:I

    .line 32
    invoke-static {v2, v0, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(III)I

    .line 35
    move-result v0

    .line 36
    iget-object v2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->morePlays:Ljava/lang/Integer;

    .line 38
    if-nez v2, :cond_29

    .line 40
    const/4 v2, 0x0

    .line 41
    goto :goto_2d

    .line 42
    :cond_29
    invoke-virtual {v2}, Ljava/lang/Object;->hashCode()I

    .line 45
    move-result v2

    .line 46
    :goto_2d
    add-int/2addr v0, v2

    .line 47
    mul-int/2addr v0, v1

    .line 48
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->name:Ljava/lang/String;

    .line 50
    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    .line 53
    move-result p0

    .line 54
    add-int/2addr p0, v0

    .line 55
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const-string v1, "SpotifriedState(stats="

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->stats:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 13
    const-string v1, ", cards="

    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 18
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->cards:Ljava/util/List;

    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 23
    const-string v1, ", choices="

    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 28
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->choices:Ljava/util/ArrayList;

    .line 30
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 33
    const-string v1, ", checked="

    .line 35
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 38
    iget v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->checked:I

    .line 40
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 43
    const-string v1, ", unchecked="

    .line 45
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 48
    iget v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->unchecked:I

    .line 50
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 53
    const-string v1, ", morePlays="

    .line 55
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->morePlays:Ljava/lang/Integer;

    .line 60
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 63
    const-string v1, ", name="

    .line 65
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 68
    const-string v1, ")"

    .line 70
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->name:Ljava/lang/String;

    .line 72
    invoke-static {v0, p0, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/StringBuilder;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 75
    move-result-object p0

    .line 76
    return-object p0
.end method
