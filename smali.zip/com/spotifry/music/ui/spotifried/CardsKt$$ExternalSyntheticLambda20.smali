# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:Ljava/lang/Object;

.field public final synthetic f$2:Z

.field public final synthetic f$3:I


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/internal/ComposableLambdaImpl;II)V
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->$r8$classId:B

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$0:Ljava/lang/Object;

    .line 9
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$1:Ljava/lang/Object;

    .line 11
    iput p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$3:I

    .line 13
    iput-boolean p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$2:Z

    .line 15
    return-void
.end method

.method public synthetic constructor <init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lcom/spotifry/music/data/spotifried/ObsessionDay;ZI)V
    .registers 6

    .line 16
    const/4 v0, 0x0

    iput-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->$r8$classId:B

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$0:Ljava/lang/Object;

    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$1:Ljava/lang/Object;

    iput-boolean p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$2:Z

    iput p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$3:I

    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->$r8$classId:B

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    iget-boolean v2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$2:Z

    .line 7
    iget v3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$3:I

    .line 9
    iget-object v4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$1:Ljava/lang/Object;

    .line 11
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda20;->f$0:Ljava/lang/Object;

    .line 13
    packed-switch v0, :pswitch_data_3a

    .line 16
    check-cast p0, Landroidx/compose/ui/Modifier;

    .line 18
    check-cast v4, Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 20
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 22
    check-cast p2, Ljava/lang/Integer;

    .line 24
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 27
    or-int/lit8 v3, v3, 0x1

    .line 29
    invoke-static {v3}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 32
    move-result p2

    .line 33
    invoke-static {p0, v4, p1, p2, v2}, Lcom/spotifry/music/ui/components/FadeInKt;->LoadingShapes(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 36
    return-object v1

    .line 37
    :pswitch_24  #0x0
    check-cast p0, Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 39
    check-cast v4, Lcom/spotifry/music/data/spotifried/ObsessionDay;

    .line 41
    check-cast p1, Landroidx/compose/runtime/ComposerImpl;

    .line 43
    check-cast p2, Ljava/lang/Integer;

    .line 45
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 48
    or-int/lit8 v3, v3, 0x1

    .line 50
    invoke-static {v3}, Landroidx/compose/runtime/AnchoredGroupPath;->updateChangedFlags(I)I

    .line 53
    move-result p2

    .line 54
    invoke-static {p0, v4, v2, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Day(Lcom/spotifry/music/data/spotifried/SpotifriedStats;Lcom/spotifry/music/data/spotifried/ObsessionDay;ZLandroidx/compose/runtime/ComposerImpl;I)V

    .line 57
    return-object v1

    nop

    :pswitch_data_3a
    .packed-switch 0x0
        :pswitch_24  #00000000
    .end packed-switch
.end method
