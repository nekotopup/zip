# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# static fields
.field public static final INSTANCE:Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .line 1
    new-instance v0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;

    .line 3
    const-string v4, "now()Ljava/time/LocalDate;"

    .line 5
    const/4 v5, 0x0

    .line 6
    const/4 v1, 0x0

    .line 7
    const-class v2, Ljava/time/LocalDate;

    .line 9
    const-string v3, "now"

    .line 11
    invoke-direct/range {v0 .. v5}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Class;Ljava/lang/String;Ljava/lang/String;I)V

    .line 14
    sput-object v0, Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;->INSTANCE:Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel$1;

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 1

    .line 1
    invoke-static {}, Ljava/time/LocalDate;->now()Ljava/time/LocalDate;

    .line 4
    move-result-object p0

    .line 5
    return-object p0
.end method
