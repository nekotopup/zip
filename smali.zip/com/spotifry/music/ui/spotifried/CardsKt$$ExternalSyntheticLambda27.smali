# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/spotifry/music/data/TopSong;

.field public final synthetic f$2:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$3:J

.field public final synthetic f$4:Landroidx/compose/foundation/shape/RoundedCornerShape;

.field public final synthetic f$5:Lcom/spotifry/music/ui/spotifried/CountUp;


# direct methods
.method public synthetic constructor <init>(ZLcom/spotifry/music/data/TopSong;Landroidx/compose/runtime/MutableState;JLandroidx/compose/foundation/shape/RoundedCornerShape;Lcom/spotifry/music/ui/spotifried/CountUp;)V
    .registers 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$0:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$1:Lcom/spotifry/music/data/TopSong;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$2:Landroidx/compose/runtime/MutableState;

    .line 10
    iput-wide p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$3:J

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$4:Landroidx/compose/foundation/shape/RoundedCornerShape;

    .line 14
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$5:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 72

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v9, p2

    .line 9
    check-cast v9, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    const/4 v4, 0x2

    .line 25
    if-nez v3, :cond_24

    .line 27
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_22

    .line 33
    const/4 v3, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v3, v4

    .line 36
    :goto_23
    or-int/2addr v2, v3

    .line 37
    :cond_24
    and-int/lit8 v3, v2, 0x13

    .line 39
    const/16 v5, 0x12

    .line 41
    const/4 v6, 0x0

    .line 42
    const/4 v7, 0x1

    .line 43
    if-eq v3, v5, :cond_2e

    .line 45
    move v3, v7

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v3, v6

    .line 48
    :goto_2f
    and-int/2addr v2, v7

    .line 49
    invoke-virtual {v9, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_42d

    .line 55
    const/high16 v2, 0x3f800000  # 1.0f

    .line 57
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 60
    move-result-object v1

    .line 61
    sget-object v3, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 63
    sget-object v5, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 65
    invoke-static {v3, v5, v9, v6}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 68
    move-result-object v3

    .line 69
    iget-wide v10, v9, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 71
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 74
    move-result v5

    .line 75
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 78
    move-result-object v8

    .line 79
    invoke-static {v9, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 82
    move-result-object v1

    .line 83
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 85
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 88
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 90
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 93
    iget-boolean v11, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 95
    if-eqz v11, :cond_64

    .line 97
    invoke-virtual {v9, v10}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 100
    goto :goto_67

    .line 101
    :cond_64
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 104
    :goto_67
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 106
    invoke-static {v9, v3, v11}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 109
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 111
    invoke-static {v9, v8, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 114
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 116
    iget-boolean v12, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 118
    if-nez v12, :cond_85

    .line 120
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 123
    move-result-object v12

    .line 124
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 127
    move-result-object v13

    .line 128
    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 131
    move-result v12

    .line 132
    if-nez v12, :cond_88

    .line 134
    :cond_85
    invoke-static {v5, v9, v5, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 137
    :cond_88
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 139
    invoke-static {v9, v1, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 142
    sget-object v1, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 144
    iget-boolean v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$0:Z

    .line 146
    const/16 v13, 0x36

    .line 148
    move-object v14, v3

    .line 149
    invoke-static {v1, v6, v12, v9, v13}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 152
    move-result-object v3

    .line 153
    sget-object v15, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 155
    const/16 v16, 0x26

    .line 157
    invoke-static/range {v16 .. v16}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 160
    move-result-wide v18

    .line 161
    const/16 v16, 0x25

    .line 163
    invoke-static/range {v16 .. v16}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 166
    move-result-wide v26

    .line 167
    const-wide v16, -0x400b333333333333L  # -1.3

    .line 172
    invoke-static/range {v16 .. v17}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 175
    move-result-wide v23

    .line 176
    const/16 v29, 0x0

    .line 178
    const v30, 0xfdff7d

    .line 181
    const-wide/16 v16, 0x0

    .line 183
    const/16 v20, 0x0

    .line 185
    const/16 v21, 0x0

    .line 187
    const/16 v22, 0x0

    .line 189
    const/16 v25, 0x0

    .line 191
    const/16 v28, 0x0

    .line 193
    invoke-static/range {v15 .. v30}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 196
    move-result-object v21

    .line 197
    const/16 v24, 0x6180

    .line 199
    const v25, 0x1affc

    .line 202
    move v15, v2

    .line 203
    const-string v2, "You couldn\'t leave this one alone."

    .line 205
    move-object/from16 v16, v5

    .line 207
    const-wide/16 v4, 0x0

    .line 209
    move/from16 v18, v6

    .line 211
    const-wide/16 v6, 0x0

    .line 213
    move-object/from16 v20, v8

    .line 215
    const/4 v8, 0x0

    .line 216
    move-object/from16 v22, v9

    .line 218
    const/4 v9, 0x0

    .line 219
    move-object/from16 v23, v10

    .line 221
    const/4 v10, 0x0

    .line 222
    move-object/from16 v26, v11

    .line 224
    move/from16 v27, v12

    .line 226
    const-wide/16 v11, 0x0

    .line 228
    const/4 v13, 0x0

    .line 229
    move-object/from16 v29, v14

    .line 231
    move/from16 v30, v15

    .line 233
    const-wide/16 v14, 0x0

    .line 235
    move-object/from16 v31, v16

    .line 237
    const/16 v16, 0x2

    .line 239
    const/16 v17, 0x0

    .line 241
    move/from16 v33, v18

    .line 243
    const/16 v18, 0x3

    .line 245
    const/16 v19, 0x0

    .line 247
    move-object/from16 v35, v20

    .line 249
    const/16 v20, 0x0

    .line 251
    move-object/from16 v36, v23

    .line 253
    const/16 v23, 0x6

    .line 255
    move-object/from16 p1, v1

    .line 257
    move-object/from16 v37, v26

    .line 259
    move-object/from16 v38, v29

    .line 261
    move/from16 v1, v30

    .line 263
    move-object/from16 v40, v31

    .line 265
    move/from16 v0, v33

    .line 267
    move-object/from16 v39, v35

    .line 269
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 272
    move-object/from16 v9, v22

    .line 274
    sget-object v2, Landroidx/compose/ui/Alignment$Companion;->CenterHorizontally:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 276
    new-instance v3, Landroidx/compose/foundation/layout/HorizontalAlignElement;

    .line 278
    invoke-direct {v3, v2}, Landroidx/compose/foundation/layout/HorizontalAlignElement;-><init>(Landroidx/compose/ui/BiasAlignment$Horizontal;)V

    .line 281
    const/4 v7, 0x0

    .line 282
    const/16 v8, 0xd

    .line 284
    const/4 v4, 0x0

    .line 285
    const/high16 v14, 0x41a00000  # 20.0f

    .line 287
    const/4 v6, 0x0

    .line 288
    move v5, v14

    .line 289
    invoke-static/range {v3 .. v8}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 292
    move-result-object v2

    .line 293
    new-instance v3, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 295
    invoke-direct {v3, v1, v0}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 298
    invoke-interface {v2, v3}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 301
    move-result-object v2

    .line 302
    const/high16 v3, 0x43960000  # 300.0f

    .line 304
    const/4 v12, 0x1

    .line 305
    invoke-static {v2, v3, v12}, Landroidx/compose/foundation/layout/SizeKt;->widthIn-VpY3zN4$default(Landroidx/compose/ui/Modifier;FI)Landroidx/compose/ui/Modifier;

    .line 308
    move-result-object v2

    .line 309
    invoke-static {v2, v1, v12}, Landroidx/compose/foundation/layout/OffsetKt;->aspectRatio(Landroidx/compose/ui/Modifier;FZ)Landroidx/compose/ui/Modifier;

    .line 312
    move-result-object v2

    .line 313
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 316
    move-result-object v3

    .line 317
    sget-object v13, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 319
    if-ne v3, v13, :cond_14f

    .line 321
    new-instance v3, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda30;

    .line 323
    const/16 v4, 0x1c

    .line 325
    move-object/from16 v15, p0

    .line 327
    iget-object v5, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$2:Landroidx/compose/runtime/MutableState;

    .line 329
    invoke-direct {v3, v5, v4}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda30;-><init>(Landroidx/compose/runtime/MutableState;B)V

    .line 332
    invoke-virtual {v9, v3}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 335
    goto :goto_151

    .line 336
    :cond_14f
    move-object/from16 v15, p0

    .line 338
    :goto_151
    check-cast v3, Lkotlin/jvm/functions/Function1;

    .line 340
    invoke-static {v2, v3}, Landroidx/compose/ui/layout/RulerKt;->onPlaced(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 343
    move-result-object v2

    .line 344
    const-string v3, "top_cover"

    .line 346
    invoke-static {v2, v3}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 349
    move-result-object v2

    .line 350
    const/16 v3, 0x30

    .line 352
    move/from16 v4, v27

    .line 354
    invoke-static {v2, v12, v4, v9, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 357
    move-result-object v2

    .line 358
    sget-object v3, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 360
    invoke-static {v3, v0}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 363
    move-result-object v3

    .line 364
    iget-wide v5, v9, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 366
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 369
    move-result v5

    .line 370
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 373
    move-result-object v6

    .line 374
    invoke-static {v9, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 377
    move-result-object v2

    .line 378
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 381
    iget-boolean v7, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 383
    if-eqz v7, :cond_188

    .line 385
    move-object/from16 v7, v36

    .line 387
    invoke-virtual {v9, v7}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 390
    :goto_185
    move-object/from16 v8, v37

    .line 392
    goto :goto_18e

    .line 393
    :cond_188
    move-object/from16 v7, v36

    .line 395
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 398
    goto :goto_185

    .line 399
    :goto_18e
    invoke-static {v9, v3, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 402
    move-object/from16 v3, v38

    .line 404
    invoke-static {v9, v6, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 407
    iget-boolean v6, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 409
    if-nez v6, :cond_1ad

    .line 411
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 414
    move-result-object v6

    .line 415
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 418
    move-result-object v10

    .line 419
    invoke-static {v6, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 422
    move-result v6

    .line 423
    if-eqz v6, :cond_1ad

    .line 425
    move-object/from16 v6, v39

    .line 427
    :goto_1aa
    move-object/from16 v5, v40

    .line 429
    goto :goto_1b3

    .line 430
    :cond_1ad
    move-object/from16 v6, v39

    .line 432
    invoke-static {v5, v9, v5, v6}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 435
    goto :goto_1aa

    .line 436
    :goto_1b3
    invoke-static {v9, v2, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 439
    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 441
    const/16 v10, 0x1f

    .line 443
    const/4 v11, 0x3

    .line 444
    move-object/from16 p3, v13

    .line 446
    iget-wide v13, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$3:J

    .line 448
    move-object/from16 v35, v6

    .line 450
    iget-object v6, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$4:Landroidx/compose/foundation/shape/RoundedCornerShape;

    .line 452
    if-lt v2, v10, :cond_1f9

    .line 454
    const v2, 0x4572055b

    .line 457
    invoke-virtual {v9, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 460
    sget-object v2, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    .line 462
    invoke-virtual {v2}, Landroidx/compose/foundation/layout/BoxScopeInstance;->matchParentSize()Landroidx/compose/ui/Modifier;

    .line 465
    move-result-object v2

    .line 466
    const/high16 v10, 0x41c00000  # 24.0f

    .line 468
    const/4 v1, 0x0

    .line 469
    invoke-static {v2, v1, v10, v12}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 472
    move-result-object v1

    .line 473
    const/high16 v2, 0x41900000  # 18.0f

    .line 475
    invoke-static {v1, v2, v2}, Landroidx/compose/foundation/layout/OffsetKt;->padding-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    .line 478
    move-result-object v1

    .line 479
    new-instance v2, Landroidx/compose/ui/draw/BlurKt$blur$1;

    .line 481
    invoke-direct {v2, v11, v0}, Landroidx/compose/ui/draw/BlurKt$blur$1;-><init>(IZ)V

    .line 484
    invoke-static {v1, v2}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 487
    move-result-object v1

    .line 488
    const v2, 0x3ee66666  # 0.45f

    .line 491
    invoke-static {v2, v13, v14}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 494
    move-result-wide v11

    .line 495
    invoke-static {v1, v11, v12, v6}, Landroidx/compose/foundation/ImageKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    .line 498
    move-result-object v1

    .line 499
    invoke-static {v1, v9, v0}, Landroidx/compose/foundation/layout/BoxKt;->Box(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 502
    :goto_1f5
    invoke-virtual {v9, v0}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 505
    goto :goto_200

    .line 506
    :cond_1f9
    const v1, 0x67d0bbdf

    .line 509
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 512
    goto :goto_1f5

    .line 513
    :goto_200
    iget-object v0, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$1:Lcom/spotifry/music/data/TopSong;

    .line 515
    iget-object v1, v0, Lcom/spotifry/music/data/TopSong;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 517
    iget-object v2, v1, Lcom/spotifry/music/data/db/SongEntity;->id:Ljava/lang/String;

    .line 519
    move-object/from16 v29, v3

    .line 521
    iget-object v3, v1, Lcom/spotifry/music/data/db/SongEntity;->thumbnailUrl:Ljava/lang/String;

    .line 523
    move/from16 v27, v4

    .line 525
    iget-object v4, v1, Lcom/spotifry/music/data/db/SongEntity;->thumbPath:Ljava/lang/String;

    .line 527
    move-object/from16 v12, p1

    .line 529
    const/high16 v11, 0x3f800000  # 1.0f

    .line 531
    invoke-static {v12, v11}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 534
    move-result-object v11

    .line 535
    const/16 v10, 0xc00

    .line 537
    move-object/from16 v31, v5

    .line 539
    move-object v5, v11

    .line 540
    const/16 v11, 0x60

    .line 542
    move-object/from16 v36, v7

    .line 544
    const/4 v7, 0x0

    .line 545
    move-object/from16 v37, v8

    .line 547
    const/4 v8, 0x0

    .line 548
    move/from16 v49, v27

    .line 550
    move-object/from16 v46, v29

    .line 552
    move-object/from16 v48, v31

    .line 554
    move-object/from16 v47, v35

    .line 556
    move-object/from16 v44, v36

    .line 558
    move-object/from16 v45, v37

    .line 560
    invoke-static/range {v2 .. v11}, Lcom/spotifry/music/ui/components/CoverKt;->CoverArt(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/graphics/Shape;ZZLandroidx/compose/runtime/ComposerImpl;II)V

    .line 563
    const/4 v2, 0x1

    .line 564
    invoke-virtual {v9, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 567
    iget-object v2, v1, Lcom/spotifry/music/data/db/SongEntity;->title:Ljava/lang/String;

    .line 569
    const/16 v16, 0x0

    .line 571
    const/16 v17, 0xd

    .line 573
    move-wide v4, v13

    .line 574
    const/4 v13, 0x0

    .line 575
    const/4 v15, 0x0

    .line 576
    move-object/from16 v3, p3

    .line 578
    move-wide/from16 v26, v4

    .line 580
    const/high16 v14, 0x41a00000  # 20.0f

    .line 582
    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 585
    move-result-object v4

    .line 586
    move-object/from16 v28, v12

    .line 588
    move/from16 v5, v49

    .line 590
    const/4 v6, 0x2

    .line 591
    const/16 v7, 0x36

    .line 593
    invoke-static {v4, v6, v5, v9, v7}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 596
    move-result-object v4

    .line 597
    sget-object v35, Lcom/spotifry/music/ui/theme/TypeKt;->Albert:Landroidx/compose/ui/text/font/FontListFontFamily;

    .line 599
    sget-object v34, Landroidx/compose/ui/text/font/FontWeight;->ExtraBold:Landroidx/compose/ui/text/font/FontWeight;

    .line 601
    const/16 v8, 0x1a

    .line 603
    invoke-static {v8}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 606
    move-result-wide v32

    .line 607
    const/16 v8, 0x1b

    .line 609
    invoke-static {v8}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 612
    move-result-wide v39

    .line 613
    const-wide v10, -0x401b333333333333L  # -0.65

    .line 618
    invoke-static {v10, v11}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 621
    move-result-wide v36

    .line 622
    new-instance v29, Landroidx/compose/ui/text/TextStyle;

    .line 624
    const/16 v41, 0x0

    .line 626
    const v42, 0xfdff59

    .line 629
    const-wide/16 v30, 0x0

    .line 631
    const/16 v38, 0x0

    .line 633
    invoke-direct/range {v29 .. v42}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 636
    const/16 v24, 0x6180

    .line 638
    const v25, 0x1affc

    .line 641
    move-object v8, v3

    .line 642
    move-object v3, v4

    .line 643
    const-wide/16 v4, 0x0

    .line 645
    const-wide/16 v6, 0x0

    .line 647
    move-object v10, v8

    .line 648
    const/4 v8, 0x0

    .line 649
    move-object/from16 v22, v9

    .line 651
    const/4 v9, 0x0

    .line 652
    move-object v11, v10

    .line 653
    const/4 v10, 0x0

    .line 654
    move-object v13, v11

    .line 655
    const-wide/16 v11, 0x0

    .line 657
    move-object v14, v13

    .line 658
    const/4 v13, 0x0

    .line 659
    move-object/from16 v16, v14

    .line 661
    const-wide/16 v14, 0x0

    .line 663
    move-object/from16 v17, v16

    .line 665
    const/16 v16, 0x2

    .line 667
    move-object/from16 v18, v17

    .line 669
    const/16 v17, 0x0

    .line 671
    move-object/from16 v20, v18

    .line 673
    const/16 v18, 0x2

    .line 675
    const/16 v19, 0x0

    .line 677
    move-object/from16 v21, v20

    .line 679
    const/16 v20, 0x0

    .line 681
    const/16 v23, 0x0

    .line 683
    move-object/from16 v43, v0

    .line 685
    move-object/from16 v50, v21

    .line 687
    move-object/from16 v21, v29

    .line 689
    move/from16 v0, v49

    .line 691
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 694
    move-object/from16 v9, v22

    .line 696
    iget-object v1, v1, Lcom/spotifry/music/data/db/SongEntity;->artist:Ljava/lang/String;

    .line 698
    invoke-static {v1}, Lcom/spotifry/music/data/Log;->cleanArtist(Ljava/lang/String;)Ljava/lang/String;

    .line 701
    move-result-object v2

    .line 702
    const/16 v16, 0x0

    .line 704
    const/16 v17, 0xd

    .line 706
    const/4 v13, 0x0

    .line 707
    const/high16 v14, 0x40800000  # 4.0f

    .line 709
    const/4 v15, 0x0

    .line 710
    move-object/from16 v12, v28

    .line 712
    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 715
    move-result-object v1

    .line 716
    const/16 v3, 0x36

    .line 718
    const/4 v6, 0x2

    .line 719
    invoke-static {v1, v6, v0, v9, v3}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 722
    move-result-object v1

    .line 723
    invoke-static {v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 726
    move-result-wide v4

    .line 727
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 729
    const/16 v6, 0xe

    .line 731
    invoke-static {v6}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 734
    move-result-wide v54

    .line 735
    const/16 v65, 0x0

    .line 737
    const v66, 0xfffffd

    .line 740
    const-wide/16 v52, 0x0

    .line 742
    const/16 v56, 0x0

    .line 744
    const/16 v57, 0x0

    .line 746
    const/16 v58, 0x0

    .line 748
    const-wide/16 v59, 0x0

    .line 750
    const/16 v61, 0x0

    .line 752
    const-wide/16 v62, 0x0

    .line 754
    const/16 v64, 0x0

    .line 756
    move-object/from16 v51, v21

    .line 758
    invoke-static/range {v51 .. v66}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 761
    move-result-object v21

    .line 762
    const v25, 0x1aff8

    .line 765
    const-wide/16 v6, 0x0

    .line 767
    const/4 v9, 0x0

    .line 768
    const-wide/16 v11, 0x0

    .line 770
    const/4 v13, 0x0

    .line 771
    const-wide/16 v14, 0x0

    .line 773
    const/16 v16, 0x2

    .line 775
    const/16 v17, 0x0

    .line 777
    const/16 v18, 0x1

    .line 779
    move/from16 v67, v3

    .line 781
    move-object v3, v1

    .line 782
    move/from16 v1, v67

    .line 784
    move-object/from16 v67, v28

    .line 786
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 789
    move-object/from16 v9, v22

    .line 791
    const/4 v2, 0x1

    .line 792
    invoke-virtual {v9, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 795
    move-object/from16 v12, v67

    .line 797
    const/4 v10, 0x3

    .line 798
    invoke-static {v12, v10, v0, v9, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 801
    move-result-object v0

    .line 802
    new-instance v1, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 804
    new-instance v3, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 806
    invoke-direct {v3, v10}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 809
    const/high16 v4, 0x41000000  # 8.0f

    .line 811
    invoke-direct {v1, v4, v3}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 814
    sget-object v3, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 816
    const/4 v4, 0x6

    .line 817
    invoke-static {v1, v3, v9, v4}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 820
    move-result-object v1

    .line 821
    iget-wide v3, v9, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 823
    invoke-static {v3, v4}, Ljava/lang/Long;->hashCode(J)I

    .line 826
    move-result v3

    .line 827
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 830
    move-result-object v4

    .line 831
    invoke-static {v9, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 834
    move-result-object v0

    .line 835
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 838
    iget-boolean v5, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 840
    if-eqz v5, :cond_351

    .line 842
    move-object/from16 v7, v44

    .line 844
    invoke-virtual {v9, v7}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 847
    :goto_34e
    move-object/from16 v8, v45

    .line 849
    goto :goto_355

    .line 850
    :cond_351
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 853
    goto :goto_34e

    .line 854
    :goto_355
    invoke-static {v9, v1, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 857
    move-object/from16 v14, v46

    .line 859
    invoke-static {v9, v4, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 862
    iget-boolean v1, v9, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 864
    if-nez v1, :cond_372

    .line 866
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 869
    move-result-object v1

    .line 870
    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 873
    move-result-object v4

    .line 874
    invoke-static {v1, v4}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 877
    move-result v1

    .line 878
    if-eqz v1, :cond_372

    .line 880
    :goto_36f
    move-object/from16 v5, v48

    .line 882
    goto :goto_378

    .line 883
    :cond_372
    move-object/from16 v6, v47

    .line 885
    invoke-static {v3, v9, v3, v6}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 888
    goto :goto_36f

    .line 889
    :goto_378
    invoke-static {v9, v0, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 892
    move-object/from16 v15, p0

    .line 894
    iget-object v0, v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda27;->f$5:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 896
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CountUp;->text:Ljava/lang/String;

    .line 898
    sget-object v3, Landroidx/compose/ui/layout/AlignmentLineKt;->FirstBaseline:Landroidx/compose/ui/layout/HorizontalAlignmentLine;

    .line 900
    new-instance v4, Landroidx/compose/foundation/layout/WithAlignmentLineElement;

    .line 902
    invoke-direct {v4, v3}, Landroidx/compose/foundation/layout/WithAlignmentLineElement;-><init>(Landroidx/compose/ui/layout/HorizontalAlignmentLine;)V

    .line 905
    invoke-virtual {v9, v0}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 908
    move-result v5

    .line 909
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 912
    move-result-object v6

    .line 913
    if-nez v5, :cond_396

    .line 915
    move-object/from16 v8, v50

    .line 917
    if-ne v6, v8, :cond_39e

    .line 919
    :cond_396
    new-instance v6, Lkotlin/collections/AbstractMap$$ExternalSyntheticLambda0;

    .line 921
    invoke-direct {v6, v0, v2}, Lkotlin/collections/AbstractMap$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;B)V

    .line 924
    invoke-virtual {v9, v6}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 927
    :cond_39e
    check-cast v6, Lkotlin/jvm/functions/Function1;

    .line 929
    invoke-static {v4, v6}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 932
    move-result-object v0

    .line 933
    sget-object v34, Landroidx/compose/ui/text/font/FontWeight;->Black:Landroidx/compose/ui/text/font/FontWeight;

    .line 935
    const/16 v4, 0x40

    .line 937
    invoke-static {v4}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 940
    move-result-wide v32

    .line 941
    const/16 v4, 0x3a

    .line 943
    invoke-static {v4}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 946
    move-result-wide v39

    .line 947
    const-wide v4, -0x3ff6666666666666L  # -3.2

    .line 952
    invoke-static {v4, v5}, Lkotlin/UnsignedKt;->getSp(D)J

    .line 955
    move-result-wide v36

    .line 956
    new-instance v29, Landroidx/compose/ui/text/TextStyle;

    .line 958
    const/16 v41, 0x0

    .line 960
    const v42, 0xfdff19

    .line 963
    const-wide/16 v30, 0x0

    .line 965
    const/16 v38, 0x0

    .line 967
    invoke-direct/range {v29 .. v42}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontFamily;JIJII)V

    .line 970
    const/16 v24, 0x0

    .line 972
    const v25, 0x1fff8

    .line 975
    const-wide/16 v6, 0x0

    .line 977
    const/4 v8, 0x0

    .line 978
    move-object/from16 v22, v9

    .line 980
    const/4 v9, 0x0

    .line 981
    const/4 v10, 0x0

    .line 982
    const-wide/16 v11, 0x0

    .line 984
    const/4 v13, 0x0

    .line 985
    const-wide/16 v14, 0x0

    .line 987
    const/16 v16, 0x0

    .line 989
    const/16 v17, 0x0

    .line 991
    const/16 v18, 0x0

    .line 993
    const/16 v19, 0x0

    .line 995
    const/16 v20, 0x0

    .line 997
    const/16 v23, 0x0

    .line 999
    move-object v4, v3

    .line 1000
    move-object v3, v0

    .line 1001
    move-object v0, v4

    .line 1002
    move v4, v2

    .line 1003
    move-object v2, v1

    .line 1004
    move v1, v4

    .line 1005
    move-wide/from16 v4, v26

    .line 1007
    move-object/from16 v21, v29

    .line 1009
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1012
    move-object/from16 v2, v43

    .line 1014
    iget v2, v2, Lcom/spotifry/music/data/TopSong;->plays:I

    .line 1016
    if-ne v2, v1, :cond_3fc

    .line 1018
    const-string v2, "play"

    .line 1020
    goto :goto_3fe

    .line 1021
    :cond_3fc
    const-string v2, "plays"

    .line 1023
    :goto_3fe
    new-instance v3, Landroidx/compose/foundation/layout/WithAlignmentLineElement;

    .line 1025
    invoke-direct {v3, v0}, Landroidx/compose/foundation/layout/WithAlignmentLineElement;-><init>(Landroidx/compose/ui/layout/HorizontalAlignmentLine;)V

    .line 1028
    invoke-static/range {v22 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 1031
    move-result-wide v4

    .line 1032
    const/high16 v24, 0xc00000

    .line 1034
    const v25, 0x1fff8

    .line 1037
    const-wide/16 v6, 0x0

    .line 1039
    const/4 v8, 0x0

    .line 1040
    const/4 v9, 0x0

    .line 1041
    const/4 v10, 0x0

    .line 1042
    const-wide/16 v11, 0x0

    .line 1044
    const/4 v13, 0x0

    .line 1045
    const-wide/16 v14, 0x0

    .line 1047
    const/16 v16, 0x0

    .line 1049
    const/16 v17, 0x0

    .line 1051
    const/16 v18, 0x0

    .line 1053
    const/16 v19, 0x0

    .line 1055
    const/16 v20, 0x0

    .line 1057
    const/16 v23, 0x0

    .line 1059
    move-object/from16 v21, v51

    .line 1061
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 1064
    move-object/from16 v9, v22

    .line 1066
    invoke-virtual {v9, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 1069
    goto :goto_430

    .line 1070
    :cond_42d
    invoke-virtual {v9}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 1073
    :goto_430
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 1075
    return-object v0
.end method
