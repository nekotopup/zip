# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:F

.field public final synthetic f$1:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$2:Lcom/spotifry/music/ui/spotifried/SpotifriedState;

.field public final synthetic f$3:Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;

.field public final synthetic f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

.field public final synthetic f$5:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$6:Landroidx/compose/runtime/MutableState;

.field public final synthetic f$7:Landroidx/compose/runtime/MutableState;


# direct methods
.method public synthetic constructor <init>(FLkotlin/jvm/functions/Function0;Lcom/spotifry/music/ui/spotifried/SpotifriedState;Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/MutableState;Landroidx/compose/runtime/MutableState;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$0:F

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$1:Lkotlin/jvm/functions/Function0;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$2:Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$3:Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;

    .line 12
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 14
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$5:Lkotlin/jvm/functions/Function0;

    .line 16
    iput-object p7, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$6:Landroidx/compose/runtime/MutableState;

    .line 18
    iput-object p8, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$7:Landroidx/compose/runtime/MutableState;

    .line 20
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 24

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$2:Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 5
    iget-object v6, v1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->cards:Ljava/util/List;

    .line 7
    move-object/from16 v13, p1

    .line 9
    check-cast v13, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p2

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    and-int/lit8 v3, v2, 0x3

    .line 21
    const/4 v4, 0x0

    .line 22
    const/4 v5, 0x1

    .line 23
    const/4 v7, 0x2

    .line 24
    if-eq v3, v7, :cond_1b

    .line 26
    move v3, v5

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    move v3, v4

    .line 29
    :goto_1c
    and-int/2addr v2, v5

    .line 30
    invoke-virtual {v13, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 33
    move-result v2

    .line 34
    if-eqz v2, :cond_152

    .line 36
    const/high16 v2, 0x3f800000  # 1.0f

    .line 38
    sget-object v14, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 40
    invoke-static {v14, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 43
    move-result-object v15

    .line 44
    const/16 v18, 0x0

    .line 46
    const/16 v20, 0x7

    .line 48
    const/16 v16, 0x0

    .line 50
    const/16 v17, 0x0

    .line 52
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$0:F

    .line 54
    move/from16 v19, v2

    .line 56
    invoke-static/range {v15 .. v20}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 59
    move-result-object v2

    .line 60
    sget-object v3, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 62
    sget-object v8, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 64
    invoke-static {v3, v8, v13, v4}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 67
    move-result-object v3

    .line 68
    iget-wide v8, v13, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 70
    invoke-static {v8, v9}, Ljava/lang/Long;->hashCode(J)I

    .line 73
    move-result v8

    .line 74
    invoke-virtual {v13}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 77
    move-result-object v9

    .line 78
    invoke-static {v13, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 81
    move-result-object v2

    .line 82
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 84
    invoke-virtual {v10}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 89
    invoke-virtual {v13}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 92
    iget-boolean v11, v13, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 94
    if-eqz v11, :cond_63

    .line 96
    invoke-virtual {v13, v10}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 99
    goto :goto_66

    .line 100
    :cond_63
    invoke-virtual {v13}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 103
    :goto_66
    sget-object v10, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 105
    invoke-static {v13, v3, v10}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 108
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 110
    invoke-static {v13, v9, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 113
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 115
    iget-boolean v9, v13, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 117
    if-nez v9, :cond_84

    .line 119
    invoke-virtual {v13}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 122
    move-result-object v9

    .line 123
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 126
    move-result-object v10

    .line 127
    invoke-static {v9, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 130
    move-result v9

    .line 131
    if-nez v9, :cond_87

    .line 133
    :cond_84
    invoke-static {v8, v13, v8, v3}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 136
    :cond_87
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 138
    invoke-static {v13, v2, v3}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 141
    const/16 v18, 0x0

    .line 143
    const/16 v19, 0xc

    .line 145
    const/high16 v15, 0x41000000  # 8.0f

    .line 147
    const/high16 v16, 0x40800000  # 4.0f

    .line 149
    const/16 v17, 0x0

    .line 151
    invoke-static/range {v14 .. v19}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 154
    move-result-object v8

    .line 155
    move v2, v15

    .line 156
    const v14, 0x180030

    .line 159
    const/16 v15, 0x3c

    .line 161
    move v3, v7

    .line 162
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$1:Lkotlin/jvm/functions/Function0;

    .line 164
    const/4 v9, 0x0

    .line 165
    const/4 v10, 0x0

    .line 166
    const/4 v11, 0x0

    .line 167
    sget-object v12, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt;->lambda$1523791782:Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 169
    invoke-static/range {v7 .. v15}, Landroidx/compose/material3/MenuKt;->IconButton(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/material3/IconButtonColors;Landroidx/compose/ui/graphics/Shape;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 172
    const/high16 v7, 0x41a00000  # 20.0f

    .line 174
    invoke-static {v7, v3}, Landroidx/compose/foundation/layout/OffsetKt;->PaddingValues-YgX7TsA$default(FI)Landroidx/compose/foundation/layout/PaddingValuesImpl;

    .line 177
    move-result-object v9

    .line 178
    new-instance v10, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 180
    new-instance v7, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 182
    const/4 v8, 0x3

    .line 183
    invoke-direct {v7, v8}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(B)V

    .line 186
    invoke-direct {v10, v2, v7}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLkotlin/jvm/functions/Function2;)V

    .line 189
    invoke-virtual {v13, v1}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 192
    move-result v2

    .line 193
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$3:Lcom/spotifry/music/ui/spotifried/SpotifriedViewModel;

    .line 195
    invoke-virtual {v13, v7}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 198
    move-result v8

    .line 199
    or-int/2addr v2, v8

    .line 200
    invoke-virtual {v13}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 203
    move-result-object v8

    .line 204
    sget-object v11, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 206
    if-nez v2, :cond_d1

    .line 208
    if-ne v8, v11, :cond_db

    .line 210
    :cond_d1
    new-instance v8, Lcom/spotifry/music/ui/SongMenuSheetKt$$ExternalSyntheticLambda29;

    .line 212
    const/16 v2, 0x1d

    .line 214
    invoke-direct {v8, v1, v7, v2}, Lcom/spotifry/music/ui/SongMenuSheetKt$$ExternalSyntheticLambda29;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 217
    invoke-virtual {v13, v8}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 220
    :cond_db
    move-object v15, v8

    .line 221
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 223
    const/16 v17, 0x6180

    .line 225
    const/16 v18, 0x1eb

    .line 227
    const/4 v7, 0x0

    .line 228
    const/4 v8, 0x0

    .line 229
    move-object v2, v11

    .line 230
    const/4 v11, 0x0

    .line 231
    const/4 v12, 0x0

    .line 232
    move-object/from16 v16, v13

    .line 234
    const/4 v13, 0x0

    .line 235
    const/4 v14, 0x0

    .line 236
    invoke-static/range {v7 .. v18}, Lkotlin/text/CharsKt;->LazyRow(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/lazy/LazyListState;Landroidx/compose/foundation/layout/PaddingValuesImpl;Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/foundation/gestures/DefaultFlingBehavior;ZLandroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 239
    move-object/from16 v13, v16

    .line 241
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 244
    move-result v7

    .line 245
    if-eqz v7, :cond_106

    .line 247
    const v0, 0x17dfd762

    .line 250
    invoke-virtual {v13, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 253
    iget-object v0, v1, Lcom/spotifry/music/ui/spotifried/SpotifriedState;->morePlays:Ljava/lang/Integer;

    .line 255
    invoke-static {v0, v13, v4}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt;->NotEnough(Ljava/lang/Integer;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 258
    invoke-virtual {v13, v4}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 261
    move v11, v5

    .line 262
    goto :goto_14e

    .line 263
    :cond_106
    const v7, 0x17dfdcc4

    .line 266
    invoke-virtual {v13, v7}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 269
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 271
    invoke-virtual {v7}, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;->getIntValue()I

    .line 274
    move-result v8

    .line 275
    invoke-virtual {v13, v7}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 278
    move-result v9

    .line 279
    invoke-virtual {v13}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 282
    move-result-object v10

    .line 283
    if-nez v9, :cond_11e

    .line 285
    if-ne v10, v2, :cond_126

    .line 287
    :cond_11e
    new-instance v10, Lcom/spotifry/music/ui/nowplaying/LyricsViewsKt$$ExternalSyntheticLambda11;

    .line 289
    invoke-direct {v10, v7, v3}, Lcom/spotifry/music/ui/nowplaying/LyricsViewsKt$$ExternalSyntheticLambda11;-><init>(Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;B)V

    .line 292
    invoke-virtual {v13, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 295
    :cond_126
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 297
    new-instance v2, Lcom/spotifry/music/ui/SongMenuSheetKt$$ExternalSyntheticLambda5;

    .line 299
    move v3, v5

    .line 300
    const/4 v5, 0x5

    .line 301
    move-object v7, v2

    .line 302
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$5:Lkotlin/jvm/functions/Function0;

    .line 304
    move v9, v3

    .line 305
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$6:Landroidx/compose/runtime/MutableState;

    .line 307
    iget-object v0, v0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$$ExternalSyntheticLambda3;->f$7:Landroidx/compose/runtime/MutableState;

    .line 309
    move v11, v9

    .line 310
    move v9, v4

    .line 311
    move-object v4, v0

    .line 312
    move-object v0, v7

    .line 313
    invoke-direct/range {v0 .. v5}, Lcom/spotifry/music/ui/SongMenuSheetKt$$ExternalSyntheticLambda5;-><init>(Ljava/lang/Object;Lkotlin/jvm/functions/Function0;Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 316
    const v1, 0x298253ec

    .line 319
    invoke-static {v1, v0, v13}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 322
    move-result-object v5

    .line 323
    const/16 v7, 0xc00

    .line 325
    move-object v2, v6

    .line 326
    move v3, v8

    .line 327
    move-object v4, v10

    .line 328
    move-object v6, v13

    .line 329
    invoke-static/range {v2 .. v7}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt;->StoryShell(Ljava/util/List;ILkotlin/jvm/functions/Function1;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 332
    invoke-virtual {v13, v9}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 335
    :goto_14e
    invoke-virtual {v13, v11}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 338
    goto :goto_155

    .line 339
    :cond_152
    invoke-virtual {v13}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 342
    :goto_155
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 344
    return-object v0
.end method
