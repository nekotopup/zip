# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$2:J


# direct methods
.method public synthetic constructor <init>(ZLcom/spotifry/music/data/spotifried/SpotifriedStats;J)V
    .registers 5

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$0:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 8
    iput-wide p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$2:J

    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 31

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v2, p2

    .line 9
    check-cast v2, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v3, p3

    .line 13
    check-cast v3, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v3

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v1, v3, 0x11

    .line 24
    const/16 v4, 0x10

    .line 26
    const/4 v5, 0x0

    .line 27
    const/4 v6, 0x1

    .line 28
    if-eq v1, v4, :cond_1f

    .line 30
    move v1, v6

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v1, v5

    .line 33
    :goto_20
    and-int/2addr v3, v6

    .line 34
    invoke-virtual {v2, v3, v1}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 37
    move-result v1

    .line 38
    if-eqz v1, :cond_149

    .line 40
    new-instance v1, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 42
    invoke-direct {v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 45
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 47
    iget-object v3, v3, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 49
    iget-object v3, v3, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->label:Ljava/lang/String;

    .line 51
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 54
    move-result v4

    .line 55
    const/4 v7, 0x4

    .line 56
    const-string v8, ","

    .line 58
    if-ne v4, v7, :cond_54

    .line 60
    move v4, v5

    .line 61
    :goto_3c
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 64
    move-result v7

    .line 65
    if-ge v4, v7, :cond_4f

    .line 67
    invoke-virtual {v3, v4}, Ljava/lang/String;->charAt(I)C

    .line 70
    move-result v7

    .line 71
    invoke-static {v7}, Ljava/lang/Character;->isDigit(C)Z

    .line 74
    move-result v7

    .line 75
    if-eqz v7, :cond_54

    .line 77
    add-int/lit8 v4, v4, 0x1

    .line 79
    goto :goto_3c

    .line 80
    :cond_4f
    invoke-virtual {v3, v8}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 83
    move-result-object v3

    .line 84
    goto :goto_92

    .line 85
    :cond_54
    const-string v4, "All time"

    .line 87
    invoke-virtual {v3, v4}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 90
    move-result v4

    .line 91
    if-eqz v4, :cond_5f

    .line 93
    const-string v3, "Everything,"

    .line 95
    goto :goto_92

    .line 96
    :cond_5f
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 99
    move-result v4

    .line 100
    if-lez v4, :cond_8c

    .line 102
    new-instance v4, Ljava/lang/StringBuilder;

    .line 104
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 107
    invoke-virtual {v3, v5}, Ljava/lang/String;->charAt(I)C

    .line 110
    move-result v7

    .line 111
    invoke-static {v7}, Ljava/lang/String;->valueOf(C)Ljava/lang/String;

    .line 114
    move-result-object v7

    .line 115
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 118
    sget-object v9, Ljava/util/Locale;->ROOT:Ljava/util/Locale;

    .line 120
    invoke-virtual {v7, v9}, Ljava/lang/String;->toLowerCase(Ljava/util/Locale;)Ljava/lang/String;

    .line 123
    move-result-object v7

    .line 124
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 127
    invoke-virtual {v4, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 130
    invoke-virtual {v3, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    .line 133
    move-result-object v3

    .line 134
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 137
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 140
    move-result-object v3

    .line 141
    :cond_8c
    const-string v4, "Your "

    .line 143
    invoke-static {v4, v3, v8}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 146
    move-result-object v3

    .line 147
    :goto_92
    invoke-virtual {v1, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 150
    const-string v3, "\nplayed\n"

    .line 152
    invoke-virtual {v1, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 155
    new-instance v7, Landroidx/compose/ui/text/SpanStyle;

    .line 157
    const/16 v25, 0x0

    .line 159
    const v26, 0xfffe

    .line 162
    iget-wide v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$2:J

    .line 164
    const-wide/16 v10, 0x0

    .line 166
    const/4 v12, 0x0

    .line 167
    const/4 v13, 0x0

    .line 168
    const/4 v14, 0x0

    .line 169
    const/4 v15, 0x0

    .line 170
    const/16 v16, 0x0

    .line 172
    const-wide/16 v17, 0x0

    .line 174
    const/16 v19, 0x0

    .line 176
    const/16 v20, 0x0

    .line 178
    const/16 v21, 0x0

    .line 180
    const-wide/16 v22, 0x0

    .line 182
    const/16 v24, 0x0

    .line 184
    invoke-direct/range {v7 .. v26}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 187
    invoke-virtual {v1, v7}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 190
    move-result v3

    .line 191
    :try_start_be
    const-string v4, "back."

    .line 193
    invoke-virtual {v1, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_c3
    .catchall {:try_start_be .. :try_end_c3} :catchall_144

    .line 196
    invoke-virtual {v1, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 199
    invoke-virtual {v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 202
    move-result-object v1

    .line 203
    sget-object v3, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 205
    iget-boolean v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda43;->f$0:Z

    .line 207
    const/16 v4, 0x36

    .line 209
    invoke-static {v3, v5, v0, v2, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 212
    move-result-object v5

    .line 213
    sget-object v19, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 215
    const/high16 v22, 0x6000000

    .line 217
    const v23, 0x3fffc

    .line 220
    move-object v8, v3

    .line 221
    move v7, v4

    .line 222
    move-object v3, v5

    .line 223
    const-wide/16 v4, 0x0

    .line 225
    move v9, v7

    .line 226
    const-wide/16 v6, 0x0

    .line 228
    move-object v11, v8

    .line 229
    const/4 v8, 0x0

    .line 230
    move v12, v9

    .line 231
    const-wide/16 v9, 0x0

    .line 233
    move-object v15, v11

    .line 234
    move v14, v12

    .line 235
    const-wide/16 v11, 0x0

    .line 237
    const/4 v13, 0x0

    .line 238
    move/from16 v17, v14

    .line 240
    const/4 v14, 0x0

    .line 241
    move-object/from16 v18, v15

    .line 243
    const/4 v15, 0x0

    .line 244
    const/16 v16, 0x0

    .line 246
    move/from16 v21, v17

    .line 248
    const/16 v17, 0x0

    .line 250
    move-object/from16 v24, v18

    .line 252
    const/16 v18, 0x0

    .line 254
    move/from16 v25, v21

    .line 256
    const/16 v21, 0x0

    .line 258
    move-object/from16 v20, v2

    .line 260
    move-object v2, v1

    .line 261
    move/from16 v1, v25

    .line 263
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 266
    move-object/from16 v2, v20

    .line 268
    const/4 v11, 0x0

    .line 269
    const/16 v12, 0xd

    .line 271
    const/4 v8, 0x0

    .line 272
    const/high16 v9, 0x41600000  # 14.0f

    .line 274
    const/4 v10, 0x0

    .line 275
    move-object/from16 v7, v24

    .line 277
    invoke-static/range {v7 .. v12}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 280
    move-result-object v3

    .line 281
    const/4 v13, 0x1

    .line 282
    invoke-static {v3, v13, v0, v2, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 285
    move-result-object v3

    .line 286
    invoke-static {v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 289
    move-result-wide v4

    .line 290
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 292
    const/high16 v24, 0xc00000

    .line 294
    const v25, 0x1fff8

    .line 297
    const-string v2, "Tap to start. This one is about you."

    .line 299
    const-wide/16 v6, 0x0

    .line 301
    const/4 v8, 0x0

    .line 302
    const/4 v9, 0x0

    .line 303
    const/4 v10, 0x0

    .line 304
    const-wide/16 v11, 0x0

    .line 306
    const/4 v13, 0x0

    .line 307
    const-wide/16 v14, 0x0

    .line 309
    const/16 v17, 0x0

    .line 311
    const/16 v18, 0x0

    .line 313
    const/16 v19, 0x0

    .line 315
    move-object/from16 v22, v20

    .line 317
    const/16 v20, 0x0

    .line 319
    const/16 v23, 0x6

    .line 321
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 324
    goto :goto_14e

    .line 325
    :catchall_144
    move-exception v0

    .line 326
    invoke-virtual {v1, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 329
    throw v0

    .line 330
    :cond_149
    move-object/from16 v20, v2

    .line 332
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 335
    :goto_14e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 337
    return-object v0
.end method
