# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Z

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/ObsessionDay;

.field public final synthetic f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$3:J

.field public final synthetic f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

.field public final synthetic f$5:J

.field public final synthetic f$6:J

.field public final synthetic f$7:Ljava/util/List;

.field public final synthetic f$8:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$9:F


# direct methods
.method public synthetic constructor <init>(ZLcom/spotifry/music/data/spotifried/ObsessionDay;Lcom/spotifry/music/data/spotifried/SpotifriedStats;JLcom/spotifry/music/ui/spotifried/CountUp;JJLjava/util/List;Landroidx/compose/animation/core/Animatable;F)V
    .registers 14

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$0:Z

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$1:Lcom/spotifry/music/data/spotifried/ObsessionDay;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 10
    iput-wide p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$3:J

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$5:J

    .line 16
    iput-wide p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$6:J

    .line 18
    iput-object p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$7:Ljava/util/List;

    .line 20
    iput-object p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$8:Landroidx/compose/animation/core/Animatable;

    .line 22
    iput p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$9:F

    .line 24
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 55

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    if-nez v3, :cond_23

    .line 26
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v3

    .line 30
    if-eqz v3, :cond_21

    .line 32
    const/4 v3, 0x4

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v3, 0x2

    .line 35
    :goto_22
    or-int/2addr v2, v3

    .line 36
    :cond_23
    and-int/lit8 v3, v2, 0x13

    .line 38
    const/16 v4, 0x12

    .line 40
    const/4 v6, 0x0

    .line 41
    const/4 v7, 0x1

    .line 42
    if-eq v3, v4, :cond_2d

    .line 44
    move v3, v7

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move v3, v6

    .line 47
    :goto_2e
    and-int/2addr v2, v7

    .line 48
    invoke-virtual {v5, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 51
    move-result v2

    .line 52
    if-eqz v2, :cond_1f6

    .line 54
    new-instance v2, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 56
    invoke-direct {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 59
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$1:Lcom/spotifry/music/data/spotifried/ObsessionDay;

    .line 61
    iget-object v4, v3, Lcom/spotifry/music/data/spotifried/ObsessionDay;->date:Ljava/time/LocalDate;

    .line 63
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$2:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 65
    iget-object v9, v8, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->start:Ljava/time/LocalDate;

    .line 67
    invoke-virtual {v9}, Ljava/time/LocalDate;->getYear()I

    .line 70
    move-result v9

    .line 71
    iget-object v8, v8, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->period:Lcom/spotifry/music/data/spotifried/WrappedPeriod;

    .line 73
    iget-object v8, v8, Lcom/spotifry/music/data/spotifried/WrappedPeriod;->to:Ljava/time/LocalDate;

    .line 75
    invoke-virtual {v8}, Ljava/time/LocalDate;->getYear()I

    .line 78
    move-result v8

    .line 79
    if-eq v9, v8, :cond_53

    .line 81
    const-string v8, "d MMMM yyyy"

    .line 83
    goto :goto_55

    .line 84
    :cond_53
    const-string v8, "d MMMM"

    .line 86
    :goto_55
    sget-object v9, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 88
    invoke-static {v8, v9}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    .line 91
    move-result-object v8

    .line 92
    invoke-virtual {v4, v8}, Ljava/time/LocalDate;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 95
    move-result-object v4

    .line 96
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 99
    new-instance v8, Ljava/lang/StringBuilder;

    .line 101
    const-string v9, "On "

    .line 103
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 106
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 109
    const-string v4, ", "

    .line 111
    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 114
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 117
    move-result-object v4

    .line 118
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 121
    new-instance v8, Landroidx/compose/ui/text/SpanStyle;

    .line 123
    const/16 v26, 0x0

    .line 125
    const v27, 0xfffe

    .line 128
    iget-wide v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$3:J

    .line 130
    const-wide/16 v11, 0x0

    .line 132
    const/4 v13, 0x0

    .line 133
    const/4 v14, 0x0

    .line 134
    const/4 v15, 0x0

    .line 135
    const/16 v16, 0x0

    .line 137
    const/16 v17, 0x0

    .line 139
    const-wide/16 v18, 0x0

    .line 141
    const/16 v20, 0x0

    .line 143
    const/16 v21, 0x0

    .line 145
    const/16 v22, 0x0

    .line 147
    const-wide/16 v23, 0x0

    .line 149
    const/16 v25, 0x0

    .line 151
    invoke-direct/range {v8 .. v27}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 154
    move-wide/from16 v24, v9

    .line 156
    invoke-virtual {v2, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pushStyle(Landroidx/compose/ui/text/SpanStyle;)I

    .line 159
    move-result v4

    .line 160
    :try_start_9f
    const-string v8, "something happened."

    .line 162
    invoke-virtual {v2, v8}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V
    :try_end_a4
    .catchall {:try_start_9f .. :try_end_a4} :catchall_1f1

    .line 165
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 168
    invoke-virtual {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 171
    move-result-object v2

    .line 172
    sget-object v4, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 174
    iget-boolean v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$0:Z

    .line 176
    const/16 v9, 0x36

    .line 178
    invoke-static {v4, v6, v8, v5, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 181
    move-result-object v6

    .line 182
    sget-object v19, Lcom/spotifry/music/ui/spotifried/CardsKt;->Headline:Landroidx/compose/ui/text/TextStyle;

    .line 184
    const/high16 v22, 0x6000000

    .line 186
    const v23, 0x3fffc

    .line 189
    move-object v10, v4

    .line 190
    move-object/from16 v20, v5

    .line 192
    const-wide/16 v4, 0x0

    .line 194
    move-object v11, v3

    .line 195
    move-object v3, v6

    .line 196
    const-wide/16 v6, 0x0

    .line 198
    move v13, v8

    .line 199
    const/4 v8, 0x0

    .line 200
    move-object v15, v10

    .line 201
    const-wide/16 v9, 0x0

    .line 203
    move-object/from16 v16, v11

    .line 205
    const-wide/16 v11, 0x0

    .line 207
    move/from16 v18, v13

    .line 209
    const/4 v13, 0x0

    .line 210
    const/4 v14, 0x0

    .line 211
    move-object/from16 v26, v15

    .line 213
    const/4 v15, 0x0

    .line 214
    move-object/from16 v27, v16

    .line 216
    const/16 v16, 0x0

    .line 218
    const/16 v17, 0x0

    .line 220
    move/from16 v29, v18

    .line 222
    const/16 v18, 0x0

    .line 224
    const/16 v21, 0x0

    .line 226
    move-object/from16 p1, v1

    .line 228
    move-object/from16 v1, v27

    .line 230
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 233
    move-object/from16 v5, v20

    .line 235
    new-instance v2, Landroidx/compose/ui/text/AnnotatedString$Builder;

    .line 237
    invoke-direct {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;-><init>()V

    .line 240
    iget-object v3, v1, Lcom/spotifry/music/data/spotifried/ObsessionDay;->song:Lcom/spotifry/music/data/db/SongEntity;

    .line 242
    iget-object v3, v3, Lcom/spotifry/music/data/db/SongEntity;->title:Ljava/lang/String;

    .line 244
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 247
    invoke-virtual {v3}, Ljava/lang/String;->length()I

    .line 250
    move-result v4

    .line 251
    const/16 v6, 0x3c

    .line 253
    if-le v4, v6, :cond_12c

    .line 255
    invoke-static {v6, v3}, Lkotlin/text/StringsKt;->take(ILjava/lang/String;)Ljava/lang/String;

    .line 258
    move-result-object v4

    .line 259
    const/16 v7, 0x20

    .line 261
    invoke-static {v4, v7}, Lkotlin/text/StringsKt;->substringBeforeLast$default(Ljava/lang/String;C)Ljava/lang/String;

    .line 264
    move-result-object v4

    .line 265
    const/4 v7, 0x3

    .line 266
    new-array v7, v7, [C

    .line 268
    fill-array-data v7, :array_1fe

    .line 271
    invoke-static {v4, v7}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/String;[C)Ljava/lang/String;

    .line 274
    move-result-object v4

    .line 275
    invoke-virtual {v4}, Ljava/lang/String;->length()I

    .line 278
    move-result v7

    .line 279
    const/16 v8, 0x28

    .line 281
    if-ge v7, v8, :cond_126

    .line 283
    invoke-static {v6, v3}, Lkotlin/text/StringsKt;->take(ILjava/lang/String;)Ljava/lang/String;

    .line 286
    move-result-object v3

    .line 287
    invoke-static {v3}, Lkotlin/text/StringsKt;->trimEnd(Ljava/lang/CharSequence;)Ljava/lang/CharSequence;

    .line 290
    move-result-object v3

    .line 291
    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 294
    move-result-object v4

    .line 295
    :cond_126
    const-string v3, "…"

    .line 297
    invoke-static {v4, v3}, Lcom/google/protobuf/FieldSet$$ExternalSyntheticOutline0;->m(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 300
    move-result-object v3

    .line 301
    :cond_12c
    new-instance v4, Ljava/lang/StringBuilder;

    .line 303
    const-string v6, "You played “"

    .line 305
    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 308
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 311
    const-string v3, "” "

    .line 313
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 316
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 319
    move-result-object v3

    .line 320
    invoke-virtual {v2, v3}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 323
    new-instance v31, Landroidx/compose/ui/text/SpanStyle;

    .line 325
    sget-object v36, Landroidx/compose/ui/text/font/FontWeight;->Bold:Landroidx/compose/ui/text/font/FontWeight;

    .line 327
    const/16 v49, 0x0

    .line 329
    const v50, 0xffba

    .line 332
    iget-wide v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$5:J

    .line 334
    const-wide/16 v34, 0x0

    .line 336
    const/16 v37, 0x0

    .line 338
    const/16 v38, 0x0

    .line 340
    const/16 v39, 0x0

    .line 342
    const-string v40, "tnum"

    .line 344
    const-wide/16 v41, 0x0

    .line 346
    const/16 v43, 0x0

    .line 348
    const/16 v44, 0x0

    .line 350
    const/16 v45, 0x0

    .line 352
    const-wide/16 v46, 0x0

    .line 354
    const/16 v48, 0x0

    .line 356
    move-wide/from16 v32, v3

    .line 358
    invoke-direct/range {v31 .. v50}, Landroidx/compose/ui/text/SpanStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontSynthesis;Landroidx/compose/ui/text/font/FontFamily;Ljava/lang/String;JLandroidx/compose/ui/text/style/BaselineShift;Landroidx/compose/ui/text/style/TextGeometricTransform;Landroidx/compose/ui/text/intl/LocaleList;JLandroidx/compose/ui/text/style/TextDecoration;Landroidx/compose/ui/graphics/Shadow;I)V

    .line 361
    move-object/from16 v3, v31

    .line 363
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$4:Lcom/spotifry/music/ui/spotifried/CountUp;

    .line 365
    iget-object v6, v4, Lcom/spotifry/music/ui/spotifried/CountUp;->text:Ljava/lang/String;

    .line 367
    iget v1, v1, Lcom/spotifry/music/data/spotifried/ObsessionDay;->plays:I

    .line 369
    const/4 v7, 0x1

    .line 370
    if-ne v1, v7, :cond_176

    .line 372
    const-string v1, "time"

    .line 374
    goto :goto_178

    .line 375
    :cond_176
    const-string v1, "times"

    .line 377
    :goto_178
    const-string v8, " "

    .line 379
    invoke-static {v6, v8, v1}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    .line 382
    move-result-object v1

    .line 383
    invoke-static {v2, v4, v3, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->countSpan(Landroidx/compose/ui/text/AnnotatedString$Builder;Lcom/spotifry/music/ui/spotifried/CountUp;Landroidx/compose/ui/text/SpanStyle;Ljava/lang/String;)V

    .line 386
    const-string v1, " in one day. We won\'t ask."

    .line 388
    invoke-virtual {v2, v1}, Landroidx/compose/ui/text/AnnotatedString$Builder;->append(Ljava/lang/String;)V

    .line 391
    invoke-virtual {v2}, Landroidx/compose/ui/text/AnnotatedString$Builder;->toAnnotatedString()Landroidx/compose/ui/text/AnnotatedString;

    .line 394
    move-result-object v2

    .line 395
    const/4 v12, 0x0

    .line 396
    const/16 v13, 0xd

    .line 398
    const/4 v9, 0x0

    .line 399
    const/high16 v10, 0x41600000  # 14.0f

    .line 401
    const/4 v11, 0x0

    .line 402
    move-object/from16 v8, v26

    .line 404
    invoke-static/range {v8 .. v13}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 407
    move-result-object v1

    .line 408
    move/from16 v3, v29

    .line 410
    const/16 v14, 0x36

    .line 412
    invoke-static {v1, v7, v3, v5, v14}, Lcom/spotifry/music/ui/spotifried/CardsKt;->rise(Landroidx/compose/ui/Modifier;IZLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/ui/Modifier;

    .line 415
    move-result-object v1

    .line 416
    move-object/from16 v20, v5

    .line 418
    invoke-static/range {v20 .. v20}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 421
    move-result-wide v4

    .line 422
    sget-object v19, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 424
    const/high16 v22, 0x6000000

    .line 426
    const v23, 0x3fff8

    .line 429
    const-wide/16 v6, 0x0

    .line 431
    const/4 v8, 0x0

    .line 432
    const-wide/16 v9, 0x0

    .line 434
    const-wide/16 v11, 0x0

    .line 436
    const/4 v13, 0x0

    .line 437
    const/4 v14, 0x0

    .line 438
    const/4 v15, 0x0

    .line 439
    const/16 v16, 0x0

    .line 441
    const/16 v17, 0x0

    .line 443
    const/16 v18, 0x0

    .line 445
    const/16 v21, 0x0

    .line 447
    move-object v3, v1

    .line 448
    invoke-static/range {v2 .. v23}, Landroidx/compose/material3/TextKt;->Text-Z58ophY(Landroidx/compose/ui/text/AnnotatedString;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontWeight;JJIZIILjava/util/Map;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 451
    move-object/from16 v5, v20

    .line 453
    const/high16 v1, 0x3f800000  # 1.0f

    .line 455
    move-object/from16 v2, p1

    .line 457
    invoke-static {v2, v1}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 460
    move-result-object v2

    .line 461
    invoke-static {v2, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 464
    move-result-object v2

    .line 465
    sget-object v3, Landroidx/compose/ui/Alignment$Companion;->BottomStart:Landroidx/compose/ui/BiasAlignment;

    .line 467
    new-instance v9, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;

    .line 469
    iget-wide v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$6:J

    .line 471
    iget-object v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$7:Ljava/util/List;

    .line 473
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$8:Landroidx/compose/animation/core/Animatable;

    .line 475
    iget v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda19;->f$9:F

    .line 477
    move-wide/from16 v16, v24

    .line 479
    move/from16 v10, v29

    .line 481
    invoke-direct/range {v9 .. v17}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda44;-><init>(ZJLjava/util/List;Landroidx/compose/animation/core/Animatable;FJ)V

    .line 484
    const v0, -0x1c3f66c4

    .line 487
    invoke-static {v0, v9, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 490
    move-result-object v4

    .line 491
    const/16 v6, 0xc30

    .line 493
    const/4 v7, 0x4

    .line 494
    invoke-static/range {v2 .. v7}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 497
    goto :goto_1fb

    .line 498
    :catchall_1f1
    move-exception v0

    .line 499
    invoke-virtual {v2, v4}, Landroidx/compose/ui/text/AnnotatedString$Builder;->pop(I)V

    .line 502
    throw v0

    .line 503
    :cond_1f6
    move-object/from16 v20, v5

    .line 505
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 508
    :goto_1fb
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 510
    return-object v0

    .line 511
    :array_1fe
    .array-data 2
        0x2cs
        0x20s
        0x2ds
    .end array-data
.end method
