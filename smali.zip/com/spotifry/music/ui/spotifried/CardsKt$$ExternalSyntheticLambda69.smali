# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:F

.field public final synthetic f$1:J

.field public final synthetic f$10:F

.field public final synthetic f$11:Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

.field public final synthetic f$2:Ljava/util/List;

.field public final synthetic f$3:Ljava/lang/Integer;

.field public final synthetic f$4:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$5:J

.field public final synthetic f$6:I

.field public final synthetic f$7:I

.field public final synthetic f$8:F

.field public final synthetic f$9:J


# direct methods
.method public synthetic constructor <init>(FJLjava/util/List;Ljava/lang/Integer;Landroidx/compose/animation/core/Animatable;JIIFJFLandroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$0:F

    .line 6
    iput-wide p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$1:J

    .line 8
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$2:Ljava/util/List;

    .line 10
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$3:Ljava/lang/Integer;

    .line 12
    iput-object p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$4:Landroidx/compose/animation/core/Animatable;

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$5:J

    .line 16
    iput p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$6:I

    .line 18
    iput p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$7:I

    .line 20
    iput p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$8:F

    .line 22
    iput-wide p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$9:J

    .line 24
    iput p14, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$10:F

    .line 26
    iput-object p15, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$11:Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 28
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 20

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$0:F

    .line 12
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 15
    move-result v11

    .line 16
    invoke-static {v11}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 19
    move-result v2

    .line 20
    int-to-long v2, v2

    .line 21
    const-wide v12, 0xffffffffL

    .line 26
    and-long v4, v2, v12

    .line 28
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 31
    move-result-wide v2

    .line 32
    const/16 v14, 0x20

    .line 34
    shr-long/2addr v2, v14

    .line 35
    long-to-int v2, v2

    .line 36
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 39
    move-result v2

    .line 40
    const/high16 v15, 0x3f800000  # 1.0f

    .line 42
    invoke-interface {v1, v15}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 45
    move-result v3

    .line 46
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 49
    move-result v2

    .line 50
    int-to-long v6, v2

    .line 51
    invoke-static {v3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 54
    move-result v2

    .line 55
    int-to-long v2, v2

    .line 56
    shl-long/2addr v6, v14

    .line 57
    and-long/2addr v2, v12

    .line 58
    or-long/2addr v6, v2

    .line 59
    const/4 v9, 0x0

    .line 60
    const/16 v10, 0x78

    .line 62
    iget-wide v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$1:J

    .line 64
    const/4 v8, 0x0

    .line 65
    invoke-static/range {v1 .. v10}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRect-n-J9OG0$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJFII)V

    .line 68
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$2:Ljava/util/List;

    .line 70
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 73
    move-result-object v10

    .line 74
    :goto_49
    invoke-interface {v10}, Ljava/util/Iterator;->hasNext()Z

    .line 77
    move-result v2

    .line 78
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$4:Landroidx/compose/animation/core/Animatable;

    .line 80
    iget v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$6:I

    .line 82
    iget v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$7:I

    .line 84
    iget-object v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$11:Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 86
    const/high16 v7, 0x40000000  # 2.0f

    .line 88
    const/high16 v8, 0x44480000  # 800.0f

    .line 90
    if-eqz v2, :cond_de

    .line 92
    invoke-interface {v10}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 95
    move-result-object v2

    .line 96
    check-cast v2, Lkotlin/Pair;

    .line 98
    iget-object v9, v2, Lkotlin/Pair;->first:Ljava/lang/Object;

    .line 100
    check-cast v9, Ljava/lang/Number;

    .line 102
    invoke-virtual {v9}, Ljava/lang/Number;->intValue()I

    .line 105
    move-result v9

    .line 106
    iget-object v2, v2, Lkotlin/Pair;->second:Ljava/lang/Object;

    .line 108
    check-cast v2, Ljava/lang/Number;

    .line 110
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 113
    move-result v2

    .line 114
    invoke-virtual {v3}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 117
    move-result-object v3

    .line 118
    check-cast v3, Ljava/lang/Number;

    .line 120
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 123
    move-result v3

    .line 124
    move-wide/from16 v16, v12

    .line 126
    sub-int v12, v9, v4

    .line 128
    int-to-float v12, v12

    .line 129
    const v13, 0x44b54000  # 1450.0f

    .line 132
    mul-float/2addr v12, v13

    .line 133
    sub-int v13, v5, v4

    .line 135
    int-to-float v13, v13

    .line 136
    div-float/2addr v12, v13

    .line 137
    const/high16 v13, 0x43960000  # 300.0f

    .line 139
    add-float/2addr v12, v13

    .line 140
    int-to-float v2, v2

    .line 141
    const/high16 v13, 0x41c80000  # 25.0f

    .line 143
    mul-float/2addr v13, v2

    .line 144
    add-float/2addr v13, v12

    .line 145
    invoke-static {v3, v13, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 148
    move-result v3

    .line 149
    const/high16 v8, 0x41400000  # 12.0f

    .line 151
    invoke-interface {v1, v8}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 154
    move-result v8

    .line 155
    sub-float v8, v11, v8

    .line 157
    iget v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$8:F

    .line 159
    invoke-interface {v1, v12}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 162
    move-result v12

    .line 163
    mul-float/2addr v12, v2

    .line 164
    sub-float/2addr v8, v12

    .line 165
    sub-float v2, v15, v3

    .line 167
    const/high16 v12, 0x42f00000  # 120.0f

    .line 169
    invoke-interface {v1, v12}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 172
    move-result v12

    .line 173
    mul-float/2addr v12, v2

    .line 174
    sub-float/2addr v8, v12

    .line 175
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$10:F

    .line 177
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 180
    move-result v2

    .line 181
    div-float/2addr v2, v7

    .line 182
    invoke-static {v6, v4, v5, v9}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 185
    move-result v4

    .line 186
    invoke-interface {v1, v4}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 189
    move-result v4

    .line 190
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 193
    move-result v4

    .line 194
    int-to-long v4, v4

    .line 195
    invoke-static {v8}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 198
    move-result v6

    .line 199
    int-to-long v6, v6

    .line 200
    shl-long/2addr v4, v14

    .line 201
    and-long v6, v6, v16

    .line 203
    or-long v5, v4, v6

    .line 205
    const v4, 0x3f666666  # 0.9f

    .line 208
    mul-float v7, v3, v4

    .line 210
    const/4 v8, 0x0

    .line 211
    const/16 v9, 0x70

    .line 213
    move v4, v2

    .line 214
    iget-wide v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$9:J

    .line 216
    invoke-static/range {v1 .. v9}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawCircle-VaOC9Bg$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JFJFLandroidx/compose/ui/graphics/drawscope/DrawStyle;I)V

    .line 219
    move-wide/from16 v12, v16

    .line 221
    goto/16 :goto_49

    .line 223
    :cond_de
    move-wide/from16 v16, v12

    .line 225
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$3:Ljava/lang/Integer;

    .line 227
    if-eqz v2, :cond_14e

    .line 229
    invoke-virtual {v3}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 232
    move-result-object v3

    .line 233
    check-cast v3, Ljava/lang/Number;

    .line 235
    invoke-virtual {v3}, Ljava/lang/Number;->floatValue()F

    .line 238
    move-result v3

    .line 239
    const v9, 0x45098000  # 2200.0f

    .line 242
    invoke-static {v3, v9, v8}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 245
    move-result v3

    .line 246
    const/high16 v8, 0x41d00000  # 26.0f

    .line 248
    invoke-interface {v1, v8}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 251
    move-result v8

    .line 252
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 255
    move-result v2

    .line 256
    invoke-static {v6, v4, v5, v2}, Lcom/spotifry/music/ui/spotifried/CardsKt;->Age$lambda$123$lambda$122$lambda$111$xOf(Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;III)F

    .line 259
    move-result v2

    .line 260
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 263
    move-result v2

    .line 264
    invoke-interface {v1, v15}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 267
    move-result v4

    .line 268
    sub-float/2addr v2, v4

    .line 269
    sub-float v4, v11, v8

    .line 271
    mul-float/2addr v4, v3

    .line 272
    sub-float/2addr v11, v4

    .line 273
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 276
    move-result v2

    .line 277
    int-to-long v2, v2

    .line 278
    invoke-static {v11}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 281
    move-result v5

    .line 282
    int-to-long v5, v5

    .line 283
    shl-long/2addr v2, v14

    .line 284
    and-long v5, v5, v16

    .line 286
    or-long/2addr v2, v5

    .line 287
    invoke-interface {v1, v7}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 290
    move-result v5

    .line 291
    invoke-static {v5}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 294
    move-result v5

    .line 295
    int-to-long v5, v5

    .line 296
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 299
    move-result v4

    .line 300
    int-to-long v7, v4

    .line 301
    shl-long/2addr v5, v14

    .line 302
    and-long v7, v7, v16

    .line 304
    or-long/2addr v5, v7

    .line 305
    invoke-interface {v1, v15}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 308
    move-result v4

    .line 309
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 312
    move-result v7

    .line 313
    int-to-long v7, v7

    .line 314
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 317
    move-result v4

    .line 318
    int-to-long v9, v4

    .line 319
    shl-long/2addr v7, v14

    .line 320
    and-long v9, v9, v16

    .line 322
    or-long/2addr v7, v9

    .line 323
    const/4 v10, 0x0

    .line 324
    const/16 v11, 0xf0

    .line 326
    iget-wide v12, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda69;->f$5:J

    .line 328
    const/4 v9, 0x0

    .line 329
    move-object v0, v1

    .line 330
    move-wide v3, v2

    .line 331
    move-wide v1, v12

    .line 332
    invoke-static/range {v0 .. v11}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 335
    :cond_14e
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 337
    return-object v0
.end method
