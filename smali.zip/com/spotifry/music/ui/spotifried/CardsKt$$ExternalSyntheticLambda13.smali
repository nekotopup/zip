# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$1:F

.field public final synthetic f$10:Z

.field public final synthetic f$11:J

.field public final synthetic f$12:Ljava/lang/String;

.field public final synthetic f$13:Ljava/lang/String;

.field public final synthetic f$14:Ljava/util/List;

.field public final synthetic f$15:Z

.field public final synthetic f$16:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

.field public final synthetic f$17:Landroidx/compose/runtime/State;

.field public final synthetic f$2:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$3:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$5:J

.field public final synthetic f$6:Lcom/spotifry/music/ui/listening/SunMotion;

.field public final synthetic f$7:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$8:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$9:Z


# direct methods
.method public synthetic constructor <init>(Lcom/spotifry/music/data/spotifried/SpotifriedStats;FLandroidx/compose/animation/core/Animatable;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;JLcom/spotifry/music/ui/listening/SunMotion;Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/core/Animatable;ZZJLjava/lang/String;Ljava/lang/String;Ljava/util/List;ZLandroidx/compose/runtime/ParcelableSnapshotMutableLongState;Landroidx/compose/runtime/State;)V
    .registers 21

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 6
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$1:F

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$3:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 12
    iput-object p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 14
    iput-wide p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$5:J

    .line 16
    iput-object p8, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$6:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 18
    iput-object p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$7:Lkotlin/jvm/functions/Function0;

    .line 20
    iput-object p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$8:Landroidx/compose/animation/core/Animatable;

    .line 22
    iput-boolean p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$9:Z

    .line 24
    iput-boolean p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$10:Z

    .line 26
    iput-wide p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$11:J

    .line 28
    iput-object p15, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$12:Ljava/lang/String;

    .line 30
    move-object/from16 p1, p16

    .line 32
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$13:Ljava/lang/String;

    .line 34
    move-object/from16 p1, p17

    .line 36
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$14:Ljava/util/List;

    .line 38
    move/from16 p1, p18

    .line 40
    iput-boolean p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$15:Z

    .line 42
    move-object/from16 p1, p19

    .line 44
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$16:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 46
    move-object/from16 p1, p20

    .line 48
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$17:Landroidx/compose/runtime/State;

    .line 50
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 45

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$0:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 5
    iget-object v2, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->hours:Ljava/util/List;

    .line 7
    move-object/from16 v1, p1

    .line 9
    check-cast v1, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 11
    move-object/from16 v12, p2

    .line 13
    check-cast v12, Landroidx/compose/runtime/ComposerImpl;

    .line 15
    move-object/from16 v3, p3

    .line 17
    check-cast v3, Ljava/lang/Integer;

    .line 19
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 22
    move-result v3

    .line 23
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    and-int/lit8 v4, v3, 0x6

    .line 28
    if-nez v4, :cond_27

    .line 30
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 33
    move-result v4

    .line 34
    if-eqz v4, :cond_25

    .line 36
    const/4 v4, 0x4

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    const/4 v4, 0x2

    .line 39
    :goto_26
    or-int/2addr v3, v4

    .line 40
    :cond_27
    and-int/lit8 v4, v3, 0x13

    .line 42
    const/16 v5, 0x12

    .line 44
    const/4 v6, 0x0

    .line 45
    const/4 v15, 0x1

    .line 46
    if-eq v4, v5, :cond_31

    .line 48
    move v4, v15

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v4, v6

    .line 51
    :goto_32
    and-int/2addr v3, v15

    .line 52
    invoke-virtual {v12, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v3

    .line 56
    if-eqz v3, :cond_207

    .line 58
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 61
    move-result v3

    .line 62
    const v4, 0x3fdc28f6  # 1.72f

    .line 65
    mul-float/2addr v3, v4

    .line 66
    invoke-virtual {v1}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 69
    move-result v1

    .line 70
    invoke-virtual {v12, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 73
    move-result v4

    .line 74
    iget v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$1:F

    .line 76
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 79
    move-result v7

    .line 80
    or-int/2addr v4, v7

    .line 81
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 84
    move-result-object v7

    .line 85
    sget-object v8, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 87
    if-nez v4, :cond_5a

    .line 89
    if-ne v7, v8, :cond_65

    .line 91
    :cond_5a
    invoke-static {v2, v5, v15}, Lcom/spotifry/music/ui/listening/SunKt;->sunReach(Ljava/util/List;FZ)F

    .line 94
    move-result v4

    .line 95
    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 98
    move-result-object v7

    .line 99
    invoke-virtual {v12, v7}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 102
    :cond_65
    check-cast v7, Ljava/lang/Number;

    .line 104
    invoke-virtual {v7}, Ljava/lang/Number;->floatValue()F

    .line 107
    move-result v4

    .line 108
    sget-object v7, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 110
    const/high16 v9, 0x3f800000  # 1.0f

    .line 112
    invoke-static {v7, v9}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 115
    move-result-object v10

    .line 116
    new-instance v11, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 118
    const/16 v13, 0xd

    .line 120
    invoke-direct {v11, v13}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 123
    invoke-static {v10, v11}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 126
    move-result-object v10

    .line 127
    new-instance v11, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 129
    const/16 v14, 0xe

    .line 131
    invoke-direct {v11, v14}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 134
    invoke-static {v10, v11}, Landroidx/compose/ui/draw/ClipKt;->drawWithContent(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 137
    move-result-object v10

    .line 138
    sget-object v11, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 140
    invoke-static {v11, v6}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 143
    move-result-object v14

    .line 144
    move-object/from16 p2, v7

    .line 146
    iget-wide v6, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 148
    invoke-static {v6, v7}, Ljava/lang/Long;->hashCode(J)I

    .line 151
    move-result v6

    .line 152
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 155
    move-result-object v7

    .line 156
    invoke-static {v12, v10}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 159
    move-result-object v10

    .line 160
    sget-object v16, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 162
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 165
    sget-object v13, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 167
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 170
    iget-boolean v9, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 172
    if-eqz v9, :cond_b1

    .line 174
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 177
    goto :goto_b4

    .line 178
    :cond_b1
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 181
    :goto_b4
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 183
    invoke-static {v12, v14, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 186
    sget-object v14, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 188
    invoke-static {v12, v7, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 191
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 193
    iget-boolean v15, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 195
    if-nez v15, :cond_d5

    .line 197
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 200
    move-result-object v15

    .line 201
    move-object/from16 v23, v2

    .line 203
    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 206
    move-result-object v2

    .line 207
    invoke-static {v15, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 210
    move-result v2

    .line 211
    if-nez v2, :cond_da

    .line 213
    goto :goto_d7

    .line 214
    :cond_d5
    move-object/from16 v23, v2

    .line 216
    :goto_d7
    invoke-static {v6, v12, v6, v7}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 219
    :cond_da
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 221
    invoke-static {v12, v10, v2}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 224
    sget-object v6, Landroidx/compose/foundation/layout/BoxScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/BoxScopeInstance;

    .line 226
    sget-object v10, Landroidx/compose/ui/Alignment$Companion;->BottomCenter:Landroidx/compose/ui/BiasAlignment;

    .line 228
    move-object/from16 v15, p2

    .line 230
    invoke-virtual {v6, v15, v10}, Landroidx/compose/foundation/layout/BoxScopeInstance;->align(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;)Landroidx/compose/ui/Modifier;

    .line 233
    move-result-object v6

    .line 234
    const/high16 v10, 0x40000000  # 2.0f

    .line 236
    div-float v10, v3, v10

    .line 238
    const/high16 v16, 0x42700000  # 60.0f

    .line 240
    sub-float v10, v10, v16

    .line 242
    move/from16 p2, v5

    .line 244
    const/4 v5, 0x0

    .line 245
    move-object/from16 v24, v15

    .line 247
    const/4 v15, 0x1

    .line 248
    invoke-static {v6, v5, v10, v15}, Landroidx/compose/foundation/layout/OffsetKt;->offset-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 251
    move-result-object v5

    .line 252
    invoke-static {v5, v3}, Landroidx/compose/foundation/layout/SizeKt;->requiredSize-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 255
    move-result-object v5

    .line 256
    iget-object v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 258
    invoke-virtual {v12, v6}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 261
    move-result v10

    .line 262
    invoke-virtual {v12, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 265
    move-result v15

    .line 266
    or-int/2addr v10, v15

    .line 267
    invoke-virtual {v12, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 270
    move-result v15

    .line 271
    or-int/2addr v10, v15

    .line 272
    invoke-virtual {v12, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 275
    move-result v15

    .line 276
    or-int/2addr v10, v15

    .line 277
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 280
    move-result-object v15

    .line 281
    move/from16 v18, v1

    .line 283
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$3:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 285
    if-nez v10, :cond_123

    .line 287
    if-eq v15, v8, :cond_123

    .line 289
    move-object/from16 v21, v1

    .line 291
    goto :goto_139

    .line 292
    :cond_123
    new-instance v16, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;

    .line 294
    iget-object v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$4:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 296
    move-object/from16 v21, v1

    .line 298
    move/from16 v19, v3

    .line 300
    move/from16 v20, v4

    .line 302
    move-object/from16 v17, v6

    .line 304
    move-object/from16 v22, v10

    .line 306
    invoke-direct/range {v16 .. v22}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda47;-><init>(Landroidx/compose/animation/core/Animatable;FFFLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;)V

    .line 309
    move-object/from16 v15, v16

    .line 311
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 314
    :goto_139
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 316
    invoke-static {v5, v15}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 319
    move-result-object v1

    .line 320
    const/4 v3, 0x0

    .line 321
    invoke-static {v11, v3}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 324
    move-result-object v3

    .line 325
    iget-wide v4, v12, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 327
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 330
    move-result v4

    .line 331
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 334
    move-result-object v5

    .line 335
    invoke-static {v12, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 338
    move-result-object v1

    .line 339
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 342
    iget-boolean v6, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 344
    if-eqz v6, :cond_15d

    .line 346
    invoke-virtual {v12, v13}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 349
    goto :goto_160

    .line 350
    :cond_15d
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 353
    :goto_160
    invoke-static {v12, v3, v9}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 356
    invoke-static {v12, v5, v14}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 359
    iget-boolean v3, v12, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 361
    if-nez v3, :cond_178

    .line 363
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 366
    move-result-object v3

    .line 367
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 370
    move-result-object v5

    .line 371
    invoke-static {v3, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 374
    move-result v3

    .line 375
    if-nez v3, :cond_17b

    .line 377
    :cond_178
    invoke-static {v4, v12, v4, v7}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 380
    :cond_17b
    invoke-static {v12, v1, v2}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 383
    move-object/from16 v15, v24

    .line 385
    const/high16 v1, 0x3f800000  # 1.0f

    .line 387
    invoke-static {v15, v1}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 390
    move-result-object v2

    .line 391
    iget-wide v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$5:J

    .line 393
    invoke-virtual {v12, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 396
    move-result v1

    .line 397
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 400
    move-result-object v5

    .line 401
    if-nez v1, :cond_194

    .line 403
    if-ne v5, v8, :cond_19e

    .line 405
    :cond_194
    new-instance v5, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 407
    const/16 v1, 0xd

    .line 409
    invoke-direct {v5, v3, v4, v1}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 412
    invoke-virtual {v12, v5}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 415
    :cond_19e
    check-cast v5, Lkotlin/jvm/functions/Function1;

    .line 417
    const/4 v1, 0x6

    .line 418
    invoke-static {v2, v5, v12, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 421
    const/high16 v2, 0x3f800000  # 1.0f

    .line 423
    invoke-static {v15, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxSize(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 426
    move-result-object v6

    .line 427
    const v13, 0x30006180

    .line 430
    const/16 v14, 0x1e0

    .line 432
    move-wide/from16 v29, v3

    .line 434
    const/4 v4, 0x0

    .line 435
    iget-object v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$6:Lcom/spotifry/music/ui/listening/SunMotion;

    .line 437
    const/4 v7, 0x0

    .line 438
    const/4 v8, 0x0

    .line 439
    const/4 v9, 0x0

    .line 440
    const/4 v10, 0x0

    .line 441
    const/4 v11, 0x0

    .line 442
    move/from16 v3, p2

    .line 444
    move-object/from16 v2, v23

    .line 446
    invoke-static/range {v2 .. v14}, Lcom/spotifry/music/ui/listening/SunKt;->Sun(Ljava/util/List;FZLcom/spotifry/music/ui/listening/SunMotion;Landroidx/compose/ui/Modifier;ZLjava/lang/Integer;Lkotlin/jvm/functions/Function1;Ljava/lang/String;ZLandroidx/compose/runtime/ComposerImpl;II)V

    .line 449
    const/4 v15, 0x1

    .line 450
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 453
    invoke-virtual {v12, v15}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 456
    new-instance v25, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;

    .line 458
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$7:Lkotlin/jvm/functions/Function0;

    .line 460
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$8:Landroidx/compose/animation/core/Animatable;

    .line 462
    iget-boolean v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$9:Z

    .line 464
    iget-boolean v5, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$10:Z

    .line 466
    iget-wide v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$11:J

    .line 468
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$12:Ljava/lang/String;

    .line 470
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$13:Ljava/lang/String;

    .line 472
    iget-object v10, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$14:Ljava/util/List;

    .line 474
    iget-boolean v11, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$15:Z

    .line 476
    iget-object v13, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$16:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 478
    iget-object v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda13;->f$17:Landroidx/compose/runtime/State;

    .line 480
    move-object/from16 v40, v0

    .line 482
    move-object/from16 v26, v2

    .line 484
    move-object/from16 v27, v3

    .line 486
    move/from16 v28, v4

    .line 488
    move/from16 v31, v5

    .line 490
    move-wide/from16 v32, v6

    .line 492
    move-object/from16 v34, v8

    .line 494
    move-object/from16 v35, v9

    .line 496
    move-object/from16 v36, v10

    .line 498
    move/from16 v37, v11

    .line 500
    move-object/from16 v39, v13

    .line 502
    move-object/from16 v38, v21

    .line 504
    invoke-direct/range {v25 .. v40}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;-><init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/core/Animatable;ZJZJLjava/lang/String;Ljava/lang/String;Ljava/util/List;ZLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;Landroidx/compose/runtime/State;)V

    .line 507
    move-object/from16 v0, v25

    .line 509
    const v2, 0x65bc7030

    .line 512
    invoke-static {v2, v0, v12}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 515
    move-result-object v0

    .line 516
    invoke-static {v0, v12, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt;->CardColumn(Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 519
    goto :goto_20a

    .line 520
    :cond_207
    invoke-virtual {v12}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 523
    :goto_20a
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 525
    return-object v0
.end method
