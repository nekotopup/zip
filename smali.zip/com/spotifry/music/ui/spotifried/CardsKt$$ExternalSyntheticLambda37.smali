# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:B

.field public final synthetic f$0:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$1:F


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Animatable;FB)V
    .registers 4

    .line 1
    iput-byte p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;->$r8$classId:B

    .line 3
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 5
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;->f$1:F

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;->$r8$classId:B

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    const/high16 v2, 0x3f800000  # 1.0f

    .line 7
    iget v3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;->f$1:F

    .line 9
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;->f$0:Landroidx/compose/animation/core/Animatable;

    .line 11
    check-cast p1, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;

    .line 13
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    packed-switch v0, :pswitch_data_a2

    .line 19
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 22
    move-result-object p0

    .line 23
    check-cast p0, Ljava/lang/Number;

    .line 25
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 28
    move-result p0

    .line 29
    const/high16 v0, 0x452f0000  # 2800.0f

    .line 31
    const/high16 v4, 0x44160000  # 600.0f

    .line 33
    invoke-static {p0, v0, v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->stepAt(FFF)F

    .line 36
    move-result p0

    .line 37
    invoke-virtual {p1, p0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 40
    sub-float/2addr v2, p0

    .line 41
    mul-float/2addr v2, v3

    .line 42
    invoke-virtual {p1, v2}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setTranslationY(F)V

    .line 45
    return-object v1

    .line 46
    :pswitch_2d  #0x3
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 49
    move-result-object v0

    .line 50
    check-cast v0, Ljava/lang/Number;

    .line 52
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 55
    move-result v0

    .line 56
    invoke-virtual {p1, v0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 59
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 62
    move-result-object p0

    .line 63
    check-cast p0, Ljava/lang/Number;

    .line 65
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 68
    move-result p0

    .line 69
    sub-float/2addr v2, p0

    .line 70
    mul-float/2addr v2, v3

    .line 71
    invoke-virtual {p1, v2}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setTranslationY(F)V

    .line 74
    return-object v1

    .line 75
    :pswitch_4a  #0x2
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 78
    move-result-object v0

    .line 79
    check-cast v0, Ljava/lang/Number;

    .line 81
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 84
    move-result v0

    .line 85
    invoke-virtual {p1, v0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 88
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 91
    move-result-object p0

    .line 92
    check-cast p0, Ljava/lang/Number;

    .line 94
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 97
    move-result p0

    .line 98
    sub-float/2addr v2, p0

    .line 99
    neg-float p0, v3

    .line 100
    mul-float/2addr v2, p0

    .line 101
    invoke-virtual {p1, v2}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setTranslationX(F)V

    .line 104
    return-object v1

    .line 105
    :pswitch_68  #0x1
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 108
    move-result-object v0

    .line 109
    check-cast v0, Ljava/lang/Number;

    .line 111
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 114
    move-result v0

    .line 115
    sub-float/2addr v2, v0

    .line 116
    mul-float/2addr v2, v3

    .line 117
    invoke-virtual {p1, v2}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setTranslationY(F)V

    .line 120
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 123
    move-result-object p0

    .line 124
    check-cast p0, Ljava/lang/Number;

    .line 126
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 129
    move-result p0

    .line 130
    invoke-virtual {p1, p0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 133
    return-object v1

    .line 134
    :pswitch_85  #0x0
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 137
    move-result-object v0

    .line 138
    check-cast v0, Ljava/lang/Number;

    .line 140
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 143
    move-result v0

    .line 144
    invoke-virtual {p1, v0}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setAlpha(F)V

    .line 147
    invoke-virtual {p0}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 150
    move-result-object p0

    .line 151
    check-cast p0, Ljava/lang/Number;

    .line 153
    invoke-virtual {p0}, Ljava/lang/Number;->floatValue()F

    .line 156
    move-result p0

    .line 157
    sub-float/2addr v2, p0

    .line 158
    mul-float/2addr v2, v3

    .line 159
    invoke-virtual {p1, v2}, Landroidx/compose/ui/graphics/ReusableGraphicsLayerScope;->setTranslationY(F)V

    .line 162
    return-object v1

    .line 163
    :pswitch_data_a2
    .packed-switch 0x0
        :pswitch_85  #00000000
        :pswitch_68  #00000001
        :pswitch_4a  #00000002
        :pswitch_2d  #00000003
    .end packed-switch
.end method
