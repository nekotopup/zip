# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:Lkotlin/jvm/functions/Function0;

.field public final synthetic f$1:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$10:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

.field public final synthetic f$11:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

.field public final synthetic f$12:Landroidx/compose/runtime/State;

.field public final synthetic f$2:Z

.field public final synthetic f$3:J

.field public final synthetic f$4:Z

.field public final synthetic f$5:J

.field public final synthetic f$6:Ljava/lang/String;

.field public final synthetic f$7:Ljava/lang/String;

.field public final synthetic f$8:Ljava/util/List;

.field public final synthetic f$9:Z


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/core/Animatable;ZJZJLjava/lang/String;Ljava/lang/String;Ljava/util/List;ZLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;Landroidx/compose/runtime/State;)V
    .registers 16

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$0:Lkotlin/jvm/functions/Function0;

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$1:Landroidx/compose/animation/core/Animatable;

    .line 8
    iput-boolean p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$2:Z

    .line 10
    iput-wide p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$3:J

    .line 12
    iput-boolean p6, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$4:Z

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$5:J

    .line 16
    iput-object p9, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$6:Ljava/lang/String;

    .line 18
    iput-object p10, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$7:Ljava/lang/String;

    .line 20
    iput-object p11, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$8:Ljava/util/List;

    .line 22
    iput-boolean p12, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$9:Z

    .line 24
    iput-object p13, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$10:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 26
    iput-object p14, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$11:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 28
    iput-object p15, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$12:Landroidx/compose/runtime/State;

    .line 30
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 35

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 7
    move-object/from16 v5, p2

    .line 9
    check-cast v5, Landroidx/compose/runtime/ComposerImpl;

    .line 11
    move-object/from16 v2, p3

    .line 13
    check-cast v2, Ljava/lang/Integer;

    .line 15
    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    .line 18
    move-result v2

    .line 19
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 22
    and-int/lit8 v3, v2, 0x6

    .line 24
    const/4 v12, 0x2

    .line 25
    if-nez v3, :cond_24

    .line 27
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v3

    .line 31
    if-eqz v3, :cond_22

    .line 33
    const/4 v3, 0x4

    .line 34
    goto :goto_23

    .line 35
    :cond_22
    move v3, v12

    .line 36
    :goto_23
    or-int/2addr v2, v3

    .line 37
    :cond_24
    and-int/lit8 v3, v2, 0x13

    .line 39
    const/16 v4, 0x12

    .line 41
    const/4 v8, 0x1

    .line 42
    const/4 v14, 0x0

    .line 43
    if-eq v3, v4, :cond_2e

    .line 45
    move v3, v8

    .line 46
    goto :goto_2f

    .line 47
    :cond_2e
    move v3, v14

    .line 48
    :goto_2f
    and-int/2addr v2, v8

    .line 49
    invoke-virtual {v5, v2, v3}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 52
    move-result v2

    .line 53
    if-eqz v2, :cond_216

    .line 55
    const/high16 v2, 0x3f800000  # 1.0f

    .line 57
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/ColumnScopeInstance;->weight$default(Landroidx/compose/foundation/layout/ColumnScopeInstance;F)Landroidx/compose/ui/Modifier;

    .line 60
    move-result-object v1

    .line 61
    invoke-static {v1, v2}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 64
    move-result-object v2

    .line 65
    new-instance v15, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;

    .line 67
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$6:Ljava/lang/String;

    .line 69
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$7:Ljava/lang/String;

    .line 71
    iget-object v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$8:Ljava/util/List;

    .line 73
    iget-boolean v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$9:Z

    .line 75
    iget-wide v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$3:J

    .line 77
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$10:Landroidx/compose/runtime/ParcelableSnapshotMutableFloatState;

    .line 79
    move-wide/from16 v20, v9

    .line 81
    iget-wide v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$5:J

    .line 83
    move-object/from16 v16, v1

    .line 85
    move-object/from16 v17, v3

    .line 87
    move-object/from16 v18, v4

    .line 89
    move/from16 v19, v6

    .line 91
    move-object/from16 v22, v7

    .line 93
    move-wide/from16 v23, v8

    .line 95
    invoke-direct/range {v15 .. v24}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda56;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/util/List;ZJLandroidx/compose/runtime/ParcelableSnapshotMutableFloatState;J)V

    .line 98
    const v1, -0x44df137a

    .line 101
    invoke-static {v1, v15, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 104
    move-result-object v4

    .line 105
    const/16 v6, 0xc00

    .line 107
    const/4 v7, 0x6

    .line 108
    const/4 v3, 0x0

    .line 109
    invoke-static/range {v2 .. v7}, Landroidx/compose/foundation/layout/OffsetKt;->BoxWithConstraints(Landroidx/compose/ui/Modifier;Landroidx/compose/ui/BiasAlignment;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 112
    sget-object v1, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 114
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 117
    move-result-object v1

    .line 118
    check-cast v1, Landroidx/compose/ui/unit/Density;

    .line 120
    const/high16 v2, 0x41900000  # 18.0f

    .line 122
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 125
    move-result v1

    .line 126
    sget-object v2, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 128
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 131
    move-result-object v3

    .line 132
    check-cast v3, Landroidx/compose/material3/ColorScheme;

    .line 134
    iget-wide v3, v3, Landroidx/compose/material3/ColorScheme;->background:J

    .line 136
    iget-object v6, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$0:Lkotlin/jvm/functions/Function0;

    .line 138
    sget-object v13, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 140
    sget-object v25, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 142
    if-eqz v6, :cond_1aa

    .line 144
    const v7, -0x179cea37

    .line 147
    invoke-virtual {v5, v7}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 150
    invoke-virtual {v5, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 153
    move-result v7

    .line 154
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 157
    move-result-object v8

    .line 158
    if-nez v7, :cond_a1

    .line 160
    if-ne v8, v13, :cond_ad

    .line 162
    :cond_a1
    new-instance v8, Lkotlin/text/Regex$$ExternalSyntheticLambda0;

    .line 164
    const/16 v7, 0x1c

    .line 166
    iget-object v9, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$11:Landroidx/compose/runtime/ParcelableSnapshotMutableLongState;

    .line 168
    invoke-direct {v8, v6, v9, v7}, Lkotlin/text/Regex$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;B)V

    .line 171
    invoke-virtual {v5, v8}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 174
    :cond_ad
    move-object/from16 v16, v8

    .line 176
    check-cast v16, Lkotlin/jvm/functions/Function0;

    .line 178
    const/16 v29, 0x0

    .line 180
    const/16 v30, 0xd

    .line 182
    const/16 v26, 0x0

    .line 184
    const/high16 v27, 0x41400000  # 12.0f

    .line 186
    const/16 v28, 0x0

    .line 188
    invoke-static/range {v25 .. v30}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 191
    move-result-object v6

    .line 192
    move-object/from16 v7, v25

    .line 194
    const/high16 v8, 0x42400000  # 48.0f

    .line 196
    const/high16 v9, 0x7fc00000  # Float.NaN

    .line 198
    invoke-static {v6, v8, v9}, Landroidx/compose/foundation/layout/SizeKt;->heightIn-VpY3zN4(Landroidx/compose/ui/Modifier;FF)Landroidx/compose/ui/Modifier;

    .line 201
    move-result-object v6

    .line 202
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$1:Landroidx/compose/animation/core/Animatable;

    .line 204
    invoke-virtual {v5, v8}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 207
    move-result v9

    .line 208
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 211
    move-result v10

    .line 212
    or-int/2addr v9, v10

    .line 213
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 216
    move-result-object v10

    .line 217
    const/4 v11, 0x3

    .line 218
    if-nez v9, :cond_dd

    .line 220
    if-ne v10, v13, :cond_e5

    .line 222
    :cond_dd
    new-instance v10, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;

    .line 224
    invoke-direct {v10, v8, v1, v11}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda37;-><init>(Landroidx/compose/animation/core/Animatable;FB)V

    .line 227
    invoke-virtual {v5, v10}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 230
    :cond_e5
    check-cast v10, Lkotlin/jvm/functions/Function1;

    .line 232
    invoke-static {v6, v10}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 235
    move-result-object v1

    .line 236
    invoke-virtual {v5, v3, v4}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 239
    move-result v6

    .line 240
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 243
    move-result-object v8

    .line 244
    const/16 v9, 0xf

    .line 246
    if-nez v6, :cond_f9

    .line 248
    if-ne v8, v13, :cond_101

    .line 250
    :cond_f9
    new-instance v8, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;

    .line 252
    invoke-direct {v8, v3, v4, v9}, Lcom/spotifry/music/MainActivityKt$$ExternalSyntheticLambda140;-><init>(JB)V

    .line 255
    invoke-virtual {v5, v8}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 258
    :cond_101
    check-cast v8, Lkotlin/jvm/functions/Function1;

    .line 260
    invoke-static {v1, v8}, Landroidx/compose/ui/draw/ClipKt;->drawBehind(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 263
    move-result-object v1

    .line 264
    iget-object v3, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$12:Landroidx/compose/runtime/State;

    .line 266
    invoke-interface {v3}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 269
    move-result-object v4

    .line 270
    check-cast v4, Ljava/lang/Boolean;

    .line 272
    invoke-virtual {v4}, Ljava/lang/Boolean;->booleanValue()Z

    .line 275
    move-result v4

    .line 276
    if-eqz v4, :cond_120

    .line 278
    const v4, -0x179c6a68

    .line 281
    invoke-virtual {v5, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 284
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 287
    move-object v4, v7

    .line 288
    goto :goto_13f

    .line 289
    :cond_120
    const v4, -0x179c6779

    .line 292
    invoke-virtual {v5, v4}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 295
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 298
    move-result-object v4

    .line 299
    if-ne v4, v13, :cond_134

    .line 301
    new-instance v4, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 303
    invoke-direct {v4, v9}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 306
    invoke-virtual {v5, v4}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 309
    :cond_134
    check-cast v4, Lkotlin/jvm/functions/Function1;

    .line 311
    invoke-static {v7, v4}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->clearAndSetSemantics(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 314
    move-result-object v25

    .line 315
    invoke-virtual {v5, v14}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 318
    move-object/from16 v4, v25

    .line 320
    :goto_13f
    invoke-interface {v1, v4}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 323
    move-result-object v1

    .line 324
    invoke-interface {v3}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 327
    move-result-object v3

    .line 328
    check-cast v3, Ljava/lang/Boolean;

    .line 330
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 333
    move-result v3

    .line 334
    iget-boolean v4, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$2:Z

    .line 336
    if-eqz v3, :cond_156

    .line 338
    if-nez v4, :cond_156

    .line 340
    const/16 v17, 0x1

    .line 342
    goto :goto_158

    .line 343
    :cond_156
    move/from16 v17, v14

    .line 345
    :goto_158
    sget-object v3, Landroidx/compose/material3/ButtonDefaults;->ContentPadding:Landroidx/compose/foundation/layout/PaddingValuesImpl;

    .line 347
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 350
    move-result-object v3

    .line 351
    check-cast v3, Landroidx/compose/material3/ColorScheme;

    .line 353
    iget-wide v8, v3, Landroidx/compose/material3/ColorScheme;->onPrimary:J

    .line 355
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 358
    move-result-object v2

    .line 359
    check-cast v2, Landroidx/compose/material3/ColorScheme;

    .line 361
    iget-wide v2, v2, Landroidx/compose/material3/ColorScheme;->onPrimary:J

    .line 363
    move v6, v11

    .line 364
    const/4 v11, 0x0

    .line 365
    move v10, v6

    .line 366
    move-object/from16 v25, v7

    .line 368
    move-wide/from16 v6, v20

    .line 370
    move v14, v4

    .line 371
    move v15, v10

    .line 372
    move-object v10, v5

    .line 373
    move-wide v4, v8

    .line 374
    move-wide v8, v2

    .line 375
    move-wide/from16 v2, v20

    .line 377
    invoke-static/range {v2 .. v11}, Landroidx/compose/material3/ButtonDefaults;->buttonColors-ro_MJ88(JJJJLandroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/material3/ButtonColors;

    .line 380
    move-result-object v6

    .line 381
    move-object v5, v10

    .line 382
    const/high16 v2, 0x41b00000  # 22.0f

    .line 384
    invoke-static {v2, v12}, Landroidx/compose/foundation/layout/OffsetKt;->PaddingValues-YgX7TsA$default(FI)Landroidx/compose/foundation/layout/PaddingValuesImpl;

    .line 387
    move-result-object v9

    .line 388
    new-instance v2, Lcom/spotifry/music/ui/home/PageScreenKt$$ExternalSyntheticLambda5;

    .line 390
    invoke-direct {v2, v15, v14}, Lcom/spotifry/music/ui/home/PageScreenKt$$ExternalSyntheticLambda5;-><init>(BZ)V

    .line 393
    const v3, 0x73c8f97b

    .line 396
    invoke-static {v3, v2, v5}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/ComposerImpl;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 399
    move-result-object v10

    .line 400
    const/high16 v12, 0x30c00000

    .line 402
    move-object v2, v13

    .line 403
    const/16 v13, 0x168

    .line 405
    move-object/from16 v22, v5

    .line 407
    const/4 v5, 0x0

    .line 408
    const/4 v7, 0x0

    .line 409
    const/4 v8, 0x0

    .line 410
    move-object v3, v1

    .line 411
    move-object v1, v2

    .line 412
    move-object/from16 v2, v16

    .line 414
    move/from16 v4, v17

    .line 416
    move-object/from16 v11, v22

    .line 418
    invoke-static/range {v2 .. v13}, Landroidx/compose/material3/MenuKt;->Button(Lkotlin/jvm/functions/Function0;Landroidx/compose/ui/Modifier;ZLandroidx/compose/ui/graphics/Shape;Landroidx/compose/material3/ButtonColors;Landroidx/compose/material3/ButtonElevation;Landroidx/compose/foundation/BorderStroke;Landroidx/compose/foundation/layout/PaddingValuesImpl;Lkotlin/jvm/functions/Function3;Landroidx/compose/runtime/ComposerImpl;II)V

    .line 421
    move-object v5, v11

    .line 422
    const/4 v2, 0x0

    .line 423
    :goto_1a6
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 426
    goto :goto_1b3

    .line 427
    :cond_1aa
    move-object v1, v13

    .line 428
    move v2, v14

    .line 429
    const v3, 0x210eae32

    .line 432
    invoke-virtual {v5, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 435
    goto :goto_1a6

    .line 436
    :goto_1b3
    iget-boolean v0, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda49;->f$4:Z

    .line 438
    if-eqz v0, :cond_20e

    .line 440
    const v0, -0x179c1621

    .line 443
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 446
    const/16 v29, 0x0

    .line 448
    const/16 v30, 0xd

    .line 450
    const/16 v26, 0x0

    .line 452
    const/high16 v27, 0x41000000  # 8.0f

    .line 454
    const/16 v28, 0x0

    .line 456
    invoke-static/range {v25 .. v30}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 459
    move-result-object v0

    .line 460
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 463
    move-result-object v2

    .line 464
    if-ne v2, v1, :cond_1db

    .line 466
    new-instance v2, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;

    .line 468
    const/16 v1, 0x10

    .line 470
    invoke-direct {v2, v1}, Lcom/spotifry/music/ui/listening/SunKt$$ExternalSyntheticLambda1;-><init>(B)V

    .line 473
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 476
    :cond_1db
    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 478
    const/4 v1, 0x0

    .line 479
    invoke-static {v0, v1, v2}, Landroidx/compose/ui/semantics/SemanticsModifierKt;->semantics(Landroidx/compose/ui/Modifier;ZLkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 482
    move-result-object v3

    .line 483
    sget-object v21, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 485
    move-object/from16 v22, v5

    .line 487
    move-wide/from16 v4, v23

    .line 489
    const/high16 v24, 0xc00000

    .line 491
    const v25, 0x1fff8

    .line 494
    const-string v2, "Couldn\'t make the pictures. Try again."

    .line 496
    const-wide/16 v6, 0x0

    .line 498
    const/4 v8, 0x0

    .line 499
    const/4 v9, 0x0

    .line 500
    const/4 v10, 0x0

    .line 501
    const-wide/16 v11, 0x0

    .line 503
    const/4 v13, 0x0

    .line 504
    const-wide/16 v14, 0x0

    .line 506
    const/16 v16, 0x0

    .line 508
    const/16 v17, 0x0

    .line 510
    const/16 v18, 0x0

    .line 512
    const/16 v19, 0x0

    .line 514
    const/16 v20, 0x0

    .line 516
    const/16 v23, 0x6

    .line 518
    invoke-static/range {v2 .. v25}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 521
    move-object/from16 v5, v22

    .line 523
    :goto_20a
    invoke-virtual {v5, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 526
    goto :goto_219

    .line 527
    :cond_20e
    const/4 v1, 0x0

    .line 528
    const v3, 0x210eae32

    .line 531
    invoke-virtual {v5, v3}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 534
    goto :goto_20a

    .line 535
    :cond_216
    invoke-virtual {v5}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 538
    :goto_219
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 540
    return-object v0
.end method
