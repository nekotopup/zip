# classes.dex

.class public final Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $c:Ljava/lang/Object;

.field public synthetic $end:F

.field public final synthetic $r8$classId:B

.field public label:Z


# direct methods
.method public constructor <init>(Landroidx/compose/ui/scrollcapture/ComposeScrollCaptureCallback;Lkotlin/coroutines/Continuation;)V
    .registers 4

    const/4 v0, 0x2

    iput-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$r8$classId:B

    .line 12
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$c:Ljava/lang/Object;

    invoke-direct {p0, v0, p2}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;FLkotlin/coroutines/Continuation;B)V
    .registers 5

    .line 1
    iput-byte p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$r8$classId:B

    .line 3
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$c:Ljava/lang/Object;

    .line 5
    iput p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$end:F

    .line 7
    const/4 p1, 0x2

    .line 8
    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 11
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 5

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$r8$classId:B

    .line 3
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$c:Ljava/lang/Object;

    .line 5
    packed-switch v0, :pswitch_data_2e

    .line 8
    new-instance p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;

    .line 10
    check-cast v1, Landroidx/compose/ui/scrollcapture/ComposeScrollCaptureCallback;

    .line 12
    invoke-direct {p0, v1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;-><init>(Landroidx/compose/ui/scrollcapture/ComposeScrollCaptureCallback;Lkotlin/coroutines/Continuation;)V

    .line 15
    check-cast p1, Ljava/lang/Number;

    .line 17
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 20
    move-result p1

    .line 21
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$end:F

    .line 23
    return-object p0

    .line 24
    :pswitch_17  #0x1
    new-instance p1, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;

    .line 26
    check-cast v1, Landroidx/compose/material3/SheetState;

    .line 28
    iget p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$end:F

    .line 30
    const/4 v0, 0x1

    .line 31
    invoke-direct {p1, v1, p0, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;-><init>(Ljava/lang/Object;FLkotlin/coroutines/Continuation;B)V

    .line 34
    return-object p1

    .line 35
    :pswitch_22  #0x0
    new-instance p1, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;

    .line 37
    check-cast v1, Landroidx/compose/animation/core/Animatable;

    .line 39
    iget p0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$end:F

    .line 41
    const/4 v0, 0x0

    .line 42
    invoke-direct {p1, v1, p0, p2, v0}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;-><init>(Ljava/lang/Object;FLkotlin/coroutines/Continuation;B)V

    .line 45
    return-object p1

    nop

    .line 47
    :pswitch_data_2e
    .packed-switch 0x0
        :pswitch_22  #00000000
        :pswitch_17  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$r8$classId:B

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    packed-switch v0, :pswitch_data_3c

    .line 8
    check-cast p1, Ljava/lang/Number;

    .line 10
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 13
    move-result p1

    .line 14
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 16
    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 19
    move-result-object p1

    .line 20
    invoke-virtual {p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 23
    move-result-object p0

    .line 24
    check-cast p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;

    .line 26
    invoke-virtual {p0, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 29
    move-result-object p0

    .line 30
    return-object p0

    .line 31
    :pswitch_1e  #0x1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 33
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 35
    invoke-virtual {p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 38
    move-result-object p0

    .line 39
    check-cast p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;

    .line 41
    invoke-virtual {p0, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 44
    move-result-object p0

    .line 45
    return-object p0

    .line 46
    :pswitch_2d  #0x0
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 48
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 50
    invoke-virtual {p0, p1, p2}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 53
    move-result-object p0

    .line 54
    check-cast p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;

    .line 56
    invoke-virtual {p0, v1}, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 59
    move-result-object p0

    .line 60
    return-object p0

    .line 61
    :pswitch_data_3c
    .packed-switch 0x0
        :pswitch_2d  #00000000
        :pswitch_1e  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 16

    .line 1
    iget-byte v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$r8$classId:B

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    const-string v2, "call to \'resume\' before \'invoke\' with coroutine"

    .line 7
    sget-object v3, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 9
    const/4 v4, 0x1

    .line 10
    iget-object v5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$c:Ljava/lang/Object;

    .line 12
    const/4 v6, 0x0

    .line 13
    packed-switch v0, :pswitch_data_104

    .line 16
    check-cast v5, Landroidx/compose/ui/scrollcapture/ComposeScrollCaptureCallback;

    .line 18
    iget-boolean v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->label:Z

    .line 20
    const-wide v7, 0xffffffffL

    .line 25
    if-eqz v0, :cond_25

    .line 27
    if-ne v0, v4, :cond_20

    .line 29
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 32
    goto :goto_5c

    .line 33
    :cond_20
    invoke-static {v2}, Lorg/jsoup/parser/CharacterReader$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 36
    move-object v3, v6

    .line 37
    goto :goto_6b

    .line 38
    :cond_25
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 41
    iget p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$end:F

    .line 43
    iget-object v0, v5, Landroidx/compose/ui/scrollcapture/ComposeScrollCaptureCallback;->node:Landroidx/compose/ui/semantics/SemanticsNode;

    .line 45
    iget-object v0, v0, Landroidx/compose/ui/semantics/SemanticsNode;->unmergedConfig:Landroidx/compose/ui/semantics/SemanticsConfiguration;

    .line 47
    sget-object v1, Landroidx/compose/ui/semantics/SemanticsActions;->ScrollByOffset:Landroidx/compose/ui/semantics/SemanticsPropertyKey;

    .line 49
    iget-object v0, v0, Landroidx/compose/ui/semantics/SemanticsConfiguration;->props:Landroidx/collection/MutableScatterMap;

    .line 51
    invoke-virtual {v0, v1}, Landroidx/collection/MutableScatterMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 54
    move-result-object v0

    .line 55
    if-eqz v0, :cond_39

    .line 57
    move-object v6, v0

    .line 58
    :cond_39
    check-cast v6, Lkotlin/jvm/functions/Function2;

    .line 60
    if-eqz v6, :cond_6c

    .line 62
    iget-object v0, v5, Landroidx/compose/ui/scrollcapture/ComposeScrollCaptureCallback;->node:Landroidx/compose/ui/semantics/SemanticsNode;

    .line 64
    iget-object v0, v0, Landroidx/compose/ui/semantics/SemanticsNode;->unmergedConfig:Landroidx/compose/ui/semantics/SemanticsConfiguration;

    .line 66
    sget-object v1, Landroidx/compose/ui/semantics/SemanticsProperties;->VerticalScrollAxisRange:Landroidx/compose/ui/semantics/SemanticsPropertyKey;

    .line 68
    invoke-virtual {v0, v1}, Landroidx/compose/ui/semantics/SemanticsConfiguration;->get(Landroidx/compose/ui/semantics/SemanticsPropertyKey;)Ljava/lang/Object;

    .line 71
    move-result-object v0

    .line 72
    check-cast v0, Landroidx/compose/ui/semantics/ScrollAxisRange;

    .line 74
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 77
    move-result p1

    .line 78
    int-to-long v0, p1

    .line 79
    and-long/2addr v0, v7

    .line 80
    new-instance p1, Landroidx/compose/ui/geometry/Offset;

    .line 82
    invoke-direct {p1, v0, v1}, Landroidx/compose/ui/geometry/Offset;-><init>(J)V

    .line 85
    iput-boolean v4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->label:Z

    .line 87
    invoke-interface {v6, p1, p0}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 90
    move-result-object p1

    .line 91
    if-eq p1, v3, :cond_6b

    .line 93
    :goto_5c
    check-cast p1, Landroidx/compose/ui/geometry/Offset;

    .line 95
    iget-wide p0, p1, Landroidx/compose/ui/geometry/Offset;->packedValue:J

    .line 97
    and-long/2addr p0, v7

    .line 98
    long-to-int p0, p0

    .line 99
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 102
    move-result p0

    .line 103
    new-instance v3, Ljava/lang/Float;

    .line 105
    invoke-direct {v3, p0}, Ljava/lang/Float;-><init>(F)V

    .line 108
    :cond_6b
    :goto_6b
    return-object v3

    .line 109
    :cond_6c
    const-string p0, "Required value was null."

    .line 111
    invoke-static {p0}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(Ljava/lang/String;)Lorg/jsoup/SerializationException;

    .line 114
    move-result-object p0

    .line 115
    throw p0

    .line 116
    :pswitch_73  #0x1
    iget-boolean v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->label:Z

    .line 118
    if-eqz v0, :cond_82

    .line 120
    if-ne v0, v4, :cond_7d

    .line 122
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 125
    goto :goto_cf

    .line 126
    :cond_7d
    invoke-static {v2}, Lorg/jsoup/parser/CharacterReader$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 129
    move-object v1, v6

    .line 130
    goto :goto_cf

    .line 131
    :cond_82
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 134
    check-cast v5, Landroidx/compose/material3/SheetState;

    .line 136
    iget p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$end:F

    .line 138
    iput-boolean v4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->label:Z

    .line 140
    iget-object v0, v5, Landroidx/compose/material3/SheetState;->anchoredDraggableState:Landroidx/compose/material3/internal/AnchoredDraggableState;

    .line 142
    iget-object v2, v0, Landroidx/compose/material3/internal/AnchoredDraggableState;->currentValue$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 144
    invoke-virtual {v2}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 147
    move-result-object v2

    .line 148
    invoke-virtual {v0}, Landroidx/compose/material3/internal/AnchoredDraggableState;->requireOffset()F

    .line 151
    move-result v4

    .line 152
    invoke-virtual {v0, v4, p1, v2}, Landroidx/compose/material3/internal/AnchoredDraggableState;->computeTarget(FFLjava/lang/Object;)Ljava/lang/Object;

    .line 155
    move-result-object v4

    .line 156
    iget-object v5, v0, Landroidx/compose/material3/internal/AnchoredDraggableState;->confirmValueChange:Lkotlin/jvm/functions/Function1;

    .line 158
    invoke-interface {v5, v4}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 161
    move-result-object v5

    .line 162
    check-cast v5, Ljava/lang/Boolean;

    .line 164
    invoke-virtual {v5}, Ljava/lang/Boolean;->booleanValue()Z

    .line 167
    move-result v5

    .line 168
    sget-object v7, Landroidx/compose/foundation/MutatePriority;->Default:Landroidx/compose/foundation/MutatePriority;

    .line 170
    if-eqz v5, :cond_ba

    .line 172
    new-instance v2, Landroidx/compose/material3/internal/AnchoredDraggableKt$animateTo$2;

    .line 174
    invoke-direct {v2, v0, p1, v6}, Landroidx/compose/material3/internal/AnchoredDraggableKt$animateTo$2;-><init>(Landroidx/compose/material3/internal/AnchoredDraggableState;FLkotlin/coroutines/Continuation;)V

    .line 177
    invoke-virtual {v0, v4, v7, v2, p0}, Landroidx/compose/material3/internal/AnchoredDraggableState;->anchoredDrag(Ljava/lang/Object;Landroidx/compose/foundation/MutatePriority;Lkotlin/jvm/functions/Function4;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 180
    move-result-object p0

    .line 181
    if-eq p0, v3, :cond_b7

    .line 183
    move-object p0, v1

    .line 184
    :cond_b7
    if-ne p0, v3, :cond_c8

    .line 186
    goto :goto_c9

    .line 187
    :cond_ba
    new-instance v4, Landroidx/compose/material3/internal/AnchoredDraggableKt$animateTo$2;

    .line 189
    invoke-direct {v4, v0, p1, v6}, Landroidx/compose/material3/internal/AnchoredDraggableKt$animateTo$2;-><init>(Landroidx/compose/material3/internal/AnchoredDraggableState;FLkotlin/coroutines/Continuation;)V

    .line 192
    invoke-virtual {v0, v2, v7, v4, p0}, Landroidx/compose/material3/internal/AnchoredDraggableState;->anchoredDrag(Ljava/lang/Object;Landroidx/compose/foundation/MutatePriority;Lkotlin/jvm/functions/Function4;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 195
    move-result-object p0

    .line 196
    if-eq p0, v3, :cond_c6

    .line 198
    move-object p0, v1

    .line 199
    :cond_c6
    if-eq p0, v3, :cond_c9

    .line 201
    :cond_c8
    move-object p0, v1

    .line 202
    :cond_c9
    :goto_c9
    if-eq p0, v3, :cond_cc

    .line 204
    move-object p0, v1

    .line 205
    :cond_cc
    if-ne p0, v3, :cond_cf

    .line 207
    move-object v1, v3

    .line 208
    :cond_cf
    :goto_cf
    return-object v1

    .line 209
    :pswitch_d0  #0x0
    iget v0, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->$end:F

    .line 211
    iget-boolean v7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->label:Z

    .line 213
    if-eqz v7, :cond_e1

    .line 215
    if-ne v7, v4, :cond_dc

    .line 217
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 220
    goto :goto_102

    .line 221
    :cond_dc
    invoke-static {v2}, Lorg/jsoup/parser/CharacterReader$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 224
    move-object v1, v6

    .line 225
    goto :goto_102

    .line 226
    :cond_e1
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 229
    move-object v8, v5

    .line 230
    check-cast v8, Landroidx/compose/animation/core/Animatable;

    .line 232
    new-instance v9, Ljava/lang/Float;

    .line 234
    invoke-direct {v9, v0}, Ljava/lang/Float;-><init>(F)V

    .line 237
    float-to-int p1, v0

    .line 238
    sget-object v0, Landroidx/compose/animation/core/EasingKt;->LinearEasing:Landroidx/collection/ArrayMap$$ExternalSyntheticBUOutline0;

    .line 240
    const/4 v2, 0x2

    .line 241
    const/4 v5, 0x0

    .line 242
    invoke-static {p1, v5, v0, v2}, Landroidx/compose/animation/core/ArcSplineKt;->tween$default(IILandroidx/compose/animation/core/Easing;I)Landroidx/compose/animation/core/TweenSpec;

    .line 245
    move-result-object v10

    .line 246
    iput-boolean v4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$clock$1$1;->label:Z

    .line 248
    const/4 v11, 0x0

    .line 249
    const/16 v13, 0xc

    .line 251
    move-object v12, p0

    .line 252
    invoke-static/range {v8 .. v13}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)Ljava/lang/Object;

    .line 255
    move-result-object p0

    .line 256
    if-ne p0, v3, :cond_102

    .line 258
    move-object v1, v3

    .line 259
    :cond_102
    :goto_102
    return-object v1

    nop

    .line 261
    :pswitch_data_104
    .packed-switch 0x0
        :pswitch_d0  #00000000
        :pswitch_73  #00000001
    .end packed-switch
.end method
