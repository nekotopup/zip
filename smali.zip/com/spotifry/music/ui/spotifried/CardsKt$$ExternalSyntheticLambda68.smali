# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic f$0:F

.field public final synthetic f$1:Ljava/util/List;

.field public final synthetic f$2:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$5:Ljava/lang/Integer;

.field public final synthetic f$6:J

.field public final synthetic f$7:J


# direct methods
.method public synthetic constructor <init>(FLjava/util/List;Landroidx/compose/animation/core/Animatable;Ljava/lang/Integer;JJ)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$0:F

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$1:Ljava/util/List;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$5:Ljava/lang/Integer;

    .line 12
    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$6:J

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$7:J

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 26

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    check-cast v1, Landroidx/compose/ui/graphics/drawscope/DrawScope;

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    iget v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$0:F

    .line 12
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 15
    move-result v13

    .line 16
    iget-object v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$1:Ljava/util/List;

    .line 18
    invoke-interface {v14}, Ljava/util/List;->size()I

    .line 21
    move-result v2

    .line 22
    const/4 v15, 0x0

    .line 23
    const/16 v16, 0x20

    .line 25
    const/4 v3, 0x1

    .line 26
    if-le v2, v3, :cond_31

    .line 28
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 31
    move-result-wide v4

    .line 32
    shr-long v4, v4, v16

    .line 34
    long-to-int v2, v4

    .line 35
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 38
    move-result v2

    .line 39
    sub-float/2addr v2, v13

    .line 40
    invoke-interface {v14}, Ljava/util/List;->size()I

    .line 43
    move-result v4

    .line 44
    sub-int/2addr v4, v3

    .line 45
    int-to-float v3, v4

    .line 46
    div-float/2addr v2, v3

    .line 47
    move/from16 v17, v2

    .line 49
    goto :goto_33

    .line 50
    :cond_31
    move/from16 v17, v15

    .line 52
    :goto_33
    const/high16 v2, 0x3fc00000  # 1.5f

    .line 54
    invoke-interface {v1, v2}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 57
    move-result v2

    .line 58
    sget v3, Lcom/spotifry/music/ui/spotifried/CardsKt;->WIDE_BAR:F

    .line 60
    invoke-interface {v1, v3}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 63
    move-result v3

    .line 64
    cmpl-float v3, v13, v3

    .line 66
    const/high16 v18, 0x40000000  # 2.0f

    .line 68
    const/high16 v4, 0x3f800000  # 1.0f

    .line 70
    if-ltz v3, :cond_4e

    .line 72
    const/high16 v3, 0x40400000  # 3.0f

    .line 74
    invoke-interface {v1, v3}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 77
    move-result v3

    .line 78
    goto :goto_58

    .line 79
    :cond_4e
    invoke-interface {v1, v4}, Landroidx/compose/ui/unit/Density;->toPx-0680j_4(F)F

    .line 82
    move-result v3

    .line 83
    div-float v5, v13, v18

    .line 85
    invoke-static {v3, v5}, Ljava/lang/Math;->min(FF)F

    .line 88
    move-result v3

    .line 89
    :goto_58
    invoke-interface {v14}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 92
    move-result-object v19

    .line 93
    const/4 v5, 0x0

    .line 94
    :goto_5d
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->hasNext()Z

    .line 97
    move-result v6

    .line 98
    if-eqz v6, :cond_123

    .line 100
    invoke-interface/range {v19 .. v19}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 103
    move-result-object v6

    .line 104
    add-int/lit8 v20, v5, 0x1

    .line 106
    if-ltz v5, :cond_11e

    .line 108
    check-cast v6, Ljava/lang/Number;

    .line 110
    invoke-virtual {v6}, Ljava/lang/Number;->floatValue()F

    .line 113
    move-result v6

    .line 114
    sget-object v7, Lcom/spotifry/music/ui/spotifried/CardsKt;->Ease:Landroidx/compose/animation/core/CubicBezierEasing;

    .line 116
    iget-object v8, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$2:Landroidx/compose/animation/core/Animatable;

    .line 118
    invoke-virtual {v8}, Landroidx/compose/animation/core/Animatable;->getValue()Ljava/lang/Object;

    .line 121
    move-result-object v8

    .line 122
    check-cast v8, Ljava/lang/Number;

    .line 124
    invoke-virtual {v8}, Ljava/lang/Number;->floatValue()F

    .line 127
    move-result v8

    .line 128
    const/high16 v9, 0x43c80000  # 400.0f

    .line 130
    sub-float/2addr v8, v9

    .line 131
    mul-int/lit16 v9, v5, 0x578

    .line 133
    invoke-interface {v14}, Ljava/util/List;->size()I

    .line 136
    move-result v10

    .line 137
    div-int/2addr v9, v10

    .line 138
    int-to-float v9, v9

    .line 139
    sub-float/2addr v8, v9

    .line 140
    const/high16 v9, 0x442f0000  # 700.0f

    .line 142
    div-float/2addr v8, v9

    .line 143
    invoke-static {v8, v15, v4}, Lkotlin/ResultKt;->coerceIn(FFF)F

    .line 146
    move-result v8

    .line 147
    invoke-virtual {v7, v8}, Landroidx/compose/animation/core/CubicBezierEasing;->transform(F)F

    .line 150
    move-result v7

    .line 151
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 154
    move-result-wide v8

    .line 155
    const-wide v10, 0xffffffffL

    .line 160
    and-long/2addr v8, v10

    .line 161
    long-to-int v8, v8

    .line 162
    invoke-static {v8}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 165
    move-result v8

    .line 166
    mul-float/2addr v8, v6

    .line 167
    invoke-static {v8, v2}, Ljava/lang/Math;->max(FF)F

    .line 170
    move-result v6

    .line 171
    mul-float/2addr v6, v7

    .line 172
    iget-object v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$5:Ljava/lang/Integer;

    .line 174
    if-eqz v7, :cond_b8

    .line 176
    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    .line 179
    move-result v7

    .line 180
    if-ne v5, v7, :cond_b8

    .line 182
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$6:J

    .line 184
    goto :goto_ba

    .line 185
    :cond_b8
    iget-wide v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;->f$7:J

    .line 187
    :goto_ba
    int-to-float v5, v5

    .line 188
    mul-float v5, v5, v17

    .line 190
    invoke-interface {v1}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->getSize-NH-jbRc()J

    .line 193
    move-result-wide v21

    .line 194
    move v9, v5

    .line 195
    and-long v4, v21, v10

    .line 197
    long-to-int v4, v4

    .line 198
    invoke-static {v4}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 201
    move-result v4

    .line 202
    sub-float/2addr v4, v6

    .line 203
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 206
    move-result v5

    .line 207
    move-wide/from16 v21, v10

    .line 209
    int-to-long v10, v5

    .line 210
    invoke-static {v4}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 213
    move-result v4

    .line 214
    int-to-long v4, v4

    .line 215
    shl-long v10, v10, v16

    .line 217
    and-long v4, v4, v21

    .line 219
    or-long/2addr v4, v10

    .line 220
    invoke-static {v13}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 223
    move-result v9

    .line 224
    int-to-long v9, v9

    .line 225
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 228
    move-result v11

    .line 229
    int-to-long v11, v11

    .line 230
    shl-long v9, v9, v16

    .line 232
    and-long v11, v11, v21

    .line 234
    or-long/2addr v9, v11

    .line 235
    div-float v6, v6, v18

    .line 237
    invoke-static {v3, v6}, Ljava/lang/Math;->min(FF)F

    .line 240
    move-result v6

    .line 241
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 244
    move-result v11

    .line 245
    int-to-long v11, v11

    .line 246
    invoke-static {v6}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 249
    move-result v6

    .line 250
    move-object/from16 v23, v1

    .line 252
    int-to-long v0, v6

    .line 253
    shl-long v11, v11, v16

    .line 255
    and-long v0, v0, v21

    .line 257
    or-long/2addr v11, v0

    .line 258
    move v0, v2

    .line 259
    move v1, v3

    .line 260
    move-wide v2, v7

    .line 261
    move-wide v6, v9

    .line 262
    move-wide v8, v11

    .line 263
    const/4 v11, 0x0

    .line 264
    const/16 v12, 0xf0

    .line 266
    const/4 v10, 0x0

    .line 267
    move/from16 v21, v1

    .line 269
    move-object/from16 v1, v23

    .line 271
    const/high16 v22, 0x3f800000  # 1.0f

    .line 273
    invoke-static/range {v1 .. v12}, Landroidx/compose/ui/graphics/drawscope/DrawScope;->drawRoundRect-u-Aw5IA$default(Landroidx/compose/ui/graphics/drawscope/DrawScope;JJJJLandroidx/compose/ui/graphics/drawscope/Stroke;FI)V

    .line 276
    move v2, v0

    .line 277
    move/from16 v5, v20

    .line 279
    move/from16 v3, v21

    .line 281
    move/from16 v4, v22

    .line 283
    move-object/from16 v0, p0

    .line 285
    goto/16 :goto_5d

    .line 287
    :cond_11e
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 290
    const/4 v0, 0x0

    .line 291
    throw v0

    .line 292
    :cond_123
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 294
    return-object v0
.end method
