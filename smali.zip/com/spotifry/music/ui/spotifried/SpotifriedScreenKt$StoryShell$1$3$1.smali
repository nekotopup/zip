# classes.dex

.class public final Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Landroidx/compose/ui/input/pointer/PointerInputEventHandler;


# instance fields
.field public final synthetic $cards:Ljava/util/List;

.field public final synthetic $index:I

.field public final synthetic $onIndex:Lkotlin/jvm/functions/Function1;


# direct methods
.method public constructor <init>(ILjava/util/List;Lkotlin/jvm/functions/Function1;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;->$index:I

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;->$cards:Ljava/util/List;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;->$onIndex:Lkotlin/jvm/functions/Function1;

    .line 10
    return-void
.end method


# virtual methods
.method public final invoke(Landroidx/compose/ui/input/pointer/PointerInputScope;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;
    .registers 6

    .line 1
    new-instance v0, Lcom/spotifry/music/player/PlayerController$$ExternalSyntheticLambda6;

    .line 3
    iget v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;->$index:I

    .line 5
    iget-object v2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;->$cards:Ljava/util/List;

    .line 7
    iget-object p0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$StoryShell$1$3$1;->$onIndex:Lkotlin/jvm/functions/Function1;

    .line 9
    invoke-direct {v0, p1, v1, v2, p0}, Lcom/spotifry/music/player/PlayerController$$ExternalSyntheticLambda6;-><init>(Landroidx/compose/ui/input/pointer/PointerInputScope;ILjava/util/List;Lkotlin/jvm/functions/Function1;)V

    .line 12
    const/4 p0, 0x7

    .line 13
    const/4 v1, 0x0

    .line 14
    invoke-static {p1, v1, v0, p2, p0}, Landroidx/compose/foundation/gestures/TapGestureDetectorKt;->detectTapGestures$default(Landroidx/compose/ui/input/pointer/PointerInputScope;Landroidx/compose/material3/SliderKt$sliderTapModifier$1$1;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)Ljava/lang/Object;

    .line 17
    move-result-object p0

    .line 18
    sget-object p1, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 20
    if-ne p0, p1, :cond_16

    .line 22
    return-object p0

    .line 23
    :cond_16
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 25
    return-object p0
.end method
