# classes.dex

.class public final Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function4;


# instance fields
.field public synthetic L$0:Landroid/app/Activity;

.field public synthetic L$1:Lcom/spotifry/music/data/spotifried/CardId;

.field public synthetic L$2:Lcom/spotifry/music/ui/spotifried/SpotifriedState;

.field public label:Z


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    check-cast p1, Landroid/app/Activity;

    .line 3
    check-cast p2, Lcom/spotifry/music/data/spotifried/CardId;

    .line 5
    check-cast p3, Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 7
    check-cast p4, Lkotlin/coroutines/Continuation;

    .line 9
    new-instance p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;

    .line 11
    const/4 v0, 0x4

    .line 12
    invoke-direct {p0, v0, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 15
    iput-object p1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$0:Landroid/app/Activity;

    .line 17
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$1:Lcom/spotifry/music/data/spotifried/CardId;

    .line 19
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$2:Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 21
    sget-object p1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 23
    invoke-virtual {p0, p1}, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 26
    move-result-object p0

    .line 27
    return-object p0
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    iget-object v3, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$0:Landroid/app/Activity;

    .line 3
    iget-object v2, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$1:Lcom/spotifry/music/data/spotifried/CardId;

    .line 5
    iget-object v1, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$2:Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 7
    iget-boolean v0, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->label:Z

    .line 9
    const/4 v4, 0x1

    .line 10
    const/4 v5, 0x0

    .line 11
    if-eqz v0, :cond_18

    .line 13
    if-ne v0, v4, :cond_12

    .line 15
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 18
    return-object p1

    .line 19
    :cond_12
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 21
    invoke-static {p0}, Lorg/jsoup/parser/CharacterReader$$ExternalSyntheticLambda2;->m$2(Ljava/lang/String;)V

    .line 24
    return-object v5

    .line 25
    :cond_18
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 28
    iput-object v5, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$0:Landroid/app/Activity;

    .line 30
    iput-object v5, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$1:Lcom/spotifry/music/data/spotifried/CardId;

    .line 32
    iput-object v5, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->L$2:Lcom/spotifry/music/ui/spotifried/SpotifriedState;

    .line 34
    iput-boolean v4, p0, Lcom/spotifry/music/ui/spotifried/SpotifriedScreenKt$SpotifriedScreen$1$1;->label:Z

    .line 36
    invoke-virtual {v3}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 39
    move-result-object p1

    .line 40
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 43
    check-cast p1, Lcom/spotifry/music/MusicApp;

    .line 45
    invoke-virtual {p1}, Lcom/spotifry/music/MusicApp;->getContainer()Lcom/spotifry/music/AppContainer;

    .line 48
    move-result-object p1

    .line 49
    sget-object v0, Lcom/spotifry/music/ui/theme/AccentChoice;->Companion:Lokio/ByteString$Companion;

    .line 51
    iget-object v4, p1, Lcom/spotifry/music/AppContainer;->settings:Lcom/spotifry/music/data/Settings;

    .line 53
    iget-object v6, v4, Lcom/spotifry/music/data/Settings;->accent:Lkotlinx/coroutines/flow/StateFlowImpl;

    .line 55
    invoke-virtual {v6}, Lkotlinx/coroutines/flow/StateFlowImpl;->getValue()Ljava/lang/Object;

    .line 58
    move-result-object v6

    .line 59
    check-cast v6, Ljava/lang/String;

    .line 61
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    invoke-static {v6}, Lokio/ByteString$Companion;->of(Ljava/lang/String;)Lcom/spotifry/music/ui/theme/AccentChoice;

    .line 67
    move-result-object v0

    .line 68
    iget-object v4, v4, Lcom/spotifry/music/data/Settings;->accentColor:Lkotlinx/coroutines/flow/StateFlowImpl;

    .line 70
    invoke-virtual {v4}, Lkotlinx/coroutines/flow/StateFlowImpl;->getValue()Ljava/lang/Object;

    .line 73
    move-result-object v4

    .line 74
    check-cast v4, Ljava/lang/Number;

    .line 76
    invoke-virtual {v4}, Ljava/lang/Number;->intValue()I

    .line 79
    move-result v4

    .line 80
    invoke-static {v0, v4, v3}, Lcom/spotifry/music/ui/theme/AccentKt;->accentFor(Lcom/spotifry/music/ui/theme/AccentChoice;ILandroid/content/Context;)Lcom/spotifry/music/ui/theme/Accent;

    .line 83
    move-result-object v4

    .line 84
    iget-object p1, p1, Lcom/spotifry/music/AppContainer;->imageClient:Lokhttp3/OkHttpClient;

    .line 86
    invoke-virtual {p1}, Lokhttp3/OkHttpClient;->newBuilder()Lokhttp3/OkHttpClient$Builder;

    .line 89
    move-result-object p1

    .line 90
    sget-object v0, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    .line 92
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 95
    const-wide/16 v6, 0x5

    .line 97
    invoke-static {v6, v7, v0}, Lokhttp3/internal/Util;->checkDuration(JLjava/util/concurrent/TimeUnit;)I

    .line 100
    move-result v0

    .line 101
    iput v0, p1, Lokhttp3/OkHttpClient$Builder;->callTimeout:I

    .line 103
    new-instance v0, Lokhttp3/OkHttpClient;

    .line 105
    invoke-direct {v0, p1}, Lokhttp3/OkHttpClient;-><init>(Lokhttp3/OkHttpClient$Builder;)V

    .line 108
    move-object p1, v5

    .line 109
    new-instance v5, Lcom/spotifry/music/ui/home/MoodViewModel$load$1;

    .line 111
    const/4 v6, 0x3

    .line 112
    invoke-direct {v5, v0, v3, p1, v6}, Lcom/spotifry/music/ui/home/MoodViewModel$load$1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;B)V

    .line 115
    sget-object p1, Lkotlinx/coroutines/Dispatchers;->Default:Lkotlinx/coroutines/scheduling/DefaultScheduler;

    .line 117
    sget-object p1, Lkotlinx/coroutines/internal/MainDispatcherLoader;->dispatcher:Lkotlinx/coroutines/android/HandlerContext;

    .line 119
    new-instance v0, Lcom/spotifry/music/ui/components/CoverKt$load$2;

    .line 121
    const/4 v6, 0x0

    .line 122
    const/16 v7, 0xf

    .line 124
    invoke-direct/range {v0 .. v7}, Lcom/spotifry/music/ui/components/CoverKt$load$2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;B)V

    .line 127
    invoke-static {p1, v0, p0}, Lkotlinx/coroutines/AwaitKt;->withContext(Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 130
    move-result-object p0

    .line 131
    sget-object p1, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 133
    if-ne p0, p1, :cond_87

    .line 135
    return-object p1

    .line 136
    :cond_87
    return-object p0
.end method
