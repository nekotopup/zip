# classes.dex

.class public final synthetic Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;
.super Ljava/lang/Object;
.source "r8-map-id-f961be8c7692cedd651fdec49c29219c5693ace9a566aa043f7557b0d3421b28"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic f$0:I

.field public final synthetic f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

.field public final synthetic f$2:Ljava/lang/Integer;

.field public final synthetic f$3:Landroidx/compose/animation/core/Animatable;

.field public final synthetic f$4:J

.field public final synthetic f$5:J


# direct methods
.method public synthetic constructor <init>(ILcom/spotifry/music/data/spotifried/SpotifriedStats;Ljava/lang/Integer;Landroidx/compose/animation/core/Animatable;JJ)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$0:I

    .line 6
    iput-object p2, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 8
    iput-object p3, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$2:Ljava/lang/Integer;

    .line 10
    iput-object p4, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 12
    iput-wide p5, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$4:J

    .line 14
    iput-wide p7, p0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$5:J

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 32

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$1:Lcom/spotifry/music/data/spotifried/SpotifriedStats;

    .line 5
    iget-object v2, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->daySeconds:Ljava/util/List;

    .line 7
    move-object/from16 v3, p1

    .line 9
    check-cast v3, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;

    .line 11
    move-object/from16 v4, p2

    .line 13
    check-cast v4, Landroidx/compose/runtime/ComposerImpl;

    .line 15
    move-object/from16 v5, p3

    .line 17
    check-cast v5, Ljava/lang/Integer;

    .line 19
    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    .line 22
    move-result v5

    .line 23
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 26
    and-int/lit8 v6, v5, 0x6

    .line 28
    if-nez v6, :cond_27

    .line 30
    invoke-virtual {v4, v3}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 33
    move-result v6

    .line 34
    if-eqz v6, :cond_25

    .line 36
    const/4 v6, 0x4

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    const/4 v6, 0x2

    .line 39
    :goto_26
    or-int/2addr v5, v6

    .line 40
    :cond_27
    and-int/lit8 v6, v5, 0x13

    .line 42
    const/16 v7, 0x12

    .line 44
    const/4 v8, 0x0

    .line 45
    const/4 v9, 0x1

    .line 46
    if-eq v6, v7, :cond_31

    .line 48
    move v6, v9

    .line 49
    goto :goto_32

    .line 50
    :cond_31
    move v6, v8

    .line 51
    :goto_32
    and-int/2addr v5, v9

    .line 52
    invoke-virtual {v4, v5, v6}, Landroidx/compose/runtime/ComposerImpl;->shouldExecute(IZ)Z

    .line 55
    move-result v5

    .line 56
    if-eqz v5, :cond_379

    .line 58
    invoke-virtual {v3}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxWidth-D9Ej5fM()F

    .line 61
    move-result v5

    .line 62
    const/high16 v6, 0x40200000  # 2.5f

    .line 64
    div-float v6, v5, v6

    .line 66
    float-to-int v6, v6

    .line 67
    iget v7, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$0:I

    .line 69
    invoke-static {v7, v6}, Ljava/lang/Math;->min(II)I

    .line 72
    move-result v6

    .line 73
    if-ge v6, v9, :cond_4b

    .line 75
    move v6, v9

    .line 76
    :cond_4b
    int-to-float v10, v6

    .line 77
    div-float/2addr v5, v10

    .line 78
    new-instance v10, Landroidx/compose/ui/unit/Dp;

    .line 80
    const/high16 v11, 0x3f800000  # 1.0f

    .line 82
    invoke-direct {v10, v11}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 85
    const v12, 0x3ecccccd  # 0.4f

    .line 88
    mul-float/2addr v12, v5

    .line 89
    new-instance v13, Landroidx/compose/ui/unit/Dp;

    .line 91
    invoke-direct {v13, v12}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 94
    invoke-virtual {v10, v13}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 97
    move-result v12

    .line 98
    if-lez v12, :cond_64

    .line 100
    move-object v10, v13

    .line 101
    :cond_64
    iget v10, v10, Landroidx/compose/ui/unit/Dp;->value:F

    .line 103
    sub-float/2addr v5, v10

    .line 104
    new-instance v10, Landroidx/compose/ui/unit/Dp;

    .line 106
    invoke-direct {v10, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 109
    sget v5, Lcom/spotifry/music/ui/spotifried/CardsKt;->WIDE_BAR:F

    .line 111
    new-instance v12, Landroidx/compose/ui/unit/Dp;

    .line 113
    invoke-direct {v12, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 116
    invoke-virtual {v10, v12}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 119
    move-result v5

    .line 120
    if-lez v5, :cond_7a

    .line 122
    move-object v10, v12

    .line 123
    :cond_7a
    invoke-virtual {v4, v2}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 126
    move-result v5

    .line 127
    invoke-virtual {v4, v6}, Landroidx/compose/runtime/ComposerImpl;->changed(I)Z

    .line 130
    move-result v12

    .line 131
    or-int/2addr v5, v12

    .line 132
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 135
    move-result-object v12

    .line 136
    sget-object v13, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 138
    if-nez v5, :cond_92

    .line 140
    if-eq v12, v13, :cond_92

    .line 142
    move-object v15, v10

    .line 143
    const/16 p1, 0x0

    .line 145
    goto/16 :goto_13e

    .line 147
    :cond_92
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 150
    move-result v5

    .line 151
    invoke-static {v5, v6}, Ljava/lang/Math;->min(II)I

    .line 154
    move-result v5

    .line 155
    new-array v6, v5, [J

    .line 157
    invoke-interface {v2}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 160
    move-result-object v12

    .line 161
    move v15, v8

    .line 162
    :goto_a1
    invoke-interface {v12}, Ljava/util/Iterator;->hasNext()Z

    .line 165
    move-result v16

    .line 166
    if-eqz v16, :cond_d4

    .line 168
    invoke-interface {v12}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 171
    move-result-object v16

    .line 172
    add-int/lit8 v17, v15, 0x1

    .line 174
    if-ltz v15, :cond_ce

    .line 176
    check-cast v16, Ljava/lang/Number;

    .line 178
    move/from16 p2, v15

    .line 180
    invoke-virtual/range {v16 .. v16}, Ljava/lang/Number;->longValue()J

    .line 183
    move-result-wide v14

    .line 184
    invoke-interface {v2}, Ljava/util/List;->size()I

    .line 187
    move-result v16

    .line 188
    mul-int v18, p2, v5

    .line 190
    div-int v18, v18, v16

    .line 192
    move-object/from16 p3, v12

    .line 194
    aget-wide v11, v6, v18

    .line 196
    invoke-static {v11, v12, v14, v15}, Ljava/lang/Math;->max(JJ)J

    .line 199
    move-result-wide v11

    .line 200
    aput-wide v11, v6, v18

    .line 202
    move-object/from16 v12, p3

    .line 204
    move/from16 v15, v17

    .line 206
    goto :goto_a1

    .line 207
    :cond_ce
    const/16 p1, 0x0

    .line 209
    invoke-static {}, Lkotlin/io/ByteStreamsKt;->throwIndexOverflow()V

    .line 212
    throw p1

    .line 213
    :cond_d4
    const/16 p1, 0x0

    .line 215
    if-nez v5, :cond_db

    .line 217
    move-object/from16 v2, p1

    .line 219
    goto :goto_f2

    .line 220
    :cond_db
    aget-wide v11, v6, v8

    .line 222
    add-int/lit8 v2, v5, -0x1

    .line 224
    if-gt v9, v2, :cond_ee

    .line 226
    move v14, v9

    .line 227
    :goto_e2
    aget-wide v15, v6, v14

    .line 229
    cmp-long v17, v11, v15

    .line 231
    if-gez v17, :cond_e9

    .line 233
    move-wide v11, v15

    .line 234
    :cond_e9
    if-eq v14, v2, :cond_ee

    .line 236
    add-int/lit8 v14, v14, 0x1

    .line 238
    goto :goto_e2

    .line 239
    :cond_ee
    invoke-static {v11, v12}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 242
    move-result-object v2

    .line 243
    :goto_f2
    if-eqz v2, :cond_127

    .line 245
    invoke-virtual {v2}, Ljava/lang/Number;->longValue()J

    .line 248
    move-result-wide v11

    .line 249
    const-wide/16 v14, 0x0

    .line 251
    cmp-long v11, v11, v14

    .line 253
    if-gtz v11, :cond_100

    .line 255
    move-object/from16 v2, p1

    .line 257
    :cond_100
    if-eqz v2, :cond_127

    .line 259
    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    .line 262
    move-result-wide v11

    .line 263
    new-instance v2, Ljava/util/ArrayList;

    .line 265
    invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 268
    move v14, v8

    .line 269
    :goto_10c
    move-object v15, v10

    .line 270
    if-ge v14, v5, :cond_125

    .line 272
    aget-wide v9, v6, v14

    .line 274
    long-to-float v9, v9

    .line 275
    long-to-float v10, v11

    .line 276
    div-float/2addr v9, v10

    .line 277
    float-to-double v9, v9

    .line 278
    invoke-static {v9, v10}, Ljava/lang/Math;->sqrt(D)D

    .line 281
    move-result-wide v9

    .line 282
    double-to-float v9, v9

    .line 283
    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 286
    move-result-object v9

    .line 287
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 290
    add-int/lit8 v14, v14, 0x1

    .line 292
    move-object v10, v15

    .line 293
    goto :goto_10c

    .line 294
    :cond_125
    move-object v12, v2

    .line 295
    goto :goto_13b

    .line 296
    :cond_127
    move-object v15, v10

    .line 297
    new-instance v2, Ljava/util/ArrayList;

    .line 299
    invoke-direct {v2, v5}, Ljava/util/ArrayList;-><init>(I)V

    .line 302
    move v6, v8

    .line 303
    :goto_12e
    if-ge v6, v5, :cond_125

    .line 305
    const/4 v9, 0x0

    .line 306
    invoke-static {v9}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 309
    move-result-object v9

    .line 310
    invoke-virtual {v2, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 313
    add-int/lit8 v6, v6, 0x1

    .line 315
    goto :goto_12e

    .line 316
    :goto_13b
    invoke-virtual {v4, v12}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 319
    :goto_13e
    check-cast v12, Ljava/util/List;

    .line 321
    iget-object v2, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$2:Ljava/lang/Integer;

    .line 323
    if-eqz v2, :cond_153

    .line 325
    invoke-virtual {v2}, Ljava/lang/Number;->intValue()I

    .line 328
    move-result v2

    .line 329
    invoke-interface {v12}, Ljava/util/List;->size()I

    .line 332
    move-result v5

    .line 333
    mul-int/2addr v5, v2

    .line 334
    div-int/2addr v5, v7

    .line 335
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 338
    move-result-object v14

    .line 339
    goto :goto_155

    .line 340
    :cond_153
    move-object/from16 v14, p1

    .line 342
    :goto_155
    invoke-virtual {v3}, Landroidx/compose/foundation/layout/BoxWithConstraintsScopeImpl;->getMaxHeight-D9Ej5fM()F

    .line 345
    move-result v2

    .line 346
    const/high16 v3, 0x41f00000  # 30.0f

    .line 348
    sub-float/2addr v2, v3

    .line 349
    new-instance v3, Landroidx/compose/ui/unit/Dp;

    .line 351
    invoke-direct {v3, v2}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 354
    new-instance v2, Landroidx/compose/ui/unit/Dp;

    .line 356
    const/high16 v5, 0x43870000  # 270.0f

    .line 358
    invoke-direct {v2, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 361
    invoke-virtual {v3, v2}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 364
    move-result v5

    .line 365
    if-lez v5, :cond_16f

    .line 367
    move-object v3, v2

    .line 368
    :cond_16f
    new-instance v2, Landroidx/compose/ui/unit/Dp;

    .line 370
    const/high16 v5, 0x42200000  # 40.0f

    .line 372
    invoke-direct {v2, v5}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 375
    invoke-virtual {v3, v2}, Landroidx/compose/ui/unit/Dp;->compareTo(Ljava/lang/Object;)I

    .line 378
    move-result v5

    .line 379
    if-gez v5, :cond_17d

    .line 381
    move-object v3, v2

    .line 382
    :cond_17d
    if-lez v7, :cond_370

    .line 384
    const v2, 0x1ae637cb

    .line 387
    invoke-virtual {v4, v2}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 390
    sget-object v2, Landroidx/compose/foundation/layout/OffsetKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 392
    sget-object v5, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 394
    invoke-static {v2, v5, v4, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 397
    move-result-object v2

    .line 398
    iget-wide v5, v4, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 400
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 403
    move-result v5

    .line 404
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 407
    move-result-object v6

    .line 408
    sget-object v9, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 410
    invoke-static {v4, v9}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 413
    move-result-object v10

    .line 414
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 416
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 419
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 421
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 424
    iget-boolean v8, v4, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 426
    if-eqz v8, :cond_1af

    .line 428
    invoke-virtual {v4, v11}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 431
    goto :goto_1b2

    .line 432
    :cond_1af
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 435
    :goto_1b2
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 437
    invoke-static {v4, v2, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 440
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 442
    invoke-static {v4, v6, v2}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 445
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 447
    move-object/from16 v16, v15

    .line 449
    iget-boolean v15, v4, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 451
    if-nez v15, :cond_1d5

    .line 453
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 456
    move-result-object v15

    .line 457
    move/from16 v25, v7

    .line 459
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 462
    move-result-object v7

    .line 463
    invoke-static {v15, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 466
    move-result v7

    .line 467
    if-nez v7, :cond_1da

    .line 469
    goto :goto_1d7

    .line 470
    :cond_1d5
    move/from16 v25, v7

    .line 472
    :goto_1d7
    invoke-static {v5, v4, v5, v6}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 475
    :cond_1da
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 477
    invoke-static {v4, v10, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 480
    const/high16 v7, 0x3f800000  # 1.0f

    .line 482
    invoke-static {v9, v7}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 485
    move-result-object v10

    .line 486
    iget v3, v3, Landroidx/compose/ui/unit/Dp;->value:F

    .line 488
    invoke-static {v10, v3}, Landroidx/compose/foundation/layout/SizeKt;->height-3ABfNKs(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 491
    move-result-object v3

    .line 492
    const-string v7, "day_bars"

    .line 494
    invoke-static {v3, v7}, Landroidx/compose/ui/platform/TestTagKt;->testTag(Landroidx/compose/ui/Modifier;Ljava/lang/String;)Landroidx/compose/ui/Modifier;

    .line 497
    move-result-object v3

    .line 498
    move-object/from16 v15, v16

    .line 500
    iget v7, v15, Landroidx/compose/ui/unit/Dp;->value:F

    .line 502
    invoke-virtual {v4, v7}, Landroidx/compose/runtime/ComposerImpl;->changed(F)Z

    .line 505
    move-result v10

    .line 506
    invoke-virtual {v4, v12}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 509
    move-result v15

    .line 510
    or-int/2addr v10, v15

    .line 511
    iget-object v15, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$3:Landroidx/compose/animation/core/Animatable;

    .line 513
    invoke-virtual {v4, v15}, Landroidx/compose/runtime/ComposerImpl;->changedInstance(Ljava/lang/Object;)Z

    .line 516
    move-result v16

    .line 517
    or-int v10, v10, v16

    .line 519
    invoke-virtual {v4, v14}, Landroidx/compose/runtime/ComposerImpl;->changed(Ljava/lang/Object;)Z

    .line 522
    move-result v16

    .line 523
    or-int v10, v10, v16

    .line 525
    move-object/from16 v20, v14

    .line 527
    move-object/from16 v19, v15

    .line 529
    iget-wide v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$4:J

    .line 531
    invoke-virtual {v4, v14, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 534
    move-result v16

    .line 535
    or-int v10, v10, v16

    .line 537
    move-wide/from16 v21, v14

    .line 539
    iget-wide v14, v0, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda45;->f$5:J

    .line 541
    invoke-virtual {v4, v14, v15}, Landroidx/compose/runtime/ComposerImpl;->changed(J)Z

    .line 544
    move-result v0

    .line 545
    or-int/2addr v10, v0

    .line 546
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 549
    move-result-object v0

    .line 550
    if-nez v10, :cond_229

    .line 552
    if-ne v0, v13, :cond_239

    .line 554
    :cond_229
    new-instance v16, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;

    .line 556
    move/from16 v17, v7

    .line 558
    move-object/from16 v18, v12

    .line 560
    move-wide/from16 v23, v14

    .line 562
    invoke-direct/range {v16 .. v24}, Lcom/spotifry/music/ui/spotifried/CardsKt$$ExternalSyntheticLambda68;-><init>(FLjava/util/List;Landroidx/compose/animation/core/Animatable;Ljava/lang/Integer;JJ)V

    .line 565
    move-object/from16 v0, v16

    .line 567
    invoke-virtual {v4, v0}, Landroidx/compose/runtime/ComposerImpl;->updateRememberedValue(Ljava/lang/Object;)V

    .line 570
    :cond_239
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 572
    const/4 v7, 0x0

    .line 573
    invoke-static {v3, v0, v4, v7}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/ComposerImpl;I)V

    .line 576
    const/high16 v0, 0x3f800000  # 1.0f

    .line 578
    invoke-static {v9, v0}, Landroidx/compose/foundation/layout/SizeKt;->fillMaxWidth(Landroidx/compose/ui/Modifier;F)Landroidx/compose/ui/Modifier;

    .line 581
    move-result-object v12

    .line 582
    const/16 v16, 0x0

    .line 584
    const/16 v17, 0xd

    .line 586
    const/4 v13, 0x0

    .line 587
    const/high16 v14, 0x41000000  # 8.0f

    .line 589
    const/4 v15, 0x0

    .line 590
    invoke-static/range {v12 .. v17}, Landroidx/compose/foundation/layout/OffsetKt;->padding-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 593
    move-result-object v0

    .line 594
    sget-object v3, Landroidx/compose/foundation/layout/OffsetKt;->SpaceBetween:Landroidx/compose/foundation/layout/Arrangement$Center$1;

    .line 596
    sget-object v9, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 598
    const/4 v10, 0x6

    .line 599
    invoke-static {v3, v9, v4, v10}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/ComposerImpl;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 602
    move-result-object v3

    .line 603
    iget-wide v9, v4, Landroidx/compose/runtime/ComposerImpl;->compositeKeyHashCode:J

    .line 605
    invoke-static {v9, v10}, Ljava/lang/Long;->hashCode(J)I

    .line 608
    move-result v9

    .line 609
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 612
    move-result-object v10

    .line 613
    invoke-static {v4, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/ComposerImpl;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 616
    move-result-object v0

    .line 617
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->startReusableNode()V

    .line 620
    iget-boolean v12, v4, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 622
    if-eqz v12, :cond_273

    .line 624
    invoke-virtual {v4, v11}, Landroidx/compose/runtime/ComposerImpl;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 627
    goto :goto_276

    .line 628
    :cond_273
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->useNode()V

    .line 631
    :goto_276
    invoke-static {v4, v3, v8}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 634
    invoke-static {v4, v10, v2}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 637
    iget-boolean v2, v4, Landroidx/compose/runtime/ComposerImpl;->inserting:Z

    .line 639
    if-nez v2, :cond_28e

    .line 641
    invoke-virtual {v4}, Landroidx/compose/runtime/ComposerImpl;->rememberedValue()Ljava/lang/Object;

    .line 644
    move-result-object v2

    .line 645
    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 648
    move-result-object v3

    .line 649
    invoke-static {v2, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 652
    move-result v2

    .line 653
    if-nez v2, :cond_291

    .line 655
    :cond_28e
    invoke-static {v9, v4, v9, v6}, Landroidx/work/OperationKt$$ExternalSyntheticLambda0;->m(ILandroidx/compose/runtime/ComposerImpl;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 658
    :cond_291
    invoke-static {v4, v0, v5}, Landroidx/compose/runtime/AnchoredGroupPath;->set-impl(Landroidx/compose/runtime/ComposerImpl;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 661
    const v0, -0x4182f2d3

    .line 664
    invoke-virtual {v4, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 667
    iget-object v0, v1, Lcom/spotifry/music/data/spotifried/SpotifriedStats;->start:Ljava/time/LocalDate;

    .line 669
    move/from16 v1, v25

    .line 671
    int-to-long v2, v1

    .line 672
    const-wide/16 v5, 0x1

    .line 674
    sub-long v5, v2, v5

    .line 676
    invoke-virtual {v0, v5, v6}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 679
    move-result-object v5

    .line 680
    invoke-virtual {v0}, Ljava/time/LocalDate;->getYear()I

    .line 683
    move-result v6

    .line 684
    invoke-virtual {v5}, Ljava/time/LocalDate;->getYear()I

    .line 687
    move-result v8

    .line 688
    if-eq v6, v8, :cond_2b4

    .line 690
    const-string v6, "MMM yyyy"

    .line 692
    goto :goto_2bd

    .line 693
    :cond_2b4
    const/16 v6, 0x3e

    .line 695
    if-le v1, v6, :cond_2bb

    .line 697
    const-string v6, "MMM"

    .line 699
    goto :goto_2bd

    .line 700
    :cond_2bb
    const-string v6, "d MMM"

    .line 702
    :goto_2bd
    sget-object v8, Lcom/spotifry/music/ui/spotifried/CardsKt;->english:Ljava/util/Locale;

    .line 704
    invoke-static {v6, v8}, Ljava/time/format/DateTimeFormatter;->ofPattern(Ljava/lang/String;Ljava/util/Locale;)Ljava/time/format/DateTimeFormatter;

    .line 707
    move-result-object v6

    .line 708
    const/16 v8, 0x1e

    .line 710
    if-ge v1, v8, :cond_2d0

    .line 712
    filled-new-array {v0, v5}, [Ljava/time/LocalDate;

    .line 715
    move-result-object v0

    .line 716
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 719
    move-result-object v0

    .line 720
    goto :goto_2df

    .line 721
    :cond_2d0
    const-wide/16 v8, 0x2

    .line 723
    div-long/2addr v2, v8

    .line 724
    invoke-virtual {v0, v2, v3}, Ljava/time/LocalDate;->plusDays(J)Ljava/time/LocalDate;

    .line 727
    move-result-object v1

    .line 728
    filled-new-array {v0, v1, v5}, [Ljava/time/LocalDate;

    .line 731
    move-result-object v0

    .line 732
    invoke-static {v0}, Lkotlin/io/ByteStreamsKt;->listOf([Ljava/lang/Object;)Ljava/util/List;

    .line 735
    move-result-object v0

    .line 736
    :goto_2df
    new-instance v1, Ljava/util/ArrayList;

    .line 738
    const/16 v2, 0xa

    .line 740
    invoke-static {v0, v2}, Lkotlin/collections/CollectionsKt__IterablesKt;->collectionSizeOrDefault(Ljava/lang/Iterable;I)I

    .line 743
    move-result v2

    .line 744
    invoke-direct {v1, v2}, Ljava/util/ArrayList;-><init>(I)V

    .line 747
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 750
    move-result-object v0

    .line 751
    :goto_2ee
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 754
    move-result v2

    .line 755
    if-eqz v2, :cond_302

    .line 757
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 760
    move-result-object v2

    .line 761
    check-cast v2, Ljava/time/LocalDate;

    .line 763
    invoke-virtual {v2, v6}, Ljava/time/LocalDate;->format(Ljava/time/format/DateTimeFormatter;)Ljava/lang/String;

    .line 766
    move-result-object v2

    .line 767
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 770
    goto :goto_2ee

    .line 771
    :cond_302
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->distinct(Ljava/util/ArrayList;)Ljava/util/List;

    .line 774
    move-result-object v0

    .line 775
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 778
    move-result-object v0

    .line 779
    :goto_30a
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 782
    move-result v1

    .line 783
    if-eqz v1, :cond_360

    .line 785
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 788
    move-result-object v1

    .line 789
    check-cast v1, Ljava/lang/String;

    .line 791
    move v2, v7

    .line 792
    invoke-static {v4}, Lcom/spotifry/music/ui/spotifried/CardsKt;->soft(Landroidx/compose/runtime/ComposerImpl;)J

    .line 795
    move-result-wide v6

    .line 796
    sget-object v8, Lcom/spotifry/music/ui/spotifried/CardsKt;->Sub:Landroidx/compose/ui/text/TextStyle;

    .line 798
    const/16 v3, 0xb

    .line 800
    invoke-static {v3}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 803
    move-result-wide v11

    .line 804
    const/16 v3, 0xe

    .line 806
    invoke-static {v3}, Lkotlin/UnsignedKt;->getSp(I)J

    .line 809
    move-result-wide v19

    .line 810
    const/16 v22, 0x0

    .line 812
    const v23, 0xfdfffd

    .line 815
    const-wide/16 v9, 0x0

    .line 817
    const/4 v13, 0x0

    .line 818
    const/4 v14, 0x0

    .line 819
    const/4 v15, 0x0

    .line 820
    const-wide/16 v16, 0x0

    .line 822
    const/16 v18, 0x0

    .line 824
    const/16 v21, 0x0

    .line 826
    invoke-static/range {v8 .. v23}, Landroidx/compose/ui/text/TextStyle;->copy-p1EtxEg$default(Landroidx/compose/ui/text/TextStyle;JJLandroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontFamily;JLandroidx/compose/ui/graphics/Shadow;JLandroidx/compose/ui/text/style/LineHeightStyle;II)Landroidx/compose/ui/text/TextStyle;

    .line 829
    move-result-object v23

    .line 830
    const/16 v26, 0x0

    .line 832
    const v27, 0x1fffa

    .line 835
    const/4 v5, 0x0

    .line 836
    const-wide/16 v8, 0x0

    .line 838
    const/4 v10, 0x0

    .line 839
    const/4 v11, 0x0

    .line 840
    const/4 v12, 0x0

    .line 841
    const-wide/16 v13, 0x0

    .line 843
    const/16 v18, 0x0

    .line 845
    const/16 v19, 0x0

    .line 847
    const/16 v20, 0x0

    .line 849
    const/16 v21, 0x0

    .line 851
    const/16 v22, 0x0

    .line 853
    const/16 v25, 0x0

    .line 855
    move-object/from16 v24, v4

    .line 857
    move-object v4, v1

    .line 858
    invoke-static/range {v4 .. v27}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJLandroidx/compose/ui/text/font/FontStyle;Landroidx/compose/ui/text/font/FontWeight;Landroidx/compose/ui/text/font/FontListFontFamily;JLandroidx/compose/ui/text/style/TextAlign;JIZIILkotlin/jvm/functions/Function1;Landroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/ComposerImpl;III)V

    .line 861
    move v7, v2

    .line 862
    move-object/from16 v4, v24

    .line 864
    goto :goto_30a

    .line 865
    :cond_360
    move-object v3, v4

    .line 866
    move v2, v7

    .line 867
    const/4 v1, 0x1

    .line 868
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 871
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 874
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 877
    :goto_36c
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/ComposerImpl;->end(Z)V

    .line 880
    goto :goto_37d

    .line 881
    :cond_370
    move-object v3, v4

    .line 882
    move v2, v8

    .line 883
    const v0, 0x40ace606

    .line 886
    invoke-virtual {v3, v0}, Landroidx/compose/runtime/ComposerImpl;->startReplaceGroup(I)V

    .line 889
    goto :goto_36c

    .line 890
    :cond_379
    move-object v3, v4

    .line 891
    invoke-virtual {v3}, Landroidx/compose/runtime/ComposerImpl;->skipToGroupEnd()V

    .line 894
    :goto_37d
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 896
    return-object v0
.end method
